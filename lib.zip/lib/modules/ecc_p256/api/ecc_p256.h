/**
 ****************************************************************************************
 *
 * @file ecc_p256.h
 *
 * @brief  ECC functions for P256
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 ****************************************************************************************
 */

#ifndef ECC_P256_H_
#define ECC_P256_H_


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "rwip_config.h"
#if (BLE_SECURE_CONNECTIONS==1)

#include <stdint.h>
#include <stdbool.h>


#define ECC_MULT_ALGO_TYPE 32
#define ECC_4BIT_WIN_OPT   0

#define ECC_PUBLICKEY_GENERATION 0x01
#define ECC_DHKEY_GENERATION     0x02
#define ECC_4BIT_TABLE_GENERATION_PT1 0x03
#define ECC_4BIT_TABLE_GENERATION_PT2 0x04
#define ECC_DHKEY_GENERATION_USING_TABLE 0x05


/*
 * STRUCTURE DEFINITIONS
 ****************************************************************************************
 */

/// Multiplication result message structure
struct ecc_result_ind
{
    uint8_t key_res_x[32];
    uint8_t key_res_y[32];
};


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */


/**
 ****************************************************************************************
 * @brief Generate a Secret Key compliant with ECC P256 algorithm
 *
 * @param[out] secret_key Private key - MSB First
 ****************************************************************************************
 */
void ecc_gen_new_secret_key(uint8_t* secret_key);

/**
 ****************************************************************************************
 * @brief Generate a new Public key pair using ECC P256 algorithm
 *
 * @param[in] secret_key Private key - MSB First
 * @param[in] blocking   Force to run full algorithm without continue mode
 ****************************************************************************************
 */
void ecc_gen_new_public_key(uint8_t* secret_key256, bool blocking);


/**
 ****************************************************************************************
 * @brief Generate a new DHKey using ECC P256 algorithm
 *
 * @param[in] secret_key Private key                  - MSB First
 * @param[in] pub_key_x  Peer public key x coordinate - LSB First
 * @param[in] pub_key_y  Peer public key y coordinate - LSB First
 * @param[in] blocking   Force to run full algorithm without continue mode
 ****************************************************************************************
 */
void ecc_generate_key256(const uint8_t* secret_key, const uint8_t* public_key_x,
                         const uint8_t* public_key_y, bool blocking);

/**
 ****************************************************************************************
 * @brief ECC P256 algorithm completed, retrieve calculated key pair
 *
 * @param[out] key_res_x  Public key x coordinate or DH Key - LSB First
 * @param[out] key_res_y  Public key y coordinate           - LSB First
 *
 * @note it also frees then allocated environment variable.
 ****************************************************************************************
 */
void ecc_point_multiplication_cmplt256(uint8_t* key_res_x, uint8_t* key_res_y);

/**
 ****************************************************************************************
 * @brief Outer function for ECC point multiplications, both multiply an ECC point by 8 bits.
 *
 * Used to continue ECC P256 algorithm.
 *
 * @return True if finished, false else
 ****************************************************************************************
 */
bool ecc_point_multiplication_uint8_256(void);

/**
 ****************************************************************************************
 * @brief Retrieve debug private and public keys
 *
 * @param[out] secret_key Private key             - MSB First
 * @param[out] pub_key_x  Public key x coordinate - LSB First
 * @param[out] pub_key_y  Public key y coordinate - LSB First
 ****************************************************************************************
 */
void ecc_get_debug_Keys(uint8_t*secret_key, uint8_t* pub_key_x, uint8_t* pub_key_y);
#endif


#endif /* ECC_P256_H_ */
