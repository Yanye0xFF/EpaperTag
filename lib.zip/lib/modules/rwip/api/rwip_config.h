/**
 ****************************************************************************************
 *
 * @file rwip_config.h
 *
 * @brief Configuration of the RW IP SW
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef RWIP_CONFIG_H_
#define RWIP_CONFIG_H_

/**
 ****************************************************************************************
 * @addtogroup ROOT
 * @{
 *
 *  Information about RW SW IP options and flags
 *
 *        BT_DUAL_MODE             BT/BLE Dual Mode
 *        BT_STD_MODE              BT Only
 *        BLE_STD_MODE             BLE Only
 *
 *        BT_EMB_PRESENT           BT controller exists
 *        BLE_EMB_PRESENT          BLE controller exists
 *        BLE_HOST_PRESENT         BLE host exists
 *
 * @name RW Stack Configuration
 * @{
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */

/******************************************************************************************/
/* --------------------------   GENERAL SETUP       --------------------------------------*/
/******************************************************************************************/

/// Flag indicating if stack is compiled in dual or single mode
#if defined(CFG_BT)
#define BLE_STD_MODE                     0
#if defined(CFG_BLE)
#define BT_DUAL_MODE                 1
#define BT_STD_MODE                  0
#else // CFG_BLE
#define BT_DUAL_MODE                 0
#define BT_STD_MODE                  1
#endif // CFG_BLE
#elif defined(CFG_BLE)
#define BT_DUAL_MODE                     0
#define BT_STD_MODE                      0
#define BLE_STD_MODE                     1
#endif // CFG_BT

/******************************************************************************************/
/* -------------------------   STACK PARTITIONING      -----------------------------------*/
/******************************************************************************************/

#if (BT_DUAL_MODE)
#define BT_EMB_PRESENT              1
#define BLE_EMB_PRESENT             1
#define HCI_PRESENT                 1
#define BLE_HOST_PRESENT            0
#define BLE_APP_PRESENT             0
#elif (BT_STD_MODE)
#define BT_EMB_PRESENT              1
#define BLE_EMB_PRESENT             0
#define HCI_PRESENT                 1
#define BLE_HOST_PRESENT            0
#define BLE_APP_PRESENT             0
#elif (BLE_STD_MODE)
#define BT_EMB_PRESENT              0
#define HCI_PRESENT                 1
#if defined(CFG_EMB)
#define BLE_EMB_PRESENT         1
#else
#define BLE_EMB_PRESENT         0
#endif //CFG_EMB
#if defined(CFG_HOST)
#define BLE_HOST_PRESENT        1
#else
#define BLE_HOST_PRESENT        0
#endif //CFG_HOST
#if defined(CFG_APP)
#define BLE_APP_PRESENT         1
#else
#define BLE_APP_PRESENT         0
#endif //CFG_APP
#endif // BT_DUAL_MODE / BT_STD_MODE / BLE_STD_MODE

#define EA_PRESENT                      (BT_EMB_PRESENT || BLE_EMB_PRESENT)

/******************************************************************************************/
/* -------------------------   INTERFACES DEFINITIONS      -------------------------------*/
/******************************************************************************************/

/// Application Host Interface
#if defined(CFG_AHITL)
#define AHI_TL_SUPPORT       1
#else // defined(CFG_AHITL)
#define AHI_TL_SUPPORT       0
#endif // defined(CFG_AHITL)


/// Host Controller Interface Support (defines if HCI parser is present or not)
#if defined(CFG_HCITL)
#define HCI_TL_SUPPORT      1
#else //defined(CFG_HCITL)
#define HCI_TL_SUPPORT      0
#endif //defined(CFG_HCITL)


#if BLE_HOST_PRESENT

#ifdef CFG_APP_MESH
#define H4TL_SUPPORT      (HCI_TL_SUPPORT)
#else

#if BLE_EMB_PRESENT
#define H4TL_SUPPORT      (AHI_TL_SUPPORT)
#else // !BLE_EMB_PRESENT
#define H4TL_SUPPORT      ((AHI_TL_SUPPORT) + (HCI_TL_SUPPORT))
#endif // BLE_EMB_PRESENT
#endif  // CFG_APP_MESH

#else // !BLE_HOST_PRESENT
#define H4TL_SUPPORT      (HCI_TL_SUPPORT)
#endif // BLE_HOST_PRESENT

enum ble_working_mode_t
{
    SPLIT_LL_PARTITION,
    FULLY_HOSTED_PARTITION,
#if AHI_TL_SUPPORT
    FULLY_EMBEDDED_PARTITION,
#endif
};


/******************************************************************************************/
/* --------------------------   BLE COMMON DEFINITIONS      ------------------------------*/
/******************************************************************************************/
/// Kernel Heap memory sized reserved for allocate dynamically connection environment
#define KE_HEAP_MEM_RESERVED        (4)

#if defined(CFG_BLE)
/// Application role definitions
#define BLE_BROADCASTER   (defined(CFG_BROADCASTER) || defined(CFG_ALLROLES))
#define BLE_OBSERVER      (defined(CFG_OBSERVER)    || defined(CFG_ALLROLES))
#define BLE_PERIPHERAL    (defined(CFG_PERIPHERAL)  || defined(CFG_ALLROLES))
#define BLE_CENTRAL       (defined(CFG_CENTRAL)     || defined(CFG_ALLROLES))

#if (!BLE_BROADCASTER) && (!BLE_OBSERVER) && (!BLE_PERIPHERAL) && (!BLE_CENTRAL)
#error "No application role defined"
#endif /* #if (!BLE_BROADCASTER) && (!BLE_OBSERVER) && (!BLE_PERIPHERAL) && (!BLE_CENTRAL) */


/// Maximum number of simultaneous connections
#if (BLE_CENTRAL)
#define BLE_CONNECTION_MAX      (CFG_CON)
#elif (BLE_PERIPHERAL)
#define BLE_CONNECTION_MAX      (1)
#else
#define BLE_CONNECTION_MAX      (1)
#endif /* #if (BLE_CENTRAL) */


/// Number of TX data buffer
#if (BLE_CONNECTION_MAX == 1)
#if (BLE_CENTRAL || BLE_PERIPHERAL)
#define BLE_TX_BUFF_DATA            (3)
#else
#define BLE_TX_BUFF_DATA            (0)
#endif //(BLE_CENTRAL || BLE_PERIPHERAL)
#else
#define BLE_TX_BUFF_DATA            (BLE_CONNECTION_MAX + 2) // Worst case (one way 251 bytes every 7.5ms)
#endif //(BLE_CONNECTION_MAX == 1)

#if (BLE_CENTRAL || BLE_PERIPHERAL)
/// Number of TX advertising buffer
#define BLE_TX_BUFF_ADV             (3) // Worst case (1 for CONNECT_REQ, 1 for ADV_DATA and 1 for SCAN_RESP_DATA)
/// Number of TX control buffer
#define BLE_TX_BUFF_CNTL            (BLE_CONNECTION_MAX) // Worst case (1 dedicated packet by link)
#else
/// Margin used for LL fragmentation (DLE feature)
//#define BLE_TX_DESC_MARGING_DLE     (0)
#if (BLE_BROADCASTER)
/// Number of TX advertising descriptors
#define BLE_TX_BUFF_ADV             (2)
/// Number of TX control descriptors
#define BLE_TX_BUFF_CNTL            (0)
#else
/// Number of TX advertising descriptors
#define BLE_TX_BUFF_ADV             (1)
/// Number of TX control descriptors
#define BLE_TX_BUFF_CNTL            (0)
#endif // BLE_BROADCASTER
#endif //(BLE_CENTRAL || BLE_PERIPHERAL)

/// Number of elements in the TX Descriptor pool
// Dedicated for DATA
// Worst case (3 packets (251 bytes) fragmented into 27 byte =  10)
#define BLE_TX_DESC_DATA            ((BLE_TX_BUFF_DATA) * 10)
// Dedicated for CONTROL
#define BLE_TX_DESC_CNTL            (BLE_TX_BUFF_CNTL)
// Dedicated for ADVERTISING
#define BLE_TX_DESC_ADV             (BLE_TX_BUFF_ADV)

/// Number of TX Buffers
#define BLE_TX_BUFFER_CNT           (BLE_TX_BUFF_DATA)

/// Total number of elements in the TX Descriptor pool
#define BLE_TX_DESC_CNT             (BLE_TX_DESC_CNTL + BLE_TX_DESC_ADV + BLE_TX_DESC_DATA)


/// Number of receive buffers in the RX ring. This number defines the interrupt
/// rate during a connection event. An interrupt is asserted every BLE_RX_BUFFER_CNT/2
/// reception. This number has an impact on the size of the exchange memory. This number
/// may have to be increased when CPU is very slow to free the received data, in order not
/// to overflow the RX ring of buffers.

#if (BLE_CENTRAL || BLE_PERIPHERAL)
/// Number of RX Descriptors
#define BLE_RX_DESC_CNT             (8)
#elif (BLE_BROADCASTER)
#define BLE_RX_DESC_CNT             (1)
#else
#define BLE_RX_DESC_CNT             (4)
#endif //(BLE_CENTRAL || BLE_PERIPHERAL)
/// Number of RX Buffers
#define BLE_RX_BUFFER_CNT               (BLE_RX_DESC_CNT)

/// Max advertising reports before sending the info to the host
#define BLE_ADV_REPORTS_MAX             1

#endif //defined(CFG_BLE)


/******************************************************************************************/
/* -------------------------   BLE APPLICATION SETTINGS      -----------------------------*/
/******************************************************************************************/

/// Health Thermometer Application
#if defined(CFG_APP_HT)
#define BLE_APP_HT           1
#else // defined(CFG_APP_HT)
#define BLE_APP_HT           0
#endif // defined(CFG_APP_HT)

/// HID Application
#if defined(CFG_APP_HID)
#define BLE_APP_HID          1
#else // defined(CFG_APP_HID)
#define BLE_APP_HID          0
#endif // defined(CFG_APP_HID)

/// DIS Application
#if defined(CFG_APP_DIS)
#define BLE_APP_DIS          1
#else // defined(CFG_APP_DIS)
#define BLE_APP_DIS          0
#endif // defined(CFG_APP_DIS)

/// Time Application
#if defined(CFG_APP_TIME)
#define BLE_APP_TIME         1
#else // defined(CFG_APP_TIME)
#define BLE_APP_TIME         0
#endif // defined(CFG_APP_TIME)

/// Battery Service Application
#if defined(CFG_APP_BAS)
#define BLE_APP_BATT          1
#else
#define BLE_APP_BATT          0
#endif // (BLE_APP_HID)

#if defined(CFG_APP_OTA)
#define BLE_APP_OTAS        1
#else // (CFG_APP_OTA)
#define BLE_APP_OTAS        0
#endif // (CFG_APP_OTA)

#if defined(CFG_APP_RTCT)
#define BLE_APP_RTCTS        1
#else // (CFG_APP_RTCT)
#define BLE_APP_RTCTS        0
#endif // (CFG_APP_RTCT)

#if defined(CFG_APP_SPSS)
#define BLE_APP_SPSS        1
#else   //CFG_APP_SPSS
#define BLE_APP_SPSS        0
#endif  //CFG_APP_SPSS


/// Security Application
#if (defined(CFG_APP_SEC) || BLE_APP_HID)
#define BLE_APP_SEC          1
#else // defined(CFG_APP_SEC)
#define BLE_APP_SEC          0
#endif // defined(CFG_APP_SEC)

#if defined(CFG_BLE_ADV_TEST_MODE)
#define BLE_ADV_TEST_MODE 1
#else  // !defined(CFG_BLE_ADV_TESTER)
#define BLE_ADV_TEST_MODE 0
#endif // defined(CFG_BLE_ADV_TESTER)


#if defined(CFG_APP_MESH)
#define BLE_APP_MESH   1
#else   //CFG_APP_SPSS
#define BLE_APP_MESH   0
#endif  //CFG_APP_SPSS



/******************************************************************************************/
/* --------------------------   DISPLAY SETUP        -------------------------------------*/
/******************************************************************************************/

/// Display controller enable/disable
#if defined(CFG_DISPLAY)
#define DISPLAY_SUPPORT      1
#else
#define DISPLAY_SUPPORT      0
#endif //CFG_DISPLAY


/******************************************************************************************/
/* -------------------------- INTERNAL TRACER SETUP --------------------------------------*/
/******************************************************************************************/
/// TCI LMP trace support
#define TCI_LMP_ENABLED                             0



/******************************************************************************************/
/* --------------------------      RTC SETUP         -------------------------------------*/
/******************************************************************************************/

/// RTC enable/disable
#if defined(CFG_RTC)
#define RTC_SUPPORT      1
#else
#define RTC_SUPPORT      0
#endif //CFG_DISPLAY

/******************************************************************************************/
/* --------------------------      PS2 SETUP         -------------------------------------*/
/******************************************************************************************/

/// PS2 enable/disable
#if defined(CFG_PS2)
#define PS2_SUPPORT      1
#else
#define PS2_SUPPORT      0
#endif //CFG_PS2

/******************************************************************************************/
/* --------------------------      BUTTON SETUP         -------------------------------------*/
/******************************************************************************************/

/// BUTTON enable/disable
#if defined(CFG_BUTTON)
#define BUTTON_SUPPORT   1
#else
#define BUTTON_SUPPORT   0
#endif

/******************************************************************************************/
/* -------------------------   DEEP SLEEP SETUP      -------------------------------------*/
/******************************************************************************************/

/// DEEP SLEEP enable
#if defined(CFG_SLEEP) && (BLE_EMB_PRESENT || BT_EMB_PRESENT)
#define DEEP_SLEEP                              1
#else
#define DEEP_SLEEP                              0
#endif /* CFG_SLEEP */

/// Use 32K Hz Clock if set to 1 else 32,768k is used
#define HZ32000                                     0

/// Time to wake-up Radio Module (in us)
#define SLEEP_RM_WAKEUP_DELAY                       625
/// Time for stabilization of the high frequency oscillator following a sleep-timer expiry (in us)
#define SLEEP_OSC_NORMAL_WAKEUP_DELAY               5000
/// Time for stabilization of the high frequency oscillator following an external wake-up request (in us)
#define SLEEP_OSC_EXT_WAKEUP_DELAY                  5000


/******************************************************************************************/
/* -------------------------    PROCESSOR SETUP      -------------------------------------*/
/******************************************************************************************/

/// 8 BIT processor
#define PROC_8BITS                        0

/******************************************************************************************/
/* --------------------------   RADIO SETUP       ----------------------------------------*/
/******************************************************************************************/

/// Power control features
#define RF_TXPWR                            1
/// Class of device
#define RF_CLASS1                           0

/******************************************************************************************/
/* -------------------------   COEXISTENCE SETUP      ------------------------------------*/
/******************************************************************************************/

/// WLAN Coexistence
#define RW_WLAN_COEX                     (defined(CFG_WLAN_COEX))
///WLAN test mode
#if defined(CFG_WLAN_COEX)
#define RW_WLAN_COEX_TEST            (defined(CFG_WLAN_COEX_TEST))
#else
#define RW_WLAN_COEX_TEST            0
#endif // defined(CFG_WLAN_COEX)

/******************************************************************************************/
/* -------------------------   CHANNEL ASSESSMENT SETUP      -----------------------------*/
/******************************************************************************************/

/// Channel Assessment
#if defined(CFG_BLE)
#if (defined(CFG_CHNL_ASSESS) && BLE_CENTRAL)
#define BLE_CHNL_ASSESS        (1)
#else
#define BLE_CHNL_ASSESS        (0)
#endif //(defined(CFG_CHNL_ASSESS) && BLE_CENTRAL)
#endif //defined(CFG_BLE)

/******************************************************************************************/
/* --------------------   SECURE CONNECTIONS SETUP  --------------------------------------*/
/******************************************************************************************/
#if defined(CFG_SEC_CON)
#define BLE_SECURE_CONNECTIONS  1
#else
#define BLE_SECURE_CONNECTIONS  0
#endif

/******************************************************************************************/
/* --------------------------   DEBUG SETUP       ----------------------------------------*/
/******************************************************************************************/

/// Flag indicating if debug mode is activated or not
#if defined(CFG_DBG)
#define RW_DEBUG                        ((BLE_EMB_PRESENT) || (BT_EMB_PRESENT))
#if (BLE_EMB_PRESENT || BT_EMB_PRESENT)
#define RW_SWDIAG                       1
#else
#define RW_SWDIAG                       0
#endif
#define KE_PROFILING                    1
#else
#define RW_DEBUG                        0
#define RW_SWDIAG                       0
#define KE_PROFILING                    0
#endif /* CFG_DBG */

/// Flag indicating if Read/Write memory commands are supported or not
#if defined(CFG_DBG_MEM)
#define RW_DEBUG_MEM               1
#else //CFG_DBG_MEM
#define RW_DEBUG_MEM               0
#endif //CFG_DBG_MEM

/// Flag indicating if Flash debug commands are supported or not
#if defined(CFG_DBG_FLASH)
#define RW_DEBUG_FLASH                  1
#else //CFG_DBG_FLASH
#define RW_DEBUG_FLASH                  0
#endif //CFG_DBG_FLASH

/// Flag indicating if NVDS feature is supported or not
#if defined(CFG_DBG_NVDS)
#define RW_DEBUG_NVDS                   1
#else //CFG_DBG_NVDS
#define RW_DEBUG_NVDS                   0
#endif //CFG_DBG_NVDS

/// Flag indicating if CPU stack profiling commands are supported or not
#if defined(CFG_DBG_STACK_PROF)
#define RW_DEBUG_STACK_PROF             1
#else
#define RW_DEBUG_STACK_PROF             0
#endif // defined (CFG_DBG_STACK_PROF)

#if defined(CFG_DBG_PRINTF)
#include <stdio.h>
#else
#define printf(...)
#endif

/// Debug printing
#if (RW_DEBUG)
#define WARNING(P)                      dbg_warning P
#else
#define WARNING(P)
#endif //RW_DEBUG

/// Modem back to back setup
#define MODEM2MODEM                          0
/// Special clock testing
#define CLK_WRAPPING                         0

/******************************************************************************************/
/* --------------------------      NVDS SETUP       --------------------------------------*/
/******************************************************************************************/

/// Flag indicating if NVDS feature is supported or not
#if defined(CFG_NVDS)
#define NVDS_SUPPORT                    1
#else //CFG_DBG_NVDS
#define NVDS_SUPPORT                    0
#endif //CFG_DBG_NVDS

/******************************************************************************************/
/* --------------------------      MISC SETUP       --------------------------------------*/
/******************************************************************************************/
/// Manufacturer: RivieraWaves SAS
#define RW_COMP_ID                           0x0060

/// Bluetooth technologies version
#define RW_BT40_VERSION                      (6)
#define RW_BT41_VERSION                      (7)
#define RW_BT42_VERSION                      (8)

/******************************************************************************************/
/* -------------------------   BT / BLE / BLE HL CONFIG    -------------------------------*/
/******************************************************************************************/

#if (BT_EMB_PRESENT)
#include "rwbt_config.h"    // bt stack configuration
#endif //BT_EMB_PRESENT

#if (BLE_EMB_PRESENT) || (BLE_HOST_PRESENT)
#include "rwble_config.h"   // ble stack configuration
#endif //BLE_EMB_PRESENT

#if (BLE_HOST_PRESENT)
#include "rwble_hl_config.h"  // ble Host stack configuration
#endif //BLE_HOST_PRESENT



/******************************************************************************************/
/* -------------------------   KERNEL SETUP          -------------------------------------*/
/******************************************************************************************/

/// Flag indicating Kernel is supported
#define KE_SUPPORT  (BLE_EMB_PRESENT || BT_EMB_PRESENT || BLE_HOST_PRESENT || BLE_APP_PRESENT)


/// Event types definition
enum KE_EVENT_TYPE
{
#if DISPLAY_SUPPORT
    KE_EVENT_DISPLAY,
#endif //DISPLAY_SUPPORT

#if RTC_SUPPORT
    KE_EVENT_RTC_1S_TICK,
#endif //RTC_SUPPORT

    KE_EVENT_LOW_PRIO_TASK,

#if BLE_EMB_PRESENT
#if BLE_SECURE_CONNECTIONS
    KE_EVENT_BLE_SEC_CON,
#endif // BLE_SECURE_CONNECTIONS
    KE_EVENT_BLE_CRYPT,
#endif //BLE_EMB_PRESENT

    KE_EVENT_KE_MESSAGE,
    KE_EVENT_KE_TIMER,

#if (AHI_TL_SUPPORT)
    KE_EVENT_AHI_TX_DONE,
#endif //(AHI_TL_SUPPORT)


#if H4TL_SUPPORT
    KE_EVENT_H4TL_TX,
#if (BLE_EMB_PRESENT || BT_EMB_PRESENT)
    KE_EVENT_H4TL_CMD_HDR_RX,
    KE_EVENT_H4TL_CMD_PLD_RX,
#endif //(BLE_EMB_PRESENT || BT_EMB_PRESENT)
#endif //H4TL_SUPPORT

#if BT_EMB_PRESENT
    KE_EVENT_BT_PSCAN_PROC,
#endif //BT_EMB_PRESENT

#if BLE_EMB_PRESENT
    KE_EVENT_BLE_EVT_DEFER,
#endif //BLE_EMB_PRESENT

    KE_EVENT_MAX,
};

/// Tasks types definition
enum KE_TASK_TYPE
{
#if (BT_EMB_PRESENT)
    // BT Controller Tasks
    TASK_LM,
    TASK_LC,
    TASK_LB,
    TASK_LD,
    TASK_HCI,
#endif // (BT_EMB_PRESENT)

#if (BLE_EMB_PRESENT)
    // Link Layer Tasks
    TASK_LLM,
    TASK_LLC,
    TASK_LLD,
#endif // (BLE_EMB_PRESENT)

#if ((BLE_EMB_PRESENT) || (BT_EMB_PRESENT))
    TASK_DBG,
#endif // ((BLE_EMB_PRESENT) || (BT_EMB_PRESENT))

#if (DISPLAY_SUPPORT)
    TASK_DISPLAY,
#endif // (DISPLAY_SUPPORT)

#if (BLE_APP_PRESENT)
    TASK_APP,               //4
#endif // (BLE_APP_PRESENT)

#if (AHI_TL_SUPPORT)
    TASK_AHI,
#endif // (AHI_TL_SUPPORT)

#if (BUTTON_SUPPORT)
    TASK_BUTTON,        //5
#endif

#if (BLE_HOST_PRESENT)
    TASK_L2CC,    // L2CAP Controller Task
    TASK_GATTM,   // Generic Attribute Profile Manager Task
    TASK_GATTC,   // Generic Attribute Profile Controller Task
    TASK_GAPM,    // Generic Access Profile Manager
    TASK_GAPC,    // Generic Access Profile Controller

    // allocate a certain number of profiles task
    //TASK_PRF_MAX = (TASK_GAPC + BLE_NB_PROFILES),
#endif // (BLE_HOST_PRESENT)

    TASK_TEMPLATE = (BLE_NB_PROFILES + TASK_GAPC + 1),          //21

    TASK_UART_TEST, //dyc add for ssc test,22
    TASK_ENCODER,
    TASK_DECODER,
    TASK_USER_START,    //for user create task

    /// Maximum number of tasks
    TASK_MAX = TASK_USER_START + 50,

    TASK_NONE = 0xFF,
};

/// Tasks types definition, this value shall be in [0-254] range
enum KE_API_ID
{
    // Link Layer Tasks
    TASK_ID_LLM          = 0,
    TASK_ID_LLC          = 1,
    TASK_ID_LLD          = 2,
    TASK_ID_DBG          = 3,

    // BT Controller Tasks
    TASK_ID_LM           = 4,
    TASK_ID_LC           = 5,
    TASK_ID_LB           = 6,
    TASK_ID_LD           = 7,

    TASK_ID_HCI          = 8,
    TASK_ID_DISPLAY      = 9,

    TASK_ID_L2CC         = 10,
    TASK_ID_GATTM        = 11,   // Generic Attribute Profile Manager Task
    TASK_ID_GATTC        = 12,   // Generic Attribute Profile Controller Task
    TASK_ID_GAPM         = 13,   // Generic Access Profile Manager
    TASK_ID_GAPC         = 14,   // Generic Access Profile Controller

    TASK_ID_APP          = 15,
    TASK_ID_AHI          = 16,

    TASK_ID_BUTTON       = 17,

    // -----------------------------------------------------------------------------------
    // --------------------- BLE Profile TASK API Identifiers ----------------------------
    // -----------------------------------------------------------------------------------
    TASK_ID_DISS         = 20,   // Device Information Service Server Task
    TASK_ID_DISC         = 21,   // Device Information Service Client Task

    TASK_ID_PROXM        = 22,   // Proximity Monitor Task
    TASK_ID_PROXR        = 23,   // Proximity Reporter Task

    TASK_ID_FINDL        = 24,   // Find Me Locator Task
    TASK_ID_FINDT        = 25,   // Find Me Target Task

    TASK_ID_HTPC         = 26,   // Health Thermometer Collector Task
    TASK_ID_HTPT         = 27,   // Health Thermometer Sensor Task

    TASK_ID_BLPS         = 28,   // Blood Pressure Sensor Task
    TASK_ID_BLPC         = 29,   // Blood Pressure Collector Task

    TASK_ID_HRPS         = 30,   // Heart Rate Sensor Task
    TASK_ID_HRPC         = 31,   // Heart Rate Collector Task

    TASK_ID_TIPS         = 32,   // Time Server Task
    TASK_ID_TIPC         = 33,   // Time Client Task

    TASK_ID_SCPPS        = 34,   // Scan Parameter Profile Server Task
    TASK_ID_SCPPC        = 35,   // Scan Parameter Profile Client Task

    TASK_ID_BASS         = 36,   // Battery Service Server Task
    TASK_ID_BASC         = 37,   // Battery Service Client Task

    TASK_ID_HOGPD        = 38,   // HID Device Task
    TASK_ID_HOGPBH       = 39,   // HID Boot Host Task
    TASK_ID_HOGPRH       = 40,   // HID Report Host Task

    TASK_ID_GLPS         = 41,   // Glucose Profile Sensor Task
    TASK_ID_GLPC         = 42,   // Glucose Profile Collector Task

    TASK_ID_RSCPS        = 43,   // Running Speed and Cadence Profile Server Task
    TASK_ID_RSCPC        = 44,   // Running Speed and Cadence Profile Collector Task

    TASK_ID_CSCPS        = 45,   // Cycling Speed and Cadence Profile Server Task
    TASK_ID_CSCPC        = 46,   // Cycling Speed and Cadence Profile Client Task

    TASK_ID_ANPS         = 47,   // Alert Notification Profile Server Task
    TASK_ID_ANPC         = 48,   // Alert Notification Profile Client Task

    TASK_ID_PASPS        = 49,   // Phone Alert Status Profile Server Task
    TASK_ID_PASPC        = 50,   // Phone Alert Status Profile Client Task

    TASK_ID_CPPS         = 51,   // Cycling Power Profile Server Task
    TASK_ID_CPPC         = 52,   // Cycling Power Profile Client Task

    TASK_ID_LANS         = 53,   // Location and Navigation Profile Server Task
    TASK_ID_LANC         = 54,   // Location and Navigation Profile Client Task

    TASK_ID_OTAS         = 55,
    TASK_ID_OTAC         = 56,

    TASK_ID_RTCTS        = 57,
    TASK_ID_RTCTC        = 58,

    TASK_ID_SPSS         = 59,
    TASK_ID_SPSC         = 60,

    TASK_ID_FLOWER_CLIENT     = 61,
    TASK_ID_ENCODER      = 63,
    TASK_ID_DECODER      = 64,
    TASK_ID_MESH         = 65,

    TASK_ID_USER_START, //for user create task
    /// Maximum number of tasks
    TASK_ID_USER_MAX = TASK_ID_USER_START + MAX_USER_PRF_NUM,

    TASK_ID_INVALID      = 0xFF, // Invalid Task Identifier
};


/// Kernel memory heaps types.
enum
{
    /// Memory allocated for environment variables
    KE_MEM_ENV,
#if (BLE_HOST_PRESENT)
    /// Memory allocated for Attribute database
    KE_MEM_ATT_DB,
#endif // (BLE_HOST_PRESENT)
    /// Memory allocated for kernel messages
    KE_MEM_KE_MSG,
    /// Non Retention memory block
    KE_MEM_NON_RETENTION,
    KE_MEM_BLOCK_MAX,
};



#if (BT_EMB_PRESENT)
#define BT_HEAP_MSG_SIZE_      BT_HEAP_MSG_SIZE
#define BT_HEAP_ENV_SIZE_      BT_HEAP_ENV_SIZE
#else
#define BT_HEAP_MSG_SIZE_      0
#define BT_HEAP_ENV_SIZE_      0
#endif //BT_EMB_PRESENT

#if (BLE_EMB_PRESENT)
#define BLE_HEAP_MSG_SIZE_     BLE_HEAP_MSG_SIZE
#define BLE_HEAP_ENV_SIZE_     BLE_HEAP_ENV_SIZE
#else
#define BLE_HEAP_MSG_SIZE_     0
#define BLE_HEAP_ENV_SIZE_     0
#endif //BLE_EMB_PRESENT

#if (BLE_HOST_PRESENT)

#define BLEHL_HEAP_MSG_SIZE_   BLEHL_HEAP_MSG_SIZE
#define BLEHL_HEAP_ENV_SIZE_   BLEHL_HEAP_ENV_SIZE
#define BLEHL_HEAP_DB_SIZE_    BLEHL_HEAP_DB_SIZE
#else
#define BLEHL_HEAP_MSG_SIZE_   0
#define BLEHL_HEAP_ENV_SIZE_   0
#define BLEHL_HEAP_DB_SIZE_    0
#endif //BLE_HOST_PRESENT


/// Kernel Message Heap
#if 0
#define RWIP_HEAP_MSG_SIZE         (  BT_HEAP_MSG_SIZE_      + \
                                    BLE_HEAP_MSG_SIZE_     + \
                                    BLEHL_HEAP_MSG_SIZE_      )
#else
#define RWIP_HEAP_MSG_SIZE         (1024)
#endif

/// Number of link in kernel environment TODO [FBE] add a define in scons build
#define KE_NB_LINK_IN_HEAP_ENV   4

/// Size of Environment heap
#ifdef CFG_APP_MESH
#define RWIP_HEAP_ENV_SIZE         (400)
#else
#define RWIP_HEAP_ENV_SIZE         ( BT_HEAP_ENV_SIZE_         + \
                                     ( BLE_HEAP_ENV_SIZE_      + \
                                       BLEHL_HEAP_ENV_SIZE_ )    \
                                     * KE_NB_LINK_IN_HEAP_ENV )
#endif


/// Size of Attribute database heap
#define RWIP_HEAP_DB_SIZE         (  BLEHL_HEAP_DB_SIZE  )

/// Size of non retention heap - 1024 bytes per ble link should be sufficient and can be tuned
#if (BLE_EMB_PRESENT)
#define RWIP_HEAP_NON_RET_SIZE    ( 1024 * BLE_CONNECTION_MAX )
#else
#define RWIP_HEAP_NON_RET_SIZE    ( 1024 )
#endif

#include "jump_table.h"

/// @} BT Stack Configuration
/// @} ROOT

#endif //RWIP_CONFIG_H_
