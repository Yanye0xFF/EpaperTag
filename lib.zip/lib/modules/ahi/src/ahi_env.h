/**
 ****************************************************************************************
 *
 * @file ahi_env.h
 *
 * @brief This file contains definitions related to the Application Host Interface
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef AHI_ENV_H_
#define AHI_ENV_H_

/**
 ****************************************************************************************
 * @addtogroup AHI Application Host Interface
 * @ingroup AHI
 * @brief Application Host Interface, based on AHI functionality.
 *
 *@{
 *
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"     // SW configuration

#if (AHI_TL_SUPPORT)

#include "ke_msg.h"



/*
 * DEFINES
 ****************************************************************************************
 */


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


///AHI Environment context structure
struct ahi_env_tag
{
    /// list of TX buffer in pending queue
    struct co_list tx_queue;

    /// message wich is currently TX.
    struct ke_msg* tx_ptr;
};

/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */

///AHI environment structure external global variable declaration
extern struct ahi_env_tag ahi_env;


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 *****************************************************************************************
 * Handles message to send over AHI interface.
 * This function check message type to send it in correct format (HCI, FE, ...)
 *
 * @param[in] kernel message to transmit
 *****************************************************************************************
 */
void ahi_send_msg(struct ke_msg* msg);


#endif //AHI_TL_SUPPORT

/// @} AHI
#endif // AHI_ENV_H_
