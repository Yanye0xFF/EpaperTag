/*
 *
 *  Bluetooth low-complexity, subband codec (SBC) encoder
 *
 *  Copyright (C) 2008-2010  Nokia Corporation
 *  Copyright (C) 2004-2010  Marcel Holtmann <marcel@holtmann.org>
 *  Copyright (C) 2012-2013  Intel Corporation
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "rwip_config.h"

#if (defined(CFG_SBC)||defined(CFG_ADPCM))

#include <stdio.h>
#include <errno.h>
//#include <fcntl.h>
//#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
//#include <getopt.h>
//#include <sys/stat.h>

//#include "gattc.h"

//#include "timer.h"
//#include "intc.h"

#include "sbc.h"
#include "encoder_task.h"
#include "audio.h"
#include "i2s.h"
#include "apb2spi.h"


void mic_start(void)
{
    ool_write(0x0b, ool_read(0x0b) | 0x40);
    
    encode_start();
    audio_codec_disable_dac();
    audio_codec_enable_adc();
    i2s_start();
    NVIC_EnableIRQ(I2S_IRQn);
}
void mic_stop(void)
{
    NVIC_DisableIRQ(I2S_IRQn);
    i2s_stop();
    audio_codec_disable_adc();
    encode_stop();
    ool_write(0x0b, ool_read(0x0b) & (~0x40));
}
void mic_ini(void)
{
    encoder_task_init();
#if ( (defined(CFG_SBC)||defined(CFG_ADPCM)) && (defined(CFG_DEC_ADPCM_MS)|| defined(CFG_DEC_SBC)) )
    speaker_mic_codec_init();
#else
    audio_codec_init(16000);
#endif
    audio_codec_disable_dac();
    audio_codec_enable_adc();
    i2s_init(I2S_MIC,16000);    //8,16,32,48
    NVIC_SetPriority(I2S_IRQn, 2);
    mic_stop();
}



#if MIC_TEST_ENABLE
#include "user_timer.h"
#include "user_c_lib.h"
os_timer_t mic_sample_timer;

void encoder_frame_out_func(uint8_t *frame_data,uint16_t frame_size)
{
    static uint16_t change_line = 0;
    for(uint32_t i=0; i<frame_size; i++)
    {
        fputc(hex4bit_to_ascii_char( (frame_data[i]>>4)&0x0F ), 0);
        fputc(hex4bit_to_ascii_char( (frame_data[i]>>0)&0x0F ), 0);
    }
    change_line += frame_size;
    if(change_line >= frame_size*ENCODER_MAX_BUFFERING_BLOCK_COUNT)
    {
        change_line = 0;
        fputc('\n', 0);
    };
}

void mic_timout_hdl(void *arg)
{
    mic_stop();
    //printf("mic_stop\r\n");
}

void test_mic(void)
{
    printf("mic_start\r\n");
    mic_start();
    os_timer_setfn(&mic_sample_timer,mic_timout_hdl,NULL);
    os_timer_arm(&mic_sample_timer,10000,0);
}
#endif

#endif  //CFG_SBC


