#include "sbc.h"
#include "adpcm.h"
#include "ke_msg.h"
#include "ke_mem.h"
#include "ke_task.h"
#include "encoder_task.h"
#include "app_spss.h"
#include "user_mem.h"

#include "arch.h"
#define ENC_DBG FR_DBG_OFF
#define ENC_LOG FR_LOG(ENC_DBG)

#define ENC_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %s \n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);

#if defined(CFG_ADPCM)
struct CodecState adpcm_state;
#endif

struct encoder_env_t encoder_env;

void encode_start(void)
{
    uint8_t *sbc_str_buffer;
    ENC_LOG("encode_start\r\n");

    if(ke_state_get(TASK_ENCODER) != ENCODER_STATE_IDLE)
    {
        return;
    }

    memset((void *)&encoder_env, 0, sizeof(struct encoder_env_t));

    encoder_env.sbc = (sbc_t *)ke_malloc(sizeof(sbc_t), KE_MEM_ENV);
    sbc_str_buffer = ke_malloc(0x4F0, KE_MEM_ENV);  //sizeof(struct sbc_priv) + SBC_ALIGN_MASK = 0x4F0

    sbc_init(encoder_env.sbc, (void *)sbc_str_buffer);

    encoder_env.sbc->frequency = SBC_FREQ_16000;
    encoder_env.sbc->blocks = SBC_BLK_16;
    encoder_env.sbc->subbands = SBC_SB_8;
    encoder_env.sbc->allocation = SBC_AM_LOUDNESS;
    encoder_env.sbc->bitpool = 14;

    encoder_env.block_size = sbc_get_codesize(encoder_env.sbc);     //0x100 = 256
#if defined(CFG_ADPCM)
    encoder_env.frame_size = encoder_env.block_size>>2;     //adpcm, fixed compressing rate == 4;
    memset(&adpcm_state,0x0,sizeof(adpcm_state));
#else
    encoder_env.frame_size = sbc_get_frame_length(encoder_env.sbc);     //0x3A = 58
#endif
    ENC_LOG("blk_sz:%d,frm_sz:%d\r\n",encoder_env.block_size,encoder_env.frame_size);


    co_list_init(&encoder_env.pcm_data_list);
    encoder_env.out_buffer = ke_malloc(ENCODER_MAX_BUFFERING_BLOCK_COUNT*encoder_env.frame_size, KE_MEM_ENV);       //0x244 = 580, <1block enc to 1frame>
    encoder_env.reserved_space = ENCODER_MAX_BUFFERING_BLOCK_COUNT*encoder_env.frame_size;      //0x244 = 580

    ENC_LOG("out_buf:%p,sbc:%p,priv:%p,str_buf:%p\r\n",encoder_env.out_buffer,encoder_env.sbc,encoder_env.sbc->priv_alloc_base,sbc_str_buffer);


    encoder_env.tmp_pcm = NULL;

    ke_state_set(TASK_ENCODER, ENCODER_STATE_BUSY);
}

void encode_stop(void)
{
    ENC_LOG("encode_stop\r\n");

    if(ke_state_get(TASK_ENCODER) == ENCODER_STATE_IDLE)
    {
        return;
    }

    GLOBAL_INT_DISABLE();
#if defined(CFG_ADPCM)
    memset(&adpcm_state,0x0,sizeof(adpcm_state));
#endif
    if(encoder_env.tmp_pcm)
    {
        //printf("x,");
        ke_msg_free( ke_param2msg(encoder_env.tmp_pcm) );
    }
    ke_state_set(TASK_ENCODER, ENCODER_STATE_IDLE);
    GLOBAL_INT_RESTORE();
    //printf("y,");

    ke_free(encoder_env.out_buffer);
    ke_free(encoder_env.sbc->priv_alloc_base);
    //printf("m,");
    ke_free(encoder_env.sbc);
}

void encode_store_pcm_data(uint16_t *data, uint8_t len)
{
    uint16_t store_len;

    if(ke_state_get(TASK_ENCODER) == ENCODER_STATE_BUSY)
    {
        len *= 2;
        while(len)
        {
            if(encoder_env.tmp_pcm == NULL)
            {
                encoder_env.tmp_pcm = (struct pcm_data_t *)KE_MSG_ALLOC_DYN(ENCODER_EVENT_NEXT_FRAME, TASK_ENCODER
                                      , NULL, pcm_data_t, encoder_env.block_size);
                encoder_env.tmp_pcm_write_pos = 0;
            }

            store_len = encoder_env.block_size-encoder_env.tmp_pcm_write_pos;
            if(store_len >= len)
            {
                store_len = len;
            }

            memcpy(&encoder_env.tmp_pcm->data[encoder_env.tmp_pcm_write_pos], data, store_len);
            len -= store_len;
            encoder_env.tmp_pcm_write_pos += store_len;
            if(encoder_env.tmp_pcm_write_pos >= encoder_env.block_size)
            {
                //  printf("t,");
                ke_msg_send(encoder_env.tmp_pcm);
                encoder_env.tmp_pcm = NULL;
            }
        }
    }
}

void  __attribute__((weak)) encoder_frame_out_func(uint8_t *frame_data,uint16_t frame_size)
{
    ;
}
static int encoder_next_frame_handler(ke_msg_id_t const msgid,
                                      struct pcm_data_t *pcm_data,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    int encoded_len, org_len;
    //printf("N:%d,%d\r\n",encoder_env.reserved_space,encoder_env.frame_size);

#if defined(CFG_ADPCM)
    if((ke_state_get(TASK_ENCODER) == ENCODER_STATE_BUSY)
       && (encoder_env.reserved_space >= encoder_env.frame_size))
    {
        encode( &adpcm_state
                ,(short *)(pcm_data->data)
                ,encoder_env.block_size>>1
                ,&encoder_env.out_buffer[encoder_env.encode_write_pos]
              );
        encoder_env.reserved_space -= encoder_env.frame_size;

        /*
            static uint16_t change_line = 0;
            for(uint32_t i=0; i<frame_size; i++)
            {
                fputc(hex4bit_to_ascii_char( (frame_data[i]>>4)&0x0F ), 0);
                fputc(hex4bit_to_ascii_char( (frame_data[i]>>0)&0x0F ), 0);
            }
            change_line += frame_size;
            if(change_line >= frame_size*ENCODER_MAX_BUFFERING_BLOCK_COUNT)
            {
                change_line = 0;
                fputc('\n', 0);
            };
            */

        
        encoder_frame_out_func(&encoder_env.out_buffer[encoder_env.encode_write_pos],encoder_env.frame_size);
        encoder_env.reserved_space += encoder_env.frame_size;
        encoder_env.encode_write_pos += encoder_env.frame_size;
        if(encoder_env.encode_write_pos >= ENCODER_MAX_BUFFERING_BLOCK_COUNT*encoder_env.frame_size)
        {
            encoder_env.encode_write_pos = 0;
        }
    }
#else   //for CFG_SBC
    if((ke_state_get(TASK_ENCODER) == ENCODER_STATE_BUSY)
       && (encoder_env.reserved_space >= encoder_env.frame_size))
    {
        org_len = sbc_encode(encoder_env.sbc,
                             pcm_data->data,
                             encoder_env.block_size,
                             &encoder_env.out_buffer[encoder_env.encode_write_pos],
                             encoder_env.frame_size,
                             &encoded_len);
        if((org_len != encoder_env.block_size)
           ||(encoded_len!= encoder_env.frame_size))
        {
            printf("encoder_next_frame_handler: error.\r\n");
        }
        encoder_env.reserved_space -= encoder_env.frame_size;

        /*
            static uint16_t change_line = 0;
            for(uint32_t i=0; i<frame_size; i++)
            {
                fputc(hex4bit_to_ascii_char( (frame_data[i]>>4)&0x0F ), 0);
                fputc(hex4bit_to_ascii_char( (frame_data[i]>>0)&0x0F ), 0);
            }
            change_line += frame_size;
            if(change_line >= frame_size*ENCODER_MAX_BUFFERING_BLOCK_COUNT)
            {
                change_line = 0;
                fputc('\n', 0);
            };
            */

        
        encoder_frame_out_func(&encoder_env.out_buffer[encoder_env.encode_write_pos],encoder_env.frame_size);
        encoder_env.reserved_space += encoder_env.frame_size;
        encoder_env.encode_write_pos += encoder_env.frame_size;
        if(encoder_env.encode_write_pos >= ENCODER_MAX_BUFFERING_BLOCK_COUNT*encoder_env.frame_size)
        {
            encoder_env.encode_write_pos = 0;
        }
    }
#endif
    return KE_MSG_CONSUMED;
}

const struct ke_msg_handler encoder_default_state[] =
{
    {ENCODER_EVENT_NEXT_FRAME,      (ke_msg_func_t)encoder_next_frame_handler},
};

/* Specifies the message handlers that are common to all states. */
const struct ke_state_handler encoder_default_handler = KE_STATE_HANDLER(encoder_default_state);

/* Defines the place holder for the states of all the task instances. */
ke_state_t encoder_state[1];

static const struct ke_task_desc TASK_DESC_ENCODER = {NULL, &encoder_default_handler,
           encoder_state, ENCODER_STATE_MAX, 1
};

void encoder_task_init(void)
{
    ke_task_create(TASK_ENCODER, &TASK_DESC_ENCODER);

    ke_state_set(TASK_ENCODER, ENCODER_STATE_IDLE);

}
