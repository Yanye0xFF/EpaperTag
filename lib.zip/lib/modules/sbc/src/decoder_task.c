#include "ke_task.h"
#include "ke_msg.h"
#include "ke_mem.h"
#include "ke_timer.h"
#include "arch.h"

#include "co_list.h"

#include "decoder_task.h"

#include "oi_codec_sbc.h"

#include "adpcm_ms.h"
#include "dec_sbc.h"


#ifdef CFG_DEC_SBC

#include "arch.h"
#define DEC_DBG FR_DBG_OFF
#define DEC_LOG FR_LOG(DEC_DBG)

#define DEC_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %s \n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);
static uint8_t stop_flag = 0;


static bool decoder_hold_flag = false;
struct decoder_env_t decoder_env;

void decoder_start(uint32_t start, uint32_t end, uint32_t tot_data_len, uint32_t start_offset, uint8_t type)
{
    struct decoder_prepare_t *param = KE_MSG_ALLOC(DECODER_EVENT_PREPARE, TASK_DECODER,
                                      TASK_NONE, decoder_prepare_t);

    param->data_start = start;
    param->data_end = end;
    param->store_type = type;
    param->tot_data_len = tot_data_len;
    param->start_offset = start_offset;
    DEC_LOG("s:%x,e:%x\r\n",start,end);

    ke_msg_send((void *)param);
    speaker_start_hw();
    decoder_hold_flag = false;
}

void decoder_stop(void)
{
    DEC_LOG("decoder_stop\r\n");
    //printf("d_s\r\n");
    struct decoder_stop_t *param = KE_MSG_ALLOC(DECODER_EVENT_STOP, TASK_DECODER,
                                   TASK_NONE, decoder_stop_t);
    ke_msg_send((void *)param);
}

void decoder_play_next_frame(void)
{
    struct decoder_play_next_frame_t *param = KE_MSG_ALLOC(DECODER_EVENT_NEXT_FRAME, TASK_DECODER,
            TASK_NONE, decoder_play_next_frame_t);
    ke_msg_send((void *)param);
}



uint16_t decoder_calc_sbc_frame_len(struct sbc_header_t *header)
{
    uint8_t m_s = header->c.m_s;
    uint8_t subband = header->c.subband ? 8:4;
    uint8_t block;
    uint8_t bitpool = header->bitpool;

    switch(header->c.block)
    {
        case 0:
            block = 4;
            break;
        case 1:
            block = 8;
            break;
        case 2:
            block = 12;
            break;
        case 3:
            block = 16;
            break;
        default:
            block = 4;
            break;
    }

    switch(m_s)
    {
        case 0:
            return (4+subband/2+(block*bitpool+7)/8);
        case 1:
            return (4+subband+(block*bitpool*2+7)/8);
        case 2:
            return (4+subband+(block*bitpool+7)/8);
        case 3:
            return (4+subband+(subband+block*bitpool+7)/8);
        default:
            return 0;
    }
}

static int decoder_prepare_handler(ke_msg_id_t const msgid,
                                   struct decoder_prepare_t *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id)
{
    ke_state_t state;
    enum ke_msg_status_tag status = KE_MSG_CONSUMED;
    uint32_t size;

    state = ke_state_get(TASK_DECODER);
    switch(state)
    {
        case DECODER_STATE_IDLE:
            size = (sizeof(OI_CODEC_SBC_DECODER_CONTEXT) + 3) & (~0x03);
            decoder_env.decoder_context = ke_malloc(size + 2048*sizeof(uint32_t), KE_MEM_NON_RETENTION);
            OI_CODEC_SBC_DecoderReset((OI_CODEC_SBC_DECODER_CONTEXT *)decoder_env.decoder_context,
                                      (OI_UINT32 *)((uint8_t *)decoder_env.decoder_context+size),
                                      2048,
                                      2,
                                      2,
                                      FALSE);
            // TBD, init iis codec
            decoder_env.data_start = param->data_start;
            decoder_env.data_end = param->data_end;
            decoder_env.current_pos = param->data_start + param->start_offset;
            decoder_env.tot_data_len = param->tot_data_len;
            decoder_env.store_type = param->store_type;
            decoder_env.data_processed_len = 0;
            stop_flag = 0;
            if(decoder_env.store_type == DECODER_STORE_TYPE_RAM)
            {
                decoder_env.frame_len = decoder_calc_sbc_frame_len((struct sbc_header_t *)decoder_env.data_start);
            }
            else
            {
                //TBD, DECODER_STORE_TYPE_FLASH
            }
            DEC_LOG("preparing,fram_len:%d\r\n",decoder_env.frame_len);
            co_list_init(&decoder_env.pcm_buffer_list);
            decoder_env.pcm_buffer_counter = 0;
            decoder_play_next_frame();
            ke_state_set(TASK_DECODER, DECODER_STATE_BUFFERING);
            break;
        case DECODER_STATE_BUFFERING:
        case DECODER_STATE_PLAYING:
            status = KE_MSG_CONSUMED;
            break;
        case DECODER_STATE_WAITING_END:
            status = KE_MSG_SAVED;
            break;
        default:
            break;
    }

    return status;
}
void  __attribute__((weak)) decoder_end_func(void)
{
    ;
}
void  __attribute__((weak)) decoder_half_processed(void)
{
    ;
}
void decoder_update_tot_data_len(uint32_t len)
{
    decoder_env.tot_data_len = len;
}
bool decoder_get_hold_status(void)
{
    return decoder_hold_flag;
}
void decoder_set_hold_status(bool flag)
{
    decoder_hold_flag = flag;
}


static int decoder_play_next_frame_handler(ke_msg_id_t const msgid,
        struct decoder_play_next_frame_t *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    ke_state_t state;
    uint8_t *buffer;
    uint32_t pcm_len;
    uint32_t streamlen;
    struct decoder_pcm_t *pcm_frame;
    // CPU_SR cpu_sr;

    state = ke_state_get(TASK_DECODER);
    switch(state)
    {
        case DECODER_STATE_IDLE:
            break;
        case DECODER_STATE_BUFFERING:
        case DECODER_STATE_PLAYING:
#if 1

            if(decoder_env.store_type == DECODER_STORE_TYPE_RAM)
            {
                buffer = (uint8_t *)decoder_env.current_pos;
            }
            else
            {
                // TBD
            }

            pcm_frame = (struct decoder_pcm_t *)ke_malloc(sizeof(struct decoder_pcm_t) + 2*128*2, KE_MEM_NON_RETENTION);
            if(pcm_frame == NULL)
            {
                return KE_MSG_SAVED;
            }

            pcm_len = 512;
            streamlen = decoder_env.frame_len;
            DEC_LOG("playing:%d\r\n",streamlen);
            OI_STATUS rets;

            //printf("p:%d\r\n",streamlen);
            if(decoder_hold_flag == false)
            {
                rets = OI_CODEC_SBC_DecodeFrame(decoder_env.decoder_context,
                                                (const OI_BYTE **)&buffer,
                                                (OI_UINT32 *)&streamlen,
                                                (OI_INT16 *)&pcm_frame->pcm_data[0],
                                                (OI_UINT32 *)&pcm_len);
            }
            else
            {
                memset((uint8_t *)&pcm_frame->pcm_data[0],0x0,pcm_len);
                rets = OI_STATUS_SUCCESS;
            }

            if( rets == OI_STATUS_SUCCESS)
            {
                pcm_frame->pcm_size = pcm_len >> 2;
                pcm_frame->pcm_offset = 0;
                GLOBAL_INT_DISABLE();
                co_list_push_back(&decoder_env.pcm_buffer_list,&pcm_frame->list);
                GLOBAL_INT_RESTORE();
                DEC_LOG("pcmlen=%d,%d\r\n",pcm_len,streamlen);
                decoder_env.pcm_buffer_counter++;

                if(state == DECODER_STATE_BUFFERING)
                {
                    if (decoder_env.pcm_buffer_counter > 2)
                    {
                        ke_state_set(TASK_DECODER, DECODER_STATE_PLAYING);
                        NVIC_EnableIRQ(I2S_IRQn);
                    }
                    else
                    {
                        decoder_play_next_frame();
                    }
                }

                if(decoder_hold_flag == false)
                {
                    decoder_env.current_pos += decoder_env.frame_len;
                    decoder_env.data_processed_len += decoder_env.frame_len;

                    if( (decoder_env.tot_data_len - decoder_env.data_processed_len) < (2048) )
                    {
                        //printf("x");
                        decoder_half_processed();
                    }

                    if( (decoder_env.tot_data_len - decoder_env.data_processed_len)  < decoder_env.frame_len )
                    {
                        if(decoder_hold_flag == false)
                        {
                            //printf("y");
                            ke_state_set(TASK_DECODER, DECODER_STATE_WAITING_END);
                            //ke_timer_set(DECODER_EVENT_WAIT_END_TO, TASK_DECODER, 3);
                        }
                    }
                    if(decoder_env.current_pos >= decoder_env.data_end)
                    {
                        //printf("z");
                        decoder_env.current_pos = decoder_env.data_start;
                    }
                }

                if(decoder_env.store_type == DECODER_STORE_TYPE_FLASH)
                {
                    // TBD, free buffer
                }
            }
            else
            {
                printf("dcoder stop:%d\r\n",rets);
                ke_free(pcm_frame);
                NVIC_EnableIRQ(I2S_IRQn);
                decoder_stop();
            }
#endif
            break;
        case DECODER_STATE_WAITING_END:
            DEC_LOG("STATE_WAITING_END\r\n");
            //if(decoder_env.pcm_buffer_list.first == NULL)
            if(decoder_env.pcm_buffer_counter == 0)
            {
                if(stop_flag == 0)
                {
                    decoder_stop();
                    stop_flag = 1;
                    //ke_timer_set(APP_PLAY_TONE_INTERVAL, TASK_APP, 100);
                }
            }
            break;
        default:
            break;
    }

    return KE_MSG_CONSUMED;
}

static int decoder_stop_handler(ke_msg_id_t const msgid,
                                struct decoder_stop_t *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
    // struct co_list_hdr *element;
    // struct decoder_pcm_t *pcm;
    // TBD, disable codec
    NVIC_DisableIRQ(I2S_IRQn);
#if 0
    element = decoder_env.pcm_buffer_list.first;
    while(element)
    {
        printf("A:%d\r\n",element);
        pcm = (struct decoder_pcm_t *)element;
        element = element->next;
        ke_free((void *)pcm);
    }
#endif
    while(1)
    {
        struct co_list_hdr *element = co_list_pop_front(&decoder_env.pcm_buffer_list);
        if(element == NULL)
            break;
        ke_free((void *)element);
    }

    if(decoder_env.decoder_context != NULL)
    {
        ke_free((void *)decoder_env.decoder_context);
        decoder_env.decoder_context = NULL;
    }

    ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);
    speaker_stop_hw();
    decoder_end_func();
    decoder_hold_flag = false;

    return KE_MSG_CONSUMED;
}

static int decoder_wait_end_to_handler(ke_msg_id_t const msgid,
                                       struct ke_timer *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    if(ke_state_get(TASK_DECODER) == DECODER_STATE_WAITING_END)
    {
        DEC_LOG("WAITTING_END\r\n");
        printf("A1:%d\r\n",co_list_is_empty(&decoder_env.pcm_buffer_list));
        if(co_list_is_empty(&decoder_env.pcm_buffer_list))
        {
            printf("wtd1\r\n");
            NVIC_DisableIRQ(I2S_IRQn);
            if(decoder_env.decoder_context != NULL)
            {
                ke_free((void *)decoder_env.decoder_context);
                decoder_env.decoder_context = NULL;
            }
            ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);
            decoder_end_func();
        }
        else
        {
            printf("wtd2\r\n");
            ke_timer_set(DECODER_EVENT_WAIT_END_TO, TASK_DECODER, 3);
        }
    }

    return KE_MSG_CONSUMED;
}

const struct ke_msg_handler decoder_default_state[] =
{
    {DECODER_EVENT_PREPARE,     (ke_msg_func_t)decoder_prepare_handler},
    {DECODER_EVENT_NEXT_FRAME,  (ke_msg_func_t)decoder_play_next_frame_handler},
    {DECODER_EVENT_STOP,        (ke_msg_func_t)decoder_stop_handler},
    {DECODER_EVENT_WAIT_END_TO, (ke_msg_func_t)decoder_wait_end_to_handler}
};

/* Specifies the message handlers that are common to all states. */
const struct ke_state_handler decoder_default_handler = KE_STATE_HANDLER(decoder_default_state);

/* Defines the place holder for the states of all the task instances. */
ke_state_t decoder_state[1];

static const struct ke_task_desc TASK_DESC_DECODER = {NULL, &decoder_default_handler,
           decoder_state, DECODER_STATE_MAX, 1
};

void decoder_task_init(void)
{
    ke_task_create(TASK_DECODER, &TASK_DESC_DECODER);

    ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);

    decoder_env.decoder_context = NULL;
}

#endif









#ifdef CFG_DEC_ADPCM_MS


#include "arch.h"
#define DEC_DBG FR_DBG_OFF
#define DEC_LOG FR_LOG(DEC_DBG)

#define DEC_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %s \n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);
static uint8_t stop_flag = 0;


static bool decoder_hold_flag = false;
struct decoder_env_t decoder_env;

void decoder_start(uint32_t start, uint32_t end, uint32_t tot_data_len, uint16_t frame_len, uint32_t start_offset, uint8_t type)
{
    struct decoder_prepare_t *param = KE_MSG_ALLOC(DECODER_EVENT_PREPARE, TASK_DECODER,
                                      TASK_NONE, decoder_prepare_t);

    param->data_start = start;
    param->data_end = end;
    param->store_type = type;
    param->tot_data_len = tot_data_len;
    param->start_offset = start_offset;
    param->frame_len = frame_len;
    DEC_LOG("s:%x,e:%x\r\n",start,end);

    ke_msg_send((void *)param);
    speaker_start_hw();
    decoder_hold_flag = false;
}

void decoder_stop(void)
{
    DEC_LOG("decoder_stop\r\n");
    //printf("d_s\r\n");
    struct decoder_stop_t *param = KE_MSG_ALLOC(DECODER_EVENT_STOP, TASK_DECODER,
                                   TASK_NONE, decoder_stop_t);
    ke_msg_send((void *)param);
}

void decoder_play_next_frame(void)
{
    struct decoder_play_next_frame_t *param = KE_MSG_ALLOC(DECODER_EVENT_NEXT_FRAME, TASK_DECODER,
            TASK_NONE, decoder_play_next_frame_t);
    ke_msg_send((void *)param);
}

struct adpcm_fmt_t
{
    uint32_t len;
    uint16_t type;
    uint16_t channels;
    uint32_t sample_rate;
    uint32_t bytes_per_sec;
    uint16_t frame_size;
    uint16_t bits_per_sample;
    uint16_t extra_size;
};

uint16_t decoder_calc_adpcm_ms_frame_len(uint8_t **header_org)
{
//    struct adpcm_fmt_t *fmt;
    uint32_t len;
    uint8_t *header = *header_org;
    uint16_t frame_size;

    if(memcmp(header, "RIFF", 4) == 0)
    {
        header += 12;
        if(memcmp(header, "fmt ", 4) == 0)
        {
            header += 4;
            len = header[0];
            len |= (header[1] << 8);
            len |= (header[2] << 16);
            len |= (header[3] << 24);

            frame_size = header[16];
            frame_size |= (header[17] << 8);
            header += 4;
            header += len;
            while(memcmp(header, "data", 4) != 0)
            {
                header += 4;
                len = header[0];
                len |= (header[1] << 8);
                len |= (header[2] << 16);
                len |= (header[3] << 24);
                header += (len + 4);
            }
            header += 8;
            DEC_LOG("decoder_calc_adpcm_ms_frame_len: %08x, %08x.\r\n", header, *header_org);
            *header_org = header;
            return frame_size;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

static int decoder_prepare_handler(ke_msg_id_t const msgid,
                                   struct decoder_prepare_t *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id)
{
    ke_state_t state;
    enum ke_msg_status_tag status = KE_MSG_CONSUMED;
//    uint32_t size;
    ADPCMContext *context;

    state = ke_state_get(TASK_DECODER);
    switch(state)
    {
        case DECODER_STATE_IDLE:
            decoder_env.decoder_context = ke_malloc(sizeof(ADPCMContext), KE_MEM_NON_RETENTION);
            context = (ADPCMContext *)decoder_env.decoder_context;
            context->channel = 1;
            context->block_align = param->frame_len;
            decoder_env.data_start = param->data_start;
            decoder_env.data_end = param->data_end;
            decoder_env.current_pos = param->data_start + param->start_offset;
            decoder_env.tot_data_len = param->tot_data_len;
            decoder_env.store_type = param->store_type;
            decoder_env.data_processed_len = 0;
            decoder_env.frame_len = param->frame_len;
            stop_flag = 0;

            DEC_LOG("preparing,fram_len:%d\r\n",decoder_env.frame_len);
            co_list_init(&decoder_env.pcm_buffer_list);
            decoder_env.pcm_buffer_counter = 0;
            decoder_play_next_frame();
            ke_state_set(TASK_DECODER, DECODER_STATE_BUFFERING);
            break;
        case DECODER_STATE_BUFFERING:
        case DECODER_STATE_PLAYING:
            status = KE_MSG_CONSUMED;
            break;
        case DECODER_STATE_WAITING_END:
            status = KE_MSG_SAVED;
            break;
        default:
            break;
    }

    return status;
}
void  __attribute__((weak)) decoder_end_func(void)
{
    ;
}
void  __attribute__((weak)) decoder_half_processed(void)
{
    ;
}
void decoder_update_tot_data_len(uint32_t len)
{
    decoder_env.tot_data_len = len;
}
bool decoder_get_hold_status(void)
{
    return decoder_hold_flag;
}
void decoder_set_hold_status(bool flag)
{
    decoder_hold_flag = flag;
}

static int decoder_play_next_frame_handler(ke_msg_id_t const msgid,
        struct decoder_play_next_frame_t *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    ke_state_t state;
    uint8_t *buffer;
    uint32_t pcm_len;
    uint32_t streamlen;
    struct decoder_pcm_t *pcm_frame;
    // CPU_SR cpu_sr;

    state = ke_state_get(TASK_DECODER);
    switch(state)
    {
        case DECODER_STATE_IDLE:
            break;
        case DECODER_STATE_BUFFERING:
        case DECODER_STATE_PLAYING:
#if 1

            if(decoder_env.store_type == DECODER_STORE_TYPE_RAM)
            {
                buffer = (uint8_t *)decoder_env.current_pos;
            }
            else
            {
                // TBD
            }

            pcm_frame = (struct decoder_pcm_t *)ke_malloc(sizeof(struct decoder_pcm_t) + 2*(decoder_env.frame_len+8)*2, KE_MEM_NON_RETENTION);
            if(pcm_frame == NULL)
            {
                return KE_MSG_SAVED;
            }

            pcm_len = 2*(decoder_env.frame_len+8)*2;
            streamlen = decoder_env.frame_len;
            DEC_LOG("playing:%d\r\n",streamlen);
            //printf("p:%d\r\n",streamlen);
            DEC_LOG("sbc_buff[0] = %02x, %02x.\r\n", buffer[0], buffer[1]);

            if(decoder_hold_flag == false)
            {
                adpcm_decode_frame(decoder_env.decoder_context, (short *)&pcm_frame->pcm_data[0], (int *)&pcm_len, buffer, decoder_env.frame_len);
            }
            else
                memset((uint8_t *)&pcm_frame->pcm_data[0],0x0,pcm_len);

            if( 1 )
            {
                pcm_frame->pcm_size = pcm_len >> 1;
                pcm_frame->pcm_offset = 0;
                GLOBAL_INT_DISABLE();
                co_list_push_back(&decoder_env.pcm_buffer_list,&pcm_frame->list);
                GLOBAL_INT_RESTORE();
                DEC_LOG("pcmlen=%d,%d\r\n",pcm_len,streamlen);
                decoder_env.pcm_buffer_counter++;

                if(state == DECODER_STATE_BUFFERING)
                {
                    if (decoder_env.pcm_buffer_counter > 2)
                    {
                        ke_state_set(TASK_DECODER, DECODER_STATE_PLAYING);
                        NVIC_EnableIRQ(I2S_IRQn);
                    }
                    else
                    {
                        decoder_play_next_frame();
                    }
                }

                if(decoder_hold_flag == false)
                {
                    decoder_env.current_pos += decoder_env.frame_len;
                    decoder_env.data_processed_len += decoder_env.frame_len;
                    if( (decoder_env.tot_data_len - decoder_env.data_processed_len) < (1024) )
                    {
                        decoder_half_processed();
                    }

                    if( (decoder_env.tot_data_len - decoder_env.data_processed_len)  < decoder_env.frame_len )
                    {
                        if(decoder_hold_flag == false)
                        {
                            //printf("y");
                            ke_state_set(TASK_DECODER, DECODER_STATE_WAITING_END);
                            //ke_timer_set(DECODER_EVENT_WAIT_END_TO, TASK_DECODER, 3);
                        }
                    }
                    if(decoder_env.current_pos >= decoder_env.data_end)
                    {
                        //printf("z");
                        decoder_env.current_pos = decoder_env.data_start;
                    }
                }

                if(decoder_env.store_type == DECODER_STORE_TYPE_FLASH)
                {
                    // TBD, free buffer
                }
            }
            else
            {
                ke_free(pcm_frame);
                NVIC_EnableIRQ(I2S_IRQn);
                decoder_stop();
            }
#endif
            break;
        case DECODER_STATE_WAITING_END:
            DEC_LOG("STATE_WAITING_END\r\n");
            //if(decoder_env.pcm_buffer_list.first == NULL)
            if(decoder_env.pcm_buffer_counter == 0)
            {
                if(stop_flag == 0)
                {
                    decoder_stop();
                    stop_flag = 1;
                    //ke_timer_set(APP_PLAY_TONE_INTERVAL, TASK_APP, 100);
                }
            }
            break;
        default:
            break;
    }

    return KE_MSG_CONSUMED;
}

static int decoder_stop_handler(ke_msg_id_t const msgid,
                                struct decoder_stop_t *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
    // struct co_list_hdr *element;
    // struct decoder_pcm_t *pcm;
    // TBD, disable codec
    NVIC_DisableIRQ(I2S_IRQn);

#if 0
    element = decoder_env.pcm_buffer_list.first;
    while(element)
    {
        printf("A:%d\r\n",element);
        pcm = (struct decoder_pcm_t *)element;
        element = element->next;
        ke_free((void *)pcm);
    }
#endif

    while(1)
    {
        struct co_list_hdr *element = co_list_pop_front(&decoder_env.pcm_buffer_list);
        if(element == NULL)
            break;
        ke_free((void *)element);
    }

    if(decoder_env.decoder_context != NULL)
    {
        ke_free((void *)decoder_env.decoder_context);
        decoder_env.decoder_context = NULL;
    }

    ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);
    speaker_stop_hw();
    decoder_end_func();
    decoder_hold_flag = false;

    return KE_MSG_CONSUMED;
}

static int decoder_wait_end_to_handler(ke_msg_id_t const msgid,
                                       struct ke_timer *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    if(ke_state_get(TASK_DECODER) == DECODER_STATE_WAITING_END)
    {
        DEC_LOG("WAITTING_END\r\n");
        printf("A1:%d\r\n",co_list_is_empty(&decoder_env.pcm_buffer_list));
        if(co_list_is_empty(&decoder_env.pcm_buffer_list))
        {
            printf("wtd1\r\n");
            NVIC_DisableIRQ(I2S_IRQn);
            if(decoder_env.decoder_context != NULL)
            {
                ke_free((void *)decoder_env.decoder_context);
                decoder_env.decoder_context = NULL;
            }
            ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);
            decoder_end_func();
        }
        else
        {
            printf("wtd2\r\n");
            ke_timer_set(DECODER_EVENT_WAIT_END_TO, TASK_DECODER, 3);
        }
    }

    return KE_MSG_CONSUMED;
}

const struct ke_msg_handler decoder_default_state[] =
{
    {DECODER_EVENT_PREPARE,     (ke_msg_func_t)decoder_prepare_handler},
    {DECODER_EVENT_NEXT_FRAME,  (ke_msg_func_t)decoder_play_next_frame_handler},
    {DECODER_EVENT_STOP,        (ke_msg_func_t)decoder_stop_handler},
    {DECODER_EVENT_WAIT_END_TO, (ke_msg_func_t)decoder_wait_end_to_handler}
};

/* Specifies the message handlers that are common to all states. */
const struct ke_state_handler decoder_default_handler = KE_STATE_HANDLER(decoder_default_state);

/* Defines the place holder for the states of all the task instances. */
ke_state_t decoder_state[1];

static const struct ke_task_desc TASK_DESC_DECODER = {NULL, &decoder_default_handler,
           decoder_state, DECODER_STATE_MAX, 1
};

void decoder_task_init(void)
{
    ke_task_create(TASK_DECODER, &TASK_DESC_DECODER);

    ke_state_set(TASK_DECODER, DECODER_STATE_IDLE);

    decoder_env.decoder_context = NULL;
}

#endif

bool decoder_is_idle(void)
{
    return (ke_state_get(TASK_DECODER) == DECODER_STATE_IDLE );
}

