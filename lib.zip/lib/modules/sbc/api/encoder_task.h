#ifndef _ENCODER_TASK_H
#define _ENCODER_TASK_H

#include <stdint.h>

#include "ke_task.h"
#include "sbc.h"
#include "co_list.h"

#define ENCODER_MAX_BUFFERING_BLOCK_COUNT       10

enum encoder_state_t
{
    ENCODER_STATE_IDLE,
    ENCODER_STATE_BUSY,
    ENCODER_STATE_MAX,
};

enum encoder_event_t
{
    ENCODER_EVENT_NEXT_FRAME = KE_FIRST_MSG(TASK_ID_ENCODER),
};

struct pcm_data_t
{
    struct co_list_hdr node;
    //int16_t data[1];
    uint8_t  data[__ARRAY_EMPTY];
};

struct encoder_env_t
{
    sbc_t *sbc;

    struct co_list pcm_data_list;

    struct pcm_data_t *tmp_pcm;
    uint16_t tmp_pcm_write_pos;

    uint8_t *out_buffer;
    uint16_t send_read_pos;
    uint16_t encode_write_pos;
    uint16_t reserved_space;

    uint16_t block_size;
    uint16_t frame_size;
};

void encode_start(void);
void encode_stop(void);
void encode_store_pcm_data(uint16_t *data, uint8_t len);
void encoder_task_init(void);

#endif  //_ENCODER_TASK_H

