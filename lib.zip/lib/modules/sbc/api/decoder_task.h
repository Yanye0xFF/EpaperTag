#ifndef _DECODER_TASK_H
#define _DECODER_TASK_H

#include <stdint.h>

#include "co_list.h"
#include "ke_task.h"

enum decoder_state_t
{
    DECODER_STATE_IDLE,
    DECODER_STATE_BUFFERING,
    DECODER_STATE_PLAYING,
    DECODER_STATE_WAITING_END,

    DECODER_STATE_MAX,
};

enum decoder_event_t
{
    DECODER_EVENT_PREPARE = KE_FIRST_MSG(TASK_ID_DECODER),
    DECODER_EVENT_NEXT_FRAME,
    DECODER_EVENT_STOP,
    DECODER_EVENT_WAIT_END_TO,
};

#define DECODER_STORE_TYPE_RAM      0
#define DECODER_STORE_TYPE_FLASH    1

struct decoder_stop_t
{
    uint8_t null;
};

struct decoder_play_next_frame_t
{
    uint8_t null;
};

struct decoder_prepare_t
{
    uint32_t data_start;
    uint32_t data_end;
    uint32_t tot_data_len;
    uint32_t start_offset;
    uint8_t store_type;
#ifdef CFG_DEC_ADPCM_MS
    uint16_t frame_len;
#endif
};

struct decoder_env_t
{
    struct co_list pcm_buffer_list;

    void * decoder_context;
    uint32_t data_start;
    uint32_t data_end;
    uint32_t tot_data_len;
    uint32_t data_processed_len;

    uint32_t current_pos;
    uint16_t frame_len;
    uint8_t store_type;
    uint8_t pcm_buffer_counter;
};

struct decoder_pcm_t
{
    struct co_list_hdr list;
    uint16_t pcm_size;
    uint16_t pcm_offset;
#ifdef CFG_DEC_SBC
    uint32_t pcm_data[1];
#endif
#ifdef CFG_DEC_ADPCM_MS
    uint16_t pcm_data[1];
#endif
};
__packed struct sbc_header_t
{
    uint8_t reserved;
    __packed struct
    {
        uint8_t subband:1;
        uint8_t reserved:1;
        uint8_t m_s:2;
        uint8_t block:2;
        uint8_t reserved2:2;
    } c;
    uint8_t bitpool;
};

extern struct decoder_env_t decoder_env;
void decoder_task_init(void);
#ifdef CFG_DEC_SBC
uint16_t decoder_calc_sbc_frame_len(struct sbc_header_t *header);
#endif
#ifdef CFG_DEC_ADPCM_MS
uint16_t decoder_calc_adpcm_ms_frame_len(uint8_t **header_org);
#endif
#ifdef CFG_DEC_SBC
void decoder_start(uint32_t start, uint32_t end, uint32_t tot_data_len, uint32_t start_offset, uint8_t type);
#endif
#ifdef CFG_DEC_ADPCM_MS
void decoder_start(uint32_t start, uint32_t end, uint32_t tot_data_len, uint16_t frame_len, uint32_t start_offset, uint8_t type);
#endif
void decoder_stop(void);
void decoder_play_next_frame(void);
void decoder_update_tot_data_len(uint32_t len);
bool decoder_get_hold_status(void);
void decoder_set_hold_status(bool flag);

bool decoder_is_idle(void);


#endif  //_DECODER_TASK_H
