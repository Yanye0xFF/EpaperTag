#ifndef __ENC_SBC_H
#define __ENC_SBC_H


void mic_ini(void);
void mic_start(void);
void mic_stop(void);


#ifndef MIC_TEST_ENABLE
#define MIC_TEST_ENABLE (0)
#endif

#if MIC_TEST_ENABLE
void test_mic(void);
#endif

#endif /* __ENC_SBC_H */
