#ifndef __DEC_SBC_H
#define __DEC_SBC_H


void speaker_ini(void);
void speaker_start(void);
void speaker_stop(void);
void speaker_stop_hw(void);
void speaker_start_hw(void);


#ifndef SPEAKER_TEST_ENABLE
#define SPEAKER_TEST_ENABLE (0)
#endif


#if SPEAKER_TEST_ENABLE
void test_speaker(void);



void test_sotre_sbc_to_flash(void);

void test_speaker_from_flash(void);
void del_sbc_from_flash(void);


#endif

#endif /* __DEC_SBC_H */
