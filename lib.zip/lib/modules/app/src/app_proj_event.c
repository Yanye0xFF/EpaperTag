/**
****************************************************************************************
*
* @file app_template_proj.c
*
* @brief Template project source code .
*
* Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
*
* <bluetooth.support@diasemi.com> and contributors.
*
****************************************************************************************
*/

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */
#include "rwip_config.h"             // SW configuration

#if (BLE_APP_PRESENT)

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "arch.h"

#include "app.h"
#include "app_sec.h"
#include "app_proj_event.h"

#include "gattc_task.h"

#include "co_math.h"                 // Common Maths Definition
#if (NVDS_SUPPORT)
#include "nvds.h"                    // NVDS Definitions
#endif //(NVDS_SUPPORT)


#include "app_batt.h"
#include "co_bt.h"
#include "prf.h"
#include "jump_table.h"
#include "patch.h"
#include "app_otas.h"
#include "gapc_task.h"

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
*/

/**
****************************************************************************************
* @brief app_api function. Project's actions start from here
*
* @return void.
****************************************************************************************
*/


void app_init_ind_func(void)
{
//APP_LOG("\r\napp_init_ind\r\n");

    if(app_env.func[APP_EVT_ID_INIT] !=NULL)
        app_env.func[APP_EVT_ID_INIT](NULL);
}


void app_device_ready_ind_func(void)
{
    APP_LOG("\r\ndevice_is_ready\r\n");

    if(app_env.func[APP_EVT_ID_DEVICE_IS_READY] !=NULL)
        app_env.func[APP_EVT_ID_DEVICE_IS_READY](NULL);
    else
        app_reset_app();
}



#include "watchdog.h"
void app_reset_complete_ind_func(void)
{
    APP_LOG("\r\nreset_complete\r\n");
    os_wdt_begins();
    set_patch7_func_idx(PATCH7_hci_acl_data_tx_handler);
    void user_proj_main(void);
    user_proj_main();
    /*
        if(app_env.func[APP_EVT_ID_RESET_COMPLETED] !=NULL)
            app_env.func[APP_EVT_ID_RESET_COMPLETED](NULL);
        else
            appm_set_dev_configuration(NULL);
    */
}

/**
 ****************************************************************************************
 * @brief app_api function. Called upon device's configuration completion
 *
 * @return void.
 ****************************************************************************************
*/


void app_set_dev_config_complete_ind_func(void)
{
    APP_LOG("\r\ndev_cfg complete\r\n");

    if(app_env.func[APP_EVT_ID_DEV_CFG_COMPLETED] !=NULL)
        app_env.func[APP_EVT_ID_DEV_CFG_COMPLETED](NULL);
    else
    {
        if (appm_add_svc())
        {
            ;
        }
    }
    return;
}

/**
 ****************************************************************************************
 * @brief app_api function. Handles Database creation. Start application.
 *
 * @return void.
 ****************************************************************************************
*/
void app_svc_added_ind_func(struct gapm_profile_added_ind *param)
{
    APP_LOG("\r\nSVC added\r\n");

//just for OTA bug fix
#if (BLE_APP_OTAS)
    if(param->prf_task_id == TASK_ID_OTAS)
    {
        for(uint8_t i = 0; i < __jump_table.prf_max ; i++)
        {
#include "otas.h"
            if(prf_env.prf[i].id == TASK_ID_OTAS)
            {
                struct otas_env_tag* otas_env = (struct otas_env_tag*) prf_env.prf[i].env;
                for(uint8_t j = 0; j<OTAS_IDX_MAX ; j++)
                    otas_env->env[j] = NULL;
                break;
            }
        }
    }
#endif

    if(app_env.func[APP_EVT_ID_SVC_ADDED] !=NULL)
        app_env.func[APP_EVT_ID_SVC_ADDED]( (void *)param );
}


void app_db_init_complete_ind_func(void)
{
    APP_LOG("\r\nCDB complete\r\n");

    if(app_env.func[APP_EVT_ID_DB_ADDED] !=NULL)
        app_env.func[APP_EVT_ID_DB_ADDED](NULL);
}

#include "gapc.h"
//For slave mode ,recvd  con_req
void app_connection_req_ind_func(uint8_t conidx,struct gapc_connection_req_ind const *arg)
{
#ifndef REMOVE_CODE_IN_MESH
    struct conn_peer_param param;
    param.conidx = conidx;
    memcpy(param.peer_addr.addr,arg->peer_addr.addr,BD_ADDR_LEN);
    param.addr_type = arg->peer_addr_type;
    param.con_interval = arg->con_interval;
    param.con_latency = arg->con_latency;
    param.sup_to = arg->sup_to;
    app_env.con_param.con_interval = arg->con_interval;
    app_env.con_param.con_latency = arg->con_latency;
    app_env.con_param.sup_to = arg->sup_to;
    // gattc_set_mtu(conidx,27);


#if (BLE_APP_OTAS)
#include "app_otas.h"
    app_otas_enable_prf(conidx);
#endif
    __jump_table.wakeup_to_poweron_offset = 0;
    APP_LOG("\r\nSlave Role[%d] Connected\r\n",conidx);
    gapc_env[conidx]->features = GAPC_ENCRYPT_FEAT_MASK |
                                 //GAPC_CONN_PARAM_REQ_FEAT_MASK |    //4.2 features
                                 GAPC_EXT_REJECT_IND_FEAT_MASK |
                                 GAPC_SLAVE_FEAT_EXCH_FEAT_MASK |
                                 GAPC_LE_PING_FEAT_MASK;
    if(app_env.func[APP_EVT_ID_SLAVER_CONNECTED] !=NULL)
        app_env.func[APP_EVT_ID_SLAVER_CONNECTED]((void *)&param);
#endif
}


void *get_stored_info_req(uint8_t info_type)
{
    //void *value_addr = NULL;
    if(app_env.func[APP_EVT_ID_REQ_INFO] !=NULL)
    {
        store_infot_t tmp;
        tmp.info_type = info_type;
        app_env.func[APP_EVT_ID_REQ_INFO]((void*)&tmp);
        //app_env.func[APP_EVT_ID_REQ_INFO]((void*)&value_addr);
        //return value_addr;
        return (tmp.buf);
    }
    else
    {
        printf("NOTE:need register func,id:APP_EVT_ID_REQ_INFO !!!\r\n");
        while(1);
        //return NULL;//(void *)mi_controller_get_store_info(info_type);
    }
}

void app_connection_paring_info_ind_func(void * buf,uint32_t len,uint8_t info_type)
{
    if(app_env.func[APP_EVT_ID_GOT_INFO] !=NULL)
    {
        store_infot_t tmp ;
        tmp.buf = buf;
        tmp.len = len;
        tmp.info_type = info_type;
        app_env.func[APP_EVT_ID_GOT_INFO]((void*)&tmp);
    }
    else
    {
        printf("NOTE:need register func,id:APP_EVT_ID_GOT_INFO !!!\r\n");
        while(1);
        //mi_controller_store_info(buf,len,info_type);
    }
}


//For slave mode , encryed.
void app_connection_slave_encrypted_ind_func(uint8_t conidx)
{
    APP_LOG("\r\nSlave Role[%d] encrypted\r\n",conidx);
    if(app_env.func[APP_EVT_ID_SLAVER_ENCRYPTED] !=NULL)
        app_env.func[APP_EVT_ID_SLAVER_ENCRYPTED]((void*)&conidx);
    else
    {
        ;
    }
}


/**
 ****************************************************************************************
 * @brief app_api function. Project's actions in app_disconnect
 *
 * @param[in] taskid     App task's id.
 * @param[in] param      Received gapc_disconnect_ind msg.
 *
 * @return void.
 ****************************************************************************************
*/
void app_disconnect_ind_func(ke_task_id_t task_id, struct gapc_disconnect_ind const *param)
{
#ifndef REMOVE_CODE_IN_MESH
    uint8_t state = ke_state_get(task_id);
    app_env.param_update_on_going = false;
    app_env.encrypted = false;
#if (BLE_APP_OTAS)
#include "app_otas.h"
    app_otas_clr_buffed_pkt();
#endif

    APP_LOG("\r\nDisConnected[%d],reason(ll code):0x%02X\r\n",param->conidx,param->reason);

    if(app_env.func[APP_EVT_ID_DISCONNECTED] !=NULL)
        app_env.func[APP_EVT_ID_DISCONNECTED]((void *)param);
    else
    {
#if (!BLE_APP_HID)
        //appm_start_advertising(NULL);
#endif //(!BLE_APP_HID)
    }
#endif
}


/**
 ****************************************************************************************
 * @brief app_api function. Called upon connection param's update rejection
 *
 * @param[in] status        Error code
 *
 * @return void.
 ****************************************************************************************
*/
void app_update_params_rejected_ind_func(uint8_t conidx,uint8_t status)
{
    app_env.param_update_on_going = false;
    struct conidx_status cs;
    cs.conidx = conidx;
    cs.status = status;
    //                appm_disconnect();
    ASSERT_INFO(0, status, APP_PARAM_UPD);
    APP_LOG("\r\nupdate_params_rejected[%d],status(hl code):0x%02X\r\n",conidx,status);
    if(app_env.func[APP_EVT_ID_PARAM_UPDATE_REJECTED] !=NULL)
        app_env.func[APP_EVT_ID_PARAM_UPDATE_REJECTED]((void *)&cs);
}

/**
 ****************************************************************************************
 * @brief app_api function. Called upon connection param's update completion
 *
 * @return void.
 ****************************************************************************************
*/
void app_update_params_update_ind_func(uint8_t conidx,struct gapc_param_updated_ind *param)
{
    app_env.param_update_on_going = false;
    struct gapc_param_updated_ind1 ind1;
    ind1.conidx = conidx;
    memcpy( (uint8_t *)&(ind1.ind),param,sizeof(struct gapc_param_updated_ind) );
    memcpy( (uint8_t *)&app_env.con_param,param,sizeof(struct gapc_param_updated_ind) );

    APP_LOG("p_up:%d,%d,%d\r\n",ind1.ind.con_interval,ind1.ind.con_latency,ind1.ind.sup_to);
    if(app_env.func[APP_EVT_ID_PARAM_UPDATE_IND] !=NULL)
        app_env.func[APP_EVT_ID_PARAM_UPDATE_IND]((void *)&ind1);
}

void app_update_params_complete_ind_func(uint8_t conidx)
{
    app_env.param_update_on_going = false;

    /**************************************************
    Handle connection parameters update event
    ***************************************************/
    //APP_LOG("\r\nupdate_params_completed \r\n");
    if(app_env.func[APP_EVT_ID_PARAM_UPDATED] !=NULL)
        app_env.func[APP_EVT_ID_PARAM_UPDATED]((void *)&conidx);
}

/**
 ****************************************************************************************
 * @brief app_api function. Handles undirect advertising completion.
 *
 * @param[in] status        Command complete message status
 *
 * @return void.
 ****************************************************************************************
*/

void app_adv_complete_ind_func(struct gapm_cmp_evt const *param)
{
    /**************************************************
    Handle undirected advirtising complete event
    ***************************************************/
    APP_LOG("adv[gap_op:%d] end, status(hl code):0x%02X\r\n",param->operation,param->status);
    if(app_env.func[APP_EVT_ID_ADV_END] !=NULL)
        app_env.func[APP_EVT_ID_ADV_END]((void *)param);

}


/**
 ****************************************************************************************
 * @brief app_api function. Handles scan procedure completion.
 *
 * @return void.
 ****************************************************************************************
*/

void app_scanning_completed_ind_func(uint8_t status)
{
    APP_LOG("\r\nscan done,status(hl code):0x%02X\r\n",status);
    if(app_env.func[APP_EVT_ID_SCAN_COMPLETED] !=NULL)
        app_env.func[APP_EVT_ID_SCAN_COMPLETED]((void *)&status);

}

/**
 ****************************************************************************************
 * @brief app_api function. Handles reception of gapm_adv_report_ind msg.
 *
 * @param[in] param     gapm_adv_report_ind message
 *
 * @return void.
 ****************************************************************************************
*/

void app_adv_report_ind_func(struct gapm_adv_report_ind *param)
{
    //show_reg2(param->report.adv_addr.addr,BD_ADDR_LEN,APP_DBG);
    APP_LOG("addr_type:%d,adv_rpt,rssi:%d,evt_typ:%d\r\n",param->report.adv_addr_type
            ,(int8_t)(param->report.rssi),param->report.evt_type);

    if(app_env.func[APP_EVT_ID_ADV_REPORT] !=NULL)
    {
        app_env.func[APP_EVT_ID_ADV_REPORT](param);
    }
    /*
    else
    {
        uint8_t dev_name[20];

        uint8_t pos = 0;
        uint8_t elem_len = 0;
        uint8_t elem_typ = 0;
        uint8_t *elem_buf = NULL;

        while( pos < param->report.data_len)
        {
            elem_len = *(param->report.data + pos);
            elem_typ = *(param->report.data + pos + 1);
            elem_buf = (param->report.data + pos + 2);

            switch( elem_typ )
            {
                case 0x01:

                    break;

                case 0x03:

                    break;
                case 0x09:
                {
                    memset(dev_name,0,sizeof(dev_name));
                    memcpy(dev_name,elem_buf,(elem_len-1));
                    printf("%s\n",dev_name);
                }
                break;

                default:
                    break;
            }
            pos += (elem_len + 1);
        }
    }*/
}





/**
 ****************************************************************************************
 * @brief Handles connection request failure.
 *      for master
 * @return void.
 ****************************************************************************************
*/
void app_get_info_ind_func(uint8_t conidx, void *param,uint8_t operation)
{
    if(operation == GAPC_GET_PEER_FEATURES)
    {
        struct gapc_peer_features_ind1 ind1;
        ind1.conidx = conidx;
        memcpy( (void *)&ind1.ind, param, sizeof(struct gapc_peer_features_ind));
        if(app_env.func[APP_EVT_ID_GOT_PEER_FEATURE] !=NULL)
            app_env.func[APP_EVT_ID_GOT_PEER_FEATURE]((void *)&ind1);
    }
    /*
        else
        {
            switch(operation)
            {
                case GAPC_GET_PEER_FEATURES:
                {
                    struct gapc_peer_features_ind *data = (struct gapc_peer_features_ind *)param;
                    APP_LOG("peer feats ind\r\n");
                    show_reg2((uint8_t *)data,sizeof(struct gapc_peer_features_ind),APP_DBG);
                }
                break;
                default:
                    break;
            }
        }
        */
}

void app_connection_success_ind_func(uint8_t conidx,struct gapc_connection_req_ind const *arg)
{
    struct conn_peer_param param;
#ifndef REMOVE_CODE_IN_MESH
    param.conidx = conidx;
    memcpy(param.peer_addr.addr,arg->peer_addr.addr,BD_ADDR_LEN);
    param.addr_type = arg->peer_addr_type;
    param.con_interval = arg->con_interval;
    param.con_latency = arg->con_latency;
    param.sup_to = arg->sup_to;
    app_env.con_param.con_interval = arg->con_interval;
    app_env.con_param.con_latency = arg->con_latency;
    app_env.con_param.sup_to = arg->sup_to;
#endif


    APP_LOG("\r\nMaster Role[%d] Connected\r\n",conidx);
    __jump_table.wakeup_to_poweron_offset = 307;
    if(app_env.func[APP_EVT_ID_MASTER_CONNECTED] !=NULL)
        app_env.func[APP_EVT_ID_MASTER_CONNECTED]((void *)&param);
    else
    {
        //appm_get_peer_info(conidx,GAPC_GET_PEER_FEATURES);
    }

}

void app_connect_failed_ind_func(uint8_t status)
{
    APP_LOG("\r\nMaster Role Connect fail(hl code):0x%02X\r\n",status);
    if(app_env.func[APP_EVT_ID_MASTER_CONNECT_FAILED] !=NULL)
        app_env.func[APP_EVT_ID_MASTER_CONNECT_FAILED](NULL);
    else
    {
        //  appm_start_scanning(NULL);
    }
}


void app_connection_master_encrypted_ind_func(uint8_t conidx)
{
    APP_LOG("\r\nMaster Role[%d] encrypted\r\n",conidx);
    if(app_env.func[APP_EVT_ID_MASTER_ENCRYPTED] !=NULL)
        app_env.func[APP_EVT_ID_MASTER_ENCRYPTED]((void *)&conidx);
}

void app_connection_master_encrypt_compeleted_ind_func(uint8_t conidx, uint8_t status)
{
    APP_LOG("Master Role encryption compeleted(hl code): 0x%2X\r\n",status);
    struct conidx_status cs;
    cs.conidx = conidx;
    cs.status = status;
    if(app_env.func[APP_EVT_ID_MASTER_ENCRYPT_COMPELETED] !=NULL)
        app_env.func[APP_EVT_ID_MASTER_ENCRYPT_COMPELETED]((void *)&cs);
}

void app_addr_resolve_result_ind_func(uint8_t conidx, uint8_t status, struct gapm_addr_solved_ind const *param)
{
    struct app_addr_solved_result_ind_t ind;
    ind.conidx = conidx;
    ind.status = status;
    ind.param = param;
    if(app_env.func[APP_EVT_ID_ADDR_RESOLVE_RESULT_IND] !=NULL)
        app_env.func[APP_EVT_ID_ADDR_RESOLVE_RESULT_IND]((void *)&ind);
}

#endif  //BLE_APP_PRESENT
/// @} APP
