#include "rwip_config.h"

#if BLE_APP_OTAS
#include <stdint.h>
#include "app.h"                    // Application Definitions
#include "app_api.h"
#include "app_sec.h"                // Application Security Module API
#include "app_task.h"               // Application task definitions
#include "app_otas.h"
#include "user_sys.h"

#include "attm.h"
#include "prf.h"
#include "otas.h"
#include "otas_task.h"
#include "ke_mem.h"
#include "flash.h"
#include "watchdog.h"

struct app_otas_status_t
{
    uint8_t read_opcode;
    uint16_t length;
    uint32_t base_addr;
} app_otas_status;
static uint16_t at_data_idx;

static struct buffed_pkt
{
    uint8_t *buf;
    uint16_t len;   //current length in the buffer
    uint16_t malloced_pkt_num;  //num of pkts
} first_pkt = {NULL,0,0};

extern void uart_finish_transfers(void);

void app_otas_init(void)
{
    app_otas_status.read_opcode = OTA_CMD_NULL;
    at_data_idx = 0;
}

void app_otas_add_otass(void)
{

    struct gapm_profile_task_add_cmd *req = KE_MSG_ALLOC_DYN(GAPM_PROFILE_TASK_ADD_CMD,
                                            TASK_GAPM, TASK_APP,
                                            gapm_profile_task_add_cmd, sizeof(struct otas_db_cfg));
    struct otas_db_cfg *cfg = (struct otas_db_cfg *)&req->param[0];

    // Fill message
    req->operation   = GAPM_PROFILE_TASK_ADD;
    req->sec_lvl     = PERM(SVC_AUTH, ENABLE);
    req->prf_task_id = TASK_ID_OTAS;
    req->app_task    = TASK_APP;
    req->start_hdl   = 0;

    cfg->enable_read = true;

    // Send the message
    ke_msg_send(req);
}

static uint8_t current_conidx = 200;
static uint8_t first_loop = false;
void app_otas_enable_prf(uint8_t conidx)
{
    first_loop = true;
    /*
        //  first_loop = false;
        struct gapc_conn_param conn_param;
        conn_param.intv_min = 6;//6;
        conn_param.intv_max = 6;//6;
        conn_param.latency  = 0;
        conn_param.time_out = 200;//200;
        //  appm_update_param(conidx, &conn_param);
    */
}

//extern uint8_t sbc_avaliable_queue;
//extern void sbc_send_data(void);
static int app_otas_send_data_rsp(ke_msg_id_t const msgid,
                                  struct otas_send_rsp_result const *rsp,
                                  ke_task_id_t const dest_id,
                                  ke_task_id_t const src_id)
{
    if(rsp->status != 0x00)
    {
        printf("error: 0x%02x.\r\n", rsp->status);
    }
    return KE_MSG_CONSUMED;
}


void __attribute__((weak)) ota_change_flash_pin(void)
{
    ;
}
void __attribute__((weak)) ota_recover_flash_pin(void)
{
    ;
}
uint32_t f_checksum = 0;
uint32_t checksum = 0;
uint32_t checksum_minus = 0;
uint32_t f_size = 0;
static int app_otas_recv_data(ke_msg_id_t const msgid,
                              struct otas_recv_data_ind const *ind,
                              ke_task_id_t const dest_id,
                              ke_task_id_t const src_id)
{
    struct app_ota_cmd_hdr_t *cmd_hdr = (struct app_ota_cmd_hdr_t *)&ind->buffer[0];
    struct app_ota_rsp_hdr_t *rsp_hdr;
    uint16_t rsp_data_len = (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);
    if( current_conidx > 10 )
        current_conidx = KE_IDX_GET(src_id);
    if( current_conidx != KE_IDX_GET(src_id) )
        return KE_MSG_CONSUMED;

    if(first_loop)
    {
        first_loop = false;
        struct gapc_conn_param conn_param;

        conn_param.intv_min = 6;
        conn_param.intv_max = 6;
        conn_param.latency  = 0;
        conn_param.time_out = 400;

        appm_update_param(KE_IDX_GET(src_id), &conn_param);
        appm_exc_mtu_cmd(KE_IDX_GET(src_id));
    }
    //static uint32_t slot_payload_len  = 0;
    //printf("[%d]:app_otas_recv_data[%d]: %d. %d\r\n",NOW()-last_now,at_data_idx, ind->length,cmd_hdr->cmd.write_data.length);
    at_data_idx++;
    ota_change_flash_pin();
    wdt_feed();

    switch(cmd_hdr->opcode)
    {
        case OTA_CMD_NVDS_TYPE:
            rsp_data_len += 1;
            break;
        case OTA_CMD_GET_STR_BASE:
            at_data_idx = 0;
            app_otas_clr_buffed_pkt();
            //slot_payload_len = 0;
            rsp_data_len += sizeof(struct storage_baseaddr);
            break;
        case OTA_CMD_READ_FW_VER:
            rsp_data_len += sizeof(struct firmware_version);
            break;
        case OTA_CMD_PAGE_ERASE:
            rsp_data_len += sizeof(struct page_erase_rsp);
            break;
        case OTA_CMD_WRITE_DATA:
            //slot_payload_len += (cmd_hdr->cmd.write_data.length);

            rsp_data_len += sizeof(struct write_data_rsp);
            break;
        case OTA_CMD_READ_DATA:
            rsp_data_len += sizeof(struct read_data_rsp) + cmd_hdr->cmd.read_data.length;
            if(rsp_data_len > OTAS_NOTIFY_DATA_SIZE)
            {
                rsp_data_len = sizeof(struct read_data_rsp) + (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);
                app_otas_status.read_opcode = OTA_CMD_READ_DATA;
                app_otas_status.length = cmd_hdr->cmd.read_data.length;
                app_otas_status.base_addr = cmd_hdr->cmd.read_data.base_address;
            }
            break;
        case OTA_CMD_WRITE_MEM:
            rsp_data_len += sizeof(struct write_mem_rsp);
            break;
        case OTA_CMD_READ_MEM:
            rsp_data_len += sizeof(struct read_mem_rsp) + cmd_hdr->cmd.read_mem.length;
            if(rsp_data_len > OTAS_NOTIFY_DATA_SIZE)
            {
                rsp_data_len = sizeof(struct read_data_rsp) + (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);
                app_otas_status.read_opcode = OTA_CMD_READ_MEM;
                app_otas_status.length = cmd_hdr->cmd.read_data.length;
                app_otas_status.base_addr = cmd_hdr->cmd.read_data.base_address;
            }
            else
            {
                app_otas_status.read_opcode = OTA_CMD_NULL;
            }
            break;
        case OTA_CMD_WRITE_CHECKSUM:
            rsp_data_len += sizeof(struct write_checksum_rsp);
            break;
    }

    struct otas_send_rsp *req = KE_MSG_ALLOC_DYN(OTAS_SEND_RSP,
                                prf_get_task_from_id(TASK_ID_OTAS),
                                TASK_APP,
                                otas_send_rsp,
                                rsp_data_len);
    uint16_t base_length;

    req->conidx = KE_IDX_GET(src_id);
    req->length = rsp_data_len;
    rsp_hdr = (struct app_ota_rsp_hdr_t *)&req->buffer[0];
    rsp_hdr->result = OTA_RSP_SUCCESS;
    rsp_hdr->org_opcode = cmd_hdr->opcode;
    rsp_hdr->length = rsp_data_len - (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);

    //#include "fr_ble_config.h"
#include "system.h"
#define STACK_TMP_TOP_ADDR          0x40003000
#define BOOT_RECV_BUFFER            0x40002000
#define BOOT_SEND_BUFFER            0x40002400
#define APP_LOAD_BASE_ADDR          0x20000000  //vectors and jump_table
#define APP_STORAGE_BASE_ADDR_0     0x00000000
#define APP_STORAGE_BASE_ADDR_1     0x00014000  //80x1024
#define VECTOR_HANDLER_COUNT        52

    switch(cmd_hdr->opcode)
    {
        case OTA_CMD_NVDS_TYPE:
            rsp_hdr->rsp.nvds_type = app_boot_get_storage_type();
            break;
        case OTA_CMD_GET_STR_BASE:
            rsp_hdr->rsp.baseaddr.baseaddr = app_boot_get_curr_storage_base();
            break;
        case OTA_CMD_READ_FW_VER:
            rsp_hdr->rsp.version.firmware_version = app_boot_get_firmwave_version();
            break;
        case OTA_CMD_PAGE_ERASE:
            rsp_hdr->rsp.page_erase.base_address = cmd_hdr->cmd.page_erase.base_address;

#if 1      //for user_data OTA no checking      
            if( app_boot_get_curr_storage_base() == APP_STORAGE_BASE_ADDR_0 )
            {
                if(rsp_hdr->rsp.page_erase.base_address < APP_STORAGE_BASE_ADDR_1)
                {
                    appm_disconnect(KE_IDX_GET(src_id));
                    break;
                }
            }
            else
            {
                if(rsp_hdr->rsp.page_erase.base_address >= APP_STORAGE_BASE_ADDR_1)
                {
                    appm_disconnect(KE_IDX_GET(src_id));
                    break;
                }
            }
#endif
            flash_erase(rsp_hdr->rsp.page_erase.base_address, 0x1000);
            f_size = 0;
            checksum = 0;
            checksum_minus = 0;
            break;
        case OTA_CMD_CHIP_ERASE:
            break;
        case OTA_CMD_WRITE_DATA:
        {
            rsp_hdr->rsp.write_data.base_address = cmd_hdr->cmd.write_data.base_address;
            rsp_hdr->rsp.write_data.length = cmd_hdr->cmd.write_data.length;
            if(rsp_hdr->rsp.write_data.base_address >= USER_FLASH_BASE_ADDR)
            {
                flash_write_with_check( rsp_hdr->rsp.write_data.base_address, rsp_hdr->rsp.write_data.length
                                        ,(uint8_t*)&ind->buffer[0]+(OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN)+sizeof(struct write_data_cmd) );
                break;
            }
            f_size += cmd_hdr->cmd.write_data.length;

            uint32_t new_bin_base = ((app_boot_get_curr_storage_base() == APP_STORAGE_BASE_ADDR_1) ? APP_STORAGE_BASE_ADDR_0 : APP_STORAGE_BASE_ADDR_1);
            if( rsp_hdr->rsp.write_data.base_address == new_bin_base )
            {
                if(first_pkt.buf == NULL)
                {
                    first_pkt.malloced_pkt_num = ROUND(380,rsp_hdr->rsp.write_data.length);
                    //printf("%d,%d\r\n",first_pkt.malloced_pkt_num,rsp_hdr->rsp.write_data.length);
                    first_pkt.buf = ke_malloc(rsp_hdr->rsp.write_data.length * first_pkt.malloced_pkt_num,KE_MEM_NON_RETENTION);
                    uint8_t * tmp = (uint8_t*)&ind->buffer[0]+(OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN)+sizeof(struct write_data_cmd);
                    first_pkt.len = rsp_hdr->rsp.write_data.length;
                    memcpy(first_pkt.buf,tmp,first_pkt.len);
                }
            }
            else
            {
                if( rsp_hdr->rsp.write_data.base_address <= (new_bin_base + rsp_hdr->rsp.write_data.length *(first_pkt.malloced_pkt_num-1)) )
                {
                    if(first_pkt.buf != NULL)
                    {
                        //printf("x:%d,",first_pkt.len);
                        uint8_t * tmp = (uint8_t*)&ind->buffer[0]+(OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN)+sizeof(struct write_data_cmd);
                        memcpy(first_pkt.buf + first_pkt.len,tmp,rsp_hdr->rsp.write_data.length);
                        first_pkt.len += rsp_hdr->rsp.write_data.length;
                        if(first_pkt.len >= rsp_hdr->rsp.write_data.length * first_pkt.malloced_pkt_num)
                        {
                            //printf("y,");
                            //firmware_offset : 264, one pkt must > 264;
                            uint32_t firmware_offset = VECTOR_HANDLER_COUNT*sizeof(uint32_t) + (uint32_t)&((struct jump_table_t *)0)->firmware_version;
                            if( *(uint32_t *)((uint32_t)first_pkt.buf + firmware_offset) <= app_boot_get_firmwave_version() )
                            {
                                uint32_t new_bin_ver = app_boot_get_firmwave_version() + 1;
                                //printf("old_ver:%08X\r\n",*(uint32_t *)((uint32_t)first_pkt.buf + firmware_offset));
                                //printf("new_ver:%08X\r\n",new_bin_ver);
                                checksum_minus = new_bin_ver - *(uint32_t *)((uint32_t)first_pkt.buf + firmware_offset);
                                *(uint32_t *)((uint32_t)first_pkt.buf + firmware_offset) = new_bin_ver;
                            }
                        }
                    }
                }
                else
                    flash_write_with_check( rsp_hdr->rsp.write_data.base_address, rsp_hdr->rsp.write_data.length
                                            ,(uint8_t*)&ind->buffer[0]+(OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN)+sizeof(struct write_data_cmd) );
            }
        }
        break;
        case OTA_CMD_READ_DATA:
            rsp_hdr->rsp.read_data.base_address = cmd_hdr->cmd.read_data.base_address;
            rsp_hdr->rsp.read_data.length = cmd_hdr->cmd.read_data.length;
            base_length = sizeof(struct read_data_rsp) + (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);
            if(rsp_data_len != base_length)
            {
                app_boot_load_data((uint8_t*)rsp_hdr+base_length,
                                   rsp_hdr->rsp.read_data.base_address,
                                   rsp_hdr->rsp.read_data.length);
            }
            break;
        case OTA_CMD_WRITE_MEM:
            rsp_hdr->rsp.write_mem.base_address = cmd_hdr->cmd.write_mem.base_address;
            rsp_hdr->rsp.write_mem.length = cmd_hdr->cmd.write_mem.length;
            memcpy((void *)rsp_hdr->rsp.write_mem.base_address,
                   (uint8_t*)&ind->buffer[0]+(OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN)+sizeof(struct write_data_cmd),
                   rsp_hdr->rsp.write_mem.length);
            break;
        case OTA_CMD_READ_MEM:
            rsp_hdr->rsp.read_mem.base_address = cmd_hdr->cmd.read_mem.base_address;
            rsp_hdr->rsp.read_mem.length = cmd_hdr->cmd.read_mem.length;
            base_length = sizeof(struct read_mem_rsp) + (OTA_HDR_OPCODE_LEN+OTA_HDR_LENGTH_LEN+OTA_HDR_RESULT_LEN);
            if(rsp_data_len != base_length)
            {
                memcpy((uint8_t*)rsp_hdr+base_length,
                       (void *)rsp_hdr->rsp.read_mem.base_address,
                       rsp_hdr->rsp.read_data.length);
            }
            break;
        case OTA_CMD_WRITE_CHECKSUM:
            rsp_hdr->rsp.write_checksum.checksum = cmd_hdr->cmd.write_checksum.checksum;
            f_checksum = cmd_hdr->cmd.write_checksum.checksum;
            //printf("f_chksum:%x\r\n",f_checksum);
            break;
        case OTA_CMD_REBOOT:
            if(first_pkt.buf != NULL)
            {
                uint32_t new_bin_base = ((app_boot_get_curr_storage_base() == APP_STORAGE_BASE_ADDR_1) ? APP_STORAGE_BASE_ADDR_0 : APP_STORAGE_BASE_ADDR_1);
                flash_write_with_check(new_bin_base, first_pkt.len, first_pkt.buf);

                checksum = 0;
                uint32_t offset = 0;
                uint32_t read_len = 0;
                while(offset < f_size)
                {
                    if( (offset + first_pkt.len) > f_size)
                        read_len = (f_size - offset);
                    else
                        read_len =  first_pkt.len;

                    flash_read(new_bin_base + offset, read_len, first_pkt.buf);
                    for(uint32_t i=0; i<read_len; i++)
                        checksum += first_pkt.buf[i];
                    offset += read_len;
                }
                checksum -=checksum_minus;
                //printf("chksum:%x\r\n",checksum);
                //if(f_checksum != checksum)
                //flash_erase(new_bin_base,0x1000);
            }
            uart_finish_transfers();
            app_otas_clr_buffed_pkt();
            sys_soft_reset();
            break;
        default:
            rsp_hdr->result = OTA_RSP_UNKNOWN_CMD;
            break;
    }

    ke_msg_send(req);
    ota_recover_flash_pin();
    return KE_MSG_CONSUMED;
}

static int app_otas_read_data(ke_msg_id_t const msgid,
                              struct otas_read_data_req const *req,
                              ke_task_id_t const dest_id,
                              ke_task_id_t const src_id)
{
    uint16_t length;

    switch(app_otas_status.read_opcode)
    {
        case OTA_CMD_READ_DATA:
        case OTA_CMD_READ_MEM:
            length = app_otas_status.length;
            break;
        default:
            length = 0;
            break;
    }

    struct otas_read_data_rsp *rsp = KE_MSG_ALLOC_DYN(OTAS_READ_DATA_RSP,
                                     prf_get_task_from_id(TASK_ID_OTAS),
                                     TASK_APP,
                                     otas_read_data_rsp,
                                     length);

    rsp->conidx = req->conidx;
    rsp->result = ATT_ERR_NO_ERROR;
    rsp->length = length;

    switch(app_otas_status.read_opcode)
    {
        case OTA_CMD_READ_DATA:
            app_boot_load_data((uint8_t*)&rsp->buffer[0],
                               app_otas_status.base_addr,
                               app_otas_status.length);
            break;
        case OTA_CMD_READ_MEM:
            memcpy((uint8_t*)&rsp->buffer[0], (uint8_t *)app_otas_status.base_addr, app_otas_status.length);
            break;
        default:
            rsp->result = PRF_APP_ERROR;
            break;
    }

    ke_msg_send(rsp);

    app_otas_status.read_opcode = OTA_CMD_NULL;

    return KE_MSG_CONSUMED;
}

void app_otas_clr_buffed_pkt(void)
{
    current_conidx = 200;
    if(first_pkt.buf != NULL)
    {
        first_loop = true;
        ke_free(first_pkt.buf);
        memset(&first_pkt,0x0,sizeof(first_pkt));
    }
}

/*
 * LOCAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Default State handlers definition
const struct ke_msg_handler app_otas_msg_handler_list[] =
{
    {OTAS_RECV_DATA_IND,        (ke_msg_func_t)app_otas_recv_data},
    {OTAS_READ_DATA_REQ,        (ke_msg_func_t)app_otas_read_data},
    {OTAS_SEND_RSP_RESULT,      (ke_msg_func_t)app_otas_send_data_rsp},
};

const struct ke_state_handler app_otas_table_handler =
{&app_otas_msg_handler_list[0], (sizeof(app_otas_msg_handler_list)/sizeof(struct ke_msg_handler))};

#endif //BLE_APP_OTAS
