/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_C_LIB_H_
#define USER_C_LIB_H_
#include <stdint.h>

uint8_t hex4bit_to_ascii_char(uint8_t hex_value);
uint8_t hex4bit_to_big_ascii_char(uint8_t hex_value);

void hex_arr_to_ascii_str(uint8_t *str, const uint8_t hex_arr[],uint8_t arr_len);
void ascii_str_to_hex_arr(uint8_t hex_arr[],uint8_t *str, uint8_t arr_len);
void int_to_ascii_str(uint8_t *str, const uint32_t int_value);
char char2int(const char c);

#endif // USER_C_LIB_H_

