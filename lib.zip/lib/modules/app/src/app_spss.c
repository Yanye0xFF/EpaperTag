/**
****************************************************************************************
*
* @file  app_spss.c
*
* @brief SPS application.
*
* Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
* program includes Confidential, Proprietary Information and is a Trade Secret of
* Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
* unless authorized in writing. All Rights Reserved.
*
* <bluetooth.support@diasemi.com> and contributors.
*
****************************************************************************************
*/

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include <stdlib.h>
#include <stdint.h>
#include <string.h>                 // string manipulation and functions

#include "rwip_config.h"            // SW configuration
#include "app.h"


#if (BLE_APP_SPSS)
#include "app_spss.h"
#include "sps_server_task.h"        // SPS functions
#include "l2cm.h"        // SPS functions

app_callback_func_t spss_recv_data_ind_func = NULL;


void app_spss_add_spsss(void)
{
    struct gapm_profile_task_add_cmd *req = KE_MSG_ALLOC(GAPM_PROFILE_TASK_ADD_CMD,
                                            TASK_GAPM, TASK_APP,
                                            gapm_profile_task_add_cmd);

    // Fill message
    req->operation   = GAPM_PROFILE_TASK_ADD;
    req->sec_lvl     = PERM(SVC_MI, ENABLE) | PERM(SVC_AUTH, NO_AUTH) | PERM_VAL(SVC_UUID_LEN, PERM_UUID_128);
    req->prf_task_id = TASK_ID_SPSS;
    req->app_task    = TASK_APP;
    req->start_hdl   = 0;

    // Send the message
    ke_msg_send(req);
}

/**
 ****************************************************************************************
 * @brief       app_sps_init initialize the required functions
 * @param[in]   void
 * @return      none
 ****************************************************************************************
 */
void app_spss_init(void)
{
    // SPS application initialisation
}

/**
 ****************************************************************************************
 * @brief       app_sps_enable(void) Sends enable message(s) when the connection is made.
 * @param[in]   void
 * @return      none
 ****************************************************************************************
 */
void app_spss_enable_prf(uint8_t conidx)
{
    // Allocate the message
    struct sps_server_enable_req * req = KE_MSG_ALLOC(SPS_SERVER_ENABLE_REQ, prf_get_task_from_id(KE_BUILD_ID(TASK_ID_SPSS, conidx)), TASK_APP, sps_server_enable_req);

    // Fill in the parameter structure
    req->appid = TASK_APP;
    req->conidx = conidx;

    // Send the message
    ke_msg_send(req);
}

/**
 ****************************************************************************************
 * @brief       Send flow control over Bluetooth
 * @param[in]   flow control        (UART_XON or UART_XOFF)
 * @return      none
 ****************************************************************************************
 */
void app_spss_send_ble_flowctrl(uint16_t flowcontrol_freelen)
{
    struct sps_server_send_notify_flow_control_state_req * req = KE_MSG_ALLOC(SPS_SERVER_SEND_FLOW_CONTROL_REQ, prf_get_task_from_id(KE_BUILD_ID(TASK_ID_SPSS, app_env.conidx))
            , TASK_APP,sps_server_send_notify_flow_control_state_req);

    req->conidx = app_env.conidx;
    req->flow_control_free_len = flowcontrol_freelen;

    ke_msg_send(req);
}

void app_spss_send_data(uint8_t conidx, uint8_t *data, uint16_t len)
{
    if(l2cm_get_nb_buffer_available() > 0)
    {
        printf("%d\r\n",l2cm_get_nb_buffer_available() );
        sps_server_tx_data(conidx, data, len);
    }
    else
        printf("x");
}

/**
 ****************************************************************************************
 * @brief       Request data transmission over Bluetooth
 * @return      none
 ****************************************************************************************
 */
void app_init_ble_tx(void)
{
    /*struct sps_server_init_ble_tx_req * req = KE_MSG_ALLOC(SPS_SERVER_INIT_BLE_TX_REQ, TASK_SPS_SERVER, TASK_APP,  sps_server_init_ble_tx_req);

    ke_msg_send(req);*/
}

static int app_spss_tmp_handler(ke_msg_id_t const msgid,
                                void const *rsp,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
    return KE_MSG_CONSUMED;
}

static int app_spss_rx_data_ind_handler(ke_msg_id_t const msgid,
                                        struct sps_server_rx_data_ind const *ind,
                                        ke_task_id_t const dest_id,
                                        ke_task_id_t const src_id)
{
    uint8_t i;

    if(spss_recv_data_ind_func != NULL)
        spss_recv_data_ind_func((void *)ind);
    else
    {
        printf("RX: ");
        for(i=0; i<ind->length; i++)
        {
            printf("0x%02x, ", ind->data[i]);
        }
        printf("\r\n");
    }

    return KE_MSG_CONSUMED;
}

/*
 * LOCAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Default State handlers definition
const struct ke_msg_handler app_spss_msg_handler_list[] =
{
    {SPS_SERVER_ENABLE_CFM,             (ke_msg_func_t)app_spss_tmp_handler},
    {SPS_SERVER_REQ_FLOW_CONTROL_IND,   (ke_msg_func_t)app_spss_tmp_handler},
    {SPS_SERVER_RX_DATA_IND,            (ke_msg_func_t)app_spss_rx_data_ind_handler},
};

const struct ke_state_handler app_spss_table_handler =
{&app_spss_msg_handler_list[0], (sizeof(app_spss_msg_handler_list)/sizeof(struct ke_msg_handler))};

#endif // (BLE_APP_SPSS)

/// @} APP
