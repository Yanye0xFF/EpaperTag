#include "rwip_config.h"
#include "prf.h"

//#include "otas_user.h"

//#include "diss.h"
//#include "bass.h"
#include "sps_server.h"
//#include "sps_client.h"
#include "rtcts.h"
//#include "prf_template.h"

//#include "hogpd.h"
#include "rwprf_config.h"

#include "hogpd_user.h"
#include "otas_user.h"

#if BLE_APP_MESH
extern const struct prf_task_cbs* m_al_prf_itf_get(void);
#endif

const struct prf_task_cbs *user_prf_itf_get_imp(uint8_t task_id)
{
    const struct prf_task_cbs* prf_cbs = NULL;

    switch(task_id)
    {
#if BLE_SERIAL_SERVER
        case TASK_ID_SERIALS:
            prf_cbs = serials_prf_itf_get();
            break;
#endif
#if (BLE_HID_DEVICE)
        case TASK_ID_HOGPD:
            prf_cbs = hogpd_prf_itf_get_user();
            break;
#endif // (BLE_HID_DEVICE)

#if (USER_FLOWER_CARE)
        case TASK_ID_FLOWER_CLIENT:
#include "flower_client.h"
            extern const struct prf_task_cbs* flower_client_prf_itf_get(void);
            prf_cbs = flower_client_prf_itf_get();
            break;
#endif // (BLE_BATT_SERVER)

#if (BLE_OTA_SERVER)
        case TASK_ID_OTAS:
            prf_cbs = otas_prf_itf_get_user();
            break;
#endif
#if 0
#if (BLE_DIS_SERVER)
        case TASK_ID_DISS:
            prf_cbs = diss_prf_itf_get();
            break;
#endif // (BLE_DIS_SERVER)
#if (BLE_BATT_SERVER)
        case TASK_ID_BASS:
            prf_cbs = bass_prf_itf_get();
            break;
#endif // (BLE_BATT_SERVER)
#endif
#if (BLE_SPS_SERVER)
        case TASK_ID_SPSS:
            prf_cbs = spss_prf_itf_get();
            break;
#endif // (BLE_SPS_SERVER)

#if (BLE_SPS_CLIENT)
        case TASK_ID_SPSC:
            prf_cbs = spsc_prf_itf_get();
            break;
#endif // (BLE_SPS_CLIENT)

#if (BLE_RTCT_SERVER)
        case TASK_ID_RTCTS:
            prf_cbs = rtcts_prf_itf_get();
            break;
#endif // (BLE_SPS_CLIENT)

#if BLE_APP_MESH
        case TASK_ID_MESH:
            prf_cbs = m_al_prf_itf_get();
            break;
#endif

        default:
            break;
    }
#include "user_profile.h"
#if USER_PROFILE_API_ENABLE
    if(task_id >= TASK_ID_USER_START  && task_id<TASK_ID_USER_MAX)
        return get_user_profile_default_itf();
#endif

    return prf_cbs;
}

