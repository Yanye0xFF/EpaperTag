/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_MEM_H_
#define USER_MEM_H_
#include "ke_mem.h"


enum os_mem_type
{
    OS_MEM_ENV = KE_MEM_ENV,
    OS_MEM_ATT_DB = KE_MEM_ATT_DB,
    OS_MEM_KE_MSG = KE_MEM_KE_MSG,
    OS_MEM_NON_RETENTION = KE_MEM_NON_RETENTION,
};


#ifndef USER_MEM_API_ENABLE
#define USER_MEM_API_ENABLE (0)
#endif

#ifndef MEM_TEST_ENABLE
#define MEM_TEST_ENABLE (0)
#endif


#if (USER_MEM_API_ENABLE)

#if MEM_TEST_ENABLE
void ke_mem_stastic_test(void);
#endif


void *ke_malloc_user(uint32_t size, uint8_t type);
void ke_free_user(void* mem_ptr);
/*
#include "ke_msg.h"
void *ke_msg_alloc_user(ke_msg_id_t const id, ke_task_id_t const dest_id,
                        ke_task_id_t const src_id, uint16_t const param_len);
#define KE_MSG_ALLOC_DYN_USER(id, dest, src, param_str,length)  (struct param_str*)ke_msg_alloc_user(id, dest, src, \
    (sizeof(struct param_str) + length));
*/

void show_msg_list(void);
uint16_t ke_get_mem_usage(uint8_t type);
uint16_t ke_get_mem_max_usage(uint8_t type);
void show_ke_malloc(void);
void show_mem_list(void);

#endif

#define os_malloc(size,type)    ke_malloc((size),(type))
void *os_zalloc(uint32_t size, uint8_t type);

#define os_free(ptr)    ke_free((ptr))
uint16_t ke_get_mem_free(uint8_t type);



#endif // APP_HT_H_
