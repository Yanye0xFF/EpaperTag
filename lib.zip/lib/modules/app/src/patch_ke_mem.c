#include <stdint.h>
#include <stdio.h>

#include "co_math.h"            // computation utilities
//#include "ke_config.h"          // kernel configuration
#include "ke_env.h"             // kernel environment
//#include "ke_mem.h"             // kernel memory
#include "ke_task.h"

#include "ke_msg.h"

#include "patch.h"

#define KE_LIST_PATTERN           (0xA55A)
#define KE_ALLOCATED_PATTERN      (0x8338)
#define KE_FREE_PATTERN           (0xF00F)

#include "user_mem.h"


#include "arch.h"
#define MEM_DBG FR_DBG_OFF
#define MEM_LOG FR_LOG(MEM_DBG)

struct
{

    /// Size of heap used
    uint16_t heap_used[KE_MEM_BLOCK_MAX];
    /// Maximum heap memory used
    uint32_t max_heap_used[KE_MEM_BLOCK_MAX];
} mem_stastic;

/*
 * LOCAL TYPE DEFINITIONS
 ****************************************************************************************
 */
/// Free memory block delimiter structure (size must be word multiple)
/// Heap can be represented as a doubled linked list.
struct mblock_free
{
    /// Used to check if memory block has been corrupted or not
    uint16_t corrupt_check;
    /// Size of the current free block (including delimiter)
    uint16_t free_size;
    /// Next free block pointer
    struct mblock_free* next;
    /// Previous free block pointer
    struct mblock_free* previous;
};

/// Used memory block delimiter structure (size must be word multiple)
struct mblock_used
{
    /// Used to check if memory block has been corrupted or not
    uint16_t corrupt_check;
    /// Size of the current used block (including delimiter)
    uint16_t size;
};

#if (USER_MEM_API_ENABLE)

void show_ke_malloc(void);

uint32_t record_lr;
static uint8_t first_msg;


static bool ke_mem_is_in_heap(uint8_t type, void* mem_ptr)
{
    bool ret = false;
    uint8_t* block = (uint8_t*)ke_env.heap[type];
    uint32_t size = ke_env.heap_size[type];

    if((((uint32_t)mem_ptr) >= ((uint32_t)block))
       && (((uint32_t)mem_ptr) <= (((uint32_t)block) + size)))
    {
        ret = true;
    }

    return ret;
}


/***************DYC added  for msg leakage check**********************/
//Debug msg malloc/free
struct ke_msg_debug_list
{
    struct ke_msg_debug_list * next;
    void *msg;
    uint32_t lr;
    uint32_t size;
    uint8_t type;
} *msg_debug_list_hdr = NULL;


uint16_t ke_get_mem_usage(uint8_t type)
{
    ASSERT_ERR(type < KE_MEM_BLOCK_MAX);

    return mem_stastic.heap_used[type];
}
uint16_t ke_get_mem_max_usage(uint8_t type)
{
    ASSERT_ERR(type < KE_MEM_BLOCK_MAX);

    return mem_stastic.max_heap_used[type];
}

static void debug_add_node_to_msg_list(void *msg,uint32_t lr,uint8_t type,uint32_t size)
{
    struct ke_msg_debug_list *tmp;
    
    GLOBAL_INT_DISABLE();
    if(msg_debug_list_hdr == NULL)
    {
//printf("mlc1:%p\r\n",msg);
        msg_debug_list_hdr = (struct ke_msg_debug_list *)ke_malloc_user(sizeof(struct ke_msg_debug_list),0xFF);
        msg_debug_list_hdr->lr = lr;
        msg_debug_list_hdr->type = type;
        msg_debug_list_hdr->size = size;
        msg_debug_list_hdr->msg = msg;
        msg_debug_list_hdr->next = NULL;
        goto __exit;
    }

    tmp = msg_debug_list_hdr;
    while(tmp->next != NULL)
    {
        //if(tmp->next == NULL) break;
        tmp = tmp->next;
    }
//printf("mlc2:%p\r\n",msg);
    tmp->next = (struct ke_msg_debug_list *)ke_malloc_user(sizeof(struct ke_msg_debug_list),0xFF);
    tmp->next->lr = lr;
    tmp->next->type = type;
    tmp->next->size = size;
    tmp->next->next = NULL;
    tmp->next->msg = msg;

__exit:
    GLOBAL_INT_RESTORE();

}

static uint8_t skip_debg_del;
static void debug_del_node_from_msg_list(void *msg)
{
    struct ke_msg_debug_list *tmp,*tmp_prev;

//printf("dbg_free:%p,%p\n",msg_debug_list_hdr->msg,msg);
    GLOBAL_INT_DISABLE();
    tmp = msg_debug_list_hdr;
    tmp_prev = msg_debug_list_hdr;

#if 0
//This code is for checking if some debug msg is malloced.
#include "gapc_task.h"
    if( ke_mem_is_in_heap(KE_MEM_KE_MSG,(void *)msg) )
    {
        if( ((struct ke_msg *)msg)->id == GAPC_LE_PKT_SIZE_IND )
            printf("come\r\n");
    }
#endif

    if(msg_debug_list_hdr->msg == msg)
    {
        msg_debug_list_hdr = msg_debug_list_hdr->next;
        skip_debg_del = 1;
        ke_free_user(tmp);
        skip_debg_del = 0;
        goto __exit;
    }

    tmp = msg_debug_list_hdr->next;
    tmp_prev = msg_debug_list_hdr;
    while(tmp!=NULL)
    {
        if(tmp->msg == msg)
        {
            tmp_prev->next = tmp->next;
            skip_debg_del = 1;
            ke_free_user(tmp);
            skip_debg_del = 0;
            goto __exit;
        }
        tmp_prev = tmp;
        tmp = tmp->next;
    }
    if( ke_mem_is_in_heap(KE_MEM_KE_MSG,(void *)msg) )          //1st em from void llm_ble_ready(void);
    {
        if( first_msg == 1 )
            printf("E:M,msg:%p |id:0x%x |destid:0x%x |srcid:0x%x\r\n",msg,((struct ke_msg *)msg)->id,
                   ((struct ke_msg *)msg)->dest_id,((struct ke_msg *)msg)->src_id);
        else
            first_msg = 1;
    }
    else
        printf("E:M:%p",msg);

__exit:
    GLOBAL_INT_RESTORE();
}

/**************DYC added  for msg leakage check***********************/

void *ke_malloc_user(uint32_t size, uint8_t type)
{
    struct mblock_free *node = NULL,*found = NULL;
    uint8_t cursor = 0;
    struct mblock_used *alloc = NULL;
    uint32_t totalsize;

    // compute overall block size (including requested size PLUS descriptor size)
    totalsize = CO_ALIGN4_HI(size) + sizeof(struct mblock_used);
    if(totalsize < sizeof(struct mblock_free))
    {
        totalsize = sizeof(struct mblock_free);
    }

    // sanity check: the totalsize should be large enough to hold free block descriptor
    ASSERT_ERR(totalsize >= sizeof(struct mblock_free));

    // protect accesses to descriptors
    GLOBAL_INT_DISABLE();
    
    uint8_t type_orig = type;
    MEM_LOG("ke_mam,typ:%d\r\n",type);

    if(type == 0xff)
        type = KE_MEM_NON_RETENTION;

    while((cursor < KE_MEM_BLOCK_MAX)&& (found == NULL))
    {
        uint8_t heap_id = ((cursor + type) % KE_MEM_BLOCK_MAX);
        uint32_t totalfreesize = 0;

        // Select Heap to use, first try to use current heap.
        node = ke_env.heap[heap_id];
        ASSERT_ERR(node != NULL);

        // go through free memory blocks list
        while (node != NULL)
        {
            ASSERT_ERR(node->corrupt_check == KE_LIST_PATTERN);
            totalfreesize += node->free_size;

            // check if there is enough room in this free block
            if (node->free_size >= (totalsize))
            {
                if ((node->free_size >= (totalsize + sizeof(struct mblock_free)))
                    || (node->previous != NULL))
                {
                    // if a match was already found, check if this one is smaller
                    if ((found == NULL) || (found->free_size > node->free_size))
                    {
                        found = node;
                    }
                }
            }

            // move to next block
            node = node->next;
        }

        // Update size to use complete list if possible.
        if(found != NULL)
        {
            if (found->free_size < (totalsize + sizeof(struct mblock_free)))
            {
                totalsize = found->free_size;
            }
        }

        mem_stastic.heap_used[heap_id] = ke_env.heap_size[heap_id] - totalfreesize;
        if(heap_id == 1)
            MEM_LOG("heap_used1:%d,%d\r\n",mem_stastic.heap_used[heap_id],heap_id);

        if(found != NULL)
        {
            mem_stastic.heap_used[heap_id] += totalsize;
            if(heap_id == 1)
                MEM_LOG("heap_used2:%d,%d\r\n",mem_stastic.heap_used[heap_id],heap_id);
        }

        // increment cursor
        cursor ++;
    }

    {
        // calculate max used size
        // uint32_t totalusedsize = 0;
        for(cursor = 0 ; cursor < KE_MEM_BLOCK_MAX ; cursor ++)
        {
            // totalusedsize +=  mem_stastic.heap_used[cursor];
            if(mem_stastic.max_heap_used[cursor] < mem_stastic.heap_used[cursor])
                mem_stastic.max_heap_used[cursor] = mem_stastic.heap_used[cursor];
        }
    }


    // Re-boot platform if no more empty space
    if(found == NULL)
    {
        //platform_reset(0);
        printf("malloc_f,reset,%d,%x\r\n",size,record_lr);
        show_ke_malloc();
        show_mem_list();
        show_msg_list();
        while(1);
    }
    else
    {
        // sublist completely reused
        if (found->free_size == totalsize)
        {
            ASSERT_ERR(found->previous != NULL);

            // update double linked list
            found->previous->next = found->next;
            if(found->next != NULL)
            {
                found->next->previous = found->previous;
            }

            // compute the pointer to the beginning of the free space
#if CPU_WORD_SIZE == 4
            alloc = (struct mblock_used*) ((uint32_t)found);
#elif CPU_WORD_SIZE == 2
            alloc = (struct mblock_used*) ((uint16_t)found);
#endif
        }
        else
        {
            // found a free block that matches, subtract the allocation size from the
            // free block size. If equal, the free block will be kept with 0 size... but
            // moving it out of the linked list is too much work.
            found->free_size -= totalsize;

            // compute the pointer to the beginning of the free space
#if CPU_WORD_SIZE == 4
            alloc = (struct mblock_used*) ((uint32_t)found + found->free_size);
#elif CPU_WORD_SIZE == 2
            alloc = (struct mblock_used*) ((uint16_t)found + found->free_size);
#endif
        }

        // save the size of the allocated block
        alloc->size = totalsize;
        alloc->corrupt_check = KE_ALLOCATED_PATTERN;

        // move to the user memory space
        alloc++;
    }
    
    //DYC added  for msg leakage check
    //if( ke_mem_is_in_heap(KE_MEM_KE_MSG,(void *)alloc) && (alloc != NULL) )
    if( alloc != NULL && type_orig != 0xff)
        debug_add_node_to_msg_list((void *)alloc,record_lr,type,size);

    // end of protection (as early as possible)
    GLOBAL_INT_RESTORE();
    ASSERT_ERR(node == NULL);

//    debug_mem_set((uint32_t*)alloc,type);
    return (void*)alloc;
}

void ke_free_user(void* mem_ptr)
{
    struct mblock_free *freed;
    struct mblock_used *bfreed;
    struct mblock_free *node, *next_node, *prev_node;
    uint32_t size;
    uint8_t cursor = 0;

    MEM_LOG("ke_free\r\n");

    // sanity checks
    ASSERT_INFO(mem_ptr != NULL, mem_ptr, 0);

//DYC added  for msg leakage check
    //if( ke_mem_is_in_heap(KE_MEM_KE_MSG,mem_ptr) )
    if( skip_debg_del == 0)
        debug_del_node_from_msg_list(mem_ptr);


//    debug_mem_reset((uint32_t*)mem_ptr);
    // point to the block descriptor (before user memory so decrement)
    bfreed = ((struct mblock_used *)mem_ptr) - 1;

    // check if memory block has been corrupted or not
    ASSERT_INFO(bfreed->corrupt_check == KE_ALLOCATED_PATTERN, bfreed->corrupt_check, mem_ptr);
    // change corruption token in order to know if buffer has been already freed.
    bfreed->corrupt_check = KE_FREE_PATTERN;

    // point to the first node of the free elements linked list
    size = bfreed->size;
    node = NULL;

    freed = ((struct mblock_free *)bfreed);

    // protect accesses to descriptors
    GLOBAL_INT_DISABLE();

    // Retrieve where memory block comes from
    while(((cursor < KE_MEM_BLOCK_MAX)) && (node == NULL))
    {

        if(ke_mem_is_in_heap(cursor, mem_ptr))
        {
            // Select Heap to use, first try to use current heap.
            node = ke_env.heap[cursor];
        }
        else
        {
            cursor ++;
        }
    }

    // sanity checks
    ASSERT_ERR(node != NULL);
    ASSERT_ERR(((uint32_t)mem_ptr > (uint32_t)node));

    prev_node = NULL;

    while(node != NULL)
    {
        ASSERT_ERR(node->corrupt_check == KE_LIST_PATTERN);
        // check if the freed block is right after the current block
        if ((uint32_t)freed == ((uint32_t)node + node->free_size))
        {
            // append the freed block to the current one
            node->free_size += size;

            // check if this merge made the link between free blocks
            if (((uint32_t) node->next) == (((uint32_t)node) + node->free_size))
            {
                next_node = node->next;
                // add the size of the next node to the current node
                node->free_size += next_node->free_size;
                // update the next of the current node
                ASSERT_ERR(next_node != NULL);
                node->next = next_node->next;
                // update linked list.
                if(next_node->next != NULL)
                {
                    next_node->next->previous = node;
                }
            }
            goto free_end;
        }
        else if ((uint32_t)freed < (uint32_t)node)
        {
            // sanity check: can not happen before first node
            ASSERT_ERR(prev_node != NULL);

            // update the next pointer of the previous node
            prev_node->next = freed;
            freed->previous = prev_node;

            freed->corrupt_check = KE_LIST_PATTERN;

            // check if the released node is right before the free block
            if (((uint32_t)freed + size) == (uint32_t)node)
            {
                // merge the two nodes
                freed->next = node->next;
                if(node->next != NULL)
                {
                    node->next->previous = freed;
                }
                freed->free_size = node->free_size + size;
            }
            else
            {
                // insert the new node
                freed->next = node;
                node->previous = freed;
                freed->free_size = size;
            }
            goto free_end;
        }

        // move to the next free block node
        prev_node = node;
        node = node->next;

    }

    freed->corrupt_check = KE_LIST_PATTERN;

    // if reached here, freed block is after last free block and not contiguous
    prev_node->next = (struct mblock_free*)freed;
    freed->next = NULL;
    freed->previous = prev_node;
    freed->free_size = size;
    freed->corrupt_check = KE_LIST_PATTERN;


free_end:
    mem_stastic.heap_used[cursor] -= size;

    //if(cursor == 1)
    {
        MEM_LOG("heap_used3:%d,%d\r\n",mem_stastic.heap_used[cursor],cursor);
        MEM_LOG("used:%d\r\n",ke_get_mem_usage(cursor));
    }

    // end of protection
    GLOBAL_INT_RESTORE();
}

#if 0
void *ke_msg_alloc_user(ke_msg_id_t const id, ke_task_id_t const dest_id,
                        ke_task_id_t const src_id, uint16_t const param_len)
{
    //printf("a,");

    struct ke_msg *msg = (struct ke_msg*) ke_malloc_user(sizeof(struct ke_msg) +
                         param_len - sizeof (uint32_t), KE_MEM_KE_MSG);

    void *param_ptr = NULL;
    ASSERT_ERR(msg != NULL);
    msg->hdr.next  = KE_MSG_NOT_IN_QUEUE;
    msg->id        = id;
    msg->dest_id   = dest_id;
    msg->src_id    = src_id;
    msg->param_len = param_len;

    param_ptr = ke_msg2param(msg);
    memset(param_ptr, 0, param_len);

    //printf("b:%p,",param_ptr);

    return param_ptr;
}
#endif


void show_msg_list(void)
{
    struct ke_msg_debug_list *tmp = msg_debug_list_hdr;
    printf("show_msg_list:\r\n");
    while(tmp != NULL)
    {
        if(tmp->type == KE_MEM_KE_MSG)
            printf("msg:%p |id:%08X |destid:%d |srcid:%d |len:%d |lr:%x\r\n",tmp->msg,((struct ke_msg *)tmp->msg)->id
                   ,((struct ke_msg *)tmp->msg)->dest_id,((struct ke_msg *)tmp->msg)->src_id
                   ,((struct ke_msg *)tmp->msg)->param_len,tmp->lr);
        tmp = tmp->next;
    }
    printf("\r\n");
}

void show_mem_list(void)
{
    struct ke_msg_debug_list *tmp = msg_debug_list_hdr;
    printf("show_mem_list:\r\n");
    while(tmp != NULL)
    {
        printf("mem:type:%d |size:%d |lr:%x\r\n",tmp->type,tmp->size,tmp->lr);
        tmp = tmp->next;
    }
    printf("\r\n");
}


void show_ke_malloc(void)
{
    uint8_t idx = 0;
    for(; idx<KE_MEM_BLOCK_MAX; idx++)
    {
        //struct mblock_free *node = ke_env.heap[idx];
        if(idx==0)
            printf("KE_MEM_ENV:");
        else if(idx==1)
            printf("KE_MEM_ATT_DB:");
        else if(idx==2)
            printf("KE_MEM_KE_MSG:");
        else if(idx==3)
            printf("KE_MEM_NON_RETENTION:");

        printf("total:%d |",ke_env.heap_size[idx]);
        printf("max:%d |",ke_get_mem_max_usage(idx));
        printf("used:%d |",ke_get_mem_usage(idx));
        printf("free:%d \r\n",ke_get_mem_free(idx));
    }
}

#if (MEM_TEST_ENABLE)
void ke_mem_stastic_test(void)
{
    void *mem_env[2];
    void *mem_db[2];
    void *mem_msg[2];
    void *mem_retaion[2];

    printf("Before malloc\r\n");
    show_ke_malloc();
    mem_env[0] = (void* )ke_malloc(50, KE_MEM_ENV);
    mem_env[1] = (void* )ke_malloc(50, KE_MEM_ENV);

    mem_db[0] = (void *)ke_malloc(50, KE_MEM_ATT_DB);
    mem_db[1] = (void *)ke_malloc(50, KE_MEM_ATT_DB);

    mem_msg[0] = (void *)ke_malloc(50, KE_MEM_KE_MSG);
    mem_msg[1] = (void *)ke_malloc(50, KE_MEM_KE_MSG);

    mem_retaion[0] = (void *)ke_malloc(50, KE_MEM_NON_RETENTION);
    mem_retaion[1] = (void *)ke_malloc(50, KE_MEM_NON_RETENTION);
    printf("After malloc\r\n");
    show_ke_malloc();

    ke_free(mem_env[1]);
    ke_free(mem_db[1]);
    ke_free(mem_msg[1]);
    ke_free(mem_retaion[1]);

    printf("After free1\r\n");
    show_ke_malloc();

    ke_free(mem_env[0]);
    ke_free(mem_db[0]);
    ke_free(mem_msg[0]);
    ke_free(mem_retaion[0]);

    printf("After free2\r\n");
    show_ke_malloc();
}
#endif

#endif  // #endif of Marco: USER_MEM_API_ENABLE


uint16_t ke_get_mem_free(uint8_t type)
{
    uint32_t total_freesize = 0;
    struct mblock_free *node;

    ASSERT_ERR(type < KE_MEM_BLOCK_MAX);
    node = ke_env.heap[type];
    while(node != NULL)
    {
        total_freesize +=node->free_size;
        node = node->next;
    }
    return total_freesize;
}


void *os_zalloc(uint32_t size, uint8_t type)
{
    void *p = ke_malloc(size,type);
    memset(p,0x0,size);
    return p;
}
