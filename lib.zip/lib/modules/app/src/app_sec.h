/**
 ****************************************************************************************
 *
 * @file app_sec.h
 *
 * @brief Application Security Entry Point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP_SEC
 * @{
 ****************************************************************************************
 */

#ifndef APP_SEC_H_
#define APP_SEC_H_

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"



#include <stdint.h>          // Standard Integer Definition

#include "gapc_task.h"

/*
 * DEFINES
 ****************************************************************************************
 */

#define APP_KEY_VALID_BDADDR    CO_BIT(0)
#define APP_KEY_VALID_BONDED    CO_BIT(1)
#define APP_KEY_VALID_LTK       CO_BIT(2)
#define APP_KEY_VALID_CSRK      CO_BIT(3)
#define APP_KEY_VALID_IRK       CO_BIT(4)


/*
 * STRUCTURES DEFINITIONS
 ****************************************************************************************
 */

struct app_sec_env_tag
{
    /// Peer address type
    //uint8_t peer_addr_type;
    /// Peer BT address
    //struct bd_addr peer_addr;
    struct gap_bdaddr peer_addr;

    uint8_t key_valid;

    uint8_t auth;

    struct gap_sec_key irk;
    struct gapc_ltk ltk;

    /// Local CSRK value
    struct gap_sec_key lcsrk;
    /// Local signature counter value
    uint32_t lsign_counter;

    /// Remote CSRK value
    struct gap_sec_key rcsrk;
    /// Remote signature counter value
    uint32_t rsign_counter;
};

/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */
struct gapc_security_ind1
{
    struct gapc_security_ind ind;
    uint8_t conidx;
};
/// Application Security Environment
extern struct app_sec_env_tag app_sec_env;

/// Table of message handlers
extern const struct ke_state_handler app_sec_table_handler;

/*
 * GLOBAL FUNCTIONS DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initialize the Application Security Module
 ****************************************************************************************
 */
void app_sec_init(void);
uint8_t app_sec_fill_connect_cfm(uint8_t conidx, struct gapc_connection_cfm *cfm);



/**
 ****************************************************************************************
 * USER_API
 ****************************************************************************************
 */
enum app_sec_bond_t
{
    APP_SEC_BOND,
    APP_SEC_BOND_OTHER,
    APP_SEC_NO_BOND,
    APP_SEC_BOND_RESOLV_CHECK,
};

//#if (BLE_APP_SEC)

enum app_sec_bond_t app_sec_get_bond_type(const struct bd_addr *bdaddr, uint8_t bdaddr_type);
bool app_sec_get_bond_status(void);
void app_sec_remove_bond(void);
void app_sec_send_security_req(uint8_t conidx);
uint8_t app_sec_resolve_address(struct bd_addr *bdaddr, uint8_t count, uint8_t *irks);

//#endif //(BLE_APP_SEC)

#endif // APP_SEC_H_

/// @} APP_SEC
