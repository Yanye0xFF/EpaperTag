#ifndef _APP_OTA_H
#define _APP_OTA_H

#include "rwip_config.h"

#if BLE_APP_OTAS

#include "ke_task.h"
#include "otas.h"
#include "otas_task.h"

#define OTA_HDR_RESULT_LEN          1
#define OTA_HDR_OPCODE_LEN          1
#define OTA_HDR_LENGTH_LEN          2

enum ota_cmd_t
{
    OTA_CMD_NVDS_TYPE,
    OTA_CMD_GET_STR_BASE,
    OTA_CMD_READ_FW_VER,    //read firmware version
    OTA_CMD_PAGE_ERASE,
    OTA_CMD_CHIP_ERASE,
    OTA_CMD_WRITE_DATA,
    OTA_CMD_READ_DATA,
    OTA_CMD_WRITE_MEM,
    OTA_CMD_READ_MEM,
    OTA_CMD_REBOOT,
    OTA_CMD_WRITE_CHECKSUM,
    OTA_CMD_NULL,
};

enum ota_rsp_t
{
    OTA_RSP_SUCCESS,
    OTA_RSP_ERROR,
    OTA_RSP_UNKNOWN_CMD,
};

enum ota_nvds_type
{
    OTA_NVDS_NONE,
    OTA_NVDS_FLASH,
    OTA_NVDS_EEPROM,
};
__packed struct write_checksum_rsp
{
    uint32_t checksum;
};

__packed struct firmware_version
{
    uint32_t firmware_version;
};

__packed struct storage_baseaddr
{
    uint32_t baseaddr;
};

__packed struct page_erase_rsp
{
    uint32_t base_address;
};

__packed struct write_mem_rsp
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct read_mem_rsp
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct write_data_rsp
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct read_data_rsp
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct app_ota_rsp_hdr_t
{
    uint8_t result;
    uint8_t org_opcode;
    uint16_t length;
    __packed union
    {
        uint8_t nvds_type;
        struct firmware_version version;
        struct storage_baseaddr baseaddr;
        struct page_erase_rsp page_erase;
        struct write_mem_rsp write_mem;
        struct read_mem_rsp read_mem;
        struct write_data_rsp write_data;
        struct read_data_rsp read_data;
        struct write_checksum_rsp write_checksum;
    } rsp;
};

__packed struct write_checksum_cmd
{
    uint32_t checksum;
};

__packed struct page_erase_cmd
{
    uint32_t base_address;
};

__packed struct write_mem_cmd
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct read_mem_cmd
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct write_data_cmd
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct read_data_cmd
{
    uint32_t base_address;
    uint16_t length;
};

__packed struct app_ota_cmd_hdr_t
{
    uint8_t opcode;
    uint16_t length;
    __packed union
    {
        struct page_erase_cmd page_erase;
        struct write_mem_cmd write_mem;
        struct read_mem_cmd read_mem;
        struct write_data_cmd write_data;
        struct read_data_cmd read_data;
        struct write_checksum_cmd write_checksum;
    } cmd;
};

void app_otas_clr_buffed_pkt(void);


void app_otas_init(void);
void app_otas_add_otass(void);
void app_otas_enable_prf(uint8_t conidx);

extern const struct ke_state_handler app_otas_table_handler;

#endif //BLE_APP_OTAS
#endif // _APP_OTA_H

