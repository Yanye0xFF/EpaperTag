/**
 ****************************************************************************************
 *
 * @file app_hid.c
 *
 * @brief HID Application Module entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

#include "rwip_config.h"            // SW configuration

#include <stdio.h>
#include <string.h>

#define HID_LOAD_NVDS       1

#if (BLE_APP_HID)

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "app.h"                    // Application Definitions
#include "app_sec.h"                // Application Security Module API
#include "app_task.h"               // Application task definitions
#include "app_hid.h"                // HID Application Module Definitions

#include "hogpd_task_user.h"             // HID Over GATT Profile Device Role Functions
#include "hogpd_user.h"

#include "prf_types.h"              // Profile common types Definition
#include "arch.h"                    // Platform Definitions
#include "prf.h"
#include "keyscan.h"
#include "system.h"
#include "low_power.h"
#include "rwip.h"
#include "app_proj_event.h"

#if (NVDS_SUPPORT)
#include "nvds.h"                   // NVDS Definitions
#endif //(NVDS_SUPPORT)

#include "co_utils.h"               // Common functions

#if (KE_PROFILING)
#include "ke_mem.h"
#endif //(KE_PROFILING)


#include "prf_utils.h"

/*
 * DEFINES
 ****************************************************************************************
 */


/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// States of the Application HID Module
enum app_hid_states
{
    /// Module is disabled (Service not added in DB)
    APP_HID_DISABLED,
    /// Module is idle (Service added but profile not enabled)
    APP_HID_IDLE,
    /// Module is enabled (Device is connected and the profile is enabled)
    APP_HID_ENABLED,
    /// The application can send reports
    APP_HID_READY,
    /// Waiting for a report
    APP_HID_WAIT_REP,

    APP_HID_STATE_MAX,
};

#ifdef HID_KEYBOARD_MAP
//For Andoird
const uint8_t hid_keyboard_report_map_user[] =
{
    0x05, 0x01,
    0x09, 0x06,
    0xA1, 0x01,
    0x85, 0x01,     //report ID  1
    0x05, 0x07,
    0x19, 0xe0,  //Local, Usage Minimum(224),
    0x29, 0xe7,     //Local, Usage Maximum(231),
    0x15, 0x00,
    0x25, 0x01,
    0x75, 0x01,         //Global,Report Size(1)
    0x95, 0x08,    //Global,Report Count(8)
    0x81, 0x02,    // Main,input
    0x95, 0x01,     //Global,Report Size(1)
    0x75, 0x08,     //Global,Report Count(8)
    0x81, 0x01,     //Main,input
    0x95, 0x05,     //Global,Report Count(5)
    0x75, 0x01,     //Global,Report Size(1)
    0x05, 0x08,     //LEDs
    0x19, 0x01,
    0x29, 0x05,     //1*5bit
    0x91, 0x02,   //output
    0x95, 0x01,
    0x75, 0x03,     //1*3bit
    0x91, 0x01,     //ouput
    0x95, 0x06,     //
    0x75, 0x08,     //6*8bits
    0x15, 0x00,
    0x25, 0xff,     //range,0~0xff
    0x05, 0x07,
    0x19, 0x00,
    0x29, 0xff, //logical, 0~0xff
    0x81, 0x00, //input
    0xc0,

    0x05, 0x0c,
    0x09, 0x01,
    0xa1, 0x01,
    0x85, 0x02,   //report ID 2
    0x19, 0x00, 0x2a, 0x9c, 0x02, 0x15, 0x00,
    0x26, 0x9c, 0x02, 0x95, 0x01, 0x75, 0x10, 0x80, 0xc0, 0x06,
    0x00, 0xff, 0x09, 0x01, 0xa1, 0x01, 0xa1, 0x02, 0x85, 0x5d,
    0x09, 0x01, 0x15, 0x00, 0x26, 0xff, 0x00, 0x75, 0x08, 0x95,
    0x14, 0x81, 0x22, 0xc0, 0xa1, 0x02, 0x85, 0x2b, 0x09, 0x01,
    0x15, 0x00, 0x26, 0xff, 0x00, 0x75, 0x08, 0x95, 0x14, 0x81,
    0x22, 0xc0, 0xa1, 0x02, 0x85, 0x5f, 0x15, 0x00, 0x26, 0xff,
    0x00, 0x75, 0x08, 0x95, 0x14, 0x81, 0x22, 0xc0, 0xc0
};
#elif defined HID_IOS_KEYBOARD_MAP
//For IOS
const uint8_t hid_keyboard_report_map_user[] =
{
    0x05, 0x01,  // Usage Page (Generic Desktop)
    0x09, 0x02,  // Usage (Mouse)
    0xA1, 0x01,  // Collection (Application)
    0x85, 0x01,  // Report Id (1)
    0x09, 0x01,  //   Usage (Pointer)
    0xA1, 0x00,  //   Collection (Physical)

    0x05, 0x09,  //     Usage Page (Buttons)
    0x19, 0x01,  //     Usage Minimum (01) - Button 1
    0x29, 0x03,  //     Usage Maximum (03) - Button 3
    0x15, 0x00,  //     Logical Minimum (0)
    0x25, 0x01,  //     Logical Maximum (1)
    0x75, 0x01,  //     Report Size (1)
    0x95, 0x03,  //     Report Count (3)
    0x81, 0x02,  //     Input (Data, Variable, Absolute) - Button states

    0x75, 0x05,  //     Report Size (5)
    0x95, 0x01,  //     Report Count (1)
    0x81, 0x01,  //     Input (Constant) - Padding or Reserved bits

    0x05, 0x01,  //     Usage Page (Generic Desktop)
    0x09, 0x30,  //     Usage (X)
    0x09, 0x31,  //     Usage (Y)
    0x09, 0x38,  //     Usage (Wheel)
    0x15, 0x81,  //     Logical Minimum (-127)
    0x25, 0x7F,  //     Logical Maximum (127)
    0x75, 0x08,  //     Report Size (8)
    0x95, 0x03,  //     Report Count (3)
    0x81, 0x06,  //     Input (Data, Variable, Relative) - X & Y wheal  3bytes
    0xC0,        //   End Collection
    0xC0,        // End Collection

#if 0
    // Report ID 2
    0x05, 0x0C,   // Usage Page (Consumer)
    0x09, 0x01,   // Usage (Consumer Control)
    0xA1, 0x01,   // Collection (Application)
    0x85, 0x02,   //     Report Id (2)

    0x0a, 0x24, 0x02,   //   Usage (web_back)   1
    0x0a, 0x25, 0x02,   //   Usage (web_forward) 2
    0x0a, 0x26, 0x02,   //   Usage (web_stop) 3
    0x0a, 0x27, 0x02,   //   Usage (WED_REFRESH) 4
    0x0a, 0x21, 0x02,   //   Usage (OPEN_SEARCHA) 5
    0x0a, 0x23, 0x02,   //   Usage (web_home)   6

    0x09, 0xE2,   //   Usage (MEDIA_MUTE)   7   0xE2
    0x09, 0xEA,   //   Usage (Volume Down)  8   0xEA
    0x09, 0xE9,   //   Usage (Volume Up)  9     0xE9
    0x09, 0xCD,   //   Usage (MEDIA_PAUSE) 10
    0x09, 0xB7,   //   Usage (MEDIA_STOP) 11
    0x09, 0xB6,   //   Usage (MEDIA_PRE_TRACK) 12
    0x09, 0xB5,   //   Usage (MEDIA_NEXT_TRACK)  13
    0x0a, 0x83, 0x01,   //   Usage (open media) 14

    0x0a, 0x94, 0x01,   //   Usage (OPEN_MY_COMPUTER) 15
    0x0a, 0x8a, 0x01,   //   Usage (OPEN_EMAIL)   16
    0x0a, 0x96, 0x01,   //   Usage (KEY_ANDROID_WEB_HOME) 17

    0x09, 0x30,   //   Usage (Power)
    0x09, 0x45,   //   Usage (Menu Right)

    0x15, 0x01,   //   Logical Min (1)
    0x25, 0x11,   //   Logical Max (17)
    0x75, 0x06,   //   Report Size (6)
    0x95, 0x01,   //   Report Count (1)
    0x81, 0x00,   //   Input (Data, Ary, Abs)
    0x09, 0x80,   //   Usage (Selection)
    0xA1, 0x02,   //   Collection (Logical)
    0x05, 0x09,   //     Usage Pg (Button), here is the key page,look usb hid key define
    0x19, 0x01,   //     Usage Min (Button 1)
    0x29, 0x03,   //     Usage Max (Button 3)
    0x15, 0x01,   //     Logical Min (1)
    0x25, 0x03,   //     Logical Max (3)
    0x75, 0x02,   //     Report Size (2)
    0x81, 0x00,   //     Input (Data, Ary, Abs)
    0xC0,         //   End Collection
    0x81, 0x03,   //   Input (Const, Var, Abs)
    0xC0,         // End Collection
#else
    0x05,0x0c,               // Usage Page (Consumer Devices)
    0x09,0x01,               // Usage index(Consumer Control)
    0xa1,0x01,               // Collection (Application)
    0x85,0x02,               //  Report ID (2)
    0x15,0x00,         //  Logical Minimum (0)
    0x25,0x01,         //  Logical Maximum (1)
    0x75,0x01,         //  Report Size (1)
    0x95,0x01,         //  Report Count (1)

    0x09,0xcd,        // Usage index(Play/Pause)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    //0x0a,0x83,0x01,   //  Usage (AL Consumer Control Configuration)
    0x0a, 0x21, 0x02,   //   Usage (OPEN_SEARCHA) 5
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0x09,0xb5,        //  Usage (Scan Next Track)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0x09,0xb6,        //  Usage (Scan Previous Track)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)

    0x09,0xea,        //  Usage (Volume -)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0x09,0xe9,        //  Usage (Volume +)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0x0a,0x25,0x02,     //Usage(AC Forward)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0x0a,0x24,0x02,   //Usage(AC Back)
    0x81,0x06,              //input(Data,Value,Relative,Bit,Filed)
    0xc0,                           // End Collection
#endif

    0x05, 0x01,     // Usage Pg (Generic Desktop)
    0x09, 0x06,     // Usage (Keyboard)
    0xA1, 0x01,     // Collection: (Application)
    0x85, 0x03,     // Report Id (3 for keyboard)
    //
    0x05, 0x07,     // Usage Pg (Key Codes)
    0x19, 0xE0,     // Usage Min (224)
    0x29, 0xE7,     // Usage Max (231)
    0x15, 0x00,     // Log Min (0)
    0x25, 0x01,     // Log Max (1)
    //
    // Modifier byte
    0x75, 0x01,     // Report Size (1)   1 bit * 8
    0x95, 0x08,     // Report Count (8)
    0x81, 0x02,     // Input: (Data, Variable, Absolute)

    // Reserved byte
    0x95, 0x01, // Report Count (1)
    0x75, 0x08, // Report Size (8)
    0x81, 0x01, // Input: (Constant)

    //LED repor
    0x95, 0x05,    //Report Count (5)
    0x75, 0x01,    //Report Size (1)
    0x05, 0x08,    //Usage Pg (LEDs )
    0x19, 0x01,    //Usage Min
    0x29, 0x05,    //Usage Max
    0x91, 0x02,    //Output (Data, Variable, Absolute)
    //3 bit reserved
    0x95, 0x01,    //Report Count (1)
    0x75, 0x03,    //Report Size (3)
    0x91, 0x01,    //Output (Constant)

    // Key arrays (6 bytes)
    // this is key array,support simultaneously pressing 6keys report,
    // from report_buf[3]~report_buf[3]
    0x95, 0x06,     // Report Count (6)
    0x75, 0x08,     // Report Size (8)
    0x15, 0x00,     // Log Min (0)
    0x25, 0xE7,     // Log Max (237)
    0x05, 0x07,     // Usage Pg (Key Codes) , here is the key page,look usb hid key define
    0x19, 0x00,     // Usage Min (0)
    0x29, 0xE7,     // Usage Max (237)
    0x81, 0x00,     // Input: (Data, Array)
    0xC0,            // End Collection
};
#else
/// HID Keyboard Report Descriptor

const uint8_t hid_keyboard_report_map_user[] =
{
    0x05, 0x01,         // Usage Page (Generic Desktop)
    0x09, 0x06,         // Usage (Keyboard)

    0xA1, 0x01,         // Collection: (Application)
    0x85, 0x01,         //  Report ID (1)

    0x05, 0x07,         //  Usage Page (Key Codes)
    0x19, 0xE0,         //  Usage Minimum (224)
    0x29, 0xE7,         //  Usage Maximum (231)
    0x15, 0x00,         //  Logical Minimum (0)
    0x25, 0x01,         //  Logical Maximum (1)
    0x75, 0x01,         //  Report Size (1)
    0x95, 0x08,         //  Report Count (8)

    0x81, 0x02,         //  Input: (Data, Variable, Absolute) ; Modifier byte

    0x95, 0x01,         //  Report Count (1)
    0x75, 0x08,         //  Report Size (8)
    0x81, 0x01,         //  Input: (Constant) ; Reserved byte
    0x95, 0x05,         //  Report Count (5)
    0x75, 0x01,         //  Report Size (1)

    0x05, 0x08,         //  Usage Page (LEDs)
    0x19, 0x01,         //  Usage Minimum (1)
    0x29, 0x05,         //  Usage Maximum (5)
    0x91, 0x02,         //  Output: (Data, Variable, Absolute)
    0x95, 0x01,         //  Report Count (1)
    0x75, 0x03,         //  Report Size (3)
    0x91, 0x01,         //  Output: (Constant, Variable, Absolute)

    0x95, 0x06,         //  Report Count (6)
    0x75, 0x08,         //  Report Size (8)
    0x15, 0x28,         //  Log Minimum (0)
    0x25, 0xfe,         //  Log Maximum (101)
    0x05, 0x07,         //  Usage Page (Key Codes)
    0x19, 0x28,         //  Usage Minimum (0)
    0x29, 0xfe,         //  Usage Maximum (101)
    0x81, 0x00,         //  Input: (Data, Array) ; Key arrays (6 bytes)

    0xC0,               // End Collection

    0x05, 0x20,         // Usage Page (Consumer Devices)
    0x09, 0x73,         // Usage (Consumer Control)
    0xA1, 0x01,         // Collection (Application)
    0x85, 0x03,         //  Report ID (3)
    0xa1, 0x00,         //  Logical Minimum (0)
    0x05, 0x20,         //  Logical Maximum (1)
    0x0a, 0x53,         //  Report Size (1)
    0x04, 0x0a,         //  Report Count (8)
    0x54, 0x04,         //  Usage (Scan Next Track)
    0x0a, 0x55,         //  Usage (Scan Previous Track)
    0x04,         //  Usage (Eject)
    0x0a, 0x57,         //  Usage (Play/Pause)
    0x04, 0x0a,         //  Usage (Mute)
    0x58, 0x04,         //  Usage (Volume Increment)
    0x0a, 0x59,         //  Usage (Volume Decrement)
    0x04, 0x16,         //  Input (Data,Var,Abs,NWrp,Lin,Pref,NNul,Bit)
    0x01, 0x80, 0x26,   //  Usage (AL Consumer Control Configuration)
    0xff, 0x7f, 0x75,   //  Usage (AL Email Reader)
    0x10, 0x95, 0x06,   //  Usage (AL Calculator)
    0x81, 0x02, 0xc0,   //  Usage (AL Local Machine Browser)
    0xC0                // End Collection
};
#endif

/*
/// HID Keyboard Report Descriptor
const uint8_t hid_mouse_report_map_user[] =
{
    0x05, 0x01,                     // Usage Page (Generic Desktop)
    0x09, 0x02,                     // Usage (Mouse)

    0xA1, 0x01,                     // Collection (Application)

    // Report ID 1: Mouse buttons + scroll/pan
    0x85, 0x01,       //     Report Id 1
    0x09, 0x01,       //     Usage (Pointer)
    0xA1, 0x00,       //     Collection (Physical)
    0x95, 0x05,       //         Report Count (3)
    0x75, 0x01,       //         Report Size (1)
    0x05, 0x09,       //         Usage Page (Buttons)
    0x19, 0x01,       //             Usage Minimum (01)
    0x29, 0x05,       //             Usage Maximum (05)
    0x15, 0x00,       //             Logical Minimum (0)
    0x25, 0x01,       //             Logical Maximum (1)
    0x81, 0x02,       //             Input (Data, Variable, Absolute)
    0x95, 0x01,       //             Report Count (1)
    0x75, 0x03,       //             Report Size (3)
    0x81, 0x01,       //             Input (Constant) for padding
    0x75, 0x08,       //             Report Size (8)
    0x95, 0x01,       //             Report Count (1)
    0x05, 0x01,       //         Usage Page (Generic Desktop)
    0x09, 0x38,       //             Usage (Wheel)
    0x15, 0x81,       //             Logical Minimum (-127)
    0x25, 0x7F,       //             Logical Maximum (127)
    0x81, 0x06,       //             Input (Data, Variable, Relative)
    0x05, 0x0C,       //         Usage Page (Consumer)
    0x0A, 0x38, 0x02, //             Usage (AC Pan)
    0x95, 0x01,       //             Report Count (1)
    0x81, 0x06,       //             Input (Data,Value,Relative,Bit Field)
    0xC0,             //     End Collection (Physical)

    // Report ID 2: Mouse motion
    0x85, 0x02,       //     Report Id 2
    0x09, 0x01,       //     Usage (Pointer)
    0xA1, 0x00,       //     Collection (Physical)
    0x75, 0x0C,       //         Report Size (12)
    0x95, 0x02,       //         Report Count (2)
    0x05, 0x01,       //         Usage Page (Generic Desktop)
    0x09, 0x30,       //             Usage (X)
    0x09, 0x31,       //             Usage (Y)
    0x16, 0x01, 0xF8, //             Logical maximum (2047)
    0x26, 0xFF, 0x07, //             Logical minimum (-2047)
    0x81, 0x06,       //             Input (Data, Variable, Relative)
    0xC0,             //     End Collection (Physical)
    0xC0,             // End Collection (Application)

    // Report ID 3: Advanced buttons
    0x05, 0x0C,       // Usage Page (Consumer)
    0x09, 0x01,       // Usage (Consumer Control)
    0xA1, 0x01,       // Collection (Application)
    0x85, 0x03,       //     Report Id (3)
    0x15, 0x00,       //     Logical minimum (0)
    0x25, 0x01,       //     Logical maximum (1)
    0x75, 0x01,       //     Report Size (1)
    0x95, 0x01,       //     Report Count (1)

    0x09, 0xCD,       //     Usage (Play/Pause)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x0A, 0x83, 0x01, //     Usage (AL Consumer Control Configuration)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x09, 0xB5,       //     Usage (Scan Next Track)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x09, 0xB6,       //     Usage (Scan Previous Track)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)

    0x09, 0xEA,       //     Usage (Volume Down)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x09, 0xE9,       //     Usage (Volume Up)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x0A, 0x25, 0x02, //     Usage (AC Forward)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0x0A, 0x24, 0x02, //     Usage (AC Back)
    0x81, 0x06,       //     Input (Data,Value,Relative,Bit Field)
    0xC0              // End Collection
};
*/

/// Length of the HID Mouse Report
#define APP_HID_KEYBOARD_REPORT_LEN         (8)
/// Length of the Report Descriptor for an HID Mouse
#define APP_HID_KEYBOARD_REPORT_MAP_LEN     (sizeof(hid_keyboard_report_map_user))      //140

/// Duration before connection update procedure if no report received (keyboard is silent) - 20s
#define APP_HID_SILENCE_DURATION_1          (400)
/// Duration before disconnection if no report is received after connection update - 60s
#define APP_HID_SILENCE_DURATION_2          (6000)

/// Number of reports that can be sent
#define APP_HID_NB_SEND_REPORT         (60)//(60)  foe 20



/*
 * LOCAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// HID Application Module Environment Structure
static struct app_hid_env_tag app_hid_env;

/*
 * GLOBAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void app_hid_init(void)
{
    // Reset the environment
    memset(&app_hid_env, 0, sizeof(app_hid_env));

    app_hid_env.nb_report = APP_HID_NB_SEND_REPORT;
    app_hid_env.timeout = APP_HID_SILENCE_DURATION_1;
}

void app_hid_add_hids(void)
{
//    uint8_t idx =0;
    struct hogpd_db_cfg *db_cfg;
    // Prepare the HOGPD_CREATE_DB_REQ message
    struct gapm_profile_task_add_cmd *req = KE_MSG_ALLOC_DYN(GAPM_PROFILE_TASK_ADD_CMD,
                                            TASK_GAPM, TASK_APP,
                                            gapm_profile_task_add_cmd, sizeof(struct hogpd_db_cfg));

    // Fill message
    req->operation   = GAPM_PROFILE_TASK_ADD;
#ifdef HID_KEYBOARD_MAP
    req->sec_lvl     = PERM(SVC_AUTH, AUTH);
#else
    req->sec_lvl     = PERM(SVC_AUTH, AUTH) | PERM(SVC_DIS, ENABLE) | PERM(SVC_EKS, ENABLE);
#endif
    req->prf_task_id = TASK_ID_HOGPD;
    req->app_task    = TASK_APP;
    req->start_hdl   = 0;

    // Set parameters
    db_cfg = (struct hogpd_db_cfg* ) req->param;

    // Only one HIDS instance is useful
    db_cfg->hids_nb = 1;


#if 0
    HOGPD_CFG_KEYBOARD      = 0x01,
    /// Mouse Device
    HOGPD_CFG_MOUSE         = 0x02,
    /// Protocol Mode present
    HOGPD_CFG_PROTO_MODE    = 0x04,
    /// Extended Reference Present  ,additional report map reference
    HOGPD_CFG_MAP_EXT_REF   = 0x08,
    /// Boot Keyboard Report write capability
    HOGPD_CFG_BOOT_KB_WR    = 0x10,
    /// Boot Mouse Report write capability
    HOGPD_CFG_BOOT_MOUSE_WR = 0x20,
    /// Valid Feature mask
    HOGPD_CFG_MASK          = 0x3F,
#endif


#ifdef HID_KEYBOARD_MAP
    // The device is a keyboard
    db_cfg->cfg[0].svc_features = HOGPD_CFG_KEYBOARD;

    //Hid reports
    db_cfg->cfg[0].report_nb    = 3;

    db_cfg->cfg[0].report_id[0] = 1;
    db_cfg->cfg[0].report_char_cfg[0] = HOGPD_CFG_REPORT_IN;    //mouse

    db_cfg->cfg[0].report_id[1] = 1;
    db_cfg->cfg[0].report_char_cfg[1] = HOGPD_CFG_REPORT_OUT;

    db_cfg->cfg[0].report_id[2] = 2;
    db_cfg->cfg[0].report_char_cfg[2] = HOGPD_CFG_REPORT_IN;

    // HID Information
    db_cfg->cfg[0].hid_info.bcdHID       = 0x0111;         // HID Version 1.11
    db_cfg->cfg[0].hid_info.bCountryCode = 0x00;
    db_cfg->cfg[0].hid_info.flags = HIDS_REMOTE_WAKE_CAPABLE | HIDS_NORM_CONNECTABLE;

#elif defined HID_IOS_KEYBOARD_MAP
    // The device is a keyboard
#if (HID_TYPE == 0 || HID_TYPE == 2)
    db_cfg->cfg[0].svc_features = HOGPD_CFG_KEYBOARD;
#elif (HID_TYPE == 1)
    db_cfg->cfg[0].svc_features = HOGPD_CFG_MOUSE;
#endif

    //Hid reports
    db_cfg->cfg[0].report_nb    = 4;

    db_cfg->cfg[0].report_id[0] = 1;    //see map array,    0x85, 0x01,  // Report Id (1), Usage (Mouse), idx = 0
    db_cfg->cfg[0].report_char_cfg[0] = HOGPD_CFG_REPORT_IN | HOGPD_CFG_REPORT_WR;

    db_cfg->cfg[0].report_id[1] = 2;    //see map array,    0x85, 0x02,  // Report Id (2), Usage (customer), idx = 1
    db_cfg->cfg[0].report_char_cfg[1] = HOGPD_CFG_REPORT_IN | HOGPD_CFG_REPORT_WR;        //rpt_idx =1

    db_cfg->cfg[0].report_id[2] = 3;    //see map array,    0x85, 0x03,  // Report Id (3), Usage (keyboard), idx = 2
    db_cfg->cfg[0].report_char_cfg[2] = HOGPD_CFG_REPORT_IN | HOGPD_CFG_REPORT_WR;

    db_cfg->cfg[0].report_id[3] = 3;
    db_cfg->cfg[0].report_char_cfg[3] = HOGPD_CFG_REPORT_OUT;
    // HID Information
    db_cfg->cfg[0].hid_info.bcdHID       = 0x0111;         // HID Version 1.11
    db_cfg->cfg[0].hid_info.bCountryCode = 0x00;
    db_cfg->cfg[0].hid_info.flags = HIDS_REMOTE_WAKE_CAPABLE | HIDS_NORM_CONNECTABLE;
#else
    // The device is a keyboard
    db_cfg->cfg[0].svc_features = HOGPD_CFG_KEYBOARD | HOGPD_CFG_PROTO_MODE;

    //Hid reports
    db_cfg->cfg[0].report_nb    = 23;
    db_cfg->cfg[0].report_id[0] = 1;
    db_cfg->cfg[0].report_id[1] = 2;
    db_cfg->cfg[0].report_id[2] = 3;
    db_cfg->cfg[0].report_id[3] = 4;
    db_cfg->cfg[0].report_id[4] = 5;
    db_cfg->cfg[0].report_id[5] = 6;
    db_cfg->cfg[0].report_id[6] = 7;
    db_cfg->cfg[0].report_id[7] = 8;

    db_cfg->cfg[0].report_id[8] = 224;
    db_cfg->cfg[0].report_id[9] = 225;
    db_cfg->cfg[0].report_id[10] = 226;
    db_cfg->cfg[0].report_id[11] = 227;
    db_cfg->cfg[0].report_id[12] = 228;
    db_cfg->cfg[0].report_id[13] = 229;
    db_cfg->cfg[0].report_id[14] = 230;
    db_cfg->cfg[0].report_id[15] = 231;
    db_cfg->cfg[0].report_id[16] = 232;
    db_cfg->cfg[0].report_id[17] = 233;
    db_cfg->cfg[0].report_id[18] = 234;
    db_cfg->cfg[0].report_id[19] = 235;
    db_cfg->cfg[0].report_id[20] = 236;
    db_cfg->cfg[0].report_id[21] = 237;
    db_cfg->cfg[0].report_id[22] = 238;
    // report featrues
    db_cfg->cfg[0].report_char_cfg[0] = HOGPD_CFG_REPORT_IN | HOGPD_REPORT_NTF_CFG_MASK | HOGPD_CFG_REPORT_WR;
    db_cfg->cfg[0].report_char_cfg[1] = HOGPD_CFG_REPORT_OUT;
    db_cfg->cfg[0].report_char_cfg[2] = HOGPD_CFG_REPORT_IN | HOGPD_REPORT_NTF_CFG_MASK | HOGPD_CFG_REPORT_WR;
    for(uint8_t idx = 3; idx<23; idx++)
    {
        db_cfg->cfg[0].report_char_cfg[idx] = HOGPD_CFG_REPORT_FEAT;
    }

    // HID Information
    db_cfg->cfg[0].hid_info.bcdHID       = 0x0100;         // HID Version 1.11
    db_cfg->cfg[0].hid_info.bCountryCode = 0x00;
    db_cfg->cfg[0].hid_info.flags        = 0x00;    //HIDS_REMOTE_WAKE_CAPABLE | HIDS_NORM_CONNECTABLE;
#endif

    // Send the message
    ke_msg_send(req);
}
void app_hid_stop_timer(void)
{
    if (ke_timer_active(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP))
    {
        ke_timer_clear(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP);
    }
}
/*
 ****************************************************************************************
 * @brief Function called when get connection complete event from the GAP
 *
 ****************************************************************************************
 */
void app_hid_enable_prf(uint8_t conidx)
{
    // Requested connection parameters
//    struct gapc_conn_param conn_param;


    // Store the connection handle
    app_hid_env.conidx = conidx;

    // Allocate the message
    struct hogpd_enable_req * req = KE_MSG_ALLOC(HOGPD_ENABLE_REQ,
                                    prf_get_task_from_id(TASK_ID_HOGPD),
                                    TASK_APP,
                                    hogpd_enable_req);

    // Fill in the parameter structure
    req->conidx             = conidx;
    // Notifications are enable

    if(app_env.func[APP_EVT_ID_REQ_INFO] !=NULL)
        memcpy( (void *)&(req->ntf_cfg[conidx]), get_stored_info_req(HID_INFO_TYPE_NTF),sizeof(uint16_t) );
    else
    {
        req->ntf_cfg[conidx] = HOGPD_CFG_REPORT_NTF_EN
                               | (HOGPD_CFG_REPORT_NTF_EN<<2) | (HOGPD_CFG_REPORT_NTF_EN<<3)| (HOGPD_CFG_REPORT_NTF_EN<<4)
                               | (HOGPD_CFG_REPORT_NTF_EN<<5) | (HOGPD_CFG_REPORT_NTF_EN<<6)| (HOGPD_CFG_REPORT_NTF_EN<<7);
        //printf("NOTE:need register func,id:APP_EVT_ID_REQ_INFO !!!\r\n");
        //while(1);
    }
    printf("req->ntf_cfg:%x\r\n",req->ntf_cfg[conidx]);

    // Go to Enabled state
    app_hid_env.state = APP_HID_READY;


    if (app_sec_get_bond_status())
    {
        //Restore the cfg and nb_report.

        // The device is ready to send reports to the peer device
        app_hid_env.state = APP_HID_READY;
        app_hid_env.nb_report = APP_HID_NB_SEND_REPORT;

#if 1
        app_hid_env.timeout = APP_HID_SILENCE_DURATION_1;
        if (app_hid_env.timeout != 0)
        {
            //ke_timer_set(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP, (uint16_t)(app_hid_env.timeout));
            app_hid_env.timer_enabled = true;
        }
#endif
    }

    /*
     * Requested connection interval: 10ms
     * Latency: 25
     * Supervision Timeout: 2s
     */
#if 0           //for mouse    
    conn_param.intv_min = 8;
    conn_param.intv_max = 8;
    conn_param.latency  = 25;
    conn_param.time_out = 200;
#endif
    //appm_update_param(conidx,&conn_param);

    // Send the message
    ke_msg_send(req);
}
uint8_t get_hid_nb_report(void)
{
    return app_hid_env.nb_report;
}

void app_hid_send_keyboard_report(uint8_t report_idx, uint8_t *report_data)
{
    uint8_t report_length;
    struct hogpd_env_tag* hogpd_env = PRF_ENV_GET(HOGPD, hogpd);

    switch (app_hid_env.state)
    {
        case (APP_HID_WAIT_REP):
            // Go back to the ready state
            app_hid_env.state = APP_HID_READY;
        case (APP_HID_READY):
        {
            // Check if the report can be sent
            if (app_hid_env.nb_report)
            {
                /*
                    if(report_idx == 0 || report_idx == 2)
                    {
                        report_length = 8;
                    }
                    else
                    {
                        report_length = 2;
                    }
                */
#if defined(HID_IOS_KEYBOARD_MAP)
                if(report_idx == 2)
                {
                    report_length = 8;
                }
                else if(report_idx == 0)
                {
                    report_length = 4;
                }
                else
                {
                    report_length = 1;
                }
#else
                if(report_idx == 0)
                {
                    report_length = 8;
                }
                else if(report_idx == 4)
                {
                    report_length = 20;
                }
                else
                {
                    report_length = 60;
                }
#endif

                // Allocate the HOGPD_REPORT_UPD_REQ message
                struct hogpd_report_upd_req * req = KE_MSG_ALLOC_DYN(HOGPD_REPORT_UPD_REQ,
                                                    prf_get_task_from_id(TASK_ID_HOGPD),
                                                    TASK_APP,
                                                    hogpd_report_upd_req,
                                                    report_length);

                req->conidx  = app_hid_env.conidx;
                //now fill report
                req->report.hid_idx  = app_hid_env.conidx;
                req->report.type     = HOGPD_REPORT; //HOGPD_BOOT_MOUSE_INPUT_REPORT;//
                req->report.idx      = report_idx;
                req->report.length   = report_length;
                memcpy(&req->report.value[0], report_data, report_length);
                HID_LOG("hid rpt:[0]%02X,[2]%02X,idx:%d\r\n",report_data[0],report_data[2],report_idx);
                HID_LOG("env_ntf_cfg:%08X\r\n",hogpd_env->svcs[app_hid_env.conidx].ntf_cfg[app_hid_env.conidx]);

                ke_msg_send(req);

                app_hid_env.nb_report--;

                // Restart the mouse timeout timer if needed
                if (app_hid_env.timeout != 0)
                {
                    // ke_timer_set(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP, (uint16_t)(app_hid_env.timeout));
                    // app_hid_env.timer_enabled = true;
                }
            }
        }
        break;
#if 0
        case (APP_HID_WAIT_REP):
        {
            // Requested connection parameters
            struct gapc_conn_param conn_param;

            /*
             * Requested connection interval: 10ms
             * Latency: 25
             * Supervision Timeout: 2s
             */
            conn_param.intv_min = 8;
            conn_param.intv_max = 8;
            conn_param.latency  = 25;
            conn_param.time_out = 200;

            appm_update_param_internal(&conn_param);

            // Restart the mouse timeout timer if needed
            if (app_hid_env.timeout != 0)
            {
                //ke_timer_set(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP, (uint16_t)(app_hid_env.timeout));
                app_hid_env.timer_enabled = true;
            }

            // Go back to the ready state
            app_hid_env.state = APP_HID_READY;
        }
        break;
#endif
        case (APP_HID_IDLE):
        {
            // Try to restart advertising if needed
            //         appm_start_advertising(NULL);
        }
        break;

        // DISABLE and ENABLED states
        default:
        {
            // Drop the message
        } break;
    }
}
void app_hid_send_data_report(uint8_t report_idx, uint8_t *report_data,uint32_t data_len)
{
    struct hogpd_env_tag* hogpd_env = PRF_ENV_GET(HOGPD, hogpd);
    switch (app_hid_env.state)
    {
        case (APP_HID_WAIT_REP):
            app_hid_env.state = APP_HID_READY;
        case (APP_HID_READY):
        {
            if (app_hid_env.nb_report)
            {
                struct hogpd_report_upd_req * req = KE_MSG_ALLOC_DYN(HOGPD_REPORT_UPD_REQ,
                                                    prf_get_task_from_id(TASK_ID_HOGPD),
                                                    TASK_APP,
                                                    hogpd_report_upd_req,
                                                    data_len);
                req->conidx  = app_hid_env.conidx;
                req->report.hid_idx  = app_hid_env.conidx;
                req->report.type     = HOGPD_REPORT;
                req->report.idx      = report_idx;
                req->report.length   = data_len;
                memcpy(&req->report.value[0], report_data, data_len);
                ke_msg_send(req);
                app_hid_env.nb_report--;
            }
        }
        break;
        default:
            break;
    }
}
/**
 ****************************************************************************************
 * @brief
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int app_hid_msg_dflt_handler(ke_msg_id_t const msgid,
                                    void const *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
    // Drop the message

    return (KE_MSG_CONSUMED);
}

static int hogpd_enable_rsp_handler(ke_msg_id_t const msgid,
                                    struct hogpd_enable_rsp const *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{

    return (KE_MSG_CONSUMED);
}

static int hogpd_ntf_cfg_ind_handler(ke_msg_id_t const msgid,
                                     struct hogpd_ntf_cfg_ind const *param,
                                     ke_task_id_t const dest_id,
                                     ke_task_id_t const src_id)
{
    HID_LOG("ntf_cfg_ind_hdl\r\n");

    if (app_hid_env.conidx == param->conidx)
    {
        if ((param->ntf_cfg[param->conidx] & HOGPD_CFG_REPORT_NTF_EN ) != 0)
        {
            // The device is ready to send reports to the peer device
            app_hid_env.state = APP_HID_READY;
        }
        else
        {
            // Come back to the Enabled state
            if (app_hid_env.state == APP_HID_READY)
            {
                app_hid_env.state = APP_HID_ENABLED;
            }
        }

        if (app_hid_env.timeout != 0)
        {
            if (!ke_timer_active(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP))
            {
                //ke_timer_set(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP, (uint16_t)(app_hid_env.timeout));
                app_hid_env.timer_enabled = true;
            }
        }

        HID_LOG("ntf_save:%08X\r\n",param->ntf_cfg[param->conidx]);
        if(app_env.func[APP_EVT_ID_GOT_INFO] !=NULL)
        {
            store_infot_t tmp ;
            tmp.buf = (void *)&param->ntf_cfg[param->conidx];
            tmp.len = sizeof(uint16_t);
            tmp.info_type = HID_INFO_TYPE_NTF;
            app_env.func[APP_EVT_ID_GOT_INFO]((void*)&tmp);
        }
        else
        {
            printf("NOTE:need register func,id:APP_EVT_ID_GOT_INFO !!!\r\n");
            while(1);
        }


    }

    return (KE_MSG_CONSUMED);
}

void  __attribute__((weak)) hogpd_write_data_ind(uint8_t conidx,struct hogpd_report_req_ind *param)
{
    ;
}
bool  __attribute__((weak)) hogpd_read_data_ind(uint8_t conidx,struct hogpd_report_req_ind *param,uint8_t *value, uint16_t *len)
{
    return false;
}


static int hogpd_report_req_ind_handler(ke_msg_id_t const msgid,
                                        struct hogpd_report_req_ind const *param,
                                        ke_task_id_t const dest_id,
                                        ke_task_id_t const src_id)
{
    if ((param->operation == HOGPD_OP_REPORT_READ) && (param->report.type == HOGPD_REPORT_MAP))
    {
        struct hogpd_report_cfm *req = KE_MSG_ALLOC_DYN(HOGPD_REPORT_CFM,
                                       src_id, ///prf_get_task_from_id(TASK_ID_HOGPD),/* src_id */
                                       dest_id, ///TASK_APP,
                                       hogpd_report_cfm,
                                       APP_HID_KEYBOARD_REPORT_MAP_LEN );          //APP_HID_KEYBOARD_REPORT_MAP_LEN

        req->conidx = app_hid_env.conidx;
        /// Operation requested (read/write @see enum hogpd_op)
        req->operation = HOGPD_OP_REPORT_READ;
        /// Status of the request
        req->status = GAP_ERR_NO_ERROR;
        /// Report Info
        //req->report;
        /// HIDS Instance
        req->report.hid_idx = param->report.hid_idx;
        /// type of report (@see enum hogpd_report_type)
        req->report.type = HOGPD_REPORT_MAP;
        /// Report Length (uint8_t)

        req->report.length = APP_HID_KEYBOARD_REPORT_MAP_LEN;
        /// Report Instance - 0 for boot reports and report map
        req->report.idx = 0;
        /// Report data
        memcpy(&req->report.value[0], &hid_keyboard_report_map_user[0], APP_HID_KEYBOARD_REPORT_MAP_LEN);   //APP_HID_KEYBOARD_REPORT_MAP_LEN

        // Send the message
        ke_msg_send(req);
    }
    else
    {
#define OP_STR(x)   ((x == HOGPD_OP_REPORT_READ)?"RPT_READ":"RPT_WRITE")
        HID_LOG("operation: %s, type: %d. idx: %d\r\n", OP_STR(param->operation), param->report.type, param->report.idx);
// hanlde your value here.
        struct hogpd_report_cfm *req = KE_MSG_ALLOC_DYN(HOGPD_REPORT_CFM,
                                       prf_get_task_from_id(TASK_ID_HOGPD),/* src_id */
                                       TASK_APP,
                                       hogpd_report_cfm,
                                       12/*param->report.length*/);

        req->conidx = param->conidx; ///app_hid_env.conidx; ///???
        /// Operation requested (read/write @see enum hogpd_op)
        req->operation = param->operation;
        /// Status of the request
        req->status = GAP_ERR_NO_ERROR;
        /// HIDS Instance
        req->report.hid_idx = param->report.hid_idx;
        /// type of report (@see enum hogpd_report_type)
        req->report.type = param->report.type;//-1;//outside
        /// Report Length (uint8_t)
        if ((param->operation == HOGPD_OP_REPORT_READ) && (param->report.type == HOGPD_REPORT))
        {
            if( hogpd_read_data_ind(KE_IDX_GET(src_id),(struct hogpd_report_req_ind *)param,req->report.value,&(req->report.length)) == false)
            {
            /*
                if(param->report.idx == 8)
                {
                    req->report.length = 12;
                    memcpy(req->report.value,"\x27\x17\x32\xb0\x10\x24\x64\x19\x80\x00\x00\x00",12);
                }
                else if(param->report.idx == 9)
                {
                    req->report.length = 6;
                    memcpy(req->report.value,"\x00\x00\x00\x20\x00\x14",6);
                }
                else if(param->report.idx == 11)
                {
                    req->report.length = 1;
                    memcpy(req->report.value,"\x00",1);
                }
                else if(param->report.idx == 12)
                {
                    req->report.length = 3;
                    memcpy(req->report.value,"\x00\x00\x00",3);
                }
                else if(param->report.idx == 16)
                {
                    //req->report.length = 13;
                    //memcpy(req->report.value,"\x00\x00\x00\x00\x20\x00\x10\x00\x05\x00\x00\x00\x00",13);
                }
                else if(param->report.idx == 17)
                {

                }
             */
            }
        }
        else if( (param->operation == HOGPD_OP_REPORT_WRITE) && (param->report.type == HOGPD_REPORT) )
        {
            hogpd_write_data_ind(KE_IDX_GET(src_id),(struct hogpd_report_req_ind *)param);
            req->report.length = 0;
        }

        /// Report Instance - 0 for boot reports and report map
        req->report.idx = param->report.idx; //0;
        // Send the message
        ke_msg_send(req);
    }


    return (KE_MSG_CONSUMED);
}

static int hogpd_proto_mode_req_ind_handler(ke_msg_id_t const msgid,
        struct hogpd_proto_mode_req_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{

    if ((param->conidx == app_hid_env.conidx) && (param->operation == HOGPD_OP_PROT_UPDATE))
    {
        //make use of param->proto_mode
        struct hogpd_proto_mode_cfm *req = KE_MSG_ALLOC_DYN(HOGPD_PROTO_MODE_CFM,
                                           prf_get_task_from_id(TASK_ID_HOGPD),/* src_id */
                                           TASK_APP,
                                           hogpd_proto_mode_cfm,
                                           0);
        /// Connection Index
        req->conidx = app_hid_env.conidx;
        /// Status of the request
        req->status = GAP_ERR_NO_ERROR;
        /// HIDS Instance
        req->hid_idx = app_hid_env.conidx;
        /// New Protocol Mode Characteristic Value
        req->proto_mode = param->proto_mode;

        // Send the message
        ke_msg_send(req);
    }
    else
    {
        struct hogpd_proto_mode_cfm *req = KE_MSG_ALLOC_DYN(HOGPD_PROTO_MODE_CFM,
                                           prf_get_task_from_id(TASK_ID_HOGPD),/* src_id */
                                           TASK_APP,
                                           hogpd_proto_mode_cfm,
                                           0);
        /// Status of the request
        req->status = ATT_ERR_APP_ERROR;

        /// Connection Index
        req->conidx = app_hid_env.conidx;
        /// HIDS Instance
        req->hid_idx = app_hid_env.conidx;
        /// New Protocol Mode Characteristic Value
        req->proto_mode = param->proto_mode;

        // Send the message
        ke_msg_send(req);
    }
    return (KE_MSG_CONSUMED);
}

static int hogpd_ctnl_pt_ind_handler(ke_msg_id_t const msgid,
                                     struct hogpd_ctnl_pt_ind const *param,
                                     ke_task_id_t const dest_id,
                                     ke_task_id_t const src_id)
{


    if (param->conidx == app_hid_env.conidx)
    {
        //make use of param->hid_ctnl_pt
        struct hogpd_report_cfm *req = KE_MSG_ALLOC_DYN(HOGPD_REPORT_CFM,
                                       prf_get_task_from_id(TASK_ID_HOGPD),/* src_id */
                                       TASK_APP,
                                       hogpd_report_cfm,
                                       0);

        req->conidx = param->conidx; ///app_hid_env.conidx; ///???
        /// Operation requested (read/write @see enum hogpd_op)
        req->operation = HOGPD_OP_REPORT_WRITE;
        /// Status of the request
        req->status = GAP_ERR_NO_ERROR;  ///???
        /// Report Info
        //req->report;
        /// HIDS Instance
        req->report.hid_idx = app_hid_env.conidx; ///???
        /// type of report (@see enum hogpd_report_type)
        req->report.type = (uint8_t)-1;//outside
        /// Report Length (uint8_t)
        req->report.length = 0;
        /// Report Instance - 0 for boot reports and report map
        req->report.idx = 0;
        /// Report data


        // Send the message
        ke_msg_send(req);
    }
    return (KE_MSG_CONSUMED);
}


void  __attribute__((weak)) hogpd_report_upd_wkfunc(uint8_t nb_report)
{
    ;
}

static int hogpd_report_upd_handler(ke_msg_id_t const msgid,
                                    struct hogpd_report_upd_rsp const *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
    HID_LOG("rpt upd done,st(hl code):0x%x\r\n",param->status);
    if (app_hid_env.conidx == param->conidx)
    {
        if (GAP_ERR_NO_ERROR == param->status)
        {
            if (app_hid_env.nb_report < APP_HID_NB_SEND_REPORT)
            {
                app_hid_env.nb_report++;
                hogpd_report_upd_wkfunc(app_hid_env.nb_report);
            }
        }
        else
        {
            // we get this message if error occur while sending report
            // most likely - disconnect
            // Go back to the ready state
            app_hid_env.state = APP_HID_IDLE;
            // change mode
            // restart adv
            // Try to restart advertising if needed
            // appm_start_advertising(NULL);
            //report was not success - need to restart???
        }
    }
    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Function called when the APP_HID_MOUSE_TIMEOUT_TIMER expires.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int app_hid_keyboard_timeout_timer_handler(ke_msg_id_t const msgid,
        void const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    app_hid_env.timer_enabled = false;

    if (app_hid_env.state == APP_HID_READY)
    {
        if(app_env.param_update_on_going == false)
        {
            // Requested connection parameters
            struct gapc_conn_param conn_param;

            /*
             * Request an update of the connection parameters
             * Requested connection interval: 10ms
             * Latency: 200
             * Supervision Timeout: 5s
             */
            conn_param.intv_min = 6;
            conn_param.intv_max = 6;
            conn_param.latency  = 100;
            conn_param.time_out = 500;
            appm_update_param(KE_IDX_GET(src_id), &conn_param);

            // Go to the Wait for Report state
            app_hid_env.state = APP_HID_WAIT_REP;
            app_hid_env.timeout = 0;
        }
        else
        {
            //timer_val = APP_HID_SILENCE_DURATION_2;
            // Relaunch the timer
            //ke_timer_set(APP_HID_KEYBOARD_TIMEOUT_TIMER, TASK_APP, (uint16_t)(app_hid_env.timeout));
            app_hid_env.timer_enabled = true;
        }
    }
    else if (app_hid_env.state == APP_HID_WAIT_REP)
    {
        // Disconnect the link with the device
        appm_disconnect(0);


        // Go back to the ready state
        app_hid_env.state = APP_HID_IDLE;
    }

    return (KE_MSG_CONSUMED);
}

/*
 * LOCAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Default State handlers definition
const struct ke_msg_handler app_hid_msg_handler_list[] =
{
    // Note: first message is latest message checked by kernel so default is put on top.
    {KE_MSG_DEFAULT_HANDLER,        (ke_msg_func_t)app_hid_msg_dflt_handler},

    {HOGPD_ENABLE_RSP,              (ke_msg_func_t)hogpd_enable_rsp_handler},
///  notification configuration changed
    {HOGPD_NTF_CFG_IND,             (ke_msg_func_t)hogpd_ntf_cfg_ind_handler},
    {HOGPD_REPORT_REQ_IND,          (ke_msg_func_t)hogpd_report_req_ind_handler},
    {HOGPD_PROTO_MODE_REQ_IND,      (ke_msg_func_t)hogpd_proto_mode_req_ind_handler},

    {HOGPD_CTNL_PT_IND,             (ke_msg_func_t)hogpd_ctnl_pt_ind_handler},

    {HOGPD_REPORT_UPD_RSP,          (ke_msg_func_t)hogpd_report_upd_handler},
    {APP_HID_KEYBOARD_TIMEOUT_TIMER,(ke_msg_func_t)app_hid_keyboard_timeout_timer_handler},
};

const struct ke_state_handler app_hid_table_handler =
{&app_hid_msg_handler_list[0], (sizeof(app_hid_msg_handler_list)/sizeof(struct ke_msg_handler))};


#endif //(BLE_APP_HID)

/// @} APP
