
#ifndef _SSC_H_
#define _SSC_H_

#include "ke_task.h"
#include "arch.h"

#define RXBUFSIZE 127

#define SSC_DBG FR_DBG_OFF
#define ssc_printf FR_LOG(SSC_DBG)

struct uart_come_cmd
{
    uint8_t cmd_come;
};

typedef struct uart_cmd
{
    uint8_t rec_data[RXBUFSIZE];
    uint8_t com_tail;           //for uart0  string input
    uint8_t cmd_lin_end;        //for uart0  string input
    uint8_t data_drop;  //ssc_enabled, then drop data before function done.  //for uart0  string input
    uint8_t ssc_enable; //if ssc_enabled

    uint8_t uart1_task_created;
    uint8_t uart1_r_count;      //if uart1 recv a cmd with 0x5a sync word
    uint8_t uart1_cmd_recved;
    uint8_t uart1_cmd_start;
} uart_cmd_t;


typedef struct cmd_s
{
    char * cmd_str;
    uint8_t   flag;
    uint8_t   id;
    void (* cmd_func)(void);
    void (* cmd_callback)(void *arg);
} ssc_cmd_t;


enum
{
    CMD_OP = 0,
    CMD_KE,
    CMD_ADV,
    CMD_SCAN,
    CMD_CONN,
#if( USER_MI_CONTROLLER || USER_MI_BOX )
    CMD_MI,         //For mi_controller
#endif
    //CMD_HBTV,         //For hbtv
    //CMD_HQTANK,           //For hqtank
    CMD_MAX_END,
};


#define CMD_T_ASYNC   0x01
#define CMD_T_SYNC    0x02
#define MAX_LINE_N    RXBUFSIZE //127
#define PROMPT  ":>"
enum
{
    FAIL,
    SUCCESS,
};


//For task
struct ssc_q_cmd
{
    uint32_t par;
    uint32_t sig;
};

enum UART_TEST_MSG
{
    SIG_SSC_RUNCMD = KE_FIRST_MSG(TASK_UART_TEST),
    /// Database Initialization State
    SIG_SSC_CMDDONE,
    SIG_SSC_RESTART,
    SIG_SSC_UART_RX_CHAR,
    SIG_SSC_CMD_FAIL,
};

/// States of APP task
enum TASK_UART_TEST_STATE
{
    UART_TEST_IDLE,
    UART_TEST_STATE_MAX,
};


void user_ssc_init(void);


void ssc_attach(void) ;
uint8_t *ssc_param_str(void) ;
void ssc_register(ssc_cmd_t *cmdset, uint8_t cmdnum,
                  void (* help)(void)) ;

extern ssc_cmd_t sscCmdSet[];
void ssc_help(void);

#endif /* _SSC_H_ */
