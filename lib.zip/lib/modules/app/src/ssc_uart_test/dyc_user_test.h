#ifndef __USER_TEST_H__
#define __USER_TEST_H__


#include "global_io.h"


struct test_param
{
    uint32 d ;       //delay
    uint16 e ;       //end
    uint16 b ;       //beign
    uint8 a ;        //auto load
//above is for timer
    uint16 h;       //heap size
    uint16 p ;       //prio beign
    uint8 q ;        //q=1, need give msg to queue from id=q to upper
    uint8 w ;        //w=1, wait for msg;  w= 0, delay
    uint8 t ;        //t=1, task suspend tsks;   t=2, in ISR cal pdkf2;  t=3, freq uart isr.
//above is for tsk
};





/*
void ICACHE_FLASH_ATTR user_test_tcpclient_send_task(void * pvParameters);
void ICACHE_FLASH_ATTR user_test_tcpserver_task(void * pvParameters);

void ICACHE_FLASH_ATTR user_test_tcpclient_only_connect(struct test_param *test);
void ICACHE_FLASH_ATTR user_test_tcpclient_only_disconnect(void);

void ICACHE_FLASH_ATTR user_test_udpclient_send_task(void * pvParameters);
void ICACHE_FLASH_ATTR udpserver_task(void * pvParameters);
*/
#endif


