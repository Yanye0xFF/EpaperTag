
#include <stdio.h>
#include <string.h>

#include "arch.h"
#include "app.h"
#include "dyc_uart_console_task.h"
#include "gapm_task.h"

#ifdef KEEP_SSC_CODE

#define in_range(c, lo, up)  ((uint8_t)c >= lo && (uint8_t)c <= up)
#define isprint(c)           in_range(c, 0x20, 0x7f)
#define isdigit(c)           in_range(c, '0', '9')
#define isxdigit(c)          (isdigit(c) || in_range(c, 'a', 'f') || in_range(c, 'A', 'F'))
#define islower(c)           in_range(c, 'a', 'z')
#define isspace(c)           (c == ' ' || c == '\f' || c == '\n' || c == '\r' || c == '\t' || c == '\v')
#define tolower(c)          ( (c>64 && c<91)?(c+32):c )


static void ssc_op_mode(void);
static void ssc_ke(void);
static void ssc_adv(void);
static void ssc_scan(void);
static void ssc_conn(void);

#if( USER_MI_CONTROLLER || USER_MI_BOX )
static void ssc_mi_controller(void);
#endif
//static void ssc_hbtv(void);
//static void ssc_hqtank(void);

static ssc_cmd_t sscCmdSet[CMD_MAX_END] =
{
    {"op", CMD_T_SYNC, CMD_OP, ssc_op_mode, NULL},
    {"ke", CMD_T_SYNC, CMD_KE, ssc_ke, NULL},
    {"adv", CMD_T_SYNC, CMD_ADV, ssc_adv, NULL },
    {"scan", CMD_T_SYNC, CMD_SCAN, ssc_scan, NULL },
    {"con", CMD_T_SYNC, CMD_CONN, ssc_conn, NULL },
#if( USER_MI_CONTROLLER || USER_MI_BOX )
    {"mi", CMD_T_SYNC, CMD_MI, ssc_mi_controller, NULL },
#endif
#if(USER_HBTV)
    {"hbtv", CMD_T_SYNC, CMD_HBTV, ssc_hbtv, NULL },
#endif
#if(USER_HQTANK)
    {"hqtank", CMD_T_SYNC, CMD_HQTANK, ssc_hqtank, NULL },
#endif

};

/*
static uint32_t __INLINE
ssc_getul_plus(char *str)
{
    uint32_t ret = 0;
    uint32_t value;
    uint32_t base = 10;
    if(*str == '0')
    {
        base = 8;
        str++;
        if((tolower(*str) == 'x') && isxdigit(str[1]))
        {
            base=16;
            str++;
        }
    }
    while(isxdigit(*str) && (value=isdigit(*str) ? *str-'0' : tolower(*str)-'a'+10)< base)
    {
        ret = ret*base +value;
        str++;
    }
    return ret;
}
*/
static uint32_t __INLINE
ssc_getul(char *str)
{
    uint32_t ret = 0;

    while (isdigit(*str))
    {
        ret = ret * 10 + *str++ - '0';
    }

    return ret;
}

static int
ssc_parse_param(char *pLine, char *argv[])
{
    int nargs = 0;

    while (nargs < MAX_LINE_N)
    {
        while ((*pLine == ' ') || (*pLine == '\t'))
        {
            ++pLine;
        }

        if (*pLine == '\0')
        {
            argv[nargs] = NULL;
            return (nargs);
        }

        argv[nargs++] = pLine;

        while (*pLine && (*pLine != ' ') && (*pLine != '\t'))
        {
            ++pLine;
        }

        if (*pLine == '\0')
        {
            argv[nargs] = NULL;
            return (nargs);
        }

        *pLine++ = '\0';
    }

    return (nargs);
}

static int optind = 0;
static int optopt;
static char *optarg;

static int
getopt(int argc, char *const argv[], const char *optstring)
{
    static int optchr = 1;
    char *cp;

    /* chark input error */
    if (optchr == 1)
    {
        if (optind >= argc)
        {
            /* all arguments processed */
            return -1;
        }

        if (argv[optind][0] != '-' || argv[optind][1] == '\0')
        {
            /* no option characters */
            return -1;
        }
    }

    if (strcmp(argv[optind], "--") == 0)
    {
        /* no more options */
        optind++;
        return -1;
    }

    optopt = argv[optind][optchr];
    cp = (char *) strchr(optstring, optopt);

    if (cp == NULL || optopt == ':')
    {
        if (argv[optind][++optchr] == '\0')
        {
            optchr = 1;
            optind++;
        }

        return '?';
    }

    if (cp[1] == ':')
    {
        /* Argument required */
        optchr = 1;

        if (argv[optind][optchr + 1])
        {
            /* No space between option and argument */
            optarg = &argv[optind++][optchr + 1];
        }
        else if (++optind >= argc)
        {
            /* option requires an argument */
            return '?';
        }
        else
        {
            /* Argument in the next argv */
            optarg = argv[optind++];
        }
    }
    else
    {
        /* No argument */
        if (argv[optind][++optchr] == '\0')
        {
            optchr = 1;
            optind++;
        }

        optarg = NULL;
    }

    return *cp;
}


#include "l2cm.h"
#include "llm.h"
#include "llc.h"
#include "lld_evt.h"
#include "app.h"

static void ssc_op_mode(void)
{
    char *argv[10], pLine[128], argc;
    int c;
    uint8_t mode = 0;
    uint32_t p = 0;

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
    printf("op_mode\r\n");

    optind = 0;

    for (;;)
    {
        c = getopt(argc, argv, "o:p:SEBRTNCMXD");

        if (c < 0)
        {
            break;
        }

        switch (c)
        {
            case 'p':
                p = ssc_getul(optarg);
                break;

            case 'f':

                break;

            case 'l':

                break;

            case 't':

                break;
            case 'C':                   //sleep ble
                mode = 'C';
                break;
            case 'D':                   //sleep ble
                mode = 'D';
                break;
            case 'E':                   //sleep ble
                mode = 'E';
                break;
            case 'S':                   //sleep ble
                mode = 'S';
                break;
            case 'R':                   //Reset ble
                mode = 'R';
                break;
            case 'T':                   //Tx test
                mode = 'T';
                break;
            case 'N':                   //Tx test
                mode = 'N';
                break;
            case 'B':                   //Reboot
                mode = 'B';
                break;
            case 'M':                   //Reboot
                mode = 'M';
                break;
            case 'X':                   //Reboot
                mode = 'X';
                break;
        }
    }
    if(mode == 'X')
    {
        printf("pkt_l:%d,nb_pkt:%d\r\n",l2cm_env.buf_mon.le_acl_data_pkt_len,l2cm_env.buf_mon.le_acl_total_nb_acl_pkt);
        printf("llm_mask[0]:%x,[1]:%x\r\n",llm_le_env.eventmask.mask[0],llm_le_env.eventmask.mask[1]);
        printf("sent:%d\r\n",GETF(llc_env[0]->data_len_ext_info.data_len_ext_flag, LLC_DLE_EVT_SENT));

        struct lld_evt_wait_tag *scan_wait_list = (struct lld_evt_wait_tag *)co_list_pick(&lld_evt_env.elt_wait);

        while (scan_wait_list != NULL)
        {
            printf("%p\r\n",scan_wait_list->elt_ptr);
            scan_wait_list = (struct lld_evt_wait_tag *)scan_wait_list->hdr.next;
        }
    }
    else if(mode == 'R')
    {
        extern void app_reset_app(void);
        app_reset_app();
    }
    else if(mode == 'D')
    {
        if(p==1)
        {
#if FLASH_TEST_ENABLE
            extern void test_flash(void);
            test_flash();
#endif
        }
        else if(p==2)
        {
            printf("watchdog test\r\n");
            while(1);
        }

    }
    else if(mode == 'C')
    {
        appm_goto_deep_sleep2(DEEP_SLEEP_WK_ONKEY,0);
//#include "gpio_dbg_lib.h"
        //      gpio_dbg_toggle(10);
    }
    else if(mode == 'E')
    {
        appm_goto_deep_sleep2(DEEP_SLEEP_WK_GPIO,p);
    }
    else if(mode == 'N')
    {
#ifdef CFG_SBC
#if MIC_TEST_ENABLE
#include "enc_sbc.h"
        test_mic();
#endif
#endif

#ifdef CFG_DEC_SBC
#if SPEAKER_TEST_ENABLE
#include "dec_sbc.h"
        //test_speaker();
        if(p == 2)
            test_sotre_sbc_to_flash();
        else if( p == 1)
            test_speaker_from_flash();
        else if( p == 3)
            del_sbc_from_flash();
#endif
#endif

    }
    else if(mode == 'T')
    {
#include "user_sys.h"
        printf("now:%d\r\n",NOW());
    }
    else if(mode == 'B')
    {
        extern void sys_soft_reset(void);
        sys_soft_reset();
    }
    else if(mode == 'M')
    {
        extern void show_sys_mem_waterwave(void);
        show_sys_mem_waterwave();
    }
    else if(mode == 'S')
    {
#include "rwip.h"
        if (p == 1)
            rwip_prevent_sleep_set(RW_GPIO_INT_ONGOING);
        else if(p == 2)
            rwip_prevent_sleep_clear(RW_GPIO_INT_ONGOING);
        else if (p == 3)
        {
            struct gapc_conn_param conn_param;
            conn_param.intv_min = 40;
            conn_param.intv_max = 40;
            conn_param.latency  = 0;
            conn_param.time_out = 600;
            appm_update_param(app_env.conidx,&conn_param);
        }

    }
    else
    {
        printf("mode:%d\n",mode);
    }

}






static void ssc_adv(void)
{
    char *argv[16], pLine[128], argc;
    int ch;
    uint8_t mode = 0;

//    uint16_t e = 0;       //end
//    uint16_t b = 0;       //beign

//        struct test_param *test;

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
    printf("adv\r\n");

    optind = 0;

    for (;;)
    {
        ch = getopt(argc, argv, "b:e:ACSTD");

        if (ch < 0)
        {
            break;
        }

        switch (ch)
        {
            case 'b':
//                b = ssc_getul(optarg);
                break;

            case 'e':
//                e = ssc_getul(optarg);
                break;

            case 'C':
                mode = 'C';
                break;
            case 'A':
                mode = 'A';
                break;
            case 'T':
                mode = 'T';
                break;

            case 'D':
                mode = 'D';
                break;
            case 'S':
                mode = 'S';
                break;

        }
    }

    switch (mode)
    {
        case 'A':
        {
            struct gapm_start_advertise_cmd msg = {0} ;

            uint8_t device_name_length;
            int8_t device_name_avail_space;

            msg.op.code  = GAPM_ADV_UNDIRECT;//GAPM_ADV_UNDIRECT;//GAPM_ADV_NON_CONN;
            msg.op.addr_src = GAPM_STATIC_ADDR;
            msg.intv_min     =  0x200;           //APP_ADV_INT_MIN;              //0x40;
            msg.intv_max     =  0x400;       //APP_ADV_INT_MAX;
            msg.channel_map = APP_ADV_CHMAP;

            msg.info.host.mode = GAP_GEN_DISCOVERABLE;
            msg.info.host.adv_filt_policy = ADV_ALLOW_SCAN_ANY_CON_ANY;

            msg.info.host.adv_data_len = strlen("\x03\x02\x95\xfe");  //cant set type 0x01 flag; type cant be same
            memcpy(&msg.info.host.adv_data[0], "\x03\x02\x95\xfe", msg.info.host.adv_data_len);

            msg.info.host.scan_rsp_data_len = strlen("\x03\xFF\xfe\x01");
            memcpy(&msg.info.host.scan_rsp_data[0], "\x03\xFF\xfe\x01", msg.info.host.scan_rsp_data_len);

#if 1
            device_name_avail_space = APP_ADV_DATA_MAX_SIZE - msg.info.host.adv_data_len - 2;
            if (device_name_avail_space > 0)
            {
                device_name_length = strlen("ADV_TEST1");
                if(device_name_length > 0)
                {
                    device_name_length = co_min(device_name_length, device_name_avail_space);
                    msg.info.host.adv_data[msg.info.host.adv_data_len]   = device_name_length + 1;
                    msg.info.host.adv_data[msg.info.host.adv_data_len + 1] = '\x09';
                    memcpy(&msg.info.host.adv_data[msg.info.host.adv_data_len + 2], "ADV_TEST1", device_name_length);
                    msg.info.host.adv_data_len += (device_name_length + 2);
                }
            }
#else
            device_name_avail_space = APP_ADV_DATA_MAX_SIZE - msg.info.host.scan_rsp_data_len - 2;
            if (device_name_avail_space > 0)
            {
                device_name_length = strlen("ADV_TEST1");
                if(device_name_length > 0)
                {
                    device_name_length = co_min(device_name_length, device_name_avail_space);
                    msg.info.host.scan_rsp_data[msg.info.host.scan_rsp_data_len]     = device_name_length + 1;
                    msg.info.host.scan_rsp_data[msg.info.host.scan_rsp_data_len + 1] = '\x09';
                    memcpy(&msg.info.host.scan_rsp_data[msg.info.host.scan_rsp_data_len + 2], "ADV_TEST1", device_name_length);
                    msg.info.host.scan_rsp_data_len += (device_name_length + 2);
                }
            }
#endif
            appm_start_advertising(&msg);
        }


        break;
        case 'S':

            break;

        case 'T':
            appm_stop_advertising();

            break;

        default:
            break;
    }
}



static void
ssc_ke(void)
{
    char *argv[16], pLine[128], argc;
    int ch;
    uint8_t mode = 0;

//    uint32_t d = 0;       //delay
//    uint16_t e = 0;       //end
//    uint16_t b = 0;       //beign
//    uint8_t a = 0;        //auto load

//    uint16_t h = 128;       //tsk stack
    uint16_t p = 0 ;       //prio start num.
//    uint8_t q = 0;        //q=1, need give msg to queue from id=q to upper
//    uint8_t w = 0;        //w=1, wait for msg;  w= 0, delay
//    uint8_t t = 0;
//    struct test_param *test;

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
//        printf("ke\n");

    optind = 0;

    for (;;)
    {
        ch = getopt(argc, argv, "b:e:d:a:h:p:q:w:t:ACSMDPUIT");

        if (ch < 0)
        {
            break;
        }

        switch (ch)
        {
            case 'b':
//                b = ssc_getul(optarg);
                break;

            case 'e':
//                e = ssc_getul(optarg);
                break;

            case 'd':
//                d = ssc_getul(optarg);
                break;

            case 'a':
//                a = ssc_getul(optarg);
                break;

            case 'h':
//                h = ssc_getul(optarg);
                break;

            case 'p':
                p = ssc_getul(optarg);
                break;

            case 'q':
//                q = ssc_getul(optarg);
                break;

            case 'w':
//                w = ssc_getul(optarg);
                break;

            case 't':
//                t = ssc_getul(optarg);
                break;

            case 'C':
                mode = 'C';
                break;

            case 'A':
                mode = 'A';
                break;

            case 'D':
                mode = 'D';
                break;

            case 'S':
                mode = 'S';
                break;

            case 'P':
                mode = 'P';
                break;

            case 'U':
                mode = 'U';
                break;
            case 'M':
                mode = 'M';
                break;

            case 'I':
                mode = 'I';
                break;

            case 'T':
                mode = 'T';
                break;

            default:
                break;
        }
    }
    /*
            test = (struct test_param *) os_zalloc(sizeof(struct test_param));
            test->e = e;
            test->b = b;
                       test->d= d;
            test->a = a;

                     test->h = h;
                       test->p = p;
            test->q = q;
                       test->w = w;
            test->t = t; */
    printf("mode:%c\r\n",mode);



    switch (mode)
    {
        case 'C':
            break;

        case 'T':
            if(p==0)
            {
#include "user_mem.h"
#if(MEM_TEST_ENABLE && USER_MEM_API_ENABLE)
                extern void ke_mem_stastic_test(void);
                ke_mem_stastic_test();
#endif
            }
            else if(p == 1)
            {
#include "user_timer.h"
                printf("do_timer_T\r\n");
#if(TIME_TEST_ENABLE)
                extern void user_timer_test(void);
                user_timer_test();
#endif
            }
            else if(p == 2)
            {
#include "user_task.h"
                printf("do_task_T1\r\n");
#if(TASK_TEST_ENABLE)
                extern void user_task_test1(void);
                user_task_test1();
#endif
            }
            else if(p == 3)
            {
#include "user_task.h"
                printf("do_task_T2\r\n");
#if(TASK_TEST_ENABLE)
                extern void user_task_test2(void);
                user_task_test2();
#endif
            }

            break;

        case 'M':
        {
#include "user_mem.h"
#if(USER_MEM_API_ENABLE)
            extern void show_ke_malloc(void);
            show_ke_malloc();
#endif
        }
        break;

        case 'D':
        {
#include "user_mem.h"
#if(USER_MEM_API_ENABLE)
            extern void show_mem_list(void);
            show_mem_list();
#endif
        }
        break;

        case 'S':
        {
#include "user_mem.h"
#if(USER_MEM_API_ENABLE)
            extern void show_msg_list(void);
            show_msg_list();
#endif
        }
        break;

        case 'P':
        {
#include "user_profile.h"
#if(PROFILE_TEST_ENABLE)
            if(p == 0)
            {
                extern void test_profile(void);
                test_profile();
            }
            else if(p == 1)
            {
                extern void test_profile_client(void);
                test_profile_client();
            }

#endif
        }
        break;
        case 'A':
        {
            extern bool appm_add_svc(void);
            appm_add_svc();
        }
        break;

        case 'U':
        {
#include "user_profile.h"
#if(PROFILE_TEST_ENABLE)
            if(p == 0)
            {
                extern void test_profile_send_ntf(void);
                test_profile_send_ntf();
            }
            else if(p == 1)
            {
                extern void test_profile_client_disc_all_svc(void);
                test_profile_client_disc_all_svc();
            }
            else if(p == 2)
            {
                extern void start_flower_care_protocol(void);
                start_flower_care_protocol();
            }
#endif
        }
        break;

        case 'I':
        {
#include "user_profile.h"
#if(USER_PROFILE_API_ENABLE)
            extern void user_destroy_all_user_svc_db(void);
            user_destroy_all_user_svc_db();
#endif
        }
        break;

        default:
            break;
    }
}


static void
ssc_scan(void)
{
    char *argv[16], pLine[128], argc;
    int ch;
    uint8_t mode = 0;

//    uint32_t d = 0;       //delay
//    uint16_t e = 0;       //end
//    uint16_t b = 0;       //beign
//    uint8_t a = 0;        //auto load
//    struct test_param *test;

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
    printf("ssc_scan\r\n");

    optind = 0;

    for (;;)
    {
        ch = getopt(argc, argv, "b:e:d:a:CTDEB");

        if (ch < 0)
        {
            break;
        }

        switch (ch)
        {
            case 'b':
//                b = ssc_getul(optarg);
                break;

            case 'e':
//                e = ssc_getul(optarg);
                break;

            case 'd':
//                d = ssc_getul(optarg);
                break;

            case 'a':
//                a = ssc_getul(optarg);
                break;

            case 'C':
                mode = 'C';
                break;

            case 'D':
                mode = 'D';
                break;

            case 'E':
                mode = 'E';
                break;

            case 'T':
                mode = 'T';
                break;

            case 'B':
                mode = 'B';
                break;

            default:
                break;

        }
    }
    /*
    test = (struct test_param *) zalloc(sizeof(struct test_param));
    test->e = e;
    test->b = b;
               test->d= d;
    test->a = a; */
    switch (mode)
    {
        case 'C':
        {
            struct gapm_start_scan_cmd msg = {0};
            msg.mode = GAP_GEN_DISCOVERY; //GAP_OBSERVER_MODE;//GAP_GEN_DISCOVERY;
            msg.op.code = GAPM_SCAN_ACTIVE;
            msg.op.addr_src = GAPM_STATIC_ADDR;
            msg.filter_duplic = SCAN_FILT_DUPLIC_DIS;
            msg.interval = 64 ;//0x180;
            msg.window = 60;
            appm_start_scan(&msg);
        }
        break;

        case 'T':
            appm_stop_scan();

            break;

        case 'E':
            break;

        case 'B':
            break;
        default:
            break;
    }
}


static void
ssc_conn(void)
{
    char *argv[16], pLine[128], argc;
    int ch;
    uint8_t mode = 0;

//    uint32_t d = 0;       //delay
//    uint16_t e = 0;       //end
//    uint16_t b = 0;       //beign
//    uint8_t a = 0;        //auto load
//    struct test_param *test;

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
    printf("ssc_conn\r\n");

    optind = 0;

    for (;;)
    {
        ch = getopt(argc, argv, "b:e:d:a:CTDEB");

        if (ch < 0)
        {
            break;
        }

        switch (ch)
        {
            case 'b':
//                b = ssc_getul(optarg);
                break;

            case 'e':
//                e = ssc_getul(optarg);
                break;

            case 'd':
//                d = ssc_getul(optarg);
                break;

            case 'a':
//                a = ssc_getul(optarg);
                break;

            case 'C':
                mode = 'C';
                break;

            case 'D':
                mode = 'D';
                break;

            case 'E':
                mode = 'E';
                break;

            case 'T':
                mode = 'T';
                break;

            case 'B':
                mode = 'B';
                break;

            default:
                break;

        }
    }

    switch (mode)
    {
        case 'C':

            appm_start_connecting(NULL);

            break;

        case 'T':
            appm_stop_connecting();
            break;

        case 'D':
        {
#if (USER_FLOWER_CARE)
#include "flower_client_task.h"
            if( ke_timer_active(LIGHT_LED_TIMER_MSG,TASK_APP) )
                ke_timer_clear(LIGHT_LED_TIMER_MSG,TASK_APP);
#endif
            appm_disconnect(0);
        }
        break;

        case 'B':
//os_printf("create UDP task\n");
            //TimerBegin( test );
            break;

        default:
            break;
    }
}




#if( USER_MI_CONTROLLER || USER_MI_BOX )
//extern void UART1_SendBuf(uint8_t *buf,uint32_t len);

#if(USER_MI_CONTROLLER)
#include "proj_mi_controller.h"
#endif
#if(USER_MI_BOX)
#include "proj_mi_box.h"
#endif
static void
ssc_mi_controller(void)
{
    char *argv[16], pLine[128], argc;
    int ch;
    uint8_t mode = 0;

#if( USER_MI_CONTROLLER )
    uint8_t p = 0;
#endif

    strcpy(pLine, (const char *)ssc_param_str());
    argc = ssc_parse_param(pLine, argv);
    printf("ssc_mi_controller\n");

    optind = 0;

    for (;;)
    {
        ch = getopt(argc, argv, "p:AKTCDEBF");

        if (ch < 0)
        {
            break;
        }

        switch (ch)
        {
            case 'p':
#if( USER_MI_CONTROLLER )
                p = ssc_getul(optarg);
#endif
                break;

            case 'A':
                mode = 'A';
                break;

            case 'K':
                mode = 'K';
                break;

            case 'C':
                mode = 'C';
                break;
            case 'D':
                mode = 'D';
                break;
            case 'E':
                mode = 'E';
                break;

            case 'T':
                mode = 'T';
                break;

            case 'B':
                mode = 'B';
                break;

            case 'F':
                mode = 'F';
                break;

            default:
                break;

        }
    }
    switch (mode)
    {
#if( USER_MI_CONTROLLER )
        case 'A':
            mi_controller_start_advertising();
            break;
        case 'B':
            mi_controller_start_IndAdv();
            break;

        case 'K':
            mi_controller_hdl_key(p);
            break;

        case 'F':
            show_reg2((uint8_t *)&mi_controller_env.info,sizeof(mi_controller_env.info),1);
            break;

        case 'T':
        {
            extern void mi_controller_test_con_param(void);
            mi_controller_test_con_param();
        }
        break;

        case 'D':
            mi_controller_remove_bond();
            break;
#endif

#if( USER_MI_BOX )
        case 'D':
        {
            extern void mi_box_remove_bond(void);
            mi_box_remove_bond();
        }
        break;
        case 'T':
        {
            extern void mi_box_test_con_param(void);
            mi_box_test_con_param();
        }
        break;

        case 'C':
        {
            struct gapm_start_connection_cmd *cmd
                = (struct gapm_start_connection_cmd *)os_malloc(sizeof(struct gapm_start_connection_cmd) + sizeof(struct gap_bdaddr),KE_MEM_NON_RETENTION);

            cmd->op.code = GAPM_CONNECTION_DIRECT;
            cmd->op.addr_src = GAPM_STATIC_ADDR;
            cmd->scan_interval = APP_SCAN_INT;

            cmd->con_intv_min = APP_CONN_INT_MIN;
            cmd->con_intv_max = APP_CONN_INT_MIN;
            cmd->scan_window = APP_SCAN_WIN;//(param->con_intv_min*2-6);

            cmd->con_latency = 0;
            cmd->superv_to = 700;
            cmd->ce_len_max = 32;
            cmd->ce_len_min = 32;
            cmd->nb_peers = 1;

            struct bd_addr connect_bdaddr = {{0xad, 0x48, 0x28, 0x29, 0xeb, 0x08}};
            memcpy(&cmd->peers[0].addr.addr[0], &connect_bdaddr, BD_ADDR_LEN);
            cmd->peers[0].addr_type = GAPM_CFG_ADDR_PUBLIC;

            appm_start_connecting(cmd);
            os_free(cmd);
        }
        break;
#endif

        default:
            break;
    }
}
#endif






void
ssc_help(void)
{
    printf("\r\n");
    printf("0.op -o mode_num(1:sta;2:ap;3:sta+ap)\r\n");
    printf("1.sta -S\n");
    printf("2.ap -S -s para1 -p para2 -t para3\n");
    printf("3.ap -C -s para1 -p para2\n");
    printf("4.ap -D\n");
    printf("5.tcp -S -p para1 -m -b\n");
    printf("6.tcp -A\n");
    printf("7.tcp -T -i xxx.xxx.xxx.xxx -p para1 -l para2 -m -b\n");
    printf("8.tcp -R -i xxx.xxx.xxx.xxx -p para1 -t para2 -m -b\n");
    printf("9.tcp -W -i xxx.xxx.xxx.xxx -p para1 -c para2 -l para3 -n para4 -t para5 -d para6 -m -b\n");
    printf("10.udp -W -i xxx.xxx.xxx.xxx -p para1 -c para2 -l para3 -n para4 -t para5 -d para6 -b\n");
    printf("11.udp -S -p paral1 -b\n");
    printf("12.ip #get ip info\n");
    printf("13.reboot #system restart\n");
    printf("14.loop #endless loop\n");
}

/******************************************************************************
 * FunctionName : user_ssc_init
 * Description  : ssc debug init
 * Parameters   : none
 * Returns      : none
 *******************************************************************************/

#include "gpio.h"
void user_ssc_init(void)
{
    ssc_attach();
    ssc_register(sscCmdSet, CMD_MAX_END, ssc_help);
}

#endif

