
#include <stdio.h>
#include "ke_task.h"
#include "co_utils.h"

#include "dyc_uart_console_task.h"


#ifdef KEEP_SSC_CODE

extern uart_cmd_t gUartCmd;   //from peripherals.c uart cmd line


static void inline ssc_flush_line (void);
static int ssc_parse_line(void);
static int ssc_run_cmd(ke_msg_id_t const msgid,
                       void *param,
                       ke_task_id_t const dest_id,
                       ke_task_id_t const src_id);
static int ssc_finish_cmd(ke_msg_id_t const msgid,
                          void *param,
                          ke_task_id_t const dest_id,
                          ke_task_id_t const src_id);

static int ssc_rx_line(ke_msg_id_t const msgid,
                       void *param,
                       ke_task_id_t const dest_id,
                       ke_task_id_t const src_id);
static int ssc_cmd_fail_handler(ke_msg_id_t const msgid,
                                void *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id);
//static void (*_ssc_help)(void);




const struct ke_msg_handler task_uart_test_default_state[] =
{
    {SIG_SSC_RUNCMD,                 (ke_msg_func_t)ssc_run_cmd},
    {SIG_SSC_CMDDONE,                 (ke_msg_func_t)ssc_finish_cmd},
    {SIG_SSC_UART_RX_CHAR,            (ke_msg_func_t)ssc_rx_line},
    {SIG_SSC_CMD_FAIL,            (ke_msg_func_t)ssc_cmd_fail_handler},
};

struct ke_state_handler task_uart_test_default_handler = KE_STATE_HANDLER(task_uart_test_default_state);

/* Defines the place holder for the states of all the task instances. */
ke_state_t task_uart_test_state[1]; //RETENTION MEMORY

/// Application Task Descriptor
static struct ke_task_desc TASK_DESC_UART_TEST = {NULL, &task_uart_test_default_handler,
           task_uart_test_state, UART_TEST_STATE_MAX, 1
};




/*
 *   As ETS is not a acutal RR or preemptive kernel, for async cmd, we need to
 *    run a callback, in order to return prompt state. i.e. neet to call
 *    ssc_cmd_done(int cmd_id).
 */
typedef struct sscon_s
{
    uint8_t *line;
    int8_t line_end;
    uint8_t run_id;
    uint8_t arg_pos;
#define CMD_FAIL_TIMEOUT 2000
    uint8_t cmdnum;
    ssc_cmd_t *cmdset;

} sscon_t;

#ifdef SSC_DEBUG
struct ssc_debug_line
{
    char line[32];
    uint8 pos;
};
static struct ssc_debug_line dbgLine;
#endif /* SSC_DEBUG */

static sscon_t gCon;
#define CON()  (&gCon)
#define LEND() (CON()->line_end)



uart_cmd_t gUartCmd =
{
    .rec_data = {0},
    .com_tail = 0,
    .cmd_lin_end = 0,
    .data_drop = 0,
    .ssc_enable = 0,

    .uart1_task_created = 0,
    .uart1_r_count = 0,
    .uart1_cmd_recved = 0,
    .uart1_cmd_start = 0,
};



static int
ssc_run_cmd(ke_msg_id_t const msgid,
            void *param,
            ke_task_id_t const dest_id,
            ke_task_id_t const src_id)
{

#define CON_IS_CMD_SYNC(cmd_id) (CON()->cmdset[(cmd_id)].flag & CMD_T_SYNC)
#define CON_IS_CMD_ASYNC(cmd_id) (CON()->cmdset[(cmd_id)].flag & CMD_T_ASYNC)

    ssc_printf("ssc_run_cmd\r\n");

    ssc_cmd_t *cmd = NULL;

    do
    {
        if (CON()->cmdnum == 0)
            break;

        if (CON()->cmdset == NULL)
            break;

        cmd = CON()->cmdset + CON()->run_id;
        if (cmd != NULL)
        {
            if (cmd->cmd_func)
            {
                cmd->cmd_func();

                if (cmd->flag & CMD_T_SYNC)
                {
                    struct ssc_q_cmd* q_cmd =
                        KE_MSG_ALLOC(SIG_SSC_CMDDONE, TASK_UART_TEST, TASK_NONE,ssc_q_cmd);
                    q_cmd->par = cmd->id;
                    q_cmd->sig = SIG_SSC_CMDDONE;
                    ke_msg_send(q_cmd);

                }
                else if (cmd->flag & CMD_T_ASYNC)
                {
                    /*
                     *  fire a timeout for async cmd
                     */
                    //os_timer_disarm(&CON()->command_fail_timer);
                    //os_timer_arm(&CON()->command_fail_timer, CMD_FAIL_TIMEOUT, 0);
                }
            }
        }

    }
    while (0);
    return (KE_MSG_CONSUMED);

}

static int
ssc_finish_cmd(ke_msg_id_t const msgid,
               void *param,
               ke_task_id_t const dest_id,
               ke_task_id_t const src_id)
{
    ssc_printf("ssc_finish_cmd\n");

    ssc_cmd_t *cmd = NULL;
    //we got only one run cmd
//    ASSERT((param & 0xffff) == CON()->run_id);
    // os_timer_disarm(&CON()->command_fail_timer);
    struct ssc_q_cmd* q_cmd = (struct ssc_q_cmd*)param;
    uint32_t parm = q_cmd->par;
    do
    {
        if (CON()->cmdnum == 0)
            break;
        if (CON()->cmdset == NULL)
            break;

        cmd = CON()->cmdset + CON()->run_id;

        if (cmd == NULL)
            break;

        if (!(cmd->flag & CMD_T_ASYNC))
            break;

        if (CON()->cmdset[CON()->run_id].cmd_callback)
        {
            CON()->cmdset[CON()->run_id].cmd_callback(&parm);
        }

    }
    while (0);
    CON()->run_id = 0xff;
    ssc_flush_line();

#undef CON_IS_CMD_SYNC
#undef CON_IS_CMD_ASYNC
    return (KE_MSG_CONSUMED);

}



static void inline
ssc_flush_line(void)
{
    ssc_printf("flush\n");
    //memset(CON()->line,0x00,MAX_LINE_N);
    LEND() = 0;
    CON()->arg_pos = 0;
    gUartCmd.com_tail = 0;
    gUartCmd.cmd_lin_end = 0;
    gUartCmd.data_drop = 0;
    memset(gUartCmd.rec_data,0,sizeof(gUartCmd.rec_data));
}



static int
ssc_parse_line(void)
{
//  os_printf("\nssc_parse_line  CON()->line=%s\n",CON()->line);
//  os_printf("\nssc_parse_line  CON()->cmdnum=%d\n",CON()->cmdnum);

#define MAX_CMD_LEN  8
    char cmd_str[MAX_CMD_LEN];
    uint8_t i = 0, j = 0;
    ssc_cmd_t *cmd = NULL;

    printf("%s",CON()->line);

    // 1~3 is 'aaa', then return fail. just for test.
    if(CON()->line[0] == 'a' && CON()->line[1] == 'a' && CON()->line[2] == 'a')
    {
        //os_printf("%s",CON()->line);
        ssc_printf("1,");
        return FAIL;
    }

    while (CON()->line[i] != ' ')
    {
        cmd_str[i] = CON()->line[i];

        if (i++ > MAX_CMD_LEN)
        {
            ssc_printf("2,");
            return FAIL;
        }
        if (i == LEND())
            break;
    }

    ssc_printf("ssc_parse_line cmd_str:%s\r\n",cmd_str);
    for (j = 0; j < CON()->cmdnum; j++)
    {
        ssc_printf("ssc_parse_line idx:[%d],CON()->cmdset->cmd_str=\"%s\"\r\n",j,CON()->cmdset[j].cmd_str);
        cmd = CON()->cmdset + j;
        if (cmd && memcmp(cmd_str, CON()->cmdset[j].cmd_str, strlen(CON()->cmdset[j].cmd_str)) == 0)
        {
            break;
        }
    }

    ssc_printf("j:%d,CON()->cmdnum:%d\r\n",j,CON()->cmdnum);

    if (j == CON()->cmdnum)
    {
        ssc_printf("3,");
        return FAIL;
    }

    CON()->run_id = j;
    CON()->arg_pos = i + 1;

    return SUCCESS;
}


extern void ssc_help(void);
static int
ssc_rx_line(ke_msg_id_t const msgid,
            void *param,
            ke_task_id_t const dest_id,
            ke_task_id_t const src_id)
{
    struct uart_come_cmd *e = (struct uart_come_cmd *)param;
    if(e->cmd_come == 0)
    {
        ssc_flush_line();
        return (KE_MSG_CONSUMED);
    }
    CON()->line_end = e->cmd_come;

    ssc_printf("%s",CON()->line);

    do
    {
        if (CON()->run_id != 0xff)
        {

            ssc_flush_line();
            //discard recieved char when we are in process of running some cmd
            return(KE_MSG_CONSUMED);
        }

        if (CON()->line[0] == '?' && (LEND() == 1))
        {
            ssc_help();
            ssc_flush_line();
            printf("\n%s\r\n", PROMPT);
            return(KE_MSG_CONSUMED);
        }


        if (ssc_parse_line() == SUCCESS)
        {
            struct ssc_q_cmd* q_cmd =
                KE_MSG_ALLOC(SIG_SSC_RUNCMD, TASK_UART_TEST, TASK_NONE,ssc_q_cmd);
            q_cmd->par = 0;
            q_cmd->sig = SIG_SSC_RUNCMD;
            ke_msg_send(q_cmd);
        }
        else
        {
            ssc_flush_line();
            printf("\n%s\r\n", PROMPT);
        }
    }
    while (0);

    return (KE_MSG_CONSUMED);

}


void ssc_register(ssc_cmd_t *cmdset, uint8_t cmdnum, void (*helper)(void))
{
    ssc_printf("ssc_register ssc cmdset->cmd_str=%s\n",cmdset->cmd_str);
    ssc_printf("ssc_register ssc cmdnum=%d\n",cmdnum);
    if (cmdnum)
    {
        CON()->cmdnum = cmdnum;
        CON()->cmdset = cmdset;
    }
    // _ssc_help = helper;
}


uint8_t * ssc_param_str(void)
{
    return &CON()->line[CON()->arg_pos];
}

static int ssc_cmd_fail_handler(ke_msg_id_t const msgid,
                                void *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
#if 0
    struct ssc_q_t* e =
        KE_MSG_ALLOC(UART_SSC_CMD_FAIL, TASK_UART_TEST, TASK_UART_TEST, ssc_q_t);
    e->par = FAIL << 16 | CON()->run_id;
    e->sig = SIG_SSC_CMDDONE;
    ke_msg_send(e);
#endif
    return (KE_MSG_CONSUMED);
}




void ssc_attach(void)
{
    ssc_printf("ssc_task\n");
    CON()->run_id = 0xff;
    CON()->line = &gUartCmd.rec_data[0];
    ke_task_create(TASK_UART_TEST, &TASK_DESC_UART_TEST);
    ke_state_set(TASK_UART_TEST, UART_TEST_IDLE);
    //show_reg2((uint8_t *)&gUartCmd,sizeof(uart_cmd_t));
    gUartCmd.ssc_enable = 1;
}


//call it in uart isr
void ssc_uart_isr_recv(uint8_t u8InChar)
{
    //printf("x:%X,%d,%d\n", u8InChar,gUartCmd.cmd_lin_end,gUartCmd.data_drop);

    if(gUartCmd.cmd_lin_end == 1 && gUartCmd.data_drop == 1)
        return;
    //printf("x:%X,%d,%d\n", u8InChar,gUartCmd.com_tail,RXBUFSIZE-1);
    /* Check if buffer full */
    if( (gUartCmd.com_tail < (RXBUFSIZE-1)) && (u8InChar != '\r' ) )
    {
        //printf("y:%X\n", u8InChar);
        /* Enqueue the character */
        gUartCmd.rec_data[gUartCmd.com_tail] = u8InChar;
        gUartCmd.com_tail++;
    }
    else
    {
        gUartCmd.rec_data[gUartCmd.com_tail] = '\n';
        if(gUartCmd.ssc_enable)
        {
            //printf("1:%s",gUartCmd.rec_data);
            gUartCmd.cmd_lin_end = 1;
            gUartCmd.data_drop = 1;
            struct uart_come_cmd *e = KE_MSG_ALLOC(SIG_SSC_UART_RX_CHAR, TASK_UART_TEST, TASK_NONE, uart_come_cmd);
            e->cmd_come = gUartCmd.com_tail;
            ke_msg_send(e);
        }
        else
        {
            gUartCmd.cmd_lin_end = 0;
            gUartCmd.com_tail = 0;
            printf("%s",gUartCmd.rec_data);
            memset(gUartCmd.rec_data,0,sizeof(gUartCmd.rec_data));
        }
    }
}

#endif





