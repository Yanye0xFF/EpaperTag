/**
 ****************************************************************************************
 *
 * @file app_audio.h
 *
 * @brief SPS Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2012
 *
 * $Rev: $
 *
 ****************************************************************************************
 */

#ifndef APP_SPSS_H_
#define APP_SPSS_H_

/**
 ****************************************************************************************
 * @addtogroup APP
 * @ingroup RICOW
 *
 * @brief SPS Application entry point.
 *
 * @{
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "rwble_config.h"
#include <stdint.h>          // standard integer definition
#include <co_bt.h>
#include "app.h"

#include "sps_server.h"
#include "sps_server_task.h"

/*
 * STRUCTURES
 ****************************************************************************************
 */

/*
 * GLOBAL VARIABLE DECLARATION
 ****************************************************************************************
 */

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

void app_spss_add_spsss(void);

/**
 ****************************************************************************************
 * @brief Initialize sps application
 ****************************************************************************************
 */
void app_spss_init(void);

/**
 ****************************************************************************************
 * @brief Enable the the notifcation of the SPS or enable the host to set it in discovery mode
 ****************************************************************************************
 */
void app_spss_enable_prf(uint8_t conidx);

/**
 ****************************************************************************************
 * @brief Request data transmission over Bluetooth
 ****************************************************************************************
*/
void app_init_ble_tx(void);

/**
 ****************************************************************************************
 * @brief Send flow control state over Bluetooth
 ****************************************************************************************
*/
void app_spss_send_ble_flowctrl(uint16_t flowcontrol_freelen);


/// @} APP
void app_spss_send_data(uint8_t conidx, uint8_t *data, uint16_t len);



extern const struct ke_state_handler app_spss_table_handler;
extern app_callback_func_t spss_recv_data_ind_func;


#endif // APP_SPSS_H_
