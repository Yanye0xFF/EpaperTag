/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_TASK_H_
#define USER_TASK_H_

#include <stdint.h>
#include "ke_task.h"
#include "ke_msg.h"
#include "user_msg_q.h"


#ifndef USER_TASK_API_ENABLE
#define USER_TASK_API_ENABLE (1)
#endif


#ifndef TASK_TEST_ENABLE
#define TASK_TEST_ENABLE (0)
#endif

typedef int (*os_task_func_t)(os_event_t *param);



#if USER_TASK_API_ENABLE

struct os_state_handler
{
    /// Pointer to the message handler table of this state.
    struct ke_msg_handler *msg_table;
    /// Number of messages handled in this state.
    uint16_t msg_cnt;
};
struct os_state_handler *from_task_func_to_state_handle(os_task_func_t task_func);

#if TASK_TEST_ENABLE
//for test
void user_task_test1(void);
void user_task_test2(void);
#endif


void ke_task_saved_update(ke_task_id_t const ke_task_id);
/*
* USER_API
*/
uint8_t os_get_free_task_type(void);
#define os_task_delete(task_id)     ke_task_delete((task_id))
uint8_t os_task_create(os_task_func_t task_func,uint8_t *task_id);
uint8_t os_task_create_x(os_task_func_t task_func,uint8_t *task_id,uint8_t fixed_task_id);
uint8_t os_get_free_task_id_num(void);
#define os_task_process_saved_msg(task_id)   ke_task_saved_update(task_id)
#endif      //end of #if USER_TASK_API_ENABLE



#endif // APP_HT_H_
