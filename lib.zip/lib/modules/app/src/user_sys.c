#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "arch.h"
#include "system.h"
#include "apb2spi.h"
#include "user_sys.h"
#include "uart.h"
#include "reg_uart.h"
#include "flash.h"
#include "user_mem.h"
#include "core_cm3.h"
#include "timer.h"
#include "jump_table.h"
#include "app.h"
#include "pmu.h"

#if 0
//total time range: 0xffffff/12000000 = 1.398s.
void systick_free_run(void)
{
    SysTick->LOAD = SysTick_LOAD_RELOAD_Msk;                         /* set reload register */
    //NVIC_SetPriority (SysTick_IRQn, (1UL << __NVIC_PRIO_BITS) - 1UL); /* set Priority for Systick Interrupt */
    SysTick->VAL = 0;
    SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk |
                     SysTick_CTRL_ENABLE_Msk;                         /* Enable SysTick IRQ and SysTick Timer */
}
uint32_t get_systick_val(void)
{
    return (SysTick_LOAD_RELOAD_Msk - SysTick->VAL);
}
#endif

#if TIM1_TICK_ENABLE
static uint32_t tim1_tick;
void hw_tim1_isr_ram(void)
{
    timer_clear_interrupt(TIM1);
    tim1_tick++;
}
void timer1_as_tick_start(void)
{
    tim1_tick = 0;
    timer_init(TIM1,100,TIM_PERIODIC);  //100us
    timer_run(TIM1);
    NVIC_SetPriority(TIMER1_IRQn, 2);
    NVIC_EnableIRQ(TIMER1_IRQn);
}
uint32_t get_tim1_tick(void)
{
    return tim1_tick;
}
#endif

void show_sys_mem_waterwave(void)
{
    show_reg2((uint8_t *)stack_space, 0x20, 1);
}

__attribute__((section("front_stack"))) uint32_t sys_get_wkup_key(void)
{
    return (ool_read(0xa2)<<24)|(ool_read(0xa3)<<16)|(ool_read(0xa4)<<8)|(ool_read(0xa5)<<0);
}

__attribute__((section("front_stack"))) sys_reset_cause_t sys_get_reset_cause(void)
{
    return (sys_reset_cause_t)apb2spi_read(0x4F,APB2SPI_TYPE_OOL);
}

void sys_soft_reset(void)
{
    apb2spi_write(0x4F,0xC4,APB2SPI_TYPE_OOL);
    __set_FAULTMASK(1);
    NVIC_SystemReset();
    while(1);
}

static const uint8_t addr_tmp[12] = {0x35,0x8c,0x8a,0x92,
                                     0x93,0x94,0x95,0x9e,
                                     0x9f,0xa0,0xa1,0xa6,
                                    };
void pmu_ram_write(uint8_t addr,uint8_t data)
{
    apb2spi_write(addr_tmp[addr],data,APB2SPI_TYPE_OOL);
}
uint8_t pmu_ram_read(uint8_t addr)
{
    return apb2spi_read(addr_tmp[addr],APB2SPI_TYPE_OOL);
}

/********************from EFUSE********************/
struct efuse_reg_t
{
    uint32_t ctrl;
    uint32_t data1;
    uint32_t data2;
    uint32_t data3;
};// only for charging voltage
uint8_t aldo_trim_value;
uint8_t vchg_trim_value;
void chip_voltage_calibration(void)
{
    volatile struct efuse_reg_t *efuse_reg = (volatile struct efuse_reg_t *)EFUSE_BASE;
    efuse_reg->ctrl = 0x1;
    co_delay_100us(1);
    while( (efuse_reg->ctrl & BIT(1))  == 0 );
    //printf("%x,%x,%x,%x\r\n",efuse_reg->ctrl,efuse_reg->data1,efuse_reg->data2,efuse_reg->data3);

    if( ( efuse_reg->data3 & BIT(16)) != 0 )
    {
        uint8_t tmp = (efuse_reg->data3 & 0xf000)>>12;
        aldo_trim_value = (efuse_reg->data3 & 0xf);
        
        if( (tmp+6) <= 0xf )
            tmp += 6;
        else
            tmp = 0xf;
        vchg_trim_value = (18- tmp);
        ool_write(0x10, 0x10 | vchg_trim_value);  //trimming   PMU_BG_TRIM [3:0]
    }
}

#include "patch.h"
#include "watchdog.h"
void user_set_cpu_clk(uint8_t freq)
{
    if( (48000000 >> freq) != system_get_pclk() )
    {
        __jump_table.system_clk = freq;
        app_set_sysclk();
        system_set_pclk(freq);
        wdt_driver_ini();
    }
}

void pmu_set_gpio_to_PMU(enum system_port_t port, uint8_t bits)
{
    uint8_t sel_reg = 0x58;
    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) & (~bits)));
}

void pmu_set_gpio_to_CPU(enum system_port_t port, uint8_t bits)
{
    uint8_t sel_reg = 0x58;
    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) | bits));
}
void pmu_set_gpio_input(enum system_port_t port, uint8_t bits, bool flag)
{
    uint8_t sel_reg = 0x5c;
    sel_reg += port;

    if(flag == true)
        ool_write(sel_reg, (ool_read(sel_reg) | bits));
    else
        ool_write(sel_reg, (ool_read(sel_reg) & (~bits)));
}

void pmu_set_gpio_output(enum system_port_t port, uint8_t bits, bool flag)
{
    uint8_t sel_reg = 0x60;
    sel_reg += port;
    if(flag == true)
        ool_write(sel_reg, (ool_read(sel_reg) & (~bits)));
    else
        ool_write(sel_reg, (ool_read(sel_reg) | bits));
}
void pmu_set_gpio_pull(enum system_port_t port, uint8_t bits, bool flag)
{
    uint8_t sel_reg = 0x64;
    sel_reg += port;

    if(flag == false)
        ool_write(sel_reg, (ool_read(sel_reg) | bits));
    else
        ool_write(sel_reg, (ool_read(sel_reg) & (~bits)));
}
void pmu_set_gpio_value(enum system_port_t port, uint8_t bits, uint8_t value)
{
    uint8_t sel_reg = 0xac;
    sel_reg += port;
    if( value == 0 )
        ool_write(sel_reg, (ool_read(sel_reg) & (~bits)) );
    else
        ool_write(sel_reg, (ool_read(sel_reg) | bits ) );
}

#include "gpio.h"

void gpio_set_dir_as_high_imp(enum system_port_t port, enum system_port_bit_t bit)
{
    struct system_regs_t *const system_regs_y = (struct system_regs_t *)SYSTEM_REG_BASE;
    gpio_set_dir(port, bit, GPIO_DIR_IN);
    system_set_port_pull(port*8+bit, false);
    system_regs_y->reserved1 |=  ( 1<<(port*8+bit) );
}

#include "led.h"
void led_set_pin_value(uint8_t led, uint8_t value)
{
    if(value == 0)
        ool_write(0xa8, (ool_read(0xa8) & ~ BIT(led)) | BIT(led+4) );
    else
        ool_write(0xa8, ool_read(0xa8) | BIT(led) | BIT(led+4));
}


#define UART_CLK        14745600
#define UART_FIFO_TRIGGER (FCR_RX_TRIGGER_00|UART_FIFO_TX_TRIGGER)
void uart_init_x(uart_param_t param)
{
    volatile struct uart_reg_t *uart_reg;
    if(param.uart_idx == 0)
        uart_reg = (volatile struct uart_reg_t *)UART0_BASE;
    else
        uart_reg = (volatile struct uart_reg_t *)UART2_BASE;

    int uart_baud_divisor;

    /* wait for tx fifo is empty */
    while(!(uart_reg->lsr & 0x40));

    uart_reset_register();

    uart_baud_divisor = UART_CLK/(32*param.baud_rate);  //uart_get_baud_divisor(param.baud_rate);

    while(!(uart_reg->lsr & 0x40));

    /* baud rate */
    uart_reg->lcr.divisor_access = 1;
    uart_reg->u1.dll.data = uart_baud_divisor & 0xff;
    uart_reg->u2.dlm.data = (uart_baud_divisor>>8) & 0xff;
    uart_reg->lcr.divisor_access = 0;

    /*word len*/
    uart_reg->lcr.word_len = param.data_bit_num-5;
    if(param.pari == 0)
    {
        uart_reg->lcr.parity_enable = 0;
        uart_reg->lcr.even_enable = 0;
    }
    else
    {
        uart_reg->lcr.parity_enable = 1;
        if(param.pari == 1)
            uart_reg->lcr.even_enable = 1;
        else
            uart_reg->lcr.even_enable = 0;
    }
    uart_reg->lcr.stop = param.stop_bit;

    /*fifo*/
    uart_reg->u3.fcr.data = UART_FIFO_TRIGGER | FCR_FIFO_ENABLE;

    /*auto flow control*/
    uart_reg->mcr.afe = 0;

    /*enable recv and line status interrupt*/
    uart_reg->u2.ier.erdi = 1;
    uart_reg->u2.ier.erlsi = 1;
}

#ifdef FLASH_NEW_CODE_FOR_SPEAKER_DEMO
/**new flash write function for faster speed**/
#define FLASH_BIT_RATE          1000000
#define FLASH_SSP_CLK           2
#define FLASH_DATA_SIZE         8
static uint8_t flash_read_status_reg(void)
{
    uint8_t buffer[2] = {0x00, 0x00};

    ssp_put_byte(FLASH_READ_STATUS_REG_OPCODE);
    ssp_put_byte(0xff);
    ssp_enable();
    ssp_get_data(buffer, 2);
    ssp_wait_busy_bit();
    ssp_disable();
    return buffer[1];
}

static void flash_write_status_reg(uint8_t status)
{
    ssp_put_byte(FLASH_WRITE_STATUS_REG_OPCODE);
    ssp_put_byte(status);
    ssp_enable();
    ssp_wait_busy_bit();
    ssp_disable();
}
static void flash_chip_protect(void)
{
    flash_write_status_reg(flash_read_status_reg() | 0x9c);
}

static void flash_chip_unprotect(void)
{
    flash_write_status_reg(flash_read_status_reg() & (~0x9c));
}

static void flash_write_enable(void)
{
    ssp_put_byte(FLASH_WRITE_ENABLE_OPCODE);
    ssp_enable();
    ssp_wait_busy_bit();
    ssp_disable();
}

static void flash_write_disable(void)
{
    ssp_put_byte(FLASH_WRITE_DISABLE_OPCODE);
    ssp_enable();
    ssp_wait_busy_bit();
    ssp_disable();
}

static void flash_poll_busy_bit(void)
{
    volatile uint16_t i;

    while(flash_read_status_reg()&0x03)
    {
        //delay
        for(i=0; i<20; i++);
    }
}
uint8_t flash_write_new(uint32_t offset, uint32_t length, uint8_t *buffer)
{
    unsigned char page_count;
    uint32_t i;
//    CPU_SR  cpu_sr;

    page_count = length >> 8;
    if((offset&0x000000ff)|(length&0x000000ff))
    {
        if((256-(offset&0x000000ff))>=(length&0x000000ff))
            page_count++;
        else
            page_count += 2;
    }

    if(length > 0)
    {
        ssp_reconfigure(FLASH_BIT_RATE, FLASH_SSP_CLK, FLASH_DATA_SIZE);

        for( i = 0; page_count > 0; page_count--)
        {
            flash_chip_unprotect();
            flash_write_enable();
            ssp_put_byte(FLASH_PAGE_PROGRAM_OPCODE);
            ssp_put_byte(offset >> 16);
            ssp_put_byte(offset >> 8);
            ssp_put_byte(offset);
            
            system_set_port_mux(GPIO_PORT_B,GPIO_BIT_1,PORTB1_FUNC_B1);
            gpio_set_dir(GPIO_PORT_B, GPIO_BIT_1, GPIO_DIR_OUT);
            system_set_port_pull(4 + (GPIO_PORT_B * 8), true);
            gpio_portb_write(gpio_portb_read() & ~(BIT(GPIO_BIT_1)) );
            
            ssp_enable();

            for(; i < length; )
            {
                ssp_put_byte(buffer[i]);
                offset++;
                i++;
                if(!(offset<<24))
                    break;
            }
            ssp_wait_busy_bit();
            ssp_disable();
            
            gpio_portb_write(gpio_portb_read() | BIT(GPIO_BIT_1) );
            system_set_port_mux(GPIO_PORT_B,GPIO_BIT_1,PORTB1_FUNC_SSP0_CSN);

            ssp_clear_rx_fifo();
            flash_poll_busy_bit();
        }

        flash_write_disable();
        flash_chip_protect();
        ssp_clear_rx_fifo();

    }

    return CO_ERROR_NO_ERROR;
}
#endif

void flash_write_with_check(uint32_t offset, uint32_t length, uint8_t *buffer)
{
#ifdef FLASH_NEW_CODE_FOR_SPEAKER_DEMO
    flash_write_new(offset, length, buffer);
#else
    /*
    uint8_t * tmp = os_malloc(length,KE_MEM_NON_RETENTION);
    do
    {
        flash_write(offset, length, buffer);
        flash_read(offset,length,tmp);
    }
    while( memcmp(buffer,tmp,length) != 0 );
    os_free(tmp);*/
    flash_write(offset, length, buffer);
#endif
}

#if (FLASH_TEST_ENABLE)
#include "fr_ble_config.h"
uint8_t buf[FLASH_PAGE_SIZE];
void test_flash(void)
{
    uint32_t id;
    flash_identify((uint8_t *)&id);
    id = (id & 0xFFFFFF);
    printf("flash id:%x\r\n",id);

    flash_erase(USER_FLASH_BASE_ADDR, 0);
    uint32_t idx = 0;
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = idx;
    flash_write_with_check(USER_FLASH_BASE_ADDR, FLASH_PAGE_SIZE, buf);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = 0xff;
    flash_read(USER_FLASH_BASE_ADDR, FLASH_PAGE_SIZE, buf);
    printf("read reg:\r\n");
    show_reg2(buf,5,1);
    show_reg2(buf+4091,5,1);


    flash_erase(USER_FLASH_BASE_ADDR, 0);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = idx+1;
    flash_write_with_check(USER_FLASH_BASE_ADDR, FLASH_PAGE_SIZE, buf);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = 0xfe;
    flash_read(USER_FLASH_BASE_ADDR, FLASH_PAGE_SIZE, buf);
    printf("read reg:\r\n");
    show_reg2(buf,5,1);
    show_reg2(buf+4091,5,1);


    flash_erase(USER_FLASH_MAX_PAGE_ADDR, 0);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = idx+2;
    flash_write_with_check(USER_FLASH_MAX_PAGE_ADDR, FLASH_PAGE_SIZE, buf);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = 0xfd;
    flash_read(USER_FLASH_MAX_PAGE_ADDR, FLASH_PAGE_SIZE, buf);
    printf("read reg:\r\n");
    show_reg2(buf,5,1);
    show_reg2(buf+4091,5,1);


    flash_erase(USER_FLASH_MAX_PAGE_ADDR, 0);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = idx+3;
    flash_write_with_check(USER_FLASH_MAX_PAGE_ADDR, FLASH_PAGE_SIZE, buf);
    for(idx=0; idx<FLASH_PAGE_SIZE; idx++)
        buf[idx] = 0xfc;
    flash_read(USER_FLASH_MAX_PAGE_ADDR, FLASH_PAGE_SIZE, buf);
    printf("read reg:\r\n");
    show_reg2(buf,5,1);
    show_reg2(buf+4091,5,1);

    flash_erase(USER_FLASH_MAX_PAGE_ADDR, 0);

//flash_chip_erase();
}


#endif





#define TIM_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %d \r\n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);

uint32_t timer_get_current_value(int timer_addr)
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    return timerp->count_value.count;
}
uint32_t timer_get_load_value(int timer_addr)
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    return timerp->load_value.load;
}

/*us 100us accuration,  max 87000us.min:100us*/
void timer_init( int timer_addr, int count_us,uint8_t run_mode )
{
    uint32_t tmp = (TIMER_10US_COUNT * count_us / 10);
    if( tmp > 0xffff || count_us <100 )
        printf("ERR, hw_timer period:%d,valid_ragne[100,%d]\r\n",count_us,(0xffff*10)/TIMER_10US_COUNT);
    else
    {
        volatile struct timer *timerp = (volatile struct timer *)timer_addr;
        timerp->control.count_enable = 0;
        timerp->control.count_mode = run_mode; /* periodic count */  //1:periodic; 0: free_run
        timerp->control.pselect = 0x01;  /* pclk / 16 */
        timerp->interrupt_clear.data = 0x01; /* clear interrupt */
        timerp->load_value.load = tmp;
    }
}




#if HWTIM_TEST_ENABLE

static uint32_t tick0 = 0;
static uint32_t tick1 = 0;
static uint8_t tim0_run_num = 0;
void hw_tim0_isr_ram(void)
{
    timer_clear_interrupt(TIM0);
    //timer_reload(TIM0);
    if(tick0>10000)
    {
        tick0 = 0;
        tim0_run_num++;
        if(tim0_run_num >= 4)
            timer_stop(TIM0);
        printf("hwt0_us:%d,%d\r\n",timer_get_current_value(TIM0),timer_get_load_value(TIM0));
    }
    else
        tick0++;
}
void hw_tim1_isr_ram(void)
{
    timer_clear_interrupt(TIM1);
    //timer_reload(TIM1);
    if(tick1>20000)
    {
        timer_stop(TIM1);
        printf("hwt1_us:%d,%d\r\n",timer_get_current_value(TIM1),timer_get_load_value(TIM1));
    }
    else
        tick1++;
}

void test_timer(void)
{
    tick1 = 0;
    tick0 = 0;
    tim0_run_num = 0;
    timer_init(TIM0,100,TIM_PERIODIC);

    timer_run(TIM0);

    timer_init(TIM1,20,TIM_PERIODIC);
    timer_init(TIM1,100000,TIM_PERIODIC);

    timer_init(TIM1,200,TIM_PERIODIC);
    timer_run(TIM1);

    NVIC_SetPriority(TIMER0_IRQn, 2);
    NVIC_EnableIRQ(TIMER0_IRQn);

    NVIC_SetPriority(TIMER1_IRQn, 2);
    NVIC_EnableIRQ(TIMER1_IRQn);
}

#endif




#include "iic.h"
/*
speed   iic bus speed, unit: KHz. value range as follow
        -[12,500]  @12M  CPU CLK;  
        -[24,1000] @12M  CPU CLK;  
        -[48,2000] @48M  CPU CLK;   
*/
void iic_init_x(enum iic_channel_t channel, uint16_t speed)
{
    iic_init(channel, speed);
}
bool iic_read_byte_small_no_block(enum iic_channel_t channel, uint8_t slave_addr,uint16_t addr,uint8_t * pdata)
{
    volatile struct iic_reg_t *iic_reg;
    uint8_t try_cnt = 0;
    if(channel == IIC_CHANNEL_0)
        iic_reg = IIC0_REG_BASE;
    else
        iic_reg = IIC1_REG_BASE;

    do
    {
        iic_reg->data = slave_addr|IIC_TRAN_START;
        //while(iic_reg->status.trans_emp != 1);
        co_delay_100us(1);
        try_cnt++;
    }
    while(iic_reg->status.no_ack == 1 && try_cnt < 5);
    if(try_cnt>=5)
        return false;

    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);

    *pdata = iic_reg->data&0xff;

    while(iic_reg->status.bus_atv == 1);
    return true;
}
bool iic_read_bytes_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size)
{
    uint16_t i, j=0;
    volatile struct iic_reg_t *iic_reg;
    uint8_t try_cnt = 0;

    if(channel == IIC_CHANNEL_0)
        iic_reg = IIC0_REG_BASE;
    else
        iic_reg = IIC1_REG_BASE;

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        //while(iic_reg->status.trans_emp != 1);
        co_delay_100us(1);
        try_cnt++;
    }
    while(iic_reg->status.no_ack == 1 && try_cnt < 5);
    if(try_cnt>=5)
        return false;

    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    for (i = 0; i < (size-1); i++)
    {
        iic_reg->data = 0x00;
        while(iic_reg->status.rec_emp != 1)
        {
            buf[j++] = iic_reg->data;
        }
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
    for(; j<size; j++)
    {
        buf[j] = iic_reg->data;
    }
    while(iic_reg->status.bus_atv == 1);
    return true;
}

bool iic_write_byte_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t data)
{
    volatile struct iic_reg_t *iic_reg;
    uint8_t try_cnt = 0;

    if(channel == IIC_CHANNEL_0)
        iic_reg = IIC0_REG_BASE;
    else
        iic_reg = IIC1_REG_BASE;

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        //while(iic_reg->status.trans_emp != 1);
        co_delay_100us(1);
        try_cnt++;
    }
    while(iic_reg->status.no_ack == 1 && try_cnt < 5);
    if(try_cnt>=5)
        return false;

    iic_reg->data = addr & 0xff;
    iic_reg->data = data | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
    return true;
}

bool iic_write_bytes_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size)
{
    uint16_t i;
    volatile struct iic_reg_t *iic_reg;
    uint8_t try_cnt = 0;

    if(channel == IIC_CHANNEL_0)
        iic_reg = IIC0_REG_BASE;
    else
        iic_reg = IIC1_REG_BASE;

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        //while(iic_reg->status.trans_emp != 1);
        co_delay_100us(1);
        try_cnt++;
    }
    while(iic_reg->status.no_ack == 1 && try_cnt < 5);
    if(try_cnt>=5)
        return false;

    iic_reg->data = addr & 0xff;

    for(i=0; i<(size-1); i++)
    {
        iic_reg->data = buf[i++];
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = buf[i] | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
    return true;
}


#if I2C_TEST_ENABLE

#define    CTRL1_XL           0x10
#define    CTRL2_G            0x11
#define    CTRL3_C            0x12
#define    CTRL4_C            0x13
#define    CTRL5_C            0x14
#define    CTRL6_C            0x15
#define    OUTX_L_G           0x22
#define    CTRL7_G            0x16
#define    OUTX_L_XL          0x28
#define    OUTX_H_XL          0x29
#define    LSM6DS33_SLAVE_ADDR  0xd6
static uint8_t i2c_test_tick =0;
void test_i2c(uint8_t i2c_channel)
{
    uint8_t i;
    uint8_t buff1[6];
    uint8_t buff2[6];
    int16_t *temp_buff1 = (int16_t*)buff1;
    int16_t *temp_buff2 = (int16_t*)buff2;
    i2c_test_tick = 0;
    iic_slv_addr = 0x78;

    enum iic_channel_t chnl = i2c_channel;
    if(chnl == 0)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_I2C0_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_I2C0_DAT);
    }
    else if(chnl == 1)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_I2C1_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_I2C1_DAT);
    }
    iic_init_x(chnl, 2);
    iic_init_x(chnl, 47);        //540
    iic_write_byte_small(chnl,LSM6DS33_SLAVE_ADDR,CTRL6_C,0x00);
    iic_write_byte_small(chnl,LSM6DS33_SLAVE_ADDR,CTRL7_G,0x00);
    iic_write_byte_small(chnl,LSM6DS33_SLAVE_ADDR,CTRL1_XL,0x80);
    iic_write_byte_small(chnl,LSM6DS33_SLAVE_ADDR,CTRL2_G,0x80);
    iic_write_byte_small(chnl,LSM6DS33_SLAVE_ADDR,CTRL3_C,0x04);

    while(1)
    {
        //co_delay_100us(10);
        for(i=0; i<6; i++)
        {
            iic_read_byte_small(chnl,LSM6DS33_SLAVE_ADDR,OUTX_L_XL+i,&buff1[i]);
            iic_read_byte_small(chnl,LSM6DS33_SLAVE_ADDR,OUTX_L_G+i,&buff2[i]);
        }
        printf("X:%d |Y:%d |Z:%d \r\n",temp_buff1[0],temp_buff1[1],temp_buff1[2]);
        printf("Pitch(X):%d|Roll(Y):%d |Yaw(Z):%d\r\n",temp_buff2[0],temp_buff2[1],temp_buff2[2]);
        i2c_test_tick++;
        if(i2c_test_tick>3)
            break;
    }
}
#endif


#include "user_msg_q.h"
#include "user_task.h"
#include "user_timer.h"
uint32_t pressed_button_isr = 0;
uint8_t exint_task_id = TASK_NONE;
uint8_t sleep_flag_after_key_release = true;

void  __attribute__((weak)) user_ext_int(uint8_t key_group,uint32_t key)
{
    printf("p[%d]:%x\r\n",key_group,key);
}
void  __attribute__((weak)) user_ext_int_release(uint8_t key_group,uint32_t key)
{
    printf("l[%d]:%x\r\n",key_group,key);
}


os_timer_t gpio_wk_timer;
static int exint_task_func(os_event_t *msg)
{
    uint32_t button = *(uint32_t *)(msg->param);
    switch((msg->event_id)&0xff)
    {
        case 0:
        {
            user_ext_int( ((msg->event_id)&0xff00)>>8,button);
        }
        break;
        case 1:
        {
            user_ext_int_release(((msg->event_id)&0xff00)>>8,button);
        }
        break;
        case 100:
        {
            os_timer_arm(&gpio_wk_timer,1000,0);
        }
        break;
        default:
            break;
    }
    // gpio_dbg_toggle(20);
    return (KE_MSG_CONSUMED);
}

static void gpio_wk_timout_func(void *arg)
{
    appm_sleep_start();
}

void set_sleep_flag_after_key_release(bool flag)
{
    sleep_flag_after_key_release = flag;
}

void test_exint(void)
{
    if ( os_task_create( exint_task_func,&exint_task_id ) != KE_TASK_OK )
    {
        printf("exint_task create fail \r\n");
    }
    os_timer_setfn(&gpio_wk_timer,gpio_wk_timout_func,NULL);
}
void start_gpio_wk_timer(void)
{
    os_event_t evt;
    evt.event_id = 100;
    evt.param_len = 0;
    evt.param = NULL;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);
}
void stop_gpio_wk_timer(void)
{
    os_timer_disarm(&gpio_wk_timer);
}

#include "exti.h"
extern void button_reverse_int_type(uint32_t changed_button, uint32_t current_value);
void  __attribute__((weak)) ext_int_isr_ram(void)
{
    uint32_t status;
    uint32_t gpio_button_sel;
    //struct button_toggle_param_t *param;
    //fputc('z',NULL);

    status = ext_int_get_status();
    ext_int_clear_status(status);

    gpio_button_sel = __jump_table.gpio_button_sel;
    gpio_button_sel |= __jump_table.onkey_map;
    stop_gpio_wk_timer();

    if(gpio_button_sel == 0)
    {
        return;
    }
    status = status & gpio_button_sel;

    pressed_button_isr ^= status;
    button_reverse_int_type(status, pressed_button_isr);

    if(pressed_button_isr)
    {
        os_event_t evt;
        evt.event_id = 0;
        evt.param_len = sizeof(pressed_button_isr);
        evt.param = &pressed_button_isr;
        evt.src_task_id = TASK_NONE;
        os_msg_post(exint_task_id,&evt);
        appm_sleep_stop();
        // gpio_dbg_toggle(10);
    }
    else
    {
        os_event_t evt;
        evt.event_id = 1;
        evt.param_len = sizeof(pressed_button_isr);
        evt.param = &pressed_button_isr;
        evt.src_task_id = TASK_NONE;
        os_msg_post(exint_task_id,&evt);
        if(sleep_flag_after_key_release == true)
        {
            // printf("z4\r\n");
            appm_sleep_start();

        }
    }
}


#include "reg_uart.h"
#include "uart2.h"
void __attribute__((weak)) uart2_isr_ram(void)
{
    uint8_t int_id;
    volatile struct uart_reg_t * const uart2_reg_ram = (volatile struct uart_reg_t *)UART2_BASE;
//printf("xx\r\n");
    int_id = uart2_reg_ram->u3.iir.int_id;

    if(int_id == 0x04 || int_id == 0x0c )   /* Receiver data available or Character time-out indication */
    {
        while(uart2_reg_ram->lsr & 0x01)
        {
#ifdef KEEP_SSC_CODE
            extern void ssc_uart_isr_recv(uint8_t u8InChar);
            //app_at_recv_c(uart2_reg_ram->u1.data);
            ssc_uart_isr_recv(uart2_reg_ram->u1.data);
			#endif
        }

    }
}

#include "uart.h"
void __attribute__((weak)) uart_isr_ram(void)
{
    uint8_t int_id;
    volatile struct uart_reg_t * const uart_reg_ram = (volatile struct uart_reg_t *)UART0_BASE;
    //printf("yy\r\n");
    int_id = uart_reg_ram->u3.iir.int_id;

    if(int_id == 0x04 || int_id == 0x0c )   /* Receiver data available or Character time-out indication */
    {
        while(uart_reg_ram->lsr & 0x01)
        {
#ifdef KEEP_SSC_CODE
            extern void ssc_uart_isr_recv(uint8_t u8InChar);
            //app_at_recv_c(uart2_reg_ram->u1.data);
            ssc_uart_isr_recv(uart_reg_ram->u1.data);
#endif
        }
    }
}


