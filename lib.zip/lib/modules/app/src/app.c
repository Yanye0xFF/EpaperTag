/**
 ****************************************************************************************
 *
 * @file app.c
 *
 * @brief Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"             // SW configuration

#if (BLE_APP_PRESENT)
#include <stdio.h>

#include "app_task.h"                // Application task Definition
#include "app.h"                     // Application Definition
#include "app_proj_event.h"
#include "app_api.h"

#include "gap.h"                     // GAP Definition
#include "gapm.h"
#include "gapm_task.h"               // GAP Manager Task API
#include "gapc_task.h"               // GAP Controller Task API

#include "system.h"
#include "iomux.h"

#include "co_bt.h"                   // Common BT Definition
#include "co_math.h"                 // Common Maths Definition
#include "co_utils.h"

#include "reg_blecore.h"
#include "llm_util.h"

#if (BLE_APP_SEC)
#include "app_sec.h"                 // Application security Definition
#endif // (BLE_APP_SEC)

#if (BLE_APP_DIS)
#include "app_dis.h"                 // Device Information Service Application Definitions
#endif //(BLE_APP_DIS)

#if (BLE_APP_BATT)
#include "app_batt.h"                // Battery Application Definitions
#endif //(BLE_APP_DIS)

#if (BLE_APP_HID)
#include "app_hid.h"                 // HID Application Definitions
#endif //(BLE_APP_HID)

#if (BLE_APP_PROXR)
#include "app_proxr.h"               //Proximity Reporter Application Definitions
#endif  //(BLE_APP_PROXR)

#if (BLE_APP_OTAS)
#include "app_otas.h"
#endif //(BLE_APP_OTAS)

#if (BLE_APP_SPSS)
#include "app_spss.h"
#endif  //(BLE_APP_SPSS)

#if (BLE_APP_SPSC)
#include "app_spsc.h"
#endif //(BLE_APP_SPSS)

#if (BLE_APP_FINDT)
#include "app_findt.h"
#endif //(BLE_APP_FMPT)

#if (BLE_APP_RTCTS)
#include "app_rtct.h"
#endif

#if (BLE_APP_SPSS)
#include "app_spss.h"
#endif  //(BLE_APP_SPSS)

#if BLE_APP_MESH
#include "app_mesh.h"
#endif


#if(USER_FLOWER_CARE)
#include "app_flower.h"
#endif

#include "rwip.h"

#include "exti.h"
#include "gpio.h"
#include "led.h"
#include "i2s.h"
#include "apb2spi.h"
#include "pmu.h"
#include "patch.h"
#include "user_sys.h"
#include "watchdog.h"
#include "reg_uart2.h"
#include "uart2.h"
#include "enc_sbc.h"
#include "dec_sbc.h"
#include "gattc_task.h"
#include "dyc_uart_console_task.h"
#include "gpio_dbg_lib.h"
#include "jump_table.h"
#include "lvd.h"
#include "keyscan.h"

/*
 * DEFINES
 ****************************************************************************************
 */

#define UART_B4_B5      0
#define UART_A0_A1      0
#define UART_C0_C1      0
/**
 * UUID List part of ADV Data
 * --------------------------------------------------------------------------------------
 * x03 - Length
 * x03 - Complete list of 16-bit UUIDs available
 * x09\x18 - Health Thermometer Service UUID
 *   or
 * x12\x18 - HID Service UUID
 * --------------------------------------------------------------------------------------
 */

#if (BLE_APP_HID)
#define APP_HID_ADV_DATA_UUID       "\x03\x03\x12\x18"
#define APP_HID_ADV_DATA_UUID_LEN   (4)
#endif //(BLE_APP_HID)

/**
 * Appearance part of ADV Data
 * --------------------------------------------------------------------------------------
 * x03 - Length
 * x19 - Appearance
 * x03\x00 - Generic Thermometer
 *   or
 * xC2\x03 - HID Mouse
 * xC1\x03 - HID Keyboard
 * --------------------------------------------------------------------------------------
 */

#if (BLE_APP_HID)
#define APP_HID_ADV_DATA_APPEARANCE   "\x03\x19\xC1\x03"
#endif //(BLE_APP_HID)

#define APP_ADV_DATA_APPEARANCE_LEN  (4)

/**
 * Default Scan response data
 * --------------------------------------------------------------------------------------
 * x09                             - Length
 * xFF                             - Vendor specific advertising type
 * x00\x60\x52\x57\x2D\x42\x4C\x45 - "FR-BLE"
 * --------------------------------------------------------------------------------------
 */
#define APP_SCNRSP_DATA         "\x09\xFF\x00\x60\x46\x52\x2D\x42\x4C\x45"
#define APP_SCNRSP_DATA_LEN     (10)

/**
 * Advertising Parameters
 */
#if (BLE_APP_HID)
/// Default Advertising duration - 30s (in multiple of 10ms)
#define APP_DFLT_ADV_DURATION   (3000)
#endif //(BLE_APP_HID)


/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

typedef void (*appm_add_svc_func_t)(void);

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// List of service to add in the database
enum appm_svc_list
{
#if (BLE_APP_DIS)
    APPM_SVC_DIS,
#endif //(BLE_APP_DIS)
#if (BLE_APP_BATT)
    APPM_SVC_BATT,
#endif //(BLE_APP_BATT)
#if (BLE_APP_HID)
    APPM_SVC_HIDS,
#endif //(BLE_APP_HID)
#if (BLE_APP_PROXR)
    APPM_SVC_PROXR,
#endif //(BLE_APP_PROXR)
#if (BLE_APP_OTAS)
    APPM_SVC_OTAS,
#endif
#if (BLE_APP_SPSS)
    APPM_SVC_SPSS,
#endif //(BLE_APP_SPSS)
#if (BLE_APP_SPSC)
    APPM_SVC_SPSC,
#endif
#if (BLE_APP_FINDT)
    APPM_SVC_FINDT,
#endif
#if (BLE_APP_RTCTS)
    APPM_SVC_RTCTS,
#endif
#if BLE_APP_MESH
    APPM_SVC_MESH,
#endif
#if (USER_FLOWER_CARE)
    APPM_CLT_FLOWER,
#endif

//extra list for user created db
    APPM_SVC_LIST_STOP,
};


uint8_t app_device_name[APP_DEVICE_NAME_LENGTH_MAX] = "FR8010_AT";
static bool reset_aldo_voltage = false;

/*
 * LOCAL VARIABLES DEFINITIONS
 ****************************************************************************************
 */

/// Application Task Descriptor
static const struct ke_task_desc TASK_DESC_APP = {NULL, &appm_default_handler,
           appm_state, APPM_STATE_MAX, APP_IDX_MAX
};

/// List of functions used to create the database
static const appm_add_svc_func_t appm_add_svc_func_list[APPM_SVC_LIST_STOP+1] =
{
#if (BLE_APP_DIS)
    (appm_add_svc_func_t)app_dis_add_dis,
#endif //(BLE_APP_DIS)
#if (BLE_APP_BATT)
    (appm_add_svc_func_t)app_batt_add_bas,
#endif //(BLE_APP_BATT)
#if (BLE_APP_HID)
    (appm_add_svc_func_t)app_hid_add_hids,
#endif //(BLE_APP_HID)
#if (BLE_APP_PROXR)
    (appm_add_svc_func_t)app_proxr_add_proxs,
#endif //(BLE_APP_PROXR)
#if (BLE_APP_OTAS)
    (appm_add_svc_func_t)app_otas_add_otass,
#endif //(BLE_APP_OTAS)
#if (BLE_APP_SPSS)
    (appm_add_svc_func_t)app_spss_add_spsss,
#endif //(BLE_APP_SPSS)
#if (BLE_APP_SPSC)
    (appm_add_svc_func_t)app_spsc_add_spscs,
#endif //(BLE_APP_SPSC)
#if (BLE_APP_FINDT)
    (appm_add_svc_func_t)app_findt_add_findt,
#endif //(BLE_APP_FMPT)
#if (BLE_APP_RTCTS)
    (appm_add_svc_func_t)app_rtcts_add_rtctss,
#endif //(BLE_APP_OTAS)
#if BLE_APP_MESH
    (appm_add_svc_func_t)app_add_mesh,
#endif
#if(USER_FLOWER_CARE)
    (appm_add_svc_func_t)app_flower_add_client,
#endif //(BLE_TMP_CLIENT)

    NULL,
};

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Application Environment Structure
struct app_env_tag app_env;

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void appm_init_imp(void)
{

    // Reset the application manager environment
    memset(&app_env, 0, sizeof(app_env)-sizeof(void *)*APP_EVT_MAX);

    // Create APP task
    ke_task_create(TASK_APP, &TASK_DESC_APP);

    // Initialize Task state
    ke_state_set(TASK_APP, APPM_INIT);

    /*------------------------------------------------------
     * INITIALIZE ALL MODULES
     *------------------------------------------------------*/

#if (BLE_APP_SEC)
    // Security Module
    app_sec_init();
#endif // (BLE_APP_SEC)

#if (BLE_APP_DIS)
    // Device Information Module
    app_dis_init();
#endif //(BLE_APP_DIS)

#if (BLE_APP_HID)
    // HID Module
    app_hid_init();
#endif //(BLE_APP_HID)

#if (BLE_APP_BATT)
    // Battery Module
    app_batt_init();
#endif //(BLE_APP_BATT)

#if (BLE_APP_PROXR)
    app_proxr_init();
#endif  //(BLE_APP_PROXR)

#if (BLE_APP_OTAS)
    app_otas_init();
#endif

#if (BLE_APP_SPSS)
    app_spss_init();
#endif

#if BLE_APP_MESH
    app_mesh_init();
#endif

#if (BLE_APP_SPSC)
    app_spsc_init();
#endif

#if (BLE_APP_RTCTS)
    app_rtcts_init();
#endif

    app_init_ind_func();
}

void appm_set_device_name(uint8_t *arg,uint8_t size)
{
    if(size < APP_DEVICE_NAME_LENGTH_MAX)
    {
        memset(app_device_name,0,APP_DEVICE_NAME_LENGTH_MAX);
        memcpy(app_device_name,arg,size);
    }
}
bool appm_add_svc(void)
{
    ke_state_set(TASK_APP, APPM_CREATE_DB);

    // Indicate if more services need to be added in the database
    bool more_svc = false;

    // Check if another should be added in the database
    if (app_env.next_svc != APPM_SVC_LIST_STOP)
    {
        ASSERT_ERR(appm_add_svc_func_list[app_env.next_svc] != NULL);

        // Call the function used to add the required service
        appm_add_svc_func_list[app_env.next_svc]();

        // Select following service to add
        app_env.next_svc++;
        more_svc = true;
    }

#include "user_profile.h"
#if USER_PROFILE_API_ENABLE
    if(more_svc == false)
    {
        if(check_user_svc_list() == false)
        {
            return false;
        }
        else
            return true;
    }
    else
#endif
        return more_svc;
}


void appm_set_dev_configuration(struct gapm_set_dev_config_cmd *msg)
{
    struct gapm_set_dev_config_cmd* cmd = KE_MSG_ALLOC(GAPM_SET_DEV_CONFIG_CMD,
                                          TASK_GAPM, TASK_APP,
                                          gapm_set_dev_config_cmd);
    if(msg == NULL)
    {
        cmd->operation = GAPM_SET_DEV_CONFIG;
        // Device Role
        cmd->role = GAP_ROLE_ALL;
        cmd->addr_type = GAPM_CFG_ADDR_PUBLIC;
        /// GAP service start handle
        cmd->gap_start_hdl = 0;
        /// GATT service start handle
        cmd->gatt_start_hdl = 0;

        // Set Data length parameters
        //cmd->sugg_max_tx_octets = BLE_MIN_OCTETS;
        //cmd->sugg_max_tx_time = BLE_MIN_TIME;
        cmd->sugg_max_tx_octets = BLE_MAX_OCTETS;
        cmd->sugg_max_tx_time = BLE_MAX_TIME;
        // Do not support secure connections
        //cmd->pairing_mode = GAPM_PAIRING_LEGACY;

// Enable Slave Preferred Connection Parameters present
        /*
        /// Device Name write permission requirements for peer device (@see gapm_write_att_perm)
        GAPM_MASK_ATT_NAME_PERM           = 0x0007,
        /// Device Appearance write permission requirements for peer device (@see gapm_write_att_perm)
        GAPM_MASK_ATT_APPEARENCE_PERM     = 0x0038,
        /// Slave Preferred Connection Parameters present in GAP attribute database.
        GAPM_MASK_ATT_SLV_PREF_CON_PAR_EN = 0x0040,
        /// Service change feature present in GATT attribute database.
        GAPM_MASK_ATT_SVC_CHG_EN          = 0x0080,
        /// Service change feature present in GATT attribute database.
        GAPM_MASK_ATT_DBG_MODE_EN         = 0x8000,
        */
        cmd->att_cfg = GAPM_MASK_ATT_SVC_CHG_EN | GAPM_MASK_ATT_SLV_PREF_CON_PAR_EN
                       | GAPM_MASK_ATT_APPEARENCE_PERM | GAPM_MASK_ATT_NAME_PERM;

        cmd->gap_start_hdl = 0;
        cmd->gatt_start_hdl = 0;

        //Defined maximum transmission unit
        cmd->max_mtu = BLE_MAX_OCTETS-4;//BLE_MAX_OCTETS;
        cmd->max_mps = BLE_MAX_OCTETS;//BLE_MAX_OCTETS;
    }
    else
        memcpy(cmd,msg,sizeof(struct gapm_set_dev_config_cmd));
    APP_LOG("\r\ndev_config start\r\n");

    ke_msg_send(cmd);
}
void appm_set_dev_configuration_default(void *arg)
{
    appm_set_dev_configuration(NULL);
}

void appm_handle_white_list_cmd(struct gapm_white_list_mgt_cmd *cmd)
{
#ifndef REMOVE_CODE_IN_MESH
    if (ke_state_get(TASK_APP) == APPM_READY)
    {
        struct gapm_white_list_mgt_cmd *param = NULL;

        if(cmd == NULL)
        {
            param = (struct gapm_white_list_mgt_cmd *)KE_MSG_ALLOC_DYN(GAPM_WHITE_LIST_MGT_CMD,
                    TASK_GAPM,
                    TASK_APP,
                    gapm_white_list_mgt_cmd,
                    sizeof(struct gap_bdaddr));

            param->operation = GAPM_GET_WLIST_SIZE;
            //param->nb = 1;
            //struct bd_addr device_bdaddr = {{0x1b, 0x18, 0x62, 0x8d, 0x7c, 0xC4}};
            //memcpy(&param->devices[0].addr.addr[0], &device_bdaddr, BD_ADDR_LEN);
            //param->devices[0].addr_type = GAPM_CFG_ADDR_PUBLIC;
            APP_LOG("get white list sz\r\n");
        }
        else
        {
            param = (struct gapm_white_list_mgt_cmd *) KE_MSG_ALLOC_DYN(GAPM_WHITE_LIST_MGT_CMD
                    , TASK_GAPM, TASK_APP, gapm_white_list_mgt_cmd, cmd->nb * sizeof(struct gap_bdaddr));
            memcpy(param,cmd,sizeof(struct gapm_white_list_mgt_cmd)+ cmd->nb * sizeof(struct gap_bdaddr));
        }

        if(param!=NULL)
            ke_msg_send(param);
    }
#endif
}


void appm_start_scan(struct gapm_start_scan_cmd *msg)
{
#ifndef REMOVE_CODE_IN_MESH
    struct gapm_start_scan_cmd *cmd;

    if (ke_state_get(TASK_APP) == APPM_READY)
    {
        cmd = (struct gapm_start_scan_cmd *)KE_MSG_ALLOC(GAPM_START_SCAN_CMD,
                TASK_GAPM,
                TASK_APP,
                gapm_start_scan_cmd);
        if(msg == NULL)
        {
            cmd->mode = GAP_GEN_DISCOVERY; //GAP_OBSERVER_MODE;//GAP_GEN_DISCOVERY;
            cmd->op.code = GAPM_SCAN_ACTIVE;
            cmd->op.addr_src = GAPM_STATIC_ADDR;
            cmd->filt_policy = SCAN_ALLOW_ADV_ALL;
            cmd->filter_duplic = SCAN_FILT_DUPLIC_DIS;
            //one scan duration time is interval
            cmd->interval = APP_SCAN_INT;
            //during this scan interval, open window for sync time is value window
            cmd->window = 40;//APP_SCAN_WIN;
            //(param->scan_window > param->scan_intv)
            //param->scan_window > 16384
            //param->scan_window < 4
            //param->scan_intv > 16384
            //param->scan_intv < 4
        }
        else
            memcpy(cmd,msg,sizeof(struct gapm_start_scan_cmd));
        APP_LOG("scan start \r\n");

        ke_msg_send(cmd);

        ke_state_set(TASK_APP, APPM_SCANNING);
    }
#endif
}
void appm_start_scan_default(void *arg)
{
    appm_start_scan(NULL);
}


void appm_stop_scan(void)
{
#ifndef REMOVE_CODE_IN_MESH
    if (ke_state_get(TASK_APP) == APPM_SCANNING)
    {
        // Prepare the GAPM_CANCEL_CMD message
        struct gapm_cancel_cmd *cmd = KE_MSG_ALLOC(GAPM_CANCEL_CMD,
                                      TASK_GAPM, TASK_APP,
                                      gapm_cancel_cmd);

        cmd->operation = GAPM_CANCEL;
        APP_LOG("scan stop \r\n");

        // Send the message
        ke_msg_send(cmd);
    }
    // else ignore the request
#endif
}


void app_adv_func_default(struct gapm_start_advertise_cmd *cmd)
{
#if !defined(REMOVE_CODE_IN_MESH) &&  !defined(PROJ_MICPHONE_KEYSCAN)
    //  Device Name Length
    uint8_t device_name_length;
    int8_t device_name_avail_space;

    cmd->op.code     = GAPM_ADV_UNDIRECT;//GAPM_ADV_UNDIRECT;//GAPM_ADV_NON_CONN;
    cmd->op.addr_src = GAPM_STATIC_ADDR;

//useless, must < intv_max
    cmd->intv_min    =  1600;           //APP_ADV_INT_MIN;              //0x40;

// decided evt->interval, 0x40*625us
    cmd->intv_max    =  1600;       //APP_ADV_INT_MAX;  1600        0x40
    cmd->channel_map = APP_ADV_CHMAP;

    cmd->info.host.adv_filt_policy = ADV_ALLOW_SCAN_ANY_CON_ANY;
    cmd->info.host.mode = GAP_GEN_DISCOVERABLE;

    cmd->info.host.adv_data_len       = ADV_DATA_LEN - 3;
    cmd->info.host.scan_rsp_data_len  = SCAN_RSP_DATA_LEN;

    {
        cmd->info.host.adv_data_len = 0;
        /*
        #if (BLE_APP_HID)
                memcpy(&cmd->info.host.adv_data[cmd->info.host.adv_data_len],
                       APP_HID_ADV_DATA_UUID, APP_HID_ADV_DATA_UUID_LEN);
                cmd->info.host.adv_data_len += APP_HID_ADV_DATA_UUID_LEN;
                memcpy(&cmd->info.host.adv_data[cmd->info.host.adv_data_len],
                       APP_HID_ADV_DATA_APPEARANCE, APP_ADV_DATA_APPEARANCE_LEN);
                cmd->info.host.adv_data_len += APP_ADV_DATA_APPEARANCE_LEN;
        #endif //(BLE_APP_HID)
        */
    }
    // Scan Response Data
    {
        cmd->info.host.scan_rsp_data_len = 0;

        memcpy(&cmd->info.host.scan_rsp_data[cmd->info.host.scan_rsp_data_len],
               APP_SCNRSP_DATA, APP_SCNRSP_DATA_LEN);
        cmd->info.host.scan_rsp_data_len += APP_SCNRSP_DATA_LEN;
    }

    // Get remaining space in the Advertising Data - 2 bytes are used for name length/flag
    device_name_avail_space = APP_ADV_DATA_MAX_SIZE - cmd->info.host.adv_data_len - 2;

    // Check if data can be added to the Advertising data
    if (device_name_avail_space > 0)
    {
        // Get default Device Name (No name if not enough space)
        device_name_length = strlen((const char *)app_device_name);

        if(device_name_length > 0)
        {
            // Check available space
            device_name_length = co_min(device_name_length, device_name_avail_space);
            // Fill Length
            cmd->info.host.adv_data[cmd->info.host.adv_data_len]     = device_name_length + 1;
            // Fill Device Name Flag
            cmd->info.host.adv_data[cmd->info.host.adv_data_len + 1] = '\x09';
            // Copy device name
            memcpy(&cmd->info.host.adv_data[cmd->info.host.adv_data_len + 2], app_device_name, device_name_length);
            // Update Advertising Data Length
            cmd->info.host.adv_data_len += (device_name_length + 2);
        }
    }
#endif
    return;
}

void appm_start_advertising(struct gapm_start_advertise_cmd *msg)
{
    APP_LOG("app_status:%d\r\n",ke_state_get(TASK_APP));
#ifndef REMOVE_CODE_IN_MESH
    // Check if the advertising procedure is already is progress
    if (ke_state_get(TASK_APP) == APPM_READY)
    {
        // Prepare the GAPM_START_ADVERTISE_CMD message
        struct gapm_start_advertise_cmd *cmd = KE_MSG_ALLOC(GAPM_START_ADVERTISE_CMD,
                                               TASK_GAPM, TASK_APP,
                                               gapm_start_advertise_cmd);

        cmd->op.addr_src    = GAPM_STATIC_ADDR;
        cmd->channel_map    = APP_ADV_CHMAP;

        cmd->intv_min = APP_ADV_INT_MIN;
        cmd->intv_max = APP_ADV_INT_MAX;

        if(msg == NULL)
            app_adv_func_default(cmd);
        else
            memcpy(cmd,msg,sizeof(struct gapm_start_advertise_cmd));

        if(cmd->op.code == GAPM_ADV_DIRECT)
        {
            APP_LOG("adv_direct start\r\n");
        }
        else
        {
            APP_LOG("adv_undirect start\r\n");
        }
        // Send the message
        ke_msg_send(cmd);

        // Set the state of the task to APPM_ADVERTISING
        ke_state_set(TASK_APP, APPM_ADVERTISING);
        app_env.role = APP_ROLE_SLAVE;
    }
#endif
    // else ignore the request
}
void appm_start_advertising_default(void *arg)
{
    appm_start_advertising(NULL);
}



void appm_stop_advertising(void)
{
    if (ke_state_get(TASK_APP) == APPM_ADVERTISING)
    {
        // Prepare the GAPM_CANCEL_CMD message
        struct gapm_cancel_cmd *cmd = KE_MSG_ALLOC(GAPM_CANCEL_CMD,
                                      TASK_GAPM, TASK_APP,
                                      gapm_cancel_cmd);

        cmd->operation = GAPM_CANCEL;
        APP_LOG("adv stop\r\n");

        // Send the message
        ke_msg_send(cmd);
    }
    // else ignore the request
}


void app_reset_app(void)
{
    // Reset the stack
    struct gapm_reset_cmd* cmd = KE_MSG_ALLOC(GAPM_RESET_CMD, TASK_GAPM, TASK_APP,gapm_reset_cmd);
    cmd->operation = GAPM_RESET;// Set GAPM_RESET
    ke_msg_send(cmd);// Send the message
}

void appm_update_param(uint8_t conidx, struct gapc_conn_param *conn_param)
{
#ifndef REMOVE_CODE_IN_MESH
    if (appm_get_connect_status(conidx) == true)
    {
        // Prepare the  GAPC_PARAM_UPDATE_CMD message
        struct gapc_param_update_cmd *cmd = KE_MSG_ALLOC(GAPC_PARAM_UPDATE_CMD,
                                            KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                            gapc_param_update_cmd);

        cmd->operation  = GAPC_UPDATE_PARAMS;
        cmd->intv_min   = conn_param->intv_min;
        cmd->intv_max   = conn_param->intv_max;
        cmd->latency    = conn_param->latency;
        cmd->time_out   = conn_param->time_out;

        // not used by a slave device
        cmd->ce_len_min = 0xFFFF;
        cmd->ce_len_max = 0xFFFF;
        // APP_LOG("update_param start\r\n");
        app_env.param_update_on_going = true;
        // Send the message
        ke_msg_send(cmd);
    }
#endif
}

void appm_get_peer_info(uint16_t conidx,uint8_t operation)
{
    // Send a GAPC_GET_INFO_CMD in order to read the device name characteristic value
    struct gapc_get_info_cmd *p_cmd = KE_MSG_ALLOC(GAPC_GET_INFO_CMD,
                                      KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                      gapc_get_info_cmd);
    APP_LOG("get_peer_info start,conidx:%d\r\n",conidx);
    p_cmd->operation = operation;
    ke_msg_send(p_cmd);
}

void appm_exc_mtu_cmd(uint8_t conidx)
{
    APP_LOG("gattc_exc_mtu_cmd,conidx:%d\r\n",conidx);

    struct gattc_exc_mtu_cmd *cmd =  KE_MSG_ALLOC(GATTC_EXC_MTU_CMD,
                                     KE_BUILD_ID(TASK_GATTC,conidx ), TASK_APP,
                                     gattc_exc_mtu_cmd);

    cmd->operation = GATTC_MTU_EXCH;
    cmd->seq_num = 0x1;

    ke_msg_send(cmd);
}




//For master only
void appm_start_bond_cmd(uint8_t conidx)
{
#ifndef REMOVE_CODE_IN_MESH
    // generate a local bond command to update correctly internal state machine
    struct gapc_bond_cmd *cmd = KE_MSG_ALLOC(GAPC_BOND_CMD,
                                KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                gapc_bond_cmd);
    cmd->operation = GAPC_BOND;
    cmd->pairing.auth= GAP_AUTH_REQ_MITM_BOND;
    cmd->pairing.ikey_dist= GAP_KDIST_ENCKEY | GAP_KDIST_IDKEY | GAP_KDIST_SIGNKEY;

    cmd->pairing.iocap=GAP_IO_CAP_KB_DISPLAY;

    cmd->pairing.key_size=0x10;
    cmd->pairing.oob=GAP_OOB_AUTH_DATA_NOT_PRESENT;
    cmd->pairing.rkey_dist= GAP_KDIST_ENCKEY | GAP_KDIST_IDKEY | GAP_KDIST_SIGNKEY;
    cmd->pairing.sec_req=GAP_NO_SEC;

    // Keep the packet for later use
    //memcpy(&(cmd->pairing), &(pdu->data.pairing_req.iocap), SMPC_CODE_PAIRING_REQ_RESP_LEN - 1);
    APP_LOG("bond start\r\n");

    ke_msg_send(cmd);
#endif
}


//For master role only
void app_sec_send_enc_req(uint8_t conidx)
{
#if (BLE_APP_SEC)
#ifndef REMOVE_CODE_IN_MESH
    struct gapc_encrypt_cmd *cmd = KE_MSG_ALLOC(GAPC_ENCRYPT_CMD,
                                   KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP, gapc_encrypt_cmd);
    cmd->operation = GAPC_ENCRYPT;
    memcpy(&cmd->ltk, &(app_sec_env.ltk), sizeof(struct gapc_ltk));

    // show_reg2(cmd->ltk.ltk.key,KEY_LEN,1);
    //  printf("%x\r\n",cmd->ltk.ediv);
    //  show_reg2(cmd->ltk.randnb.nb,RAND_NB_LEN,1);
    //  printf("%x\r\n",cmd->ltk.key_size);


    APP_LOG("master_send_enc_req\r\n");
//    show_reg2((uint8_t *)ltk,sizeof(struct gapc_ltk),1);
    ke_msg_send(cmd);
#endif
#endif
}


void appm_start_connecting(struct gapm_start_connection_cmd *cmd)
{
#ifndef REMOVE_CODE_IN_MESH
    if (ke_state_get(TASK_APP) == APPM_READY)
    {
        struct gapm_start_connection_cmd *param = NULL;

        if(cmd == NULL)
        {

            param = (struct gapm_start_connection_cmd *)KE_MSG_ALLOC_DYN(GAPM_START_CONNECTION_CMD,
                    TASK_GAPM,
                    TASK_APP,
                    gapm_start_connection_cmd,
                    sizeof(struct gap_bdaddr));
            /*
                        param->op.code = GAPM_CONNECTION_DIRECT;
                        param->op.addr_src = GAPM_STATIC_ADDR;
                        param->scan_interval = APP_SCAN_INT;
                        param->scan_window = APP_SCAN_WIN;
                        param->con_intv_min = APP_CONN_INT_MIN;
                        param->con_intv_max = APP_CONN_INT_MAX;
                        param->con_latency = APP_CONN_LATENCY;
                        param->superv_to = APP_CONN_SU_TO;
                        param->ce_len_max = APP_CONN_CE_MAX;
                        param->ce_len_min = APP_CONN_CE_MIN;
                        param->nb_peers = 1;
            */

            param->op.code = GAPM_CONNECTION_DIRECT;
            param->op.addr_src = GAPM_STATIC_ADDR;
            param->scan_interval = APP_SCAN_INT;

            param->con_intv_min = APP_CONN_INT_MIN;
            param->con_intv_max = APP_CONN_INT_MIN;

            param->scan_window = APP_SCAN_WIN;//(param->con_intv_min*2-6);

            param->con_latency = 0;
            param->superv_to = 700;
            param->ce_len_max = 32;
            param->ce_len_min = 32;
            param->nb_peers = 1;
//0x0f, 0x09, 0x07, 0x09, 0x17, 0x20
//0x24, 0x18, 0x62, 0x8d, 0x7c, 0xC4
            struct bd_addr connect_bdaddr = {{0x24, 0x18, 0x62, 0x8d, 0x7c, 0xC4}};
            memcpy(&param->peers[0].addr.addr[0], &connect_bdaddr, BD_ADDR_LEN);
            param->peers[0].addr_type = GAPM_CFG_ADDR_PUBLIC;//GAPM_CFG_ADDR_PUBLIC;GAPM_CFG_ADDR_PRIVATE
        }
        else
        {
            // create a kenrel message to start connecting  with an advertiser
            param = (struct gapm_start_connection_cmd *) KE_MSG_ALLOC_DYN(GAPM_START_CONNECTION_CMD
                    , TASK_GAPM, TASK_APP, gapm_start_connection_cmd, cmd->nb_peers * sizeof(struct gap_bdaddr));
            memcpy(param,cmd,sizeof(struct gapm_start_connection_cmd)+ cmd->nb_peers * sizeof(struct gap_bdaddr));
        }

        APP_LOG("con start\r\n");
        if(param!=NULL)
            ke_msg_send(param);

        //ke_timer_set(APP_CON_TIMEOUT_TIMER, TASK_APP, APP_DFLT_CON_DURATION);
        ke_state_set(TASK_APP, APPM_INITIATING);
        app_env.role = APP_ROLE_MASTER;
    }
#endif
}
void appm_start_connecting_default(void *arg)
{
    appm_start_connecting(NULL);
}


void appm_stop_connecting(void)
{
#if !defined(REMOVE_CODE_IN_MESH) && !defined(PROJ_MICPHONE_KEYSCAN)
    if (ke_state_get(TASK_APP) == APPM_INITIATING)
    {
        // Stop the advertising timer if needed
        if (ke_timer_active(APP_CON_TIMEOUT_TIMER, TASK_APP))
        {
            ke_timer_clear(APP_CON_TIMEOUT_TIMER, TASK_APP);
        }
        // Prepare the GAPM_CANCEL_CMD message
        struct gapm_cancel_cmd *cmd = KE_MSG_ALLOC(GAPM_CANCEL_CMD,
                                      TASK_GAPM, TASK_APP,
                                      gapm_cancel_cmd);

        cmd->operation = GAPM_CANCEL;
        APP_LOG("con stop\r\n");
        // Send the message
        ke_msg_send(cmd);
    }
    // else ignore the request
#endif
}

void appm_disconnect(uint8_t conidx)
{
#ifndef REMOVE_CODE_IN_MESH
    if (appm_get_connect_status(conidx) == true)
    {
        struct gapc_disconnect_cmd *cmd = KE_MSG_ALLOC(GAPC_DISCONNECT_CMD,
                                          KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                          gapc_disconnect_cmd);

        cmd->operation = GAPC_DISCONNECT;
        cmd->reason    = CO_ERROR_REMOTE_USER_TERM_CON;
        APP_LOG("discon_cmd start\r\n");

        // Send the message
        ke_msg_send(cmd);
    }
#endif
}

/*
uint8_t appm_get_dev_name(uint8_t* name)
{
    // copy name to provided pointer
    memcpy(name, app_env.dev_name, app_env.dev_name_len);
    // return name length
    return app_env.dev_name_len;
}*/


uint8_t appm_get_connect_num(void)
{
    uint8_t num = 0;
    for(uint8_t i = 0; i<BLE_CONNECTION_MAX; i++)
    {
        if(app_env.connected[i])
            num++;
    }
    return num;
}

bool appm_get_connect_status(uint8_t conidx)
{
    return (app_env.connected[conidx]);
}

app_status_t appm_get_current_status(void)
{
    return (app_status_t)ke_state_get(TASK_APP);
}


void appm_set_cb_func(uint8_t id,   app_callback_func_t func)
{
    if(id < APP_EVT_MAX)
        app_env.func[id] = func;
}


void ble_set_addr(uint8_t* addr)
{
    if(addr != NULL)
        memcpy(__jump_table.addr.addr, addr, BD_ADDR_LEN);

    //show_reg2(__jump_table.addr.addr,BD_ADDR_LEN,1);
    ble_bdaddrl_set(co_read32p(&__jump_table.addr.addr[0]));
    ble_bdaddru_set(co_read16p(&__jump_table.addr.addr[4]));
    llm_util_set_public_addr(&__jump_table.addr);
    memcpy(&(gapm_env.addr), &(__jump_table.addr), BD_ADDR_LEN);
    //printf("%08X,%08X\r\n",ble_bdaddrl_get(),ble_bdaddru_get());
}
uint8_t *ble_get_addr(void)
{
    return (__jump_table.addr.addr);
}

void appm_use_aes128_block(uint8_t *key, uint8_t *plaintext,app_callback_func_t func)
{
    //uint8_t i;
    appm_set_cb_func(APP_EVT_ID_GOT_AES128_RESULT,func);

    struct gapm_use_enc_block_cmd *cmd = KE_MSG_ALLOC(GAPM_USE_ENC_BLOCK_CMD,
                                         TASK_GAPM, TASK_APP,
                                         gapm_use_enc_block_cmd);
    cmd->operation = GAPM_USE_ENC_BLOCK;
    //for(i=0; i<KEY_LEN; i++) {
    //  cmd->operand_1[i] = key[KEY_LEN-1-i];
    //  cmd->operand_2[i] = plaintext[KEY_LEN-1-i];
    //}

    memcpy(&cmd->operand_1[0], key, KEY_LEN);
    memcpy(&cmd->operand_2[0], plaintext, KEY_LEN);

    ke_msg_send(cmd);
}

void appm_sleep_stop(void)
{
    //fputc('P',NULL);
    rwip_prevent_sleep_set(RW_GPIO_INT_ONGOING);
}
//init and scan can't enter sleep
void appm_sleep_start(void)
{
    //fputc('S',NULL);
    if( appm_get_current_status()!=APPM_STATUS_INITIATING
        && appm_get_current_status()!=APPM_STATUS_SCANNING
      )
        rwip_prevent_sleep_clear(RW_GPIO_INT_ONGOING);
}
void appm_set_exit_int_gpio(uint32_t exit_int_gpio)
{
    __jump_table.gpio_button_sel = exit_int_gpio;
    gpio_init();
    uint8_t i;
    uint8_t index;
    uint8_t button_sel;
    for(i=0; i<32; i+=8)
    {
        index = i/8;
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        //input enable
        ool_write(PMU_REG_PORTA_IE+index, ool_read(PMU_REG_PORTA_IE+index) | (button_sel));
        //output disable
        ool_write(PMU_REG_PORTA_OEN+index, ool_read(PMU_REG_PORTA_OEN+index) | (button_sel));
        //pull enable
        ool_write(PMU_REG_PORTA_PUL+index, ool_read(PMU_REG_PORTA_PUL+index) & (~button_sel));
    }
}


void __attribute__((section("deep_sleep_code"))) app_set_uart_port(void)
{
    struct jump_table_t *jump_table_p = &__jump_table;

#ifndef LOG_UART_RX
#define LOG_UART_RX (1)
#endif

    if( (jump_table_p->system_option & SYSTEM_OPTION_PRINT_SEL_MSK) == SYSTEM_OPTION_PRINT_UART2 )
    {
        //system_set_port_mux(GPIO_PORT_C, GPIO_BIT_4, PORTC4_FUNC_UART2_RXD);
        //system_set_port_mux(GPIO_PORT_C, GPIO_BIT_5, PORTC5_FUNC_UART2_TXD);
#if (LOG_UART_RX)
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_UART1_RXD);
#endif
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_UART1_TXD);
    }
    else if( (jump_table_p->system_option & SYSTEM_OPTION_PRINT_SEL_MSK) == SYSTEM_OPTION_PRINT_UART1 )
    {
#if (LOG_UART_RX)
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_UART0_RXD);
#endif
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_UART0_TXD);
    }
}

/*
@value
0: 2.1V; 1: 2.3V; 2: 2.5V; 3: 2.7V; 4: 2.9V; 5: 3.1V; 6: 3.3V; 7: 3.5V
@is_bypass
0: aldo voltage is set by value;  1: aldo voltage is VBAT
*/
void appm_set_aldo_voltage(uint8_t value,uint8_t is_bypass)
{
    if(is_bypass)
        ool_write(0x00, ool_read(0x00)|BIT(4) );       //ALDO voltage  2.5V
    else
        ool_write(0x00, (ool_read(0x00)&(0x1f)) | ((value & 0x7)<<5) );      
    reset_aldo_voltage  = true;
}

#include "ssp.h"
uint8_t __attribute__((section("deep_sleep_code"))) flash_power_down(void)
{
#ifndef SLEEP_OPEN_FLASH
    volatile uint8_t dumy;
    ssp_clear_rx_fifo();
    ssp_put_byte(0xB9);
    ssp_enable();
    ssp_get_data((unsigned char *)&dumy, 1);
    ssp_wait_busy_bit();
    ssp_disable();
    return CO_ERROR_NO_ERROR;
#endif
}
uint8_t __attribute__((section("deep_sleep_code"))) flash_wakeup(void)
{
#ifndef SLEEP_OPEN_FLASH
    volatile uint8_t dumy;
    ssp_clear_rx_fifo();
    ssp_put_byte(0xAB);
    ssp_enable();
    ssp_get_data((unsigned char *)&dumy, 1);
    ssp_wait_busy_bit();
    ssp_disable();
    return CO_ERROR_NO_ERROR;
#endif
}

static void __attribute__((section("deep_sleep_code"))) rf_deep_sleep_patch(void)
{
    if(is_key_scan_enable())
        ool_write(0x54, 0x13);
    else
        ool_write(0x54, 0x10);

    ool_write(0x4a, 0x0f);  //enable rtc wake up
    ool_write(0x3d, 0x4c);  //clear timer wake up
    if(stack_space[STACK_SIZE-1] == 0)
    {
        ool_write(0x3d, 0x10);  //disable timer wakup,enable gpio wk
        if(stack_space[STACK_SIZE-2] == DEEP_SLEEP_WK_ONKEY)
        {
            pmu_set_on_off_mode(PMU_ON_OFF_MODE_PRESS,PMU_TONKEY_0_1S);
            pmu_power_off(0);
        }
    }
    else
        ool_write(0x3d, 0x11);  //enable timer wakup
    ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL)| BIT(0) );
    while(1);
}

void appm_goto_deep_sleep2(deep_sleep_wk_type type,uint32_t tick_ms)
{
    stack_space[STACK_SIZE-2] = type;
    if(type == DEEP_SLEEP_WK_ONKEY)
        appm_goto_deep_sleep(0,0);
    else
        appm_goto_deep_sleep(tick_ms,0);
}

#include "low_power.h"
#include "intc.h"
void __attribute__((section("deep_sleep_code"))) appm_goto_deep_sleep(uint32_t tick_ms,uint32_t wk_key)
{
    uint32_t rtc_alarm_counter;

    if(tick_ms < 10 && tick_ms != 0)    //30
        return;
    //GLOBAL_INT_DISABLE();
    CPU_SR_Save(0x20);

    appm_set_exit_int_gpio(wk_key);
    //appm_set_exit_int_gpio(0x0);//A0~A3 can't wkup, A2 is boot uart RXD,easy to freeze, A3 is log port

    user_gpio_init = NULL;

    stack_space[STACK_SIZE-1] = tick_ms;
    printf("D:%d\r\n",stack_space[STACK_SIZE-1]);
    //change RC
    ool_write(0x14, ool_read(0x14) | 0x01);

    if(tick_ms == 0)
    {
        ool_write(0x42, 0xFF);
        ool_write(0x43, 0xFF);
    }
    else
    {
        //uint32_t sleep_duratoin = (tick_ms*8)/5;
        switch(__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK)
        {
            //case SYSTEM_OPTION_LP_CLK_32768:
            //  rtc_alarm_counter = (sleep_duratoin << 11)/100;
            //break;
            //case SYSTEM_OPTION_LP_CLK_32K:
            //  rtc_alarm_counter = sleep_duratoin * 20;
            //break;
            default:
                rtc_alarm_counter = tick_ms * system_get_rc_clk_patch(true) / 1000;
                break;
        }
        if((__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK) == SYSTEM_OPTION_LP_CLK_RC)
            rtc_alarm_counter >>= 4;
        else
            rtc_alarm_counter >>= 5;
        if((__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK) != SYSTEM_OPTION_LP_CLK_32768)
            rtc_alarm_counter -= 5;
        else
            rtc_alarm_counter -= 8;
        ool_write(0x42, rtc_alarm_counter & 0xFF);  //0x45~0x42: 32bits rtc sleep time * 0.5ms
        ool_write(0x43, (rtc_alarm_counter>>8) & 0xFF);
        ool_write(0x44, (rtc_alarm_counter>>16) & 0xFF);
        ool_write(0x45, (rtc_alarm_counter>>24) & 0xFF);
    }
    uint8_t i;
    uint8_t index;
    uint8_t button_sel;
    //printf("b:%x\r\n",__jump_table.gpio_button_sel);
    for(i=0; i<32; i+=8)
    {
        index = i/8;
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        pmu_enable_ext_wakeup_group((enum system_port_t)index, button_sel);
    }
    ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL) | PMU_REG_GPIO_WK_EN);

    //led 0/1 linkage
    /*
    led_set_div(100);
    led_cfg(0,0,0,0);
    led_run(0);
    led_cfg(1,0,0,0);
    led_run(1);
    led_cfg(2,0,0,0);
    led_run(2);
    led_cfg(3,0,0,0);
    led_run(3);
    led_cfg(4,0,0,0);
    led_run(4);
    led_cfg(5,0,0,0);
    led_run(5);  */

#define V_0_50  (0)
#define V_0_55  (BIT(0))
#define V_0_60  (BIT(1))
#define V_0_65  (BIT(1)|BIT(0))
#define V_0_70  (BIT(2))
#define V_0_75  (BIT(2)|BIT(0))
#define V_0_80  (BIT(2)|BIT(1))
#define V_0_85  (BIT(2)|BIT(1)|BIT(0))
#define V_0_90  (BIT(3))
#define V_0_95  (BIT(3)|BIT(0))
#define V_1_00  (BIT(3)|BIT(1))
#define V_1_05  (BIT(3)|BIT(1)|BIT(0))

#define BV_1_30  (0)
#define BV_1_35  (BIT(0))
#define BV_1_40  (BIT(1))
#define BV_1_45  (BIT(1)|BIT(0))
#define BV_1_50  (BIT(2))
#define BV_1_55  (BIT(2)|BIT(0))
#define BV_1_60  (BIT(2)|BIT(1))

    ool_write(0x0f, SET_FEILD(0x5d,0xf,2,V_0_85));  //0x49-0.8V, 0101 1101
    ool_write(0x0f, SET_FEILD(0x5f,0xf,2,V_0_85));  //0x4b-0.8v, 0101 1111
    ool_write(0x02, SET_FEILD(0xd1,0x7,3,BV_1_40));  //1101 0001   0xd1
    ool_write(0x02, SET_FEILD(0xd3,0x7,3,BV_1_40));  //1101 0011   0xd3

#ifdef FOR_MESH_CUSTOMER_CODE
    ool_write(0x89, 0x3f);
    ool_write(0x88, 0xff);
    flash_power_down(); //38us
#else
    if(stack_space[STACK_SIZE-2] == DEEP_SLEEP_WK_ONKEY)
    {
        ool_write(0x88, 0x00);
        ool_write(0x89, 0x00);
    }
    else
    {
        ool_write(0x88, 0x08);      //FE,0x08
        ool_write(0x89, 0x00);
        flash_power_down(); //38us
    }
#endif

    ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) & 0xF0);   //SPI FLASH CS to pmu

    ool_write(PMU_REG_SYSTEM_STATUS, PMU_REG_SYS_WK_MAGIC);     //mark C6 to this

    rwip_rf.sleep = rf_deep_sleep_patch;
    low_power_save();


    //while(ble_deep_sleep_stat_getf());
    low_power_restore_patch_imp(0);
    system_init();
    intc_init();
    gpio_init();
    ssp_init();

//NOTE: all func here should be in deepsleep code area, use printf,pls,change 0x88 value to 0xFE
#if 0
    uart_init(__jump_table.bandrate & 0x0F);
    uart2_init((__jump_table.bandrate & 0xF0)>>4);
    app_set_sysclk();
    NVIC_EnableIRQ(UART0_IRQn);
    NVIC_EnableIRQ(UART1_IRQn);
    app_set_uart_port();
#endif

    ool_write(PMU_REG_SYSTEM_STATUS, 0xC6);
#ifdef FOR_MESH_CUSTOMER_CODE
    ool_write(0x89, 0x3f);
    ool_write(0x88, 0xff);
#else
    ool_write(0x89, 0x08);
    ool_write(0x88, 0xFF);
#endif
    ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) | 0x0F);   //SPI FLASH CS to digital
    flash_wakeup(); //38us

    uint32_t wake_up_key = 0;
    for(i=0; i<32; i+=8)
    {
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        pmu_disable_ext_wakeup_group((enum system_port_t)(i/8), button_sel);
        //if( ool_read(PMU_REG_WAKEUP_STATE_0 + i/8) )
        wake_up_key |= (ool_read(PMU_REG_WAKEUP_STATE_0 + i/8)<<i);
    }
    //printf("%x\r\n",wake_up_key);
    ool_write(0xa2,(wake_up_key>>24)&0xff);
    ool_write(0xa3,(wake_up_key>>16)&0xff);
    ool_write(0xa4,(wake_up_key>>8)&0xff);
    ool_write(0xa5,(wake_up_key>>0)&0xff);

    //GLOBAL_INT_RESTORE();
    //printf("xxxx\r\n");
    //printf("xxxx:%d,%d,%d,%d,%d\r\n",system_regs->key_scan_value[0],system_regs->key_scan_value[1]
    //         ,system_regs->key_scan_value[2]
    //       ,system_regs->key_scan_value[3],system_regs->key_scan_value[4]);

//printf("xxxx:%d\r\n",stack_space[STACK_SIZE-1]);
//printf can't use
#ifdef FOR_MESH_CUSTOMER_CODE
    uint32_t *dst, *src, len;
    dst = (uint32_t *)0x2000016c;
    src = (uint32_t *)0x000266fc;
    for(len=0; len<0xc0; len+=4)
    {
        *dst++ = *src++;
    }
    /*dst = (uint32_t *)0x200000d0;
    for(len=0; len<0x9c; len+=4) {
        *dst++ = 0;
    }*/
    dst = (uint32_t *)0x2000022c;
    for(len=0; len<0x650; len+=4)
    {
        *dst++ = 0;
    }
    //app_boot_set_storage_type(1);
    //app_boot_load();
    GLOBAL_INT_STOP();
    CPU_SR_Restore(0x00);
    ((void(*)(void))0x0001da1d)();
#endif
    __set_FAULTMASK(1);
    NVIC_SystemReset();

    while(1);

}

//range:  3.0V~4.2V
uint8_t app_get_battay_value(void)
{
    uint8_t value;
    ool_write(0x01,ool_read(0x01) | CO_BIT(5));
    ool_write(0x01,ool_read(0x01) & ~(CO_BIT(4)));
    ool_write(0x01,ool_read(0x01) & ~(CO_BIT(6)));
    co_delay_100us(1);
    ool_write(0x01,ool_read(0x01) | CO_BIT(6));
    value = system_regs->reserved3[0] & 0x07;
    ool_write(0x01,ool_read(0x01) | (CO_BIT(4)));
    return value;
}

uint32_t appm_get_rand_low4byte_mac(void)
{
    uint32_t value_u32;

    uint32_t value_u16;
    value_u16 = nvram_read(504);
    value_u16 <<= 8;
    value_u16 |= nvram_read(505);
    value_u32 = nvram_read(value_u16 & 0x1FF);

    value_u16 = nvram_read(506);
    value_u16 <<= 8;
    value_u16 |= nvram_read(507);
    value_u32 <<= 8;
    value_u32 |= nvram_read(value_u16 & 0x1FF);

    value_u16 = nvram_read(508);
    value_u16 <<= 8;
    value_u16 |= nvram_read(509);
    value_u32 <<= 8;
    value_u32 |= nvram_read(value_u16 & 0x1FF);

    value_u16 = nvram_read(510);
    value_u16 <<= 8;
    value_u16 |= nvram_read(511);
    value_u32 <<= 8;
    value_u32 |= nvram_read(value_u16 & 0x1FF);
    return value_u32;
}


typedef void(*FUNC)(void);
uint32_t patch_find_entry(uint32_t lr,uint32_t lr1);

extern struct prf_task_cbs *user_prf_itf_get_imp(uint8_t task_id);
extern uint8_t rwip_sleep_mode_check_imp(uint32_t *sleep_duratoin);
extern uint16_t lp_frequency;
extern uint8_t *zi_base, *ke_heap_base, *user_heap_base, *rw_base;


/*
static void reset_ble_core(void)
{
    ble_rwble_en_setf(0);
    ble_master_soft_rst_setf(1);
    while(ble_master_soft_rst_getf());
    ble_master_tgsoft_rst_setf(1);
    while(ble_master_tgsoft_rst_getf());
    ble_reg_soft_rst_setf(1);
    while(ble_reg_soft_rst_getf());
}
*/

void __attribute__((weak)) user_proj_main_before_ble_ini(void)
{
    printf("weak user_proj_main_before_ble_ini\r\n");
}

void __attribute__((weak)) user_proj_main(void)
{
    printf("weak user_proj_main\r\n");

//appm_set_dev_configuration(NULL);
#if MIC_TEST_ENABLE
    test_mic();
#endif

}

/*
static void first_power_on_check(void)
{
//    uint8_t nData;
    system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_A0);
    gpio_set_dir(GPIO_PORT_A, GPIO_BIT_0, GPIO_DIR_OUT);
    gpio_porta_write(gpio_porta_read() & 0xfe);
    co_delay_100us(100);
    gpio_porta_write(gpio_porta_read() | 0x01);
    gpio_set_dir(GPIO_PORT_A, GPIO_BIT_0, GPIO_DIR_IN);
}
*/
/*
ke_msg_func_t ke_task_default_handler_get_imp(ke_msg_id_t const msg_id, ke_task_id_t const task_id, ke_msg_func_t org_func)
{
    if((msg_id & 0xFF00) == (TASK_ID_MESH << 8))
    {
        printf("msg_id: 0x%04x\r\n", msg_id);
    }
    //printf("msg_id: 0x%04x, task_id: 0x%04x.\r\n", msg_id, task_id);
    return org_func;
}

ke_msg_func_t ke_task_state_handler_get_imp(ke_msg_id_t const msg_id, ke_task_id_t const task_id, ke_msg_func_t org_func)
{
    if((msg_id & 0xFF00) == (TASK_ID_MESH << 8))
    {
        printf("msg_id: 0x%04x\r\n", msg_id);
    }
    //printf("msg_id: 0x%04x, task_id: 0x%04x.\r\n", msg_id, task_id);
    return org_func;
}
*/


void user_main_sub(uint8_t index)
{
    if(index == 1)
    {
#ifdef FOR_MESH_CUSTOMER_CODE
        flash_read(((uint32_t)rw_base&0x0FFFFFFF), ((uint32_t)zi_base-(uint32_t)rw_base), rw_base);
#endif
        memset(zi_base,0x0,((uint32_t)ke_heap_base-(uint32_t)zi_base));
        //bootup voltage
        ool_write(0x11,ool_read(0x11) & 0x8f);
        ool_write(0x13,ool_read(0x13) & 0x8f);

        //printf("%02X\r\n",apb2spi_read(0x4F,APB2SPI_TYPE_OOL));
        //      if(apb2spi_read(0x4F,APB2SPI_TYPE_OOL)!=0xC4)       //default is 0x5A
        //      sys_soft_reset();

        struct jump_table_t *jump_table_p = &__jump_table;
        //for trace printf
        if( (jump_table_p->system_option & SYSTEM_OPTION_PRINT_SEL_MSK) == SYSTEM_OPTION_PRINT_SWO )
        {
            system_set_port_mux(GPIO_PORT_C, GPIO_BIT_5, PORTC5_FUNC_SW_DV);   //for SWD log watch
            CoreDebug->DEMCR = 0x01000000;  //enable
        }
        FPB->CTRL = 0x0262;      //disable FPB at the beginning

        //����debug��������jlink��ʱ��������CPU
        //co_delay_100us(10000);

        app_pmu_init();
        //select RC0
        ool_write(0x14, ool_read(0x14) & 0xfe);

        uart2_init( (jump_table_p->bandrate & 0xF0)>>4 );
        volatile struct uart_reg_t * const uart2_reg = (volatile struct uart_reg_t *)UART2_BASE;
        uart2_reg->u3.fcr.data = 0x21;

        app_set_uart_port();
        if(pmu_first_power_on(true))
        {
            //first_power_on_check();
            printf("first power on.\r\n");
        }
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_A1);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_A0);
        ool_write(0x06, (ool_read(0x06) & 0xff)|0x60 );     //0x9f

        memset((uint8_t *)(0x40002000),0x0,0x2000);
        //memset((void *)0x40002000, 0, 8*1024);
        __jump_table.rwip_heap_no_ret_start = user_heap_base;
#if defined(PROJ_MICPHONE_KEYSCAN)
        __jump_table.rwip_heap_no_ret_size = (0x20010000 - (uint32_t)user_heap_base);
#else
        __jump_table.rwip_heap_no_ret_size = (0x20014000 - (uint32_t)user_heap_base);
#endif
        memset(__jump_table.rwip_heap_env_start, 0xFF, __jump_table.rwip_heap_env_size);
        memset(__jump_table.rwip_heap_db_start, 0xFF, __jump_table.rwip_heap_db_size);
        memset(__jump_table.rwip_heap_msg_start, 0xFF, __jump_table.rwip_heap_msg_size);
        memset(__jump_table.rwip_heap_no_ret_start, 0xFF, __jump_table.rwip_heap_no_ret_size);

        memset(__jump_table.rwip_ke_env_start, 0, sizeof(void *) * TASK_MAX);
        /*
                if(__jump_table.system_option & SYSTEM_OPTION_LP_CLK_32768)
                {
                    lp_frequency = 32768;
                }
                else if(__jump_table.system_option & SYSTEM_OPTION_LP_CLK_32K)
                {
                    lp_frequency = 32000;
                }
        */
        appm_init = appm_init_imp;
        user_prf_itf_get = user_prf_itf_get_imp;
        svc_exception_handler = (FUNC)patch_find_entry;

        system_regs->osc_pll_cfg.ext_int_wakeup_en = 1;

        app_user_before_sleep_callback = user_before_sleep;
        app_user_after_sleep_callback = user_after_sleep;//user_after_sleep_new;

        rf_init = rf_init_patch;
        rf_get_param_ready = rf_get_param_ready_patch;
        rwip_sleep_mode_check = rwip_sleep_mode_check_imp;

        low_power_restore_patch = low_power_restore_patch_imp;
        user_gpio_init = user_gpio_patch_imp;
				wdt_stop();
        //ke_task_default_handler_get = ke_task_default_handler_get_imp;
        //ke_task_state_handler_get = ke_task_state_handler_get_imp;
    }

    if(index == 2)
    {
        app_set_uart_port();
        //Re set apb2spi clk, pulse it
        //REG_PL_WR(APB2SPI_BASE+0x410, 2);//4
        app_set_sysclk();
        pmu_enable_isr(PMU_REG_ISR_CALI_EN);
    }

    if(index == 3)
    {
#ifndef PROJ_MICPHONE_KEYSCAN
        chip_voltage_calibration();
#endif
        pmu_disable_isr(PMU_REG_ISR_CALI_EN);
        pmu_clear_isr_state(PMU_REG_CLR_CALI);
        check_charging();
        user_proj_main_before_ble_ini();
        if( reset_aldo_voltage == false )
            ool_write(0x00,0x80);   //ALDO voltage  2.7V  to save power in deepsleep;
    }

    if(index == 4)
    {
        // uart2_init(BAUD_RATE_115200);
#if 0
#include "reg_uart.h"
        uart_param_t param =
        {
            .baud_rate = 115200,
            .uart_idx = 0,
            .data_bit_num = 8,
            .pari = 0,
            .stop_bit = 1,
        };
        uart_init_x(param);
#endif

#ifdef KEEP_SSC_CODE
        NVIC_EnableIRQ(UART1_IRQn); // charge running ,dont enable uart2 isr
        user_ssc_init();
#endif
        set_patch7_func_idx(PATCH7_hci_le_rd_local_p256_public_key_cmd_handler);
        patch_init();

        GLOBAL_INT_START();     //func is realized in the rom. it is valid,stop all isr

        //GLOBAL_INT_DISABLE(); //can't stop svccall
        //NVIC_SetPriority(SVCall_IRQn, 0);
        //void *p = ke_malloc(15,0);
        printf("\r\nFR_SDK,ver:%d.%d",VER_MAIN,VER_SUB);
        if(VER_DBG != 0)
            printf(".%d",VER_DBG);

        printf(", fw_ver:%d,Compile @:%s,%s\r\n",app_boot_get_firmwave_version(),__DATE__,__TIME__);
        printf("reset cause:0x%02X\r\n",sys_get_reset_cause());
        printf("wake_up_key:%x\r\n",sys_get_wkup_key());

        NOW_START();
        //gpio_dbg_init(GPIO_PORT_A,GPIO_BIT_0,PORTA0_FUNC_A0);

#if defined(CFG_SBC) || defined(CFG_ADPCM)
        mic_ini();
#endif
#if defined(CFG_DEC_SBC) || defined(CFG_DEC_ADPCM_MS)
        speaker_ini();
#endif

        ool_write(PMU_REG_PORTB_IE, ool_read(PMU_REG_PORTB_IE) & 0xF0);
        ool_write(PMU_REG_PORTB_OEN, ool_read(PMU_REG_PORTB_OEN) & 0xF0);
        ool_write(PMU_REG_GPIOB_V, ool_read(PMU_REG_GPIOB_V) | 0x0F);

        //sperate mic and rf power source
        //ool_write(0x0b, 0x06);
        //ool_write(0x0b, ool_read(0x0b) | 0x40);
        ool_write(0x0b, ool_read(0x0b) & (~0x40));
        // ool_write(0x0b, ool_read(0x0b) & (~ BIT(6)) );

        ool_write(PMU_REG_SLP_VAL_0, 0x0);
        ool_write(PMU_REG_SLP_VAL_1, 0x0);
        ool_write(PMU_REG_SLP_VAL_2, 0x0);
        ool_write(PMU_REG_SLP_VAL_3, 0x0);

        test_exint();
        ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL) | PMU_REG_GPIO_WK_EN);

        //Flash cs pin status, give it to pmu
        //ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) & 0xF0);
        rwip_prevent_sleep_set(RW_GPIO_INT_ONGOING);
        //printf("reg0:%x\r\n",ool_read(0x0));
//*(uint32_t *)0x50000030 = 0xcccccccc; //enable modem debug port
//system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, 0xf);   //for SWD log watch
//system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, 0xf);   //for SWD log watch

        //printf("onkey:%x,%x,%x\r\n",ool_read(PMU_REG_RTC_SETTINGS),ool_read(PMU_REG_TONKEY),ool_read(0x1d));
//#include "fr_ble_config.h"
        // uint32_t firmware_offset = VECTOR_HANDLER_COUNT*sizeof(uint32_t) + (uint32_t)&((struct jump_table_t *)0)->checkword;
        // printf("%d\r\n",firmware_offset);

        /*
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_A2);
        gpio_set_dir(GPIO_PORT_A,GPIO_BIT_2,GPIO_DIR_OUT);
        system_set_port_pull(2, 1);

        gpio_porta_write( gpio_porta_read()|BIT(2) );
        co_delay_100us(30);
        gpio_porta_write( gpio_porta_read() & ~(BIT(2)) );
        co_delay_100us(30);

        gpio_porta_write( gpio_porta_read()|BIT(2) );
        co_delay_100us(30);
        gpio_porta_write( gpio_porta_read() & ~(BIT(2)) );
        */
        //if(sys_get_reset_cause() != SOFT_RESET)       //default is 0x5A
        //sys_soft_reset();
        //while(1);
        //*(uint32_t *)(0xf1) = 0x44444444;
        //printf("%x\r\n",*(uint32_t *)(0xefffff31));

//*Note*: CANOT use patch function here. interruption is not enable

        //extern uint8_t *ROM1_BASE, *JUMP_TABLE_BASE, *RESET_BASE;
        //printf("image base:%p,%p,%p\r\n",ROM1_BASE,JUMP_TABLE_BASE,RESET_BASE);
        //printf("image base:%p,%p,%p\r\n",zi_base,ke_heap_base,user_heap_base);
    }
}

__attribute__((section("front_stack")))void user_main(uint8_t index)
{
    if(index == 0)
    {
        //put your code here, make sure your code addr is before  0x20002e00
        /*
        uart2_init( BAUD_RATE_115200 );
        app_set_uart_port();
        fputc('x',0);
        fputc('y',0);
        */
        system_set_pclk(__jump_table.system_clk);
        wdt_stop();
        wdt_init(RESET_ACTION,5);
        wdt_start();
        app_boot_load_data((uint8_t *)0x20002e00, 0x2e00+app_boot_get_curr_storage_base(), 0x14000 - 0x2e00);
    }
    else
        user_main_sub(index);
}


#endif //(BLE_APP_PRESENT)

/// @} APP
