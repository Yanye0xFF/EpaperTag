#include "rwip_config.h"
#include "jump_table.h"

//the following four files are used for RWIP_HEAP_ENV_SIZE definiation
#include "llc.h"
#include "l2cc.h"
#include "gattc.h"
#include "gapc.h"
#include "prf.h"
#include "ke_task.h"

#include "uart.h"

// Heap header size is 12 bytes
#define RWIP_HEAP_HEADER             (12 / sizeof(uint32_t))
// ceil(len/sizeof(uint32_t)) + RWIP_HEAP_HEADER
#define RWIP_CALC_HEAP_LEN(len)      ((((len) + (sizeof(uint32_t) - 1)) / sizeof(uint32_t)) + RWIP_HEAP_HEADER)

/// Memory allocated for environment variables
//RWIP_CALC_HEAP_LEN(RWIP_HEAP_ENV_SIZE)
uint32_t rwip_heap_env[RWIP_CALC_HEAP_LEN(RWIP_HEAP_ENV_SIZE)] __attribute__((section("deep_sleep_code")));
#if (BLE_HOST_PRESENT)
/// Memory allocated for Attribute database
uint32_t rwip_heap_db[RWIP_CALC_HEAP_LEN(RWIP_HEAP_DB_SIZE)] __attribute__((section("ke_heap"),zero_init));  //zero_init
#endif // (BLE_HOST_PRESENT)
/// Memory allocated for kernel messages,       RWIP_CALC_HEAP_LEN(RWIP_HEAP_MSG_SIZE)
uint32_t rwip_heap_msg[RWIP_CALC_HEAP_LEN(RWIP_HEAP_MSG_SIZE)] __attribute__((section("deep_sleep_code")));

/// Non Retention memory block
//uint32_t rwip_heap_non_ret[RWIP_CALC_HEAP_LEN(RWIP_HEAP_NON_RET_SIZE)] __attribute__((section("user_heap"), zero_init));

struct prf_task_env prf[BLE_NB_PROFILES];// __attribute__((section("front_stack")));

/// KE TASK element structure
struct ke_task_elem
{
    struct ke_task_desc const * p_desc;
};
struct ke_task_elem task_list[TASK_MAX] __attribute__((section("front_stack")));

//STACK_SIZE
uint32_t stack_space[STACK_SIZE] __attribute__((section("front_stack")));

//char dev_name[] = "FR8010_HID";

extern void user_main(void);
struct jump_table_t _jump_table __attribute__((section("jump_table"))) =
{   
    .reserved_data = 0,
    .entry = (void *)user_main,
    .rwip_heap_env_start = (uint8_t *)rwip_heap_env,
    .rwip_heap_env_size = RWIP_HEAP_ENV_SIZE,
#if (BLE_HOST_PRESENT)
    .rwip_heap_db_start = (uint8_t *)rwip_heap_db,
    .rwip_heap_db_size = RWIP_HEAP_DB_SIZE,
#else
    .rwip_heap_db_start = 0,
    .rwip_heap_db_size = 0,
#endif
    .rwip_heap_msg_start = (uint8_t *)rwip_heap_msg,
    .rwip_heap_msg_size = RWIP_HEAP_MSG_SIZE,

    .rwip_heap_no_ret_start = 0,     //(uint8_t *)rwip_heap_non_ret,
    .rwip_heap_no_ret_size = 0,     //RWIP_HEAP_NON_RET_SIZE,

    .rwip_prf_env_start = (uint32_t *)prf,
    .rwip_ke_env_start = (uint32_t *)task_list,

    .stack_top_address = &stack_space[STACK_SIZE-1],
#if RW_DEBUG_STACK_PROF
    .stack_size = ((STACK_SIZE<<2)),
#endif

#ifndef FIRMWARE_VERSION
#define FIRMWARE_VERSION (0x000000044)
#endif

    .firmware_version = FIRMWARE_VERSION,
    .cp_config[0].cp_dest = 0x900>>2,
                                 .cp_config[0].cp_src = 0x900>>2, //cpy idx addr
                                 .cp_config[0].cp_size = 0x2e00,//0xFF00,       //0x14000-0x900 = 79616, //code size, 0~0x900 is variable in rom
                                 .cp_config[1].cp_dest = (0xFF00 + 0x900)>>2,
                                 .cp_config[1].cp_src = (0xFF00 + 0x900)>>2, //cpy idx addr
                                 .cp_config[1].cp_size = (0),        //0x14000-0x900 = 79616, //code size, 0~0x900 is variable in rom

                                 .GAP_TMR_LIM_ADV_TIMEOUT_VAL = 2000,       //20s for GAP_LIM_DISCOVERABLE
                                 .GAP_TMR_GEN_DISC_SCAN_VAL = 1024,       //1024*10ms = 10.24s
                                 .GAP_TMR_LIM_DISC_SCAN_VAL = 768,       //768 *10ms = 7.68s
                                 .GAP_TMR_PRIV_ADDR_INT_VAL = 0x3A98,
                                 .GAP_TMR_CONN_PARAM_TIMEOUT_VAL = 0x0BB8,
                                 .GAP_TMR_LECB_CONN_TIMEOUT_VAL = 0x0BB8,
                                 .GAP_TMR_LECB_DISCONN_TIMEOUT_VAL = 0x0BB8,
                                 .GAP_MAX_LE_MTU_VAL = 2048,
                                 .GAP_MAX_NAME_SIZE_VAL = 0x20,
                                 .GAP_LE_EVT_MASK_VAL = 0x3F,

                                 .LLM_UTIL_CH_ASSES_DFLT_TIMER_DUR_VAL = 5,
                                 .LLM_CHNL_REASSESS_DFLT_TIMER_DUR_VAL = 8,
                                 .LLM_UTIL_CH_ASSES_DFLT_MIN_THR_VAL = -10,
                                 .LLM_UTIL_CH_ASSES_DFLT_MAX_THR_VAL = 10,
                                 .LLM_UTIL_CH_ASSES_DFLT_NOISE_THR_VAL = -60,

                                 .gpio_button_sel = 0x00000000,
                                 .button_disable_multi_click = 0x0c,
#ifdef FOR_NORDIC_HELMET
                                 .radio_power_down_up = 0x1f600560,  //0x1a700d70,0x1a600560
#else
                                 .radio_power_down_up = 0x1a600560,  //0x1a700d70,0x1a600560
#endif
                                 .diag_port = 0x00000000,//0x85 base counter, 0xa0 interrupt, 0xa4 sync window
                                 .twext = 0,//2500,
                                 .twrm = 0,//625,
                                 .twosc = 0,//2500,
                                 .wakeup_to_poweron_offset = 0,//307,//(1547-704),
#if defined(PROJ_MICPHONE_KEYSCAN)
                                 .wakeup_to_proget = 5, //affect interval from cs_isr done to prog
#else
                                 .wakeup_to_proget = 5, //affect interval from cs_isr done to prog
#endif
                                 .lp_clk_calib_cnt = 60,//affect calibration accuration
                                 .wakeup_to_poweron_rc_cnt = 81,//(0x4f-2+4),//81,,affect sleep_compensate time
                                 .system_work_type = FULLY_HOSTED_PARTITION,
#ifndef CFG_CPU_CLK_SEL
#define CFG_CPU_CLK_SEL (2)
#endif
                                 //ENLARGE POWER: high freq will
                                 .system_clk = CFG_CPU_CLK_SEL,    //[bit1:bit0] 00: 48MHz 01: 24MHz 10: 12MHz
                                 //.bandrate = BAUD_RATE_460800+BAUD_RATE_460800*16,
                                 .bandrate = BAUD_RATE_115200+BAUD_RATE_115200*16,
                                 .onkey_map = 0x00000000,
#ifndef LOG_SWO
#define LOG_SWO (0)
#endif
                                 .system_option = SYSTEM_OPTION_FIX_BAD_CHANNEL
                                 |SYSTEM_OPTION_VECTOR_REMAP
                                 |SYSTEM_OPTION_WAIT_SLEEP_FLAG
#if (LOG_SWO)
                                 |SYSTEM_OPTION_PRINT_SWO
#elif(LOG_SWO == 0)
                                 |SYSTEM_OPTION_PRINT_UART2
#endif
                                 |SYSTEM_OPTION_SLEEP_ENABLE
                                 |SYSTEM_OPTION_DEEP_SLEEP_ENABLE
                                 |SYSTEM_OPTION_LP_CLK_RC
                                 |SYSTEM_OPTION_EXT_WAKEUP_ENABLE,
                                 /*|SYSTEM_OPTION_LP_CLK_32768
                                   |SYSTEM_OPTION_FIX_BAD_CHANNEL
                                   |SYSTEM_OPTION_VECTOR_REMAP
                                   |SYSTEM_OPTION_WAIT_SLEEP_FLAG
                                   |SYSTEM_OPTION_SLEEP_ENABLE
                                   |SYSTEM_OPTION_EXT_WAKEUP_ENABLE
                                   |SYSTEM_OPTION_DEEP_SLEEP_ENABLE
                                   |SYSTEM_OPTION_PRINT_UART1*/

                                 .le_features = 0x1d,
                                 /*GAPC_ENCRYPT_FEAT_MASK |
                                 //GAPC_CONN_PARAM_REQ_FEAT_MASK |
                                 GAPC_EXT_REJECT_IND_FEAT_MASK |
                                 GAPC_SLAVE_FEAT_EXCH_FEAT_MASK |
                                 GAPC_LE_PING_FEAT_MASK,*/       //0xff,

                                 .lowpower_sca = SCA_500PPM,
                                 .conn_max = CFG_MAX_CON,
                                 .prf_max = BLE_NB_PROFILES,
    .addr = {0x0f, 0x19, 0x07, 0x09, 0x17, 0x20},
    .checkword = {0x52, 0x51, 0x51, 0x52},
};



