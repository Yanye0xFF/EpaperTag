/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_SYS_H_
#define USER_SYS_H_

#include <stdint.h>
#include "system.h"
#include "stdbool.h"

#ifndef FLASH_TEST_ENABLE
#define FLASH_TEST_ENABLE 0
#endif

#ifndef HWTIM_TEST_ENABLE
#define HWTIM_TEST_ENABLE 0
#endif
#ifndef I2C_TEST_ENABLE
#define I2C_TEST_ENABLE 0
#endif

void test_exint(void);

#if FLASH_TEST_ENABLE
void test_flash(void);
#endif

#if HWTIM_TEST_ENABLE
void test_timer(void);
#endif
#if I2C_TEST_ENABLE
void test_i2c(uint8_t i2c_channel);
#endif


typedef enum
{
    POWER_ON = 0x5A,
    SOFT_RESET = 0xC4,
    RESET_IN_SLEEP = 0xC3,
} sys_reset_cause_t;
void start_gpio_wk_timer(void);
void stop_gpio_wk_timer(void);
void set_sleep_flag_after_key_release(bool flag);
extern uint8_t exint_task_id;
extern uint8_t sleep_flag_after_key_release;

uint32_t sys_get_wkup_key(void);
void sys_soft_reset(void);
sys_reset_cause_t sys_get_reset_cause(void);
void show_sys_mem_waterwave(void);
void user_set_cpu_clk(uint8_t freq);

void pmu_set_gpio_to_PMU(enum system_port_t port, uint8_t bits);
void pmu_set_gpio_to_CPU(enum system_port_t port, uint8_t bits);
void pmu_set_gpio_input(enum system_port_t port, uint8_t bits, bool flag);
void pmu_set_gpio_output(enum system_port_t port, uint8_t bits, bool flag);
void pmu_set_gpio_pull(enum system_port_t port, uint8_t bits, bool flag);
void pmu_set_gpio_value(enum system_port_t port, uint8_t bits, uint8_t value);

void pmu_ram_write(uint8_t addr,uint8_t data);
uint8_t pmu_ram_read(uint8_t addr);

void chip_voltage_calibration(void);
extern uint8_t vchg_trim_value;
extern uint8_t aldo_trim_value;



#ifndef TIM1_TICK_ENABLE
#define TIM1_TICK_ENABLE 0
#endif

#if TIM1_TICK_ENABLE
void timer1_as_tick_start(void);
uint32_t get_tim1_tick(void);
#define NOW()     get_tim1_tick()
#define NOW_START()     timer1_as_tick_start()
#else
#define NOW()       (0)
#define NOW_START()
#endif

#endif // APP_HT_H_
