#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "user_msg_q.h"


#define MSG_LOG     //printf
#define MSG_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %d \r\n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);

void os_msg_post(uint16_t dest_task_id,os_event_t *evt)
{
    void *tmp_param = NULL;
    tmp_param = ke_msg_alloc(evt->event_id,dest_task_id,evt->src_task_id,evt->param_len);
    MSG_ASSERT( tmp_param != NULL );
    if(evt->param != NULL && evt->param_len != 0)
        memcpy(tmp_param,evt->param,evt->param_len);
    ke_msg_send(tmp_param);
}



