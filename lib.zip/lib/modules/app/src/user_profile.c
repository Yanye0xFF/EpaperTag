#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "rwip_config.h"
#include "gapm_task.h"
#include "gattc_task.h"
#include "attm_db.h"
#include "gattm.h"
#include "ke_mem.h"
#include "prf.h"
#include "prf_utils.h"
#include "prf_types.h"

#include "user_profile.h"
#include "user_task.h"
#include "user_msg_q.h"
#include "user_mem.h"
#include "user_timer.h"

#include "app.h"
#include "user_sys.h"

//For debug log
#include "l2cm.h"



#include "arch.h"
#if (USER_PROFILE_API_ENABLE)

#define USER_PRF_DBG FR_DBG_OFF
#define USER_PRF_LOG FR_LOG(USER_PRF_DBG)


#define USER_PRF_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %d \r\n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);


typedef struct
{
    struct user_prf_task_cbs *prf_cbs;
    user_svc_req_t *req;
    uint16_t prf_id;
    uint16_t task;
    uint16_t start_hdl;
    uint16_t pkt_seq_num;
} user_svc_add_func_t;

static user_svc_add_func_t user_svc_add_func_list[MAX_USER_PRF_NUM];
static uint8_t added_svc_idx = 0;

uint8_t user_get_free_prf_num(void)
{
    uint8_t idx = 0;
    uint8_t num = 0;
    for(; idx<MAX_USER_PRF_NUM; idx++)
    {
        if(user_svc_add_func_list[idx].prf_id == 0)
            num++;
    }
    return num;
}

uint16_t user_get_free_prf_id(void)
{
    uint8_t idx = 0;
    for(; idx<MAX_USER_PRF_NUM; idx++)
    {
        if(user_svc_add_func_list[idx].prf_id == 0)
            return (TASK_ID_USER_START+idx);
    }
    return (TASK_ID_INVALID);
}
//For user to call
prf_err_t user_add_svc_to_list(user_svc_req_t *req,user_svc_cfg_t *cfg_param,struct user_prf_task_cbs *prf_cbs)
{
    uint8_t idx;
    for(idx = 0; idx<MAX_USER_PRF_NUM ; idx++)
    {
        if(user_svc_add_func_list[idx].prf_id == 0x0 )
        {
            user_svc_add_func_list[idx].req = (void *)ke_malloc(sizeof(user_svc_req_t)+sizeof(user_svc_cfg_t),KE_MEM_NON_RETENTION);
            //USER_PRF_ASSERT(user_svc_add_func_list[idx].req != NULL);
            if(user_svc_add_func_list[idx].req == NULL)
                return ERR_NO_MEM;
            memcpy(user_svc_add_func_list[idx].req,req,sizeof(user_svc_req_t));
            memcpy((uint8_t *)(user_svc_add_func_list[idx].req)+sizeof(user_svc_req_t),cfg_param,sizeof(user_svc_cfg_t));

            if(prf_cbs != NULL)
            {
                user_svc_add_func_list[idx].prf_cbs = (struct user_prf_task_cbs *)ke_malloc(sizeof(struct user_prf_task_cbs),KE_MEM_NON_RETENTION);
                if(user_svc_add_func_list[idx].prf_cbs == NULL)
                {
                    ke_free(user_svc_add_func_list[idx].req);
                    return ERR_NO_MEM;
                }

                memcpy( (void *)(user_svc_add_func_list[idx].prf_cbs),(void *)prf_cbs,sizeof(struct user_prf_task_cbs) );
            }
            user_svc_add_func_list[idx].prf_id = req->prf_id;
            added_svc_idx = 0;  //preparation for add to db

            return ERR_OK;
        }
    }
    return ERR_OVER_PRF_MAX_NUM;
}
//For user to call
void user_del_svc_from_list(uint16_t prf_id)
{
    uint8_t idx;
    for(idx = 0; idx<MAX_USER_PRF_NUM ; idx++)
    {
        if( user_svc_add_func_list[idx].prf_id == prf_id )
        {
            if(user_svc_add_func_list[idx].req != NULL)
                ke_free(user_svc_add_func_list[idx].req);
            if(user_svc_add_func_list[idx].prf_cbs != NULL)
                ke_free(user_svc_add_func_list[idx].prf_cbs);
            user_svc_add_func_list[idx].req = NULL;
            user_svc_add_func_list[idx].prf_cbs = NULL;
            user_svc_add_func_list[idx].prf_id = 0;
            break;
        }
    }
}
void user_destroy_all_user_svc_db(void)
{
    struct attm_svc * current_svc = gattm_env.db.svcs;
    struct attm_svc * next_svc;
    struct attm_svc * prev_svc;

    uint16_t svc_task_id = 0;
    uint8_t prf_idx = 0;

    struct prf_task_env *prf = (struct prf_task_env *)__jump_table.rwip_prf_env_start;

    /* browse all database and free all services. */
    while(current_svc != NULL)
    {
        next_svc = current_svc->next;
        svc_task_id = current_svc->svc.task_id;
        if( svc_task_id > TASK_GAPC
            && svc_task_id < (__jump_table.prf_max+TASK_GAPC) )
        {
            prf_idx = svc_task_id -TASK_GAPC-1;
            //make sure it is profile user created
            if( prf[prf_idx].id >=TASK_ID_USER_START && prf[prf_idx].id < TASK_ID_USER_MAX )
            {
                if(prev_svc!= NULL)
                    prev_svc->next = current_svc->next;
                //free current db memory & set next of prev_svc is null
                ke_free(current_svc);
                current_svc = NULL;
            }
        }
        prev_svc = current_svc;
        current_svc = next_svc;
    }

//free all user task mallocs
    for(uint8_t idx = 0 ; idx<BLE_NB_PROFILES ; idx++)
    {
        if( prf[idx].id >=TASK_ID_USER_START && prf[idx].id < TASK_ID_USER_MAX )
        {
            //free prf[..] task_desc
            if(prf[idx].desc.default_handler != NULL)
            {
                ke_free( (void *)(prf[idx].desc.default_handler->msg_table) );
                ke_free( (void *)(prf[idx].desc.default_handler) );
                prf[idx].desc.default_handler = NULL;
            }
            ke_task_msg_flush(KE_TYPE_GET(prf[idx].task));

            //set all prf[..] param to ini
            prf[idx].env    = NULL;
            prf[idx].id = TASK_ID_INVALID;
        }
    }

    // reset all buffed svc list content
    flush_all_user_svc_list();
}


void user_change_svc_uuid(uint8_t prf_id,uint8_t idx,uint8_t *uuid,uint8_t uuid_len)
{
    struct attm_svc * current_svc = gattm_env.db.svcs;
    struct attm_svc * next_svc;
    //struct attm_svc * prev_svc;

    uint16_t svc_task_id = 0;
    uint8_t prf_idx = 0;

    struct prf_task_env *prf = (struct prf_task_env *)__jump_table.rwip_prf_env_start;

    /* browse all database and free all services. */
    while(current_svc != NULL)
    {
        next_svc = current_svc->next;
        svc_task_id = current_svc->svc.task_id;
        if( svc_task_id > TASK_GAPC
            && svc_task_id < (__jump_table.prf_max+TASK_GAPC) )
        {
            prf_idx = svc_task_id -TASK_GAPC-1;

            if( prf[prf_idx].id ==prf_id)
            {
                if(idx == 0)
                {
                    if(uuid_len == ATT_UUID_16_LEN)
                        memcpy(&(current_svc->svc.uuid),uuid,ATT_UUID_16_LEN);
                    else
                    {
                        uint8_t *pos = (uint8_t *)( (uint32_t)(&current_svc->svc) + current_svc->svc.uuid );
                        memcpy(pos,uuid,uuid_len);
                    }
                }
                else if ( (idx-1) < current_svc->svc.nb_att)
                {
                    if(uuid_len == ATT_UUID_16_LEN)
                        memcpy(&(current_svc->atts[idx-1].uuid),uuid,ATT_UUID_16_LEN);
                    else
                    {
                        uint8_t *pos = (uint8_t *)( (uint32_t)(&current_svc->atts[idx-1]) + current_svc->atts[idx-1].uuid );
                        memcpy(pos,uuid,uuid_len);
                    }
                }
            }
        }
        //prev_svc = current_svc;
        current_svc = next_svc;
    }
}


uint16_t user_get_prf_task_num(uint16_t prf_id)
{
    return user_svc_add_func_list[prf_id-TASK_ID_USER_START].task;
}
uint16_t user_get_prf_start_hdl(uint16_t prf_id)
{
    return user_svc_add_func_list[prf_id-TASK_ID_USER_START].start_hdl;
}

/*******************Profile Server functions******************/
void user_profile_reset_pkt_num(uint16_t profile_id)
{
    (user_svc_add_func_list[profile_id-TASK_ID_USER_START].pkt_seq_num) = 0;
}
uint16_t user_profile_get_pkt_num(uint16_t profile_id)
{
    return (user_svc_add_func_list[profile_id-TASK_ID_USER_START].pkt_seq_num-1);
}

void user_profile_send_ntf(uint8_t conidx, struct user_prf_pkt *pkt_param)
{
    struct gattc_send_evt_cmd* send_cmd = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                          KE_BUILD_ID(TASK_GATTC, conidx), user_get_prf_task_num(pkt_param->prf_id),
                                          gattc_send_evt_cmd, pkt_param->packet_size);

    send_cmd->handle = user_get_prf_start_hdl(pkt_param->prf_id) + pkt_param->att_idx;
    send_cmd->operation = pkt_param->op_type;      //GATTC_INDICATE

    send_cmd->seq_num = (user_svc_add_func_list[pkt_param->prf_id-TASK_ID_USER_START].pkt_seq_num)++;

    send_cmd->length = pkt_param->packet_size;
    memcpy(send_cmd->value, pkt_param->packet, send_cmd->length);

    ke_msg_send(send_cmd);
    //ke_free(send_cmd);
}

//For appm_add_svc() to call
bool check_user_svc_list(void)
{
    for(; added_svc_idx<MAX_USER_PRF_NUM; added_svc_idx++)
    {
        if(user_svc_add_func_list[added_svc_idx].req != NULL)
        {
            struct gapm_profile_task_add_cmd *cmd = KE_MSG_ALLOC_DYN(GAPM_PROFILE_TASK_ADD_CMD,
                                                    TASK_GAPM, TASK_APP,
                                                    gapm_profile_task_add_cmd,
                                                    sizeof(user_svc_cfg_t));
            memcpy(cmd,user_svc_add_func_list[added_svc_idx].req,sizeof(user_svc_req_t));

            USER_PRF_LOG("cmd:%d,%d,%d,%x,%d\r\n",cmd->app_task,cmd->operation,cmd->prf_task_id,cmd->sec_lvl,cmd->start_hdl);

            memcpy((uint8_t *)(cmd->param)
                   ,(uint8_t *)(user_svc_add_func_list[added_svc_idx].req)+sizeof(user_svc_req_t)
                   ,sizeof(user_svc_cfg_t));
            ke_msg_send(cmd);

            ke_free(user_svc_add_func_list[added_svc_idx].req);
            user_svc_add_func_list[added_svc_idx].req   = NULL;
            //not free prf_cbs;
            return true;
        }
    }
    return false;
}
/*
void add_alloced_info_to_user_svc(void *param)
{
    struct gapm_profile_added_ind *ind = (struct gapm_profile_added_ind *)param;
    if(ind->prf_task_id >= TASK_ID_USER_START && ind->prf_task_id < TASK_ID_USER_MAX)
    {
        user_svc_add_func_list[ind->prf_task_id-TASK_ID_USER_START].task = ind->prf_task_nb;
        user_svc_add_func_list[ind->prf_task_id-TASK_ID_USER_START].start_hdl = ind->start_hdl;
    }
}
*/
//For reset_compelete() to call
void flush_all_user_svc_list(void)
{
    USER_PRF_LOG("size(add_func_list):%d\r\n",sizeof(user_svc_add_func_list));
    uint8_t idx;
    for(idx = 0; idx<MAX_USER_PRF_NUM ; idx++)
    {
        if(user_svc_add_func_list[idx].req != NULL)
        {
            ke_free(user_svc_add_func_list[idx].req);
            user_svc_add_func_list[idx].req = NULL;
        }
        if(user_svc_add_func_list[idx].prf_cbs != NULL)
        {
            ke_free(user_svc_add_func_list[idx].prf_cbs);
            user_svc_add_func_list[idx].prf_cbs = NULL;
        }
        user_svc_add_func_list[idx].prf_id = 0;
    }
    added_svc_idx = 0;
}




/*******************Profile Client functions******************/
struct prf_client_db_content
{
    struct prf_svc svc;
    struct prf_char_inf *chars;
    struct prf_char_desc_inf *descs;
};
struct prf_client_db
{
    // struct ke_msg * operation;
    struct prf_char_def_uuid128 *chars_req;         //store user wanted char_req & descs_req
    struct prf_char_desc_def_uuid128 *descs_req;
    uint8_t svc_grp_idx;
    uint8_t svc_grp_regested_flag;
    struct prf_client_db_content svc[MAX_PEER_PRF_NUM];   //default set peer 10 svc_group
};
static struct prf_client_db gTestClientDB = {0};

//usage: user_profile_disc_all_svc(user_get_prf_task_num(prf_id),0);
void user_profile_disc_all_svc(ke_task_id_t src_task, uint8_t conidx)
{
    if( user_profile_is_peer_db_valid() )
        goto _exit;
    else
    {
        //send GATT discover primary services by UUID request
        struct gattc_sdp_svc_disc_cmd * svc_req = KE_MSG_ALLOC_DYN(GATTC_SDP_SVC_DISC_CMD,
                KE_BUILD_ID(TASK_GATTC, conidx), src_task,
                gattc_sdp_svc_disc_cmd, ATT_UUID_16_LEN);

        svc_req->operation         = GATTC_SDP_DISC_SVC_ALL;
        svc_req->start_hdl        = ATT_1ST_REQ_START_HDL;
        svc_req->end_hdl          = ATT_1ST_REQ_END_HDL;
        svc_req->seq_num = 0x0;
        svc_req->uuid_len = ATT_UUID_16_LEN;
        co_write16p(&(svc_req->uuid[0]), 0x0);
        ke_msg_send(svc_req);
    }
_exit:
    ;
}
//usage: user_profile_disc_all_svc(user_get_prf_task_num(prf_id),0);
void user_profile_disc_svc(ke_task_id_t src_task, uint8_t conidx, uint8_t uuid_len, uint8_t *uuid)
{
    if( user_profile_is_peer_db_valid() )
        goto _exit;
    else
    {
        //send GATT discover primary services by UUID request
        struct gattc_sdp_svc_disc_cmd * svc_req = KE_MSG_ALLOC_DYN(GATTC_SDP_SVC_DISC_CMD,
                KE_BUILD_ID(TASK_GATTC, conidx), src_task,
                gattc_sdp_svc_disc_cmd, uuid_len);

        svc_req->operation         = GATTC_SDP_DISC_SVC;
        svc_req->start_hdl        = ATT_1ST_REQ_START_HDL;
        svc_req->end_hdl          = ATT_1ST_REQ_END_HDL;
        svc_req->uuid_len = uuid_len;
        memcpy(&(svc_req->uuid[0]), uuid, uuid_len);
        ke_msg_send(svc_req);
    }
_exit:
    ;
}


static void prf_extract_svc_info_uuid128(struct gattc_sdp_svc_ind const * param,
        uint8_t nb_chars, struct prf_char_def_uuid128* chars_req, struct prf_char_inf* chars,
        uint8_t nb_descs, struct prf_char_desc_def_uuid128* descs_req, struct prf_char_desc_inf* descs,
        uint8_t peer_svc_grp_idx)
{
    uint8_t svc_char;
    uint8_t svc_desc;
    uint8_t fnd_att;
    uint8_t temp_for_const_uuid[ATT_UUID_128_LEN];
    uint8_t i;

    for (fnd_att=0; fnd_att< (param->end_hdl - param->start_hdl); fnd_att++)
    {
        if(param->info[fnd_att].att_type == GATTC_SDP_ATT_CHAR)
        {
            uint16_t char_hdl = param->start_hdl+ 1 + fnd_att;
            uint16_t val_hdl  = param->info[fnd_att].att_char.handle;
            uint8_t  val_prop = param->info[fnd_att].att_char.prop;
            uint8_t  char_idx = fnd_att;

            // check that value handle is in a valid range
            if((val_hdl <= param->end_hdl) && (val_hdl > (param->start_hdl + fnd_att)))
            {
                // retrieve value index
                uint8_t val_idx = (val_hdl - param->start_hdl - 1);

                //Look over requested characteristics
                for (svc_char=0; svc_char<nb_chars ; svc_char++)
                {
                    for(i=0; i<chars_req[svc_char].uuid_len; i++)
                        temp_for_const_uuid[i] = chars_req[svc_char].uuid[i];

                    //  show_reg2((uint8_t*)param->info[val_idx].att.uuid,param->info[val_idx].att.uuid_len,1);
                    //  show_reg3(temp_for_const_uuid,chars_req[svc_char].uuid_len,1);
                    //  show_reg3(chars_req[svc_char].uuid,chars_req[svc_char].uuid_len,1);

                    // check if attribute is valid
                    if((chars[svc_char].char_hdl == ATT_INVALID_HDL)
                       && attm_uuid_comp((uint8_t*)param->info[val_idx].att.uuid, param->info[val_idx].att.uuid_len
                                         , temp_for_const_uuid, chars_req[svc_char].uuid_len))
                    {
                        //Save properties and handles
                        chars[svc_char].char_hdl       = char_hdl;
                        chars[svc_char].val_hdl        = val_hdl;
                        chars[svc_char].prop           = val_prop;
                        chars_req[svc_char].peer_svc_grp_idx = peer_svc_grp_idx;

                        // find end of characteristic handle and discover descriptors
                        do
                        {
                            fnd_att++;

                            // found a descriptor
                            if(param->info[fnd_att].att_type == GATTC_SDP_ATT_DESC)
                            {
                                //Retrieve characteristic descriptor handle using UUID
                                for(svc_desc = 0; svc_desc < nb_descs; svc_desc++)
                                {
                                    for(i=0; i<descs_req[svc_desc].uuid_len; i++)
                                    {
                                        temp_for_const_uuid[i] = descs_req[svc_desc].uuid[i];
                                    }
                                    // check if it's expected descriptor
                                    if ((descs[svc_desc].desc_hdl == ATT_INVALID_HANDLE)
                                        && (descs_req[svc_desc].char_code == svc_char)
                                        && (attm_uuid_comp((uint8_t*)param->info[fnd_att].att.uuid,param->info[fnd_att].att.uuid_len
                                                           ,temp_for_const_uuid, descs_req[svc_desc].uuid_len )))
                                    {
                                        descs[svc_desc].desc_hdl = param->start_hdl + 1 + fnd_att;
                                        descs_req[svc_desc].peer_svc_grp_idx = peer_svc_grp_idx;
                                        // search for next descriptor
                                        break;
                                    }
                                }
                            }
                        }
                        while(((param->start_hdl+ 1 + fnd_att) <= param->end_hdl)
                              && (param->info[fnd_att].att_type != GATTC_SDP_ATT_CHAR)
                              && (param->info[fnd_att].att_type != GATTC_SDP_INC_SVC));
                        // return to previous valid value
                        fnd_att--;
                        // previous handle was end of the characteristic
                        chars[svc_char].char_ehdl_off    = fnd_att - char_idx;

                        // search next characteristic
                        break;
                    }
                }
            }
        }
    }
}

void store_peer_prf_info(struct gattc_sdp_svc_ind const *ind, uint8_t nb_chars, void *chars_elem,
                         uint8_t nb_descs, void *descs_elem)
{
    struct prf_char_def_uuid128 * chars_req = (struct prf_char_def_uuid128 *)chars_elem;
    struct prf_char_desc_def_uuid128 *descs_req = (struct prf_char_desc_def_uuid128 *)descs_elem;

    if(gTestClientDB.chars_req == NULL)
        gTestClientDB.chars_req = chars_req;
    if(gTestClientDB.descs_req == NULL)
        gTestClientDB.descs_req = descs_req;

    if(gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars == NULL)
        gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars =
            (struct prf_char_inf *)os_zalloc( sizeof(struct prf_char_inf)*nb_chars, KE_MEM_NON_RETENTION);

    if(gTestClientDB.svc[gTestClientDB.svc_grp_idx].descs == NULL)
        gTestClientDB.svc[gTestClientDB.svc_grp_idx].descs =
            (struct prf_char_desc_inf *)os_zalloc( sizeof(struct prf_char_desc_inf)*nb_descs, KE_MEM_NON_RETENTION);

    USER_PRF_ASSERT(gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars != NULL);
    USER_PRF_ASSERT(gTestClientDB.svc[gTestClientDB.svc_grp_idx].descs != NULL);
    USER_PRF_LOG("svc_grp_idx:%d,%p\r\n",gTestClientDB.svc_grp_idx,gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars);

    prf_extract_svc_info_uuid128(ind, nb_chars, chars_req,
                                 gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars,
                                 nb_descs, descs_req,
                                 gTestClientDB.svc[gTestClientDB.svc_grp_idx].descs,
                                 gTestClientDB.svc_grp_idx);
#if 0
    printf("grp:%d,%p,%p\r\n",gTestClientDB.svc_grp_idx,&gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[0],
           &gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[1]);
    printf("[0]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[0].val_hdl);
    printf("[1]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[1].val_hdl);
    printf("[2]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[2].val_hdl);
    printf("[3]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[3].val_hdl);
    printf("[4]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[4].val_hdl);
    printf("[5]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[5].val_hdl);
    printf("[6]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[6].val_hdl);
    printf("[7]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[7].val_hdl);
    printf("[8]_hdl:%d\r\n",gTestClientDB.svc[gTestClientDB.svc_grp_idx].chars[8].val_hdl);
#endif

    gTestClientDB.svc[gTestClientDB.svc_grp_idx].svc.shdl = ind->start_hdl;
    gTestClientDB.svc[gTestClientDB.svc_grp_idx].svc.ehdl = ind->end_hdl;
    gTestClientDB.svc_grp_idx++;
    USER_PRF_ASSERT( gTestClientDB.svc_grp_idx <= MAX_PEER_PRF_NUM );
}
void regist_peer_prf_info(uint8_t conidx,uint16_t prf_id)
{
    prf_env_t prf_env;
    prf_env.app_task = TASK_APP;
    prf_env.prf_task = user_svc_add_func_list[prf_id - TASK_ID_USER_START].task;
//printf("%d,%d,%d\r\n",test_profile_client_id,gTestClientDB.svc[0].svc.shdl,gTestClientDB.svc[0].svc.ehdl);
    for (uint8_t peer_grp_idx = 0; peer_grp_idx < gTestClientDB.svc_grp_idx; peer_grp_idx++)
    {
        //printf("reg_idx:%d\r\n",peer_grp_idx);
        prf_register_atthdl2gatt(&prf_env, conidx, &gTestClientDB.svc[peer_grp_idx].svc);
        gTestClientDB.svc_grp_regested_flag = 1;
    }
}
uint16_t user_profile_get_handle_from_peer_db(uint8_t type,uint8_t idx)
{
    uint8_t svc_grp_idx;
    uint16_t handle = 0;
    if(type == PRF_CLIENT_CHAR_TYPE)
    {
        svc_grp_idx = gTestClientDB.chars_req[idx].peer_svc_grp_idx;
        if(svc_grp_idx != 0xff)
            handle = gTestClientDB.svc[svc_grp_idx].chars[idx].val_hdl;
    }
    else if(type == PRF_CLIENT_DESC_TYPE)
    {
        svc_grp_idx = gTestClientDB.descs_req[idx].peer_svc_grp_idx;
        if(svc_grp_idx != 0xff)
            handle = gTestClientDB.svc[svc_grp_idx].descs[idx].desc_hdl;
    }
    //printf("svc_grp_idx:%d,handle:%d\r\n",svc_grp_idx,handle);
    return handle;
}

void user_profile_send_value_cmd(uint8_t conidx,struct user_prf_pkt *pkt_param)
{
    prf_env_t prf_env;
    prf_env.app_task = TASK_APP;
    prf_env.prf_task = user_svc_add_func_list[pkt_param->prf_id - TASK_ID_USER_START].task;

    uint16_t handle = user_profile_get_handle_from_peer_db(pkt_param->att_type, pkt_param->att_idx);
    if(handle != ATT_INVALID_HANDLE)
    {
        struct gattc_write_cmd *wr_char = KE_MSG_ALLOC_DYN(GATTC_WRITE_CMD,
                                          KE_BUILD_ID(TASK_GATTC, conidx), prf_src_task_get(&prf_env, conidx),
                                          gattc_write_cmd, pkt_param->packet_size);

        wr_char->seq_num        = (user_svc_add_func_list[pkt_param->prf_id-TASK_ID_USER_START].pkt_seq_num)++;//pkt_param->seq_num;
        wr_char->offset         = 0x0000;
        wr_char->cursor         = 0x0000;
        wr_char->operation       = pkt_param->op_type;
        wr_char->handle         = handle;
        wr_char->length         = pkt_param->packet_size;
        wr_char->auto_execute   = true;
        memcpy(&wr_char->value[0], pkt_param->packet, pkt_param->packet_size);
        ke_msg_send(wr_char);
    }
}

void user_profile_read_value_cmd(uint8_t conidx,uint8_t type, uint8_t idx,uint8_t prf_id)
{
    prf_env_t prf_env;
    prf_env.app_task = TASK_APP;
    prf_env.prf_task = user_svc_add_func_list[prf_id - TASK_ID_USER_START].task;

    uint8_t svc_grp_idx;
    if(type == PRF_CLIENT_CHAR_TYPE)
        svc_grp_idx = gTestClientDB.chars_req->peer_svc_grp_idx;
    else if(type == PRF_CLIENT_DESC_TYPE)
        svc_grp_idx = gTestClientDB.descs_req->peer_svc_grp_idx;

    uint16_t handle = user_profile_get_handle_from_peer_db(type, idx);
    prf_read_char_send( &prf_env, conidx,
                        gTestClientDB.svc[svc_grp_idx].svc.shdl,
                        gTestClientDB.svc[svc_grp_idx].svc.ehdl,  handle);
}
void user_profile_clr_peer_db(void)
{
    gTestClientDB.chars_req = NULL;
    gTestClientDB.descs_req = NULL;

    for(uint8_t grp_idx = 0; grp_idx < gTestClientDB.svc_grp_idx; grp_idx++)
    {
        if( gTestClientDB.svc[grp_idx].chars != NULL )
        {
            os_free(gTestClientDB.svc[grp_idx].chars);
            gTestClientDB.svc[grp_idx].chars = NULL;
        }

        if( gTestClientDB.svc[grp_idx].descs != NULL )
        {
            os_free(gTestClientDB.svc[grp_idx].descs);
            gTestClientDB.svc[grp_idx].descs = NULL;
        }

    }
    gTestClientDB.svc_grp_idx = 0;
    gTestClientDB.svc_grp_regested_flag = 0;
}

uint8_t user_profile_is_peer_db_valid(void)
{
    return gTestClientDB.svc_grp_regested_flag ;
}
uint8_t user_profile_get_peer_svc_grp_num(void)
{
    return gTestClientDB.svc_grp_idx ;
}


/*******************COMMON functions******************/
static uint8_t default_profile_init(struct prf_task_env* env, uint16_t *start_hdl, uint16_t app_task, uint8_t sec_lvl,  void* params)
{
    user_svc_cfg_t *cfg = (user_svc_cfg_t *)params;

    uint8_t status = ATT_ERR_NO_ERROR;
    uint16_t req_prf_id = *(uint16_t *)(start_hdl - 2);

    USER_PRF_LOG("default init:%x,%d,%p | %d,%d,%d \r\n",cfg->svc_uuid,cfg->svc_att_nb,cfg->svc_att_db
                 ,req_prf_id,*start_hdl,app_task);

    if(cfg->svc_att_db != NULL)     //for client
    {
        if(cfg->db_ext_uuid128 == NULL)
            status = attm_svc_create_db(start_hdl, cfg->svc_uuid, NULL,
                                        cfg->svc_att_nb, NULL, env->task, cfg->svc_att_db,
                                        (sec_lvl & (PERM_MASK_SVC_DIS | PERM_MASK_SVC_AUTH | PERM_MASK_SVC_EKS)) | PERM(SVC_MI, DISABLE));
#ifndef PROJ_MICPHONE_KEYSCAN       // to save code space
        else
            status = attm_svc_create_db_ext(start_hdl, cfg->svc_uuid, NULL,
                                            cfg->svc_att_nb, NULL, env->task, cfg->svc_att_db,
                                            (sec_lvl & (PERM_MASK_SVC_UUID_LEN | PERM_MASK_SVC_DIS | PERM_MASK_SVC_AUTH | PERM_MASK_SVC_EKS)) | PERM(SVC_MI, DISABLE)
                                            ,cfg->db_ext_uuid128);
        USER_PRF_LOG("sec_lvl:%x\r\n",(sec_lvl & (PERM_MASK_SVC_UUID_LEN | PERM_MASK_SVC_DIS | PERM_MASK_SVC_AUTH | PERM_MASK_SVC_EKS)) | PERM(SVC_MI, DISABLE));
#endif
    }

    if (status == ATT_ERR_NO_ERROR)
    {
        struct os_state_handler *tmp_state_hdl = from_task_func_to_state_handle((os_task_func_t)(cfg->svc_db_func));
        USER_PRF_ASSERT(tmp_state_hdl != NULL)

        env->env = NULL;
        env->id                     = req_prf_id;
        env->desc.state_handler     = NULL;
        env->desc.idx_max           = 1;
        env->desc.state_max         = 1;
        env->desc.state             = NULL;
        env->desc.default_handler   = (const struct ke_state_handler *)tmp_state_hdl;

        //printf("req_prf_id:%d\r\n",req_prf_id);

        user_svc_add_func_list[req_prf_id-TASK_ID_USER_START].task = env->task;
        user_svc_add_func_list[req_prf_id-TASK_ID_USER_START].start_hdl = *start_hdl;

        if(user_svc_add_func_list[req_prf_id-TASK_ID_USER_START].prf_cbs != NULL)
        {
            if( user_svc_add_func_list[req_prf_id-TASK_ID_USER_START].prf_cbs->init != NULL)
                user_svc_add_func_list[req_prf_id-TASK_ID_USER_START].prf_cbs->init();
        }
    }
    else
    {
        printf("cdb fail(hl code):0x%x\r\n",status);
        USER_PRF_ASSERT(status == ATT_ERR_NO_ERROR);
    }
    return (status);
}

static void default_profile_destroy(struct prf_task_env* env)
{
    USER_PRF_LOG("default destroy1\r\n");

    if(env->desc.default_handler != NULL)
    {
        ke_free((void *)env->desc.default_handler->msg_table);
        ke_free((void *)env->desc.default_handler);
    }

    if(user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs != NULL)
    {
        if( user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->destroy != NULL)
            user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->destroy();
    }

}
static void default_profile_create(struct prf_task_env* env, uint8_t conidx)
{
    USER_PRF_LOG("default create1\r\n");

    user_svc_add_func_list[env->id-TASK_ID_USER_START].pkt_seq_num = 0;

    if(user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs != NULL)
    {
        if( user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->create != NULL)
            user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->create(conidx);
    }

}
static void default_profile_cleanup(struct prf_task_env* env, uint8_t conidx, uint8_t reason)
{
    USER_PRF_LOG("default cleanup1\r\n");

    if(user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs != NULL)
    {
        if( user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->cleanup != NULL)
            user_svc_add_func_list[env->id-TASK_ID_USER_START].prf_cbs->cleanup(conidx, reason);
    }
}
static struct prf_task_cbs default_profile_cbs =
{
    (prf_init_fnct) default_profile_init,
    default_profile_destroy,
    default_profile_create,
    default_profile_cleanup,
};
//for get_user_if() to call
struct prf_task_cbs* get_user_profile_default_itf(void)
{
    return &default_profile_cbs;
}







#if (PROFILE_TEST_ENABLE)

enum
{
    TEST_IDX_SVC,

    TEST_IDX_NTF_CHAR,
    TEST_IDX_NTF_VALUE,
    TEST_IDX_NTF_CFG,
    TEST_IDX_NTF_USER_DESC,

    TEST_IDX_TX_CHAR,
    TEST_IDX_TX_VALUE,

    TEST_IDX_RX_CHAR,
    TEST_IDX_RX_VALUE,

    TEST_IDX_NB,
};

uint8_t test_db_uuids[] =
{
    0xb7, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVICE_UUID
    0xb8, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVER_TX_UUID
    0xba, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVER_RX_UUID
    0xb9, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07  //SPS_FLOW_CTRL_UUID
};
struct attm_desc test_att_db[TEST_IDX_NB] =
{
    // Update Over The AIR Service Declaration
    [TEST_IDX_SVC]                          =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    // Notify Characteristic Declaration            13
    [TEST_IDX_NTF_CHAR]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, TEST_IDX_NTF_VALUE},
    // Notify Characteristic Value                  14
    [TEST_IDX_NTF_VALUE]                    =   {ATT_UUID_16(0xF002), PERM(RD, ENABLE)|PERM(NTF, ENABLE), PERM(RI, ENABLE), 300},             //PERM(IND, ENABLE)
    // Notify Characteristic - Client Char. Configuration Descriptor    15      fixed  2byte ATT_DESC_SERVER_CHAR_CFG
    [TEST_IDX_NTF_CFG]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor      16
    [TEST_IDX_NTF_USER_DESC]                =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0xC},

    // Tx Characteristic Declaration
    [TEST_IDX_TX_CHAR]                      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, TEST_IDX_TX_VALUE},
    // Tx Characteristic Value          18
    [TEST_IDX_TX_VALUE]                     =   {ATT_UUID_16(0xF000), PERM(RD, ENABLE), PERM(RI, ENABLE) | PERM_VAL(UUID_LEN, PERM_UUID_128), 300},     // | PERM(WRITE_COMMAND, ENABLE)

    // Rx Characteristic Declaration
    [TEST_IDX_RX_CHAR]                      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, TEST_IDX_RX_VALUE},
    // Rx Characteristic Value          20
    [TEST_IDX_RX_VALUE]                     =   {ATT_UUID_16(0xF001), PERM(WRITE_REQ, ENABLE), PERM(RI, ENABLE), 300},
};
static uint8_t test_profile_conidx1 = 0;
static uint16_t test_profile_id = 0;
uint8_t tmp[300];
uint32_t last_now_tick = 0;
uint32_t recv_test_len = 0;

static int test_profile_task_func(os_event_t *msg)
{
    printf("tst_prf_task[%d]:%x\r\n",KE_IDX_GET(msg->src_task_id),msg->event_id);
    switch(msg->event_id)
    {
        //before write, ask peer max receving length.
        case GATTC_ATT_INFO_REQ_IND:    //0xc17
        {
            struct gattc_att_info_req_ind *param = (struct gattc_att_info_req_ind *)msg->param;

            struct gattc_att_info_cfm cfm;
            cfm.handle = param->handle;
            switch(param->handle - user_get_prf_start_hdl(test_profile_id) )
            {
                case TEST_IDX_NTF_CFG:
                    cfm.length = 2;
                    cfm.status = ATT_ERR_NO_ERROR;
                    break;
                case TEST_IDX_NTF_USER_DESC:
                    cfm.length = 0xC;
                    cfm.status = ATT_ERR_NO_ERROR;
                    break;
                case TEST_IDX_RX_VALUE:
                    cfm.length = 300;
                    cfm.status = ATT_ERR_NO_ERROR;
                    break;
                default:
                    cfm.length = 0;
                    cfm.status = ATT_ERR_WRITE_NOT_PERMITTED;
                    break;
            }
            os_event_t evt;
            evt.event_id = GATTC_ATT_INFO_CFM;
            evt.src_task_id = user_get_prf_task_num(test_profile_id);
            evt.param = &cfm;
            evt.param_len = sizeof(struct gattc_att_info_cfm);
            os_msg_post(msg->src_task_id,&evt);

            printf("ATT_INFO_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(test_profile_id));

        }
        break;
        case GATTC_WRITE_REQ_IND:   //0xc15
        {
            struct gattc_write_req_ind *param = (struct gattc_write_req_ind *)msg->param;
            recv_test_len += param->length;

            struct gattc_write_cfm cfm;
            cfm.handle = param->handle;
            cfm.status = ATT_ERR_NO_ERROR;

            os_event_t evt;
            evt.event_id = GATTC_WRITE_CFM;
            evt.src_task_id = user_get_prf_task_num(test_profile_id);
            evt.param = &cfm;
            evt.param_len = sizeof(struct gattc_write_cfm);
            os_msg_post(msg->src_task_id,&evt);

            //printf("WRITE_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(test_profile_id));
            //show_reg2(param->value,param->length,1);
            printf("[%d]tot:%d\r\n",NOW(),recv_test_len);
            //user_get_prf_start_hdl(test_profile_id) + TEST_IDX_RX_VALUE;

            struct gapc_conn_param conn_param;
            conn_param.intv_min = 6;
            conn_param.intv_max = 6;
            conn_param.latency  = 99;
            conn_param.time_out = 1000;
            appm_update_param(KE_IDX_GET(msg->src_task_id), &conn_param);
            appm_exc_mtu_cmd(KE_IDX_GET(msg->src_task_id));

        }
        break;
        case GATTC_READ_REQ_IND:    //0xc13
        {
            struct gattc_read_req_ind *param = (struct gattc_read_req_ind *)msg->param;
            struct gattc_read_cfm* cfm = (struct gattc_read_cfm*)ke_malloc(sizeof(struct gattc_read_cfm)+sizeof(uint16_t)
                                         ,KE_MEM_NON_RETENTION);
            cfm->handle = param->handle;
            cfm->status = 0x00;
            cfm->length = sizeof(uint16_t);
            uint16_t tmp_value;
            if( (param->handle - user_get_prf_start_hdl(test_profile_id)) == TEST_IDX_NTF_CFG )
                tmp_value =  PRF_CLI_START_NTF; //PRF_CLI_STOP_NTFIND;
            else if( (param->handle - user_get_prf_start_hdl(test_profile_id)) == TEST_IDX_TX_VALUE )
                tmp_value = 0x1122;
            else
                tmp_value = 0x3344;

            memcpy(cfm->value, &tmp_value, sizeof(uint16_t));
            printf("%x,%x\r\n",cfm->value[0],cfm->value[1]);

            os_event_t evt;
            evt.event_id = GATTC_READ_CFM;
            evt.src_task_id = user_get_prf_task_num(test_profile_id);
            evt.param = cfm;
            evt.param_len = sizeof(struct gattc_read_cfm)+sizeof(uint16_t);
            os_msg_post(msg->src_task_id,&evt);

            ke_free(cfm);
            printf("READ_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(test_profile_id));

        }
        break;
        case GATTC_CMP_EVT:     //0xc00, only for NTF or INTF
        {
            struct gattc_cmp_evt *param = (struct gattc_cmp_evt *)msg->param;
            switch(param->operation)
            {
                case GATTC_NOTIFY:

                    // printf("[%d]NTF done[%d],",NOW()-last_now_tick,l2cm_get_nb_buffer_available());
                    // last_now_tick = NOW();

                    if(param->seq_num<(293-1))        //293
                    {
                        struct user_prf_pkt pkt_param;
                        pkt_param.att_idx = TEST_IDX_NTF_VALUE;
                        pkt_param.op_type = GATTC_NOTIFY;
                        pkt_param.prf_id = test_profile_id;
                        pkt_param.packet = tmp;
                        pkt_param.packet_size = gattc_get_mtu(0) -3;     //244
                        user_profile_send_ntf(KE_IDX_GET(msg->src_task_id),&pkt_param);
                    }
                    else
                    {
                        printf("[%d]NTF done[%d],",NOW()-last_now_tick,l2cm_get_nb_buffer_available());
                        last_now_tick = NOW();
                    }
                    break;
                case GATTC_INDICATE:
                    printf("IND done,");
                    break;
                default:
                    break;
            }
            //printf("%x,%d\r\n",param->status,param->seq_num);
        }
        break;
        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}

void init1(void)
{
    uint8_t temp[] = "test_prf";
    uint8_t status = attmdb_att_set_value(TEST_IDX_NTF_USER_DESC + user_get_prf_start_hdl(test_profile_id), sizeof(temp), 0, temp);
    printf("init1:%x,%d\r\n",status,TEST_IDX_NTF_USER_DESC + user_get_prf_start_hdl(test_profile_id));
}
void destroy1(void)
{
    printf("destroy1\r\n");
}
void create1(uint8_t conidx)
{
    printf("create1\r\n");
    test_profile_conidx1 = conidx;

}
void cleanup1(uint8_t conidx, uint8_t reason)
{
    printf("cleanup1\r\n");
    recv_test_len = 0;
}

void test_profile_send_ntf(void)
{
    struct user_prf_pkt pkt_param;
    pkt_param.att_idx = TEST_IDX_NTF_VALUE;
    pkt_param.op_type = GATTC_NOTIFY;  //  GATTC_NOTIFY / GATTC_INDICATE
    pkt_param.prf_id = test_profile_id;

    for(uint16_t idx = 0; idx<300; idx++)
        tmp[idx] = (idx&0x7f);
    //printf("[%d]tx_start[%d]\r\n",NOW() - last_now_tick,gattc_get_mtu(0) );
    last_now_tick = NOW();

    pkt_param.packet = tmp;
    user_profile_reset_pkt_num(test_profile_id);
    pkt_param.packet_size = gattc_get_mtu(0) - 3;//sizeof(tmp);     //251 - 7  one slot
    user_profile_send_ntf(test_profile_conidx1,&pkt_param);
}

//when device is ready ,call this, then call add_svc
void test_profile(void)
{
    user_svc_req_t req;
    req.app_task = TASK_APP;
    req.prf_id = user_get_free_prf_id();
    req.operation   = GAPM_PROFILE_TASK_ADD;
    req.sec_lvl     = PERM(SVC_AUTH, ENABLE) | PERM_VAL(SVC_UUID_LEN, PERM_UUID_128);
    req.start_hdl   = 0;

    user_svc_cfg_t cfg;
    cfg.svc_uuid = ATT_UUID_16(0xF0FF);
    cfg.svc_att_db = test_att_db;
    cfg.svc_att_nb = TEST_IDX_NB;
    cfg.svc_db_func = test_profile_task_func;
    cfg.db_ext_uuid128 = test_db_uuids;

    struct user_prf_task_cbs prf_cbs;
    prf_cbs.init = init1;
    prf_cbs.destroy = destroy1;
    prf_cbs.create = NULL;
    prf_cbs.cleanup = NULL;

    printf("before_add_svc:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());

    user_add_svc_to_list(&req,&cfg,&prf_cbs);

    printf("after_add_svc:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());
    user_del_svc_from_list(req.prf_id);

    printf("after_del_svc:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());

    prf_cbs.create = create1;
    prf_cbs.cleanup = cleanup1;
    if(user_add_svc_to_list(&req,&cfg,&prf_cbs) == ERR_OK)
        test_profile_id = req.prf_id;

    printf("after_re_add_svc:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());

}





/******************Below is for profile client test*****************************/
enum test_client_char_idx
{
    CHAR_IDX1,      //18
    CHAR_IDX2,      //27
    CHAR_IDX3,      //33
    CHAR_IDX4,      //51
    CHAR_IDX5,      //53
    CHAR_IDX6,      //56
    CHAR_IDX7,      //60
    CHAR_IDX8,      //62
    CHAR_IDX9,      //65
    CHAR_MAX,
};
struct prf_char_def_uuid128 test_client_elem_char[CHAR_MAX] =
{
    [CHAR_IDX1]  =      //18
    { ATT_UUID_16_LEN,ATT_UUID_ARRAY(0x0001),     ATT_MANDATORY,0,0xff},
    [CHAR_IDX2]  =      //27
    { ATT_UUID_16_LEN,ATT_UUID_ARRAY(0x0010),     ATT_MANDATORY,0,0xff},
    [CHAR_IDX3]  =      //33
    { ATT_UUID_16_LEN,ATT_UUID_ARRAY(0x1001),     ATT_MANDATORY,0,0xff},
    [CHAR_IDX4]  =      //51
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a00), ATT_MANDATORY,0,0xff},
    [CHAR_IDX5]  =      //53
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a01), ATT_MANDATORY,0,0xff},
    [CHAR_IDX6]  =      //56
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a02), ATT_MANDATORY,0,0xff},
    [CHAR_IDX7]  =      //60
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a11), ATT_MANDATORY,0,0xff},
    [CHAR_IDX8]  =      //62
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a10), ATT_MANDATORY,0,0xff},
    [CHAR_IDX9]  =      //65
    { ATT_UUID_128_LEN,ATT_UUID128_ARRAY(0x1a12), ATT_MANDATORY,0,0xff},
};
enum test_client_desc_idx
{
    DESC_IDX1,      //19
    DESC_IDX2,      //54
    DESC_IDX3,      //63
    DESC_MAX,
};
struct prf_char_desc_def_uuid128 test_client_elem_desc[DESC_MAX] =
{
    [DESC_IDX1]   = {ATT_UUID_16_LEN, ATT_UUID_ARRAY(ATT_DESC_CLIENT_CHAR_CFG), ATT_OPTIONAL, CHAR_IDX1,0xff},     //19
    [DESC_IDX2]   = {ATT_UUID_16_LEN, ATT_UUID_ARRAY(ATT_DESC_CLIENT_CHAR_CFG), ATT_OPTIONAL, CHAR_IDX5,0xff},     //54
    [DESC_IDX3]   = {ATT_UUID_16_LEN, ATT_UUID_ARRAY(ATT_DESC_CLIENT_CHAR_CFG), ATT_OPTIONAL, CHAR_IDX8,0xff},     //63
};
static uint8_t test_profile_conidx2 = 0;
static uint16_t test_profile_client_id = 0;
static uint8_t registed_num = 0;
os_timer_t led_timer;
static void led_time_out_hdl(void *arg)
{
    uint8_t data[2];
    data[0]=0x00;
    data[1] = 0x00;
    struct user_prf_pkt pkt_param;
    pkt_param.att_idx = DESC_IDX2;
    pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
    pkt_param.op_type = GATTC_WRITE;
    pkt_param.prf_id = test_profile_client_id;
    pkt_param.packet = data;
    pkt_param.packet_size = 2;
    user_profile_send_value_cmd(test_profile_conidx2,&pkt_param);

    data[0]=0xfd;
    data[1] = 0xff;
    pkt_param.att_idx = CHAR_IDX4;
    pkt_param.att_type = PRF_CLIENT_CHAR_TYPE;
    pkt_param.packet_size = 2;
    user_profile_send_value_cmd(test_profile_conidx2,&pkt_param);
}
void start_flower_care_protocol(void)
{
    uint8_t data[20];
    data[0]=0x90;
    data[1] = 0xca;
    data[2]=0x85;
    data[3] = 0xde;
    struct user_prf_pkt pkt_param;
    pkt_param.att_idx = CHAR_IDX2;          //27
    pkt_param.att_type = PRF_CLIENT_CHAR_TYPE;
    pkt_param.op_type = GATTC_WRITE;
    pkt_param.prf_id = test_profile_client_id;
    pkt_param.packet = data;
    pkt_param.packet_size = 4;
    user_profile_send_value_cmd(test_profile_conidx2,&pkt_param);

    data[0]=0x01;
    data[1] = 0x00;
    pkt_param.att_idx = DESC_IDX1;          //19
    pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
    pkt_param.packet_size = 2;
    user_profile_send_value_cmd(test_profile_conidx2,&pkt_param);

    data[0]=0xa6;
    data[1] = 0xaa;
    data[2]=0xcd;
    data[3] = 0x8c;
    data[4]=0x9e;
    data[5] = 0xd9;
    data[6]=0x49;
    data[7] = 0x0b;
    data[8]=0x7c;
    data[9] = 0xff;
    data[10]=0x3e;
    data[11] = 0xa6;
    pkt_param.att_idx = CHAR_IDX1;              //18
    pkt_param.att_type = PRF_CLIENT_CHAR_TYPE;
    pkt_param.packet_size = 12;
    user_profile_send_value_cmd(test_profile_conidx2,&pkt_param);

    os_timer_setfn(&led_timer,led_time_out_hdl,NULL);
    os_timer_arm(&led_timer,5000,1);
}
static int test_profile_client_task_func(os_event_t *msg)
{
    printf("CCC:%x\r\n",msg->event_id);
    switch(msg->event_id)
    {
        case GATTC_READ_IND:    //0xc09
        {
            struct gattc_read_ind  *param = (struct gattc_read_ind  *)msg->param;
            printf("read_hdl:%d,%d\r\n",param->handle,user_profile_get_handle_from_peer_db(PRF_CLIENT_CHAR_TYPE,CHAR_IDX5));
            // show_reg2(param->value,param->length,1);
            if( param->handle == user_profile_get_handle_from_peer_db(PRF_CLIENT_CHAR_TYPE,CHAR_IDX5) )
            {
                printf("pls read\r\n");
                user_profile_read_value_cmd(KE_IDX_GET(msg->src_task_id),PRF_CLIENT_CHAR_TYPE,CHAR_IDX6,test_profile_client_id);
            }
            else if( param->handle == user_profile_get_handle_from_peer_db(PRF_CLIENT_CHAR_TYPE,CHAR_IDX6) )
            {
                ;
            }
        }
        break;
        case GATTC_SDP_SVC_IND:   //0xC1A
        {
            store_peer_prf_info(msg->param, CHAR_MAX, test_client_elem_char, DESC_MAX,test_client_elem_desc);
        }
        break;
        case GATTC_EVENT_IND:    //0xC0C
        {
            struct gattc_event_ind *param = (struct gattc_event_ind *)msg->param;
            printf("evt_hdl:%d\r\n",param->handle);
            // show_reg2(param->value,param->length,1);
            if ( param->handle == user_profile_get_handle_from_peer_db(PRF_CLIENT_CHAR_TYPE,CHAR_IDX1) )
            {
                uint8_t data[20];
                data[0] = 0xa8;
                data[1] = 0x03;
                data[2] = 0xd6;
                data[3] = 0xde;
                struct user_prf_pkt pkt_param;
                pkt_param.att_idx = CHAR_IDX1;
                pkt_param.att_type = PRF_CLIENT_CHAR_TYPE;
                pkt_param.op_type = GATTC_WRITE;
                pkt_param.prf_id = test_profile_client_id;
                pkt_param.packet = data;
                pkt_param.packet_size = 4;
                user_profile_send_value_cmd(KE_IDX_GET(msg->src_task_id),&pkt_param);

                data[0] = 0x00;
                data[1] = 0x00;
                pkt_param.att_idx = DESC_IDX1;
                pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
                pkt_param.packet_size = 2;
                user_profile_send_value_cmd(KE_IDX_GET(msg->src_task_id),&pkt_param);

                data[0] = 0x01;
                data[1] = 0x00;
                pkt_param.att_idx = DESC_IDX2;
                pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
                pkt_param.packet_size = 2;
                user_profile_send_value_cmd(KE_IDX_GET(msg->src_task_id),&pkt_param);

                data[0] = 0xb0;
                data[1] = 0xff;
                pkt_param.att_idx = CHAR_IDX4;
                pkt_param.att_type = PRF_CLIENT_CHAR_TYPE;
                pkt_param.packet_size = 2;
                user_profile_send_value_cmd(KE_IDX_GET(msg->src_task_id),&pkt_param);

                user_profile_read_value_cmd(KE_IDX_GET(msg->src_task_id),PRF_CLIENT_CHAR_TYPE,CHAR_IDX5,test_profile_client_id);
            }
        }
        break;
        case GATTC_CMP_EVT:     //0xC00
        {
            struct gattc_cmp_evt *param = (struct gattc_cmp_evt *)msg->param;
            switch(param->operation)
            {
                case GATTC_SDP_DISC_SVC_ALL:
                    printf("Disc all svc done:%d\r\n",gTestClientDB.svc_grp_idx);       //gTestClientDB.svc_grp_idx
                    regist_peer_prf_info(KE_IDX_GET(msg->src_task_id),test_profile_client_id);
                    break;
                case GATTC_REGISTER:
                    printf("Client prf reg done\r\n");
                    registed_num++;
                    if(registed_num >= user_profile_get_peer_svc_grp_num())
                    {
                        printf("Regist done,enable ntf\r\n");
                        uint16_t data = PRF_CLI_START_NTF;
                        struct user_prf_pkt pkt_param;
                        pkt_param.att_idx = DESC_IDX1;
                        pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
                        pkt_param.op_type = GATTC_WRITE;
                        pkt_param.prf_id = test_profile_client_id;
                        pkt_param.packet = (void *)&data;
                        pkt_param.packet_size = sizeof(data);
                        user_profile_send_value_cmd(KE_IDX_GET(msg->src_task_id),&pkt_param);
                        start_flower_care_protocol();
                    }

                    break;
                default:
                    break;
            }
            printf("cmp_evt,status:%x,seqnum:%d\r\n",param->status,param->seq_num);
        }
        break;
        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}

static void init2(void)
{
    printf("init2\r\n");
}
static void destroy2(void)
{
    printf("destroy2\r\n");
}
static void create2(uint8_t conidx)
{
    test_profile_conidx2 = conidx;
    registed_num = 0;
    printf("create2\r\n");
}
static void cleanup2(uint8_t conidx, uint8_t reason)
{
    printf("cleanup2:%d,reason(ll code):0x%X\r\n",conidx,reason);
    os_timer_disarm(&led_timer);
    //user_profile_clr_peer_db();
}



void test_profile_client_disc_all_svc(void)
{
    user_profile_disc_all_svc(user_get_prf_task_num(test_profile_client_id), test_profile_conidx2);
}


//when device is ready ,call this, then call add_svc
void test_profile_client(void)
{
    user_svc_req_t req;
    req.app_task = TASK_APP;
    req.prf_id = user_get_free_prf_id();
    req.operation   = GAPM_PROFILE_TASK_ADD;
    req.sec_lvl     = 0;
    req.start_hdl   = 0;

    user_svc_cfg_t cfg;
    cfg.svc_uuid = 0;
    cfg.svc_att_db = NULL;
    cfg.svc_att_nb = 0;
    cfg.svc_db_func = test_profile_client_task_func;
    cfg.db_ext_uuid128 = NULL;

    struct user_prf_task_cbs prf_cbs;
    prf_cbs.init = init2;
    prf_cbs.destroy = destroy2;
    prf_cbs.create = create2;
    prf_cbs.cleanup = cleanup2;

    printf("before_add_prf_client:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());

    user_add_svc_to_list(&req,&cfg,&prf_cbs);

    printf("after_add_prf_client:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());
    user_del_svc_from_list(req.prf_id);

    printf("after_del_prf_client:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());

    prf_cbs.init = NULL;
    prf_cbs.destroy = NULL;
    if(user_add_svc_to_list(&req,&cfg,&prf_cbs) == ERR_OK)
        test_profile_client_id = req.prf_id;

    printf("after_re_add_prf_client:\r\n");
    printf("free_prf_num:%d,nxt_free_prf_id:%d\r\n",user_get_free_prf_num(),user_get_free_prf_id());
}

#endif          //end of #if PROFILE_TEST_ENABLE




#endif          // end of #if USER_PROFILE_API_ENABLE




