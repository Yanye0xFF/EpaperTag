/**
 ****************************************************************************************
 *
 * @file app_sec.c
 *
 * @brief Application Security Entry Point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"



#include <string.h>
#include "co_math.h"
#include "gapc_task.h"      // GAP Controller Task API Definition
#include "gapm_task.h"
#include "gap.h"            // GAP Definition
#include "gapc.h"           // GAPC Definition
#include "prf_types.h"

#include "app.h"            // Application API Definition
#include "app_sec.h"        // Application Security API Definition
#include "app_task.h"       // Application Manager API Definition

#if (DISPLAY_SUPPORT)
#include "app_display.h"    // Display Application Definitions
#endif //(DISPLAY_SUPPORT)

#if (NVDS_SUPPORT)
#include "nvds.h"           // NVDS API Definitions
#endif //(NVDS_SUPPORT)
#include "app_proj_event.h"

#if (BLE_APP_SEC)

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

#define APP_SEC_GAP_AUTH        GAP_AUTH_REQ_NO_MITM_BOND

/// Application Security Environment Structure
struct app_sec_env_tag app_sec_env;

/*
 * GLOBAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void app_sec_init()
{
    memset((void *)&app_sec_env, 0, sizeof(struct app_sec_env_tag));
    //read store key info?
    if(app_env.func[APP_EVT_ID_REQ_INFO] !=NULL)
    {
        app_sec_env.key_valid = *(uint8_t *)get_stored_info_req(PARING_INFO_TYPE_BOND_FLAG);
        memcpy( (void *)&app_sec_env.peer_addr, get_stored_info_req(PARING_INFO_TYPE_PEER_BD_ADDRESS),sizeof(struct gap_bdaddr) );
        memcpy( (void *)&app_sec_env.irk, get_stored_info_req(PARING_INFO_TYPE_IRK),sizeof(struct gap_sec_key) );
        memcpy( (void *)&app_sec_env.ltk, get_stored_info_req(PARING_INFO_TYPE_LTK),sizeof(struct gapc_ltk) );
    }
}

static bool app_sec_check_bdaddr(const struct bd_addr *bdaddr, uint8_t bdaddr_type)
{
    if((app_sec_env.key_valid & APP_KEY_VALID_BDADDR)
       &&(memcmp((void *)&app_sec_env.peer_addr.addr, (void *)bdaddr, sizeof(struct bd_addr))==0)
       &&(app_sec_env.peer_addr.addr_type == bdaddr_type))
    {
        return true;
    }
    else
    {
        return false;
    }
}

enum app_sec_bond_t app_sec_get_bond_type(const struct bd_addr *bdaddr, uint8_t bdaddr_type)
{
    if(app_sec_env.key_valid & APP_KEY_VALID_BONDED)
    {
        if(bdaddr_type == ADDR_RAND)
        {
            if((bdaddr->addr[5] & 0xC0) == 0x40)
            {
                if(app_sec_env.key_valid & APP_KEY_VALID_IRK)
                {
                    return APP_SEC_BOND_RESOLV_CHECK;
                }
                else
                {
                    return APP_SEC_BOND_OTHER;
                }
            }
            else
            {
                if(app_sec_check_bdaddr(bdaddr, bdaddr_type))
                {
                    return APP_SEC_BOND;
                }
                else
                {
                    return APP_SEC_BOND_OTHER;
                }
            }
        }
        else
        {
            if(app_sec_check_bdaddr(bdaddr, bdaddr_type))
            {
                return APP_SEC_BOND;
            }
            else
            {
                return APP_SEC_BOND_OTHER;
            }
        }
    }
    else
    {
        return APP_SEC_NO_BOND;
    }
}

bool app_sec_get_bond_status(void)
{
    return ( (app_sec_env.key_valid & APP_KEY_VALID_BONDED) != 0 );
}
void app_sec_remove_bond(void)
{
    if ((app_sec_env.key_valid & APP_KEY_VALID_BONDED) != 0)
    {
        // Update the environment variable
        memset((void *)&app_sec_env, 0, sizeof(struct app_sec_env_tag));
    }
}


uint8_t app_sec_resolve_address(struct bd_addr *bdaddr, uint8_t count, uint8_t *irks)
{
    struct gapm_resolv_addr_cmd *cmd;

    //if(app_sec_env.key_valid & APP_KEY_VALID_IRK)
    {
        cmd = KE_MSG_ALLOC_DYN(GAPM_RESOLV_ADDR_CMD,
                               TASK_GAPM, TASK_APP,
                               gapm_resolv_addr_cmd,
                               count * sizeof(struct gap_sec_key));

        cmd->operation = GAPM_RESOLV_ADDR;
        cmd->nb_key = count;
        memcpy((void *)&cmd->addr, (void *)bdaddr, 6);
        memcpy((void *)&cmd->irk, irks, count * sizeof(struct gap_sec_key));
        ke_msg_send(cmd);

        return true;
    }
    //else
    {
      //  return false;
    }
}

void app_sec_send_security_req(uint8_t conidx)
{
    // Send security request
    struct gapc_security_cmd *cmd = KE_MSG_ALLOC(GAPC_SECURITY_CMD,
                                    KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                    gapc_security_cmd);

    cmd->operation = GAPC_SECURITY_REQ;
    cmd->auth      = APP_SEC_GAP_AUTH;//GAP_AUTH_REQ_MITM_BOND;

    // Send the message
    ke_msg_send(cmd);
}

uint8_t app_sec_check_ediv_rand(struct gapc_encrypt_req_ind const *param, uint8_t conidx)
{
    uint8_t ret = false;

    if(app_sec_env.key_valid & APP_KEY_VALID_LTK)
    {
        if ((param->ediv == app_sec_env.ltk.ediv) &&
            !memcmp(&param->rand_nb.nb[0], &app_sec_env.ltk.randnb.nb[0], sizeof(struct rand_nb)))
        {
            ret = true;
        }
    }

    return ret;
}

uint8_t app_sec_fill_connect_cfm(uint8_t conidx, struct gapc_connection_cfm *cfm)
{
    cfm->auth = app_sec_env.auth;
    if(app_sec_env.key_valid & APP_KEY_VALID_LTK)
    {
        cfm->ltk_present = true;
    }

    if(app_sec_env.key_valid & APP_KEY_VALID_CSRK)
    {
        cfm->lsign_counter = app_sec_env.lsign_counter;
        memcpy((void*)&cfm->lcsrk, (void *)&app_sec_env.lcsrk, sizeof(struct gap_sec_key));
        cfm->rsign_counter = app_sec_env.rsign_counter;
        memcpy((void*)&cfm->rcsrk, (void *)&app_sec_env.rcsrk, sizeof(struct gap_sec_key));
    }

    return true;
}

/*
 * MESSAGE HANDLERS
 ****************************************************************************************
 */
static int gapc_bond_req_ind_handler(ke_msg_id_t const msgid,
                                     struct gapc_bond_req_ind const *param,
                                     ke_task_id_t const dest_id,
                                     ke_task_id_t const src_id)
{
    // Prepare the GAPC_BOND_CFM message
    struct gapc_bond_cfm *cfm = KE_MSG_ALLOC(GAPC_BOND_CFM,
                                src_id, TASK_APP,
                                gapc_bond_cfm);
    printf("b_r:%d\r\n",param->request);
    switch (param->request)
    {
        case (GAPC_PAIRING_REQ):
        {
            cfm->request = GAPC_PAIRING_RSP;
            cfm->accept  = true;

            // Pairing Features
            if(app_env.func[APP_EVT_ID_SLAVER_GOT_BOND_REQ] !=NULL)
                app_env.func[APP_EVT_ID_SLAVER_GOT_BOND_REQ]((void *)cfm);
            else
            {
#if 0
                cfm->data.pairing_feat.auth      = GAP_AUTH_REQ_MITM_BOND;//GAP_AUTH_REQ_MITM_BOND;
                cfm->data.pairing_feat.iocap     = GAP_IO_CAP_DISPLAY_ONLY;//

                cfm->data.pairing_feat.key_size  = 16;
                cfm->data.pairing_feat.oob       = GAP_OOB_AUTH_DATA_NOT_PRESENT;
                cfm->data.pairing_feat.sec_req   = GAP_SEC1_NOAUTH_PAIR_ENC;//GAP_SEC1_SEC_CON_PAIR_ENC;//GAP_NO_SEC;
                cfm->data.pairing_feat.ikey_dist = GAP_KDIST_IDKEY;
                cfm->data.pairing_feat.rkey_dist = GAP_KDIST_ENCKEY | GAP_KDIST_IDKEY;
#else
                cfm->data.pairing_feat.auth      = GAP_AUTH_REQ_NO_MITM_BOND;//GAP_AUTH_REQ_MITM_BOND;
                cfm->data.pairing_feat.iocap     = GAP_IO_CAP_NO_INPUT_NO_OUTPUT;
                cfm->data.pairing_feat.key_size  = 16;
                cfm->data.pairing_feat.oob       = GAP_OOB_AUTH_DATA_NOT_PRESENT;
                cfm->data.pairing_feat.sec_req   = GAP_NO_SEC;//GAP_SEC1_SEC_CON_PAIR_ENC;//GAP_NO_SEC;
                cfm->data.pairing_feat.ikey_dist = GAP_KDIST_IDKEY;
                cfm->data.pairing_feat.rkey_dist = GAP_KDIST_ENCKEY | GAP_KDIST_IDKEY;
#endif
            }

        }
        break;

        case (GAPC_LTK_EXCH):
        {
            uint8_t counter;

            cfm->accept  = true;
            cfm->request = GAPC_LTK_EXCH;

            // Generate all the values
            cfm->data.ltk.ediv = (uint16_t)co_rand_word();

            for (counter = 0; counter < RAND_NB_LEN; counter++)
            {
                cfm->data.ltk.ltk.key[counter]    = (uint8_t)co_rand_word();
                cfm->data.ltk.randnb.nb[counter] = (uint8_t)co_rand_word();
            }

            for (counter = RAND_NB_LEN; counter < KEY_LEN; counter++)
            {
                cfm->data.ltk.ltk.key[counter]    = (uint8_t)co_rand_word();
            }

            memcpy((uint8_t *)&app_sec_env.ltk, (uint8_t *)&cfm->data.ltk, sizeof(struct gapc_ltk));
            app_sec_env.key_valid |= APP_KEY_VALID_LTK;
            app_connection_paring_info_ind_func((void *)&cfm->data.ltk,sizeof(struct gapc_ltk),PARING_INFO_TYPE_LTK);

        }
        break;

        case (GAPC_IRK_EXCH):
        {
#if 0
#if (NVDS_SUPPORT)
            uint8_t addr_len = BD_ADDR_LEN;
#endif

            cfm->accept  = true;
            cfm->request = GAPC_IRK_EXCH;

            // Load IRK
            memcpy(cfm->data.irk.irk.key, app_sec_env.irk.key, KEY_LEN);
            // load device address
            cfm->data.irk.addr.addr_type = ADDR_PUBLIC;
#if (NVDS_SUPPORT)
            if (nvds_get(NVDS_TAG_BD_ADDRESS, &addr_len, cfm->data.irk.addr.addr.addr) != NVDS_OK)
#endif
            {
                ASSERT_ERR(0);
            }
#endif
        }
        break;
        case (GAPC_CSRK_EXCH):
        {
            cfm->accept  = true;
            cfm->request = GAPC_CSRK_EXCH;

            uint8_t counter;
            for (counter = 0; counter < KEY_LEN; counter++)
            {
                cfm->data.csrk.key[counter] = (uint8_t)co_rand_word();
            }

        }
        break;

        case (GAPC_TK_EXCH):
        {
            // Generate a PIN Code- (Between 100000 and 999999)
            //uint32_t pin_code = (100000 + (co_rand_word()%900000));

            cfm->accept  = true;
            cfm->request = GAPC_TK_EXCH;

            // Set the TK value
            memset(cfm->data.tk.key, 0, KEY_LEN);

            //cfm->data.tk.key[0] = (uint8_t)((pin_code & 0x000000FF) >>  0);
            //cfm->data.tk.key[1] = (uint8_t)((pin_code & 0x0000FF00) >>  8);
            //cfm->data.tk.key[2] = (uint8_t)((pin_code & 0x00FF0000) >> 16);
            //cfm->data.tk.key[3] = (uint8_t)((pin_code & 0xFF000000) >> 24);
            void *tk_buf = get_stored_info_req(PARING_INFO_TYPE_TK);
            if(tk_buf != NULL)
            {
                memcpy( cfm->data.tk.key,tk_buf,4 );
                ke_msg_send(cfm);
            }
            return (KE_MSG_CONSUMED);
        }
        //break;

        default:
        {
            ASSERT_ERR(0);
        }
        break;
    }

    // Send the message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int gapc_bond_ind_handler(ke_msg_id_t const msgid,
                                 struct gapc_bond_ind const *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id)
{
    SEC_LOG("gapc_bond_ind_handler: info %d.\r\n", param->info);

    switch (param->info)
    {
        case (GAPC_PAIRING_SUCCEED):
        {
            app_sec_env.key_valid |= (APP_KEY_VALID_BONDED|APP_KEY_VALID_BDADDR);
            app_sec_env.auth = param->data.auth.info;

            memcpy((void *)&app_sec_env.peer_addr,(void *)gapc_get_bdaddr(KE_IDX_GET(src_id), SMPC_INFO_PEER),sizeof(struct gap_bdaddr));
            app_connection_paring_info_ind_func((void *)&app_sec_env.peer_addr,sizeof(struct gap_bdaddr),PARING_INFO_TYPE_PEER_BD_ADDRESS);
            app_connection_paring_info_ind_func((void *)&app_sec_env.key_valid,1,PARING_INFO_TYPE_BOND_FLAG);
            //DYC added
            app_env.encrypted = true;
            if(app_env.role == APP_ROLE_MASTER) //master then inform
                app_connection_master_encrypted_ind_func(KE_IDX_GET(src_id));
            else
                app_connection_slave_encrypted_ind_func(KE_IDX_GET(src_id));
        }
        break;

        case (GAPC_REPEATED_ATTEMPT):
        {
            appm_disconnect(KE_IDX_GET(src_id));
        }
        break;

        case (GAPC_PAIRING_FAILED):
        {
            printf("pair failed\r\n");//app_sec_send_security_req(KE_IDX_GET(src_id));
        }
        break;

        case (GAPC_IRK_EXCH):
        {
            memcpy((void *)&app_sec_env.irk, (void *)&param->data.irk, sizeof(struct gap_sec_key));
            app_sec_env.key_valid |= APP_KEY_VALID_IRK;
            app_connection_paring_info_ind_func((void *)&app_sec_env.irk,sizeof(struct gap_sec_key),PARING_INFO_TYPE_IRK);
        }
        break;

        case (GAPC_LTK_EXCH):
        {
//no use.
            SEC_LOG("recvd slave peer ltk:\r\n");
//show_reg3(param->data.ltk.ltk.key,16);
            SEC_LOG("peer slave ediv:\r\n");
//show_reg2((uint8_t *)&param->data.ltk.ediv,2);
            SEC_LOG("peer slave rand:\r\n");
//show_reg3(param->data.ltk.randnb.nb,8);

            //Record slave's LTK info   for master role
            if(GAPC_GET_FIELD(KE_IDX_GET(src_id), ROLE) == 0)
            {
                SEC_LOG("store ltk for master role\r\n");
                app_sec_env.key_valid |= APP_KEY_VALID_LTK;
                app_connection_paring_info_ind_func((void *)&param->data.ltk,sizeof(struct gapc_ltk),PARING_INFO_TYPE_LTK);
            }

        }
        break;

        case (GAPC_CSRK_EXCH):
        {
            //no use.
            SEC_LOG("recvd slave peer csrk:\r\n");
            //show_reg3(param->data.csrk.key,16);
            app_sec_env.key_valid |= APP_KEY_VALID_CSRK;

        }
        break;

        default:
        {
            ASSERT_ERR(0);
        }
        break;
    }

    return (KE_MSG_CONSUMED);
}

static int gapc_encrypt_req_ind_handler(ke_msg_id_t const msgid,
                                        struct gapc_encrypt_req_ind const *param,
                                        ke_task_id_t const dest_id,
                                        ke_task_id_t const src_id)
{
    // Prepare the GAPC_ENCRYPT_CFM message
    struct gapc_encrypt_cfm *cfm = KE_MSG_ALLOC(GAPC_ENCRYPT_CFM,
                                   src_id, TASK_APP,
                                   gapc_encrypt_cfm);

    cfm->found    = false;

    if (app_sec_env.key_valid & APP_KEY_VALID_BONDED)
    {
        printf("e_r\r\n");
        // Check if the provided EDIV and Rand Nb values match with the stored values
        if (app_sec_check_ediv_rand(param, KE_IDX_GET(src_id)))
        {
            printf("e_f\r\n");
            cfm->found    = true;
            cfm->key_size = 16;
            //show_reg2((uint8_t *)&app_sec_env.ltk.ltk,sizeof(struct gap_sec_key),1);
            //memcpy((uint8_t *)&cfm->ltk, (uint8_t *)&app_sec_env.ltk, sizeof(struct gapc_ltk));
            memcpy((uint8_t *)&cfm->ltk, (uint8_t *)&app_sec_env.ltk.ltk, sizeof(struct gap_sec_key));
        }
        /*
         * else we are bonded with another device, disconnect the link
         */
    }
    /*
     * else the peer device is not known, an error should trigger a new pairing procedure.
     */

    // Send the message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int gapc_encrypt_ind_handler(ke_msg_id_t const msgid,
                                    struct gapc_encrypt_ind *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
    //DYC added
    app_env.encrypted = true;
    if(app_env.role == APP_ROLE_MASTER) //master then inform
        app_connection_master_encrypted_ind_func(KE_IDX_GET(src_id));
    else
        app_connection_slave_encrypted_ind_func(KE_IDX_GET(src_id));
    return (KE_MSG_CONSUMED);
}



static int gapc_security_ind_handler(ke_msg_id_t const msgid,
                                     struct gapc_security_ind *param,
                                     ke_task_id_t const dest_id,
                                     ke_task_id_t const src_id)
{
    SEC_LOG("peer auth:%x \r\n",param->auth);
    struct gapc_security_ind1 ind;
    ind.ind.auth = param->auth;
    ind.conidx = KE_IDX_GET(src_id);
    if(app_env.func[APP_EVT_ID_MASTER_GOT_SEC_REQ] !=NULL)
        app_env.func[APP_EVT_ID_MASTER_GOT_SEC_REQ]((void *)&ind);

    return (KE_MSG_CONSUMED);
}


static int app_sec_msg_dflt_handler(ke_msg_id_t const msgid,
                                    void *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
    // Drop the message

    return (KE_MSG_CONSUMED);
}

/*
 * LOCAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Default State handlers definition
const struct ke_msg_handler app_sec_msg_handler_list[] =
{
    // Note: first message is latest message checked by kernel so default is put on top.
    {KE_MSG_DEFAULT_HANDLER,  (ke_msg_func_t)app_sec_msg_dflt_handler},

    {GAPC_SECURITY_IND,  (ke_msg_func_t)gapc_security_ind_handler},

    {GAPC_BOND_REQ_IND,       (ke_msg_func_t)gapc_bond_req_ind_handler},
    {GAPC_BOND_IND,           (ke_msg_func_t)gapc_bond_ind_handler},
    {GAPC_ENCRYPT_REQ_IND,    (ke_msg_func_t)gapc_encrypt_req_ind_handler},
    {GAPC_ENCRYPT_IND,        (ke_msg_func_t)gapc_encrypt_ind_handler},
};

const struct ke_state_handler app_sec_table_handler =
{&app_sec_msg_handler_list[0], (sizeof(app_sec_msg_handler_list)/sizeof(struct ke_msg_handler))};

#else   //(BLE_APP_SEC)

enum app_sec_bond_t app_sec_get_bond_type(const struct bd_addr *bdaddr, uint8_t bdaddr_type)
{
    return APP_SEC_NO_BOND;
}

#endif //(BLE_APP_SEC)

/// @} APP
