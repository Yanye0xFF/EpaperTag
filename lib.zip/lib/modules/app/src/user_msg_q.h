/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_MSG_Q_H_
#define USER_MSG_Q_H_

#include <stdint.h>
#include <ke_msg.h>

typedef struct _os_event_
{
    uint16_t event_id;
    void *param;
    uint16_t param_len;
    uint16_t src_task_id;
} os_event_t;

void os_msg_post(uint16_t dest_task_id,os_event_t *evt);

#endif // APP_HT_H_
