#include <stdint.h>
#include <stdio.h>
#include "ke_msg.h"
#include "ke_timer.h"
#include "user_timer.h"
#include "app_task.h"
#include "arch.h"
#include "system.h"
#include "ke_env.h"

#include "arch.h"
#define TIM_DBG FR_DBG_OFF
#define TIM_LOG FR_LOG(TIM_DBG)


#define TIMER_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %d \r\n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);



#define TIM_ID_NOT_USE (0xff)


#if USER_TIMER_API_ENABLE

static os_timer_t *timer_list = NULL;

static uint32_t timer_id_flag[2];
static uint8_t get_valid_tim_evt_id(void)
{
    uint8_t idx = 0;
    for(; idx<64; idx++)
    {
        if(idx<32)
        {
            if( (timer_id_flag[0] & BIT(idx)) ==0 )
            {
                timer_id_flag[0] |= BIT(idx);
                return idx;
            }
        }
        else
        {
            if( (timer_id_flag[1] & BIT(idx-32)) ==0 )
            {
                timer_id_flag[1] |= BIT(idx-32);
                return idx;
            }
        }
    }
    return 0xff;
}

static void free_time_evt_id(uint8_t idx)
{
    if(idx<32)
    {
        timer_id_flag[0] &= ~(BIT(idx));
    }
    else
    {
        timer_id_flag[1] &= ~(BIT(idx-32));
    }
}

static uint8_t is_timer_in_list(os_timer_t *ptimer)
{
    os_timer_t *curr=NULL;
//printf("i1\r\n");
    for (curr = timer_list;
         curr;
         curr = curr->timer_next)
    {
//printf("curr:%p,prev:%p,ptimer:%p\r\n",curr,prev,ptimer);
        if ((void *)curr == (void *)ptimer)
        {
//          printf("yy\r\n");
            return 1;
        }
    }
    return 0;
}

static void timer_insert(os_timer_t *ptimer)
{
    os_timer_t *curr,*prev=NULL;
//printf("i1\r\n");
    for (curr = timer_list;
         curr;
         )
    {
//printf("curr:%p,prev:%p,ptimer:%p\r\n",curr,prev,ptimer);
        if ((void *)curr == (void *)ptimer)
        {
            goto _exit;
        }
		prev = curr;
		curr = curr->timer_next;
    }

    if (prev)
    {
        prev->timer_next = ptimer;
    }
    else
    {
        timer_list = ptimer;
    }
//printf("i2\r\n");
    TIMER_ASSERT(ptimer->timer_next != ptimer);

_exit:
    ;
//printf("i3\r\n");
}


void os_timer_setfn(os_timer_t *ptimer, os_timer_func_t pfunction, void *parg)
{
    GLOBAL_INT_DISABLE();
    ptimer->timer_period = 0;
    ptimer->timer_id = TIM_ID_NOT_USE;
    ptimer->timer_func = pfunction;
    ptimer->timer_arg = parg;

    TIM_LOG("ptimer:%p\r\n",ptimer);
    if(is_timer_in_list(ptimer) == 0)
    {
        ptimer->timer_next = NULL;
        TIM_LOG("not in list\r\n");
        //GLOBAL_INT_DISABLE();
        timer_insert(ptimer);
        //GLOBAL_INT_RESTORE();
    }
    GLOBAL_INT_RESTORE();
    TIM_LOG("setfn_out\r\n");
}

void os_timer_disarm(os_timer_t *ptimer)
{
    GLOBAL_INT_DISABLE();

    if(ptimer->timer_id != TIM_ID_NOT_USE)
    {
        if( ke_timer_active(ptimer->timer_id,TASK_APP) )
            ke_timer_clear(ptimer->timer_id,TASK_APP);

//try to free queued timer msg
        struct co_list *list = &ke_env.queue_sent;
        struct co_list_hdr *elem = list->first;
        struct co_list_hdr *prev = NULL;
        struct ke_msg *msg;
        while(elem != NULL)
        {
            msg = (struct ke_msg*)elem;
            if(msg->id == ptimer->timer_id && msg->dest_id == TASK_APP)
            {

                if(prev)
                    prev->next = elem->next;
                else
                    list->first = elem->next;

                if(elem->next)
                    elem->next = NULL;
                else
                    list->last = prev;


                ke_msg_free(msg);
                break;
            }
            prev = elem;
            elem = elem->next;
        }

        free_time_evt_id(ptimer->timer_id - APP_USER_TIMER_EVENT_START);
        ptimer->timer_period = 0;
        ptimer->timer_id = TIM_ID_NOT_USE;
    }
    GLOBAL_INT_RESTORE();
}

// 10~83886070 ms
void os_timer_arm(os_timer_t *ptimer,
                  uint32_t milliseconds,
                  bool repeat_flag)
{
    uint32_t timer_ticks;
    uint8_t idx = 0;
    os_timer_disarm(ptimer);
    GLOBAL_INT_DISABLE();
    if(ptimer->timer_id == TIM_ID_NOT_USE)
    {
        timer_ticks = (milliseconds/10);
        if (repeat_flag)
        {
            ptimer->timer_period = timer_ticks;
        }

        free_time_evt_id(ptimer->timer_id - APP_USER_TIMER_EVENT_START);
        ptimer->timer_id = TIM_ID_NOT_USE;

        idx = get_valid_tim_evt_id();
        if(idx != 0xff)
            ptimer->timer_id = APP_USER_TIMER_EVENT_START + idx;
        else
            TIMER_ASSERT(0);

        TIM_LOG("time set,id:%04X,ticks:%d\r\n",ptimer->timer_id,timer_ticks);
        ke_timer_set(ptimer->timer_id, TASK_APP, timer_ticks);
    }
    GLOBAL_INT_RESTORE();
}



void check_timer_handle(uint16_t timer_id)
{
//    uint8_t idx;
    os_timer_t *curr;
    TIM_LOG("time out,id:%04X\r\n",timer_id);

    GLOBAL_INT_DISABLE();
    for (curr = timer_list;
         curr;
         curr = curr->timer_next)
    {
        if (curr->timer_id == timer_id)
        {
            TIM_LOG("timer found\r\n");
            if(curr->timer_period != 0)
            {
                TIM_LOG("loop timer arm again,period:%d\r\n",curr->timer_period);
                ke_timer_set(curr->timer_id, TASK_APP, curr->timer_period);
            }
			GLOBAL_INT_RESTORE();
            if(curr->timer_func != NULL)
                curr->timer_func(curr->timer_arg);
			GLOBAL_INT_DISABLE();
            goto _exit;
        }
    }

    TIMER_ASSERT(0);

_exit:
    GLOBAL_INT_RESTORE();
}
/*
void
ets_delay_us(uint16 us)
{
    uint32 start = xthal_get_ccount();
    uint32 end = us*TICKS_PER_US;

    //suppose no wrap issue
    while ((xthal_get_ccount() - start) < end) {
        //nothing to do
    }
}
*/


#if (TIME_TEST_ENABLE)
/****below for timer test**********
Right log:
    timer[1]
    id_flag[0]:00000007,[1]:00000000
    timer[2]
    timer[1]
    id_flag[0]:00000007,[1]:00000000
    timer[3]
    timer[1]
    id_flag[0]:00000005,[1]:00000000
    timer[2]
    timer[1]
    id_flag[0]:00000003,[1]:00000000
    timer[1]
    id_flag[0]:00000003,[1]:00000000
    timer[2]
**********************************/

os_timer_t timer1;      //loop 1s, 2times, then disarm
os_timer_t timer2;      //one time 2s, run 3times, then stop
os_timer_t timer3;      //one time 3s, before timeout,do disarm
uint8_t param[3] = {1,2,3};
static uint8_t tick1 = 0;
static uint8_t tick2 = 0;
static uint8_t tick3 = 0;

void test_func3_1(void *arg)
{
    printf("timer[%d]:3_1\r\n",*(uint8_t *)arg);
}

void test_func1(void *arg)
{
    printf("timer[%d]\r\n",*(uint8_t *)arg);
    printf("id_flag[0]:%08x,[1]:%08X\r\n",timer_id_flag[0],timer_id_flag[1]);
    tick1++;
    if(tick1==3)
    {
        os_timer_disarm(&timer3);
        os_timer_setfn(&timer3,test_func3_1,&param[2]);
        os_timer_arm(&timer3,20,0);
    }
    if(tick1==5)
        os_timer_disarm(&timer1);
}
void test_func2(void *arg)
{
    printf("timer[%d]\r\n",*(uint8_t *)arg);
    static uint8_t tick = 0;
    tick2++;
    if(tick2<=2)
        os_timer_arm(&timer2,2000,0);
}
void test_func3(void *arg)
{
    printf("timer[%d]\r\n",*(uint8_t *)arg);
}
void user_timer_test(void)
{
    TIM_LOG("TIM SET\r\n");
    tick1 = 0;
    tick2 = 0;
    tick3 = 0;

    os_timer_setfn(&timer1,test_func1,&param[0]);
    os_timer_setfn(&timer2,test_func2,&param[1]);
    os_timer_setfn(&timer3,test_func3,&param[2]);

    TIM_LOG("ARM\r\n");

    os_timer_arm(&timer1,1000,1);
    os_timer_arm(&timer3,1500,1);
    //os_timer_disarm(&timer3);

    os_timer_disarm(&timer2);
    os_timer_arm(&timer2,2000,0);
}

#endif

#endif      //end of #if USER_TIMER_API_ENABLE


