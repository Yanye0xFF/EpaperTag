/**
 ****************************************************************************************
 *
 * @file appm_task.c
 *
 * @brief RW APP Task implementation
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APPTASK
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <string.h>

#include "rwip_config.h"          // SW configuration

#if (BLE_APP_PRESENT)

#include "app_task.h"             // Application Manager Task API
#include "app.h"                  // Application Manager Definition
#include "app_proj_event.h"

#include "gapc_task.h"            // GAP Controller Task API
#include "gapm_task.h"            // GAP Manager Task API
#include "arch.h"                 // Platform Definitions
#include "gattc_task.h"

#include "app_sec.h"
#include "button.h"

#if (BLE_APP_SEC)
#include "app_sec.h"              // Security Module Definition
#endif //(BLE_APP_SEC)

#if (BLE_APP_DIS)
#include "app_dis.h"              // Device Information Module Definition
#include "diss_task.h"
#endif //(BLE_APP_DIS)

#if (BLE_APP_BATT)
#include "app_batt.h"             // Battery Module Definition
#include "bass_task.h"
#endif //(BLE_APP_BATT)

#if (BLE_APP_HID)
#include "app_hid.h"              // HID Module Definition
#include "hogpd_task_user.h"
#endif //(BLE_APP_HID)

#if (BLE_APP_PROXR)
#include "app_proxr.h"               //Proximity Reporter Application Definitions
#endif  //(BLE_APP_PROXR)

#if (BLE_APP_TIME)
#include "app_time.h"             // Time Module Definition
#endif //(BLE_APP_TIME)

#if (BLE_APP_OTAS)
#include "app_otas.h"
#endif //(BLE_APP_OTAS)

#if (BLE_APP_SPSS)
#include "app_spss.h"
#endif //(BLE_APP_SPSS)

#if (BLE_APP_SPSC)
#include "app_spsc.h"
#endif //(BLE_APP_SPSS)

#if (BLE_APP_FINDT)
#include "app_findt.h"
#endif //(BLE_APP_FMPT)

#if (BLE_APP_RTCTS)
#include "app_rtct.h"
#endif //(BLE_APP_FMPT)

#if (BLE_APP_SPSS)
#include "app_spss.h"
#endif  //(BLE_APP_SPSS)

#if BLE_APP_MESH
#include "app_mesh.h"
#endif


#if (USER_FLOWER_CARE)
#include "app_flower.h"
#endif

#include "flash.h"
#include "sbc.h"
#include "apb2spi.h"
#include "pmu.h"
#include "i2s.h"
#include "led.h"
#include "rwip.h"
#include "gpio.h"

#include "reg_ble_em_tx_desc.h"
#include "llm.h"

#include "user_timer.h"


/*
 * LOCAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */

static uint8_t appm_get_handler(const struct ke_state_handler *handler_list,
                                ke_msg_id_t msgid,
                                void *param,
                                ke_task_id_t src_id)
{
    // Counter
    uint8_t counter;

    // Get the message handler function by parsing the message table
    for (counter = handler_list->msg_cnt; 0 < counter; counter--)
    {
#if 0   //owen
        struct ke_msg_handler handler = (struct ke_msg_handler)(*(handler_list->msg_table + counter - 1));
#else
        struct ke_msg_handler handler;

        handler.id = (handler_list->msg_table + counter - 1)->id;
        handler.func = (handler_list->msg_table + counter - 1)->func;
#endif
        if ((handler.id == msgid) ||
            (handler.id == KE_MSG_DEFAULT_HANDLER))
        {
            // If handler is NULL, message should not have been received in this state
            ASSERT_ERR(handler.func);

            return (uint8_t)(handler.func(msgid, param, TASK_APP, src_id));
        }
    }

    // If we are here no handler has been found, drop the message
    return (KE_MSG_CONSUMED);
}

/*
 * MESSAGE HANDLERS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int app_adv_timeout_handler(ke_msg_id_t const msgid,
                                   void const *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id)
{
    // Stop advertising
    appm_stop_advertising();

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int app_con_timeout_handler(ke_msg_id_t const msgid,
                                   void const *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id)
{
    APP_LOG("app create connection timeout.\r\n");

    appm_stop_connecting();

    return (KE_MSG_CONSUMED);
}

void app_get_current_rssi(uint8_t conidx);

#if BLE_APP_OTAS
void sbc_enc_start(void);
void sbc_enc_end(void);
#endif


#if BLE_APP_HID
void app_hid_send_keyboard_report(uint8_t report_idx, uint8_t *report_data);
#endif
extern uint32_t interval_patch;


static void app_accept_conn_req(uint8_t conidx, enum app_sec_bond_t bond)
{
    // Send connection confirmation
    struct gapc_connection_cfm *cfm = KE_MSG_ALLOC(GAPC_CONNECTION_CFM,
                                      KE_BUILD_ID(TASK_GAPC, conidx), TASK_APP,
                                      gapc_connection_cfm);
#if (BLE_APP_SEC)
    if(bond == APP_SEC_BOND)
    {
        app_sec_fill_connect_cfm(conidx, cfm);
    }
    else
#endif
    {
        cfm->auth = 0;
    }

    // Send the message
    ke_msg_send(cfm);

#if BLE_APP_MESH
    app_mesh_enable_prf(conidx);
#endif
}

/**
 ****************************************************************************************
 * @brief Handles ready indication from the GAP. - Reset the stack
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapm_device_ready_ind_handler(ke_msg_id_t const msgid,
        void const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    // Application has not been initialized
    ASSERT_ERR(ke_state_get(dest_id) == APPM_INIT);

    app_device_ready_ind_func();

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles GAP manager command complete events.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
#include "gattm.h"
static void fix_bug_gap_gattc_svc(void)
{
    struct attm_svc * current_svc = gattm_env.db.svcs;
    struct attm_svc * next_svc;

    while(current_svc != NULL)
    {
        next_svc = current_svc->next;
        if( current_svc->svc.task_id == TASK_GAPC || current_svc->svc.task_id == TASK_GATTC )
            current_svc->svc.perm |= PERM_MASK_SVC_MI;
        current_svc = next_svc;
    }
}
static int gapm_cmp_evt_handler(ke_msg_id_t const msgid,
                                struct gapm_cmp_evt const *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
    APP_LOG("gpam_op: %d, status(hl code): 0x%2X.\r\n", param->operation, param->status);
    switch(param->operation)
    {
        // Reset completed
        case (GAPM_RESET):
        {
            if(param->status == GAP_ERR_NO_ERROR)
            {
                appm_init_imp();
#include "user_profile.h"
#if USER_PROFILE_API_ENABLE
                flush_all_user_svc_list();
#endif

                app_reset_complete_ind_func();
            }
            else
            {
                ASSERT_ERR(0);
            }
        }
        break;

        // Device Configuration updated
        case (GAPM_SET_DEV_CONFIG):
        {
            ASSERT_ERR(param->status == GAP_ERR_NO_ERROR);
            fix_bug_gap_gattc_svc();
            app_set_dev_config_complete_ind_func();
        }
        break;

        case (GAPM_GET_WLIST_SIZE):
        {

        }
        break;

        case (GAPM_PROFILE_TASK_ADD):
        {
            ;
        }
        break;

        case (GAPM_ADV_NON_CONN):
        case (GAPM_ADV_DIRECT):
        case (GAPM_ADV_UNDIRECT):
        {
            if (ke_state_get(TASK_APP) == APPM_ADVERTISING)
            {
                ke_state_set(TASK_APP, APPM_READY);
                //app_env.role = APP_ROLE_NONE;
            }
            app_adv_complete_ind_func(param);
        }
        break;


        case GAPM_SCAN_PASSIVE:
        case GAPM_SCAN_ACTIVE:
        {
            if (ke_state_get(TASK_APP) == APPM_SCANNING)
            {
                ke_state_set(TASK_APP, APPM_READY);
                //app_env.role = APP_ROLE_NONE;
            }
            app_scanning_completed_ind_func(param->status);
        }
        break;

        case GAPM_CANCEL:
        {
            if(param->status != GAP_ERR_NO_ERROR)
            {
                ASSERT_ERR(0); // unexpected error
            }
        }
        case GAPM_CONNECTION_DIRECT:
        case GAPM_CONNECTION_AUTO:
        case GAPM_CONNECTION_SELECTIVE:
        case GAPM_CONNECTION_NAME_REQUEST:
            if (ke_state_get(TASK_APP) == APPM_INITIATING)
            {
                ke_state_set(TASK_APP, APPM_READY);
                //app_env.role = APP_ROLE_NONE;
            }
            if (param->status == GAP_ERR_CANCELED)
            {
                app_connect_failed_ind_func(param->status);
            }
            //printf("connect result: %d\r\n", param->status);
            break;

        case GAPM_RESOLV_ADDR:
            printf("B:%d\r\n",param->status);
            if(param->status != SMP_ERROR_NO_ERROR)
            {
                app_addr_resolve_result_ind_func(KE_IDX_GET(src_id), param->status, NULL);
            }
            break;

        default:
        {
            // Drop the message
        }
        break;
    }

    return (KE_MSG_CONSUMED);
}

static int gapc_get_dev_info_req_ind_handler(ke_msg_id_t const msgid,
        struct gapc_get_dev_info_req_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    uint8_t name_len;
    struct gapc_get_dev_info_cfm *cfm;
    // Allocate message
    if(param->req == GAPC_DEV_NAME)
    {
        name_len = strlen((const char *)app_device_name);
        cfm = KE_MSG_ALLOC_DYN(GAPC_GET_DEV_INFO_CFM,
                               KE_BUILD_ID(TASK_GAPC, KE_IDX_GET(src_id)),
                               TASK_APP,
                               gapc_get_dev_info_cfm,
                               name_len);
    }
    else
    {
        cfm = KE_MSG_ALLOC(GAPC_GET_DEV_INFO_CFM,
                           KE_BUILD_ID(TASK_GAPC, KE_IDX_GET(src_id)),
                           TASK_APP,
                           gapc_get_dev_info_cfm);
    }
    cfm->req = param->req;

    switch(param->req)
    {
        case GAPC_DEV_NAME:
        {
            cfm->info.name.length = name_len;
            memcpy(&cfm->info.name.value[0], app_device_name, name_len);
        }
        break;

        case GAPC_DEV_APPEARANCE:
        {
            // Set the device appearance
            // HID Keyboard
            //GAP_APPEARE_HID_KEYBOARD  0x03c1;
            //GAP_APPEARE_HID_MOUSE     0x03c2;
            //GAP_APPEARE_HID_JOYSTIC   0x03c3;
            //GAP_APPEARE_HID_GAMEPAD   0x03c4;
#if (HID_TYPE == 0)
            cfm->info.appearance = 0x03c1;
#elif (HID_TYPE == 1)
            cfm->info.appearance = 0x03c2;
#elif (HID_TYPE == 2)
            cfm->info.appearance = 0x03c3;
#endif
        }
        break;

        case GAPC_DEV_SLV_PREF_PARAMS:
        {
            // Slave preferred Connection interval Min
            cfm->info.slv_params.con_intv_min = 8;
            // Slave preferred Connection interval Max
            cfm->info.slv_params.con_intv_max = 10;
            // Slave preferred Connection latency
            cfm->info.slv_params.slave_latency  = 60;
            // Slave preferred Link supervision timeout
            cfm->info.slv_params.conn_timeout    = 500;  // 5s (500*10ms)
        }
        break;

        default: /* Do Nothing */
            break;
    }

    // Send message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}
/**
 ****************************************************************************************
 * @brief Handles GAPC_SET_DEV_INFO_REQ_IND message.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapc_set_dev_info_req_ind_handler(ke_msg_id_t const msgid,
        struct gapc_set_dev_info_req_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    // Set Device configuration
    struct gapc_set_dev_info_cfm* cfm = KE_MSG_ALLOC(GAPC_SET_DEV_INFO_CFM,
                                        TASK_GAPM, TASK_APP,
                                        gapc_set_dev_info_cfm);
    // Reject to change parameters
    cfm->status = GAP_ERR_REJECTED;
    cfm->req = param->req;
    // Send message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int gapc_peer_features_ind_handler(ke_msg_id_t const msgid,
        struct gapc_peer_features_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    app_get_info_ind_func(KE_IDX_GET(src_id),(void *)param,GAPC_GET_PEER_FEATURES);
    return KE_MSG_CONSUMED;
}

static bool con_param_accept_flag = true;
void set_con_param_accpet_flag(bool flag)
{
    con_param_accept_flag = flag;
}
static int gapc_param_update_req_ind_handler(ke_msg_id_t const msgid,
        struct gapc_param_update_req_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
//please check con param here.
    struct gapc_param_update_cfm *cfm = KE_MSG_ALLOC(GAPC_PARAM_UPDATE_CFM, src_id, dest_id,
                                        gapc_param_update_cfm);
    APP_LOG("peer con param req:%d,%d,%d,%d\r\n",param->intv_min,param->intv_max,param->latency,param->time_out);

    cfm->accept = con_param_accept_flag;
    if( param->intv_min > 80
        || param->intv_max > 100
        || param->latency > 300
      )
        cfm->accept = false;
    cfm->ce_len_max = 0xffff;
    cfm->ce_len_min = 0xffff;
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}


/**
 ****************************************************************************************
 * @brief Handles connection complete event from the GAP. Enable all required profiles
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapc_connection_req_ind_handler(ke_msg_id_t const msgid,
        struct gapc_connection_req_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    enum app_sec_bond_t bond;

    // Check if the received Connection Handle was valid
    if (KE_IDX_GET(src_id) != GAP_INVALID_CONIDX)
    {
        app_env.conidx  = KE_IDX_GET(src_id);
        APP_LOG("app_task,conn_req_ind_handler,conidx:%d\n",app_env.conidx);

        // Clear the advertising timeout timer
        if (ke_timer_active(APP_ADV_TIMEOUT_TIMER, TASK_APP))
        {
            ke_timer_clear(APP_ADV_TIMEOUT_TIMER, TASK_APP);
        }

        if (ke_timer_active(APP_CON_TIMEOUT_TIMER, TASK_APP))
        {
            ke_timer_clear(APP_CON_TIMEOUT_TIMER, TASK_APP);
        }
        app_env.connected[KE_IDX_GET(src_id)] = true;
        //if(old_app_status == APPM_INITIATING) //master then inform
        if(app_env.role == APP_ROLE_MASTER) //master then inform
            app_connection_success_ind_func(KE_IDX_GET(src_id),param);
        else    //slave then inform
            app_connection_req_ind_func(KE_IDX_GET(src_id),param);

        bond = app_sec_get_bond_type(&param->peer_addr, param->peer_addr_type);
        app_accept_conn_req(KE_IDX_GET(src_id), bond);
    }
    else
    {
        // No connection has been establish, restart advertising
        //appm_start_advertising(NULL);
        //appm_start_scan();
        APP_LOG("conn_idx_invalid:%d\n",KE_IDX_GET(src_id));
    }

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles GAP controller command complete events.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapc_cmp_evt_handler(ke_msg_id_t const msgid,
                                struct gapc_cmp_evt const *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id)
{
    if(param->operation != GAPC_UPDATE_PARAMS)
        APP_LOG("gpac_op: %d, status(hl code): 0x%2X\r\n", param->operation, param->status);
    switch(param->operation)
    {
        case (GAPC_UPDATE_PARAMS):
        {
            if (param->status != GAP_ERR_NO_ERROR)
            {
                //appm_disconnect();
                app_update_params_rejected_ind_func(KE_IDX_GET(src_id),param->status);
            }
            else
            {
                app_update_params_complete_ind_func(KE_IDX_GET(src_id));
            }
        }
        break;

        case GAPC_SECURITY_REQ:
        {
            APP_LOG("send sec_req,status:%d\n",param->status);
        }
        break;

        case GAPC_ENCRYPT:
        {
            app_connection_master_encrypt_compeleted_ind_func(KE_IDX_GET(src_id),param->status);
        }
        break;

        default:
        {
            if(param->status != GAP_ERR_NO_ERROR)
            {
                ASSERT_ERR(0); // unexpected error
            }
        }
        break;
    }

    return (KE_MSG_CONSUMED);
}

static int gapm_adv_report_ind_handler(ke_msg_id_t const msgid,
                                       struct gapm_adv_report_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
#if 0
    printf("scan result:\r\n");
    printf("address type is %d.\r\n", param->report.adv_addr_type);
    printf("rssi is -%ddB.\r\naddress:", param->report.rssi ^ 0xFF);
    for(uint8_t i=0; i<BD_ADDR_LEN; i++)
    {
        printf(" %02x", param->report.adv_addr.addr[i]);
    }
    printf("\r\n");
#endif
    app_adv_report_ind_func((struct gapm_adv_report_ind *)param);
    return (KE_MSG_CONSUMED);
}
/**
 ****************************************************************************************
 * @brief Handles disconnection complete event from the GAP.
 *
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance (TASK_GAP).
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapc_disconnect_ind_handler(ke_msg_id_t const msgid,
                                       struct gapc_disconnect_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    if(rwip_prevent_sleep_get() & RW_POWER_OFF_ONGOING)
    {
        pmu_power_off(false);
    }
    app_env.connected[KE_IDX_GET(src_id)] = false;
    app_env.conidx = 0;
    for(uint8_t i = BLE_CONNECTION_MAX; i>0; i--)
    {
        if(app_env.connected[i-1])
        {
            app_env.conidx  = i-1;
            break;
        }
    }
    app_env.role = APP_ROLE_NONE;
    app_disconnect_ind_func(dest_id, param);

    return (KE_MSG_CONSUMED);
}

static int gapc_white_list_size_ind_handler(ke_msg_id_t const msgid,
        struct gapm_white_list_size_ind const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    printf("white list size:%d\r\n",param->size);
    return (KE_MSG_CONSUMED);
}


static int gapm_addr_solved_ind_handler(ke_msg_id_t const msgid,
                                        struct gapm_addr_solved_ind const *param,
                                        ke_task_id_t const dest_id,
                                        ke_task_id_t const src_id)
{
    uint8_t conidx;

    conidx = KE_IDX_GET(src_id);
    printf("A\r\n");
    //app_accept_conn_req(conidx, app_sec_get_bond_type(&param->addr, ADDR_RAND));
    app_addr_resolve_result_ind_func(conidx, CO_ERROR_NO_ERROR, param);

    return KE_MSG_CONSUMED;
}

void app_get_current_rssi(uint8_t conidx)
{
    struct gapc_get_info_cmd *param;

    param = KE_MSG_ALLOC(GAPC_GET_INFO_CMD,
                         KE_BUILD_ID(TASK_GAPC, conidx),
                         TASK_APP,
                         gapc_get_info_cmd);

    param->operation = GAPC_GET_CON_RSSI;

    ke_msg_send(param);
}

static int app_get_current_rssi_rsp(ke_msg_id_t const msgid,
                                    struct gapc_con_rssi_ind const *ind,
                                    ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    APP_LOG("ind is -%d.\r\n", ((ind->rssi-1) ^ 0xFF));

    return KE_MSG_CONSUMED;
}

/*static const char *button_event_to_str[] = {
    "BUTTON_PRESSED",
    "BUTTON_RELEASED",
    "BUTTON_SHORT_PRESSED",
    "BUTTON_MULTI_PRESSED",
    "BUTTON_LONG_PRESSED",
    "BUTTON_LONG_PRESSING",
    "BUTTON_LONG_RELEASED",
    "BUTTON_LONG_LONG_PRESSED",
    "BUTTON_LONG_LONG_RELEASED",
    "BUTTON_COMB_PRESSED",
    "BUTTON_COMB_RELEASED",
    "BUTTON_COMB_SHORT_PRESSED",
    "BUTTON_COMB_LONG_PRESSED",
    "BUTTON_COMB_LONG_PRESSING",
    "BUTTON_COMB_LONG_RELEASED",
    "BUTTON_COMB_LONG_LONG_PRESSED",
    "BUTTON_COMB_LONG_LONG_RELEASED",
};*/

//uint8_t sbc_transfering = false;
static int app_button_process(ke_msg_id_t const msgid,
                              struct button_msg_t const *param,
                              ke_task_id_t const dest_id,
                              ke_task_id_t const src_id)
{
    return (KE_MSG_CONSUMED);
}


/*********below for timer realization****************/
static int app_user_timeout_handler(ke_msg_id_t const msgid,
                                    struct button_msg_t const *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
#include "user_timer.h"
#if USER_TIMER_API_ENABLE
    check_timer_handle(msgid);
#endif
    return (KE_MSG_CONSUMED);
}
/*********above for timer realization****************/

/**
 ****************************************************************************************
 * @brief Handles reception of all messages sent from the lower layers to the application
 * @param[in] msgid     Id of the message received.
 * @param[in] param     Pointer to the parameters of the message.
 * @param[in] dest_id   ID of the receiving task instance
 * @param[in] src_id    ID of the sending task instance.
 *
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int appm_msg_handler(ke_msg_id_t const msgid,
                            void *param,
                            ke_task_id_t const dest_id,
                            ke_task_id_t const src_id)
{
    // Get task type of source task/// Start Security Request command procedure
    struct gapc_security_cmd
    {
        /// GAP request type:
        /// - GAPC_SECURITY_REQ: Start security request procedure
        uint8_t operation;
        /// Authentification level (@see gap_auth)
        uint8_t auth;
    };
    // Retrieve identifier of the task from received message
    ke_task_id_t src_task_id = MSG_T(msgid);
    // Current State
    uint8_t state            = ke_state_get(dest_id);
    // Message policy
    uint8_t msg_pol          = KE_MSG_CONSUMED;

    if (state == APPM_CREATE_DB)
    {
        switch (msgid)
        {
            case (GAPM_PROFILE_ADDED_IND):
            {
                app_svc_added_ind_func(param);
                // Add the next requested service
                if (!appm_add_svc())
                {
                    // Go to the ready state
                    ke_state_set(TASK_APP, APPM_READY);
                    app_env.role = APP_ROLE_NONE;
#if BLE_APP_MESH
                    app_mesh_start();
#endif
                    app_db_init_complete_ind_func();
                }
            }
            break;

            default:
            {
                ASSERT_ERR(0);
            }
            break;
        }
        //goto _exit;
    }
    if (msgid == GAPC_LE_PKT_SIZE_IND)
    {
        struct gapc_le_pkt_size_ind *ind = (struct gapc_le_pkt_size_ind *)param;
        APP_LOG("peer le pkt:rx_oct:%d,rx_time:%d,tx_oct:%d,tx_time:%d\r\n",ind->max_rx_octets,ind->max_rx_time,ind->max_tx_octets,ind->max_tx_time);
        //goto _exit;
    }
    switch (src_task_id)
    {
        case (TASK_ID_GAPC):
        {
#if (BLE_APP_SEC)
            if ((msgid >= GAPC_BOND_CMD) &&
                (msgid <= GAPC_SECURITY_IND))
            {
                // Call the Security Module
                msg_pol = appm_get_handler(&app_sec_table_handler, msgid, param, src_id);
            }
#endif //(BLE_APP_SEC)
            // else drop the message
            if(msgid == GAPC_PARAM_UPDATED_IND)
            {
                app_update_params_update_ind_func(KE_IDX_GET(src_id),param);
            }
        }
        break;

        case (TASK_ID_GATTC):
        {
            // Service Changed - Drop
            if(msgid == GATTC_MTU_CHANGED_IND)
            {
                struct gattc_mtu_changed_ind * mtu_ind = (struct gattc_mtu_changed_ind *)param;
                APP_LOG("mtu[%d] exchanged:%d\r\n",KE_IDX_GET(src_id),mtu_ind->mtu);
            }
        }
        break;

#if (BLE_APP_DIS)
        case (TASK_ID_DISS):
        {
            // Call the Device Information Module
            msg_pol = appm_get_handler(&app_dis_table_handler, msgid, param, src_id);
        }
        break;
#endif //(BLE_APP_DIS)

#if (BLE_APP_HID)
        case (TASK_ID_HOGPD):
        {
            // Call the HID Module
            msg_pol = appm_get_handler(&app_hid_table_handler, msgid, param, src_id);
        }
        break;
#endif //(BLE_APP_HID)

#if (BLE_APP_BATT)
        case (TASK_ID_BASS):
        {
            // Call the Battery Module
            msg_pol = appm_get_handler(&app_batt_table_handler, msgid, param, src_id);
        }
        break;
#endif //(BLE_APP_BATT)

#if (BLE_APP_PROXR)
        case (TASK_ID_PROXR):
        {
            // Call the Battery Module
            msg_pol = appm_get_handler(&app_proxr_table_handler, msgid, param, src_id);
        }
        break;
#endif  //(BLE_APP_PROXR)

#if (BLE_APP_TIME)
        case (TASK_ID_TIPC):
        {
            // Call the Time Module
        } break;
#endif

#if (BLE_APP_OTAS)
        case (TASK_ID_OTAS):
        {
            msg_pol = appm_get_handler(&app_otas_table_handler, msgid, param, src_id);
        }
        break;
#endif // (BLE_APP_OTAS)

#if (BLE_APP_SPSS)
        case (TASK_ID_SPSS):
        {
            msg_pol = appm_get_handler(&app_spss_table_handler, msgid, param, src_id);
        }
        break;
#endif // (BLE_APP_SPSS)

#if (BLE_APP_MESH)
        case (TASK_ID_MESH):
        {
            msg_pol = appm_get_handler(&app_mesh_table_handler, msgid, param, src_id);
        }
        break;
#endif // (BLE_APP_SPSS)

#if (BLE_APP_SPSC)
        case (TASK_ID_SPSC):
        {
            msg_pol = appm_get_handler(&app_spsc_table_handler, msgid, param, src_id);
        }
        break;
#endif

#if (BLE_APP_FINDT)
        case (TASK_ID_FINDT):
        {
            msg_pol = appm_get_handler(&app_findt_table_handler, msgid, param, src_id);
        }
        break;
#endif

#if (BLE_APP_RTCTS)
        case (TASK_ID_RTCTS):
        {
            msg_pol = appm_get_handler(&app_rtcts_table_handler, msgid, param, src_id);
        }
        break;
#endif

#if (USER_FLOWER_CARE)
        case (TASK_ID_FLOWER_CLIENT):
        {
            msg_pol = appm_get_handler(&app_flower_table_handler, msgid, param, src_id);
        }
        break;
#endif //

        default:
        {
#if (BLE_APP_HID)
            if (msgid == APP_HID_KEYBOARD_TIMEOUT_TIMER)
            {
                msg_pol = appm_get_handler(&app_hid_table_handler, msgid, param, src_id);
            }
#endif //(BLE_APP_HID)
            //For user timer
            if (msgid >= APP_USER_TIMER_EVENT_START && msgid <= APP_USER_TIMER_EVENT_END)
            {
                app_user_timeout_handler(msgid, param, dest_id, src_id);
                return (KE_MSG_CONSUMED);
            }
        }
        break;
    }
//_exit:
    return (msg_pol);
}


static int app_enc_block_ind_handler(ke_msg_id_t const msgid,
                                     struct gapm_use_enc_block_ind *param,
                                     ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    if(app_env.func[APP_EVT_ID_GOT_AES128_RESULT] !=NULL)
        app_env.func[APP_EVT_ID_GOT_AES128_RESULT]((void *)param);

    return (KE_MSG_CONSUMED);
}

/*
 * GLOBAL VARIABLES DEFINITION
 ****************************************************************************************
 */
#if 0
extern int sbc_enc_timeout_handler(ke_msg_id_t const msgid,
                                   void const *param,
                                   ke_task_id_t const dest_id,
                                   ke_task_id_t const src_id);
extern int sbc_enc_frame_hander(ke_msg_id_t const msgid,
                                void *param,
                                ke_task_id_t const dest_id,
                                ke_task_id_t const src_id);
#endif
extern int app_mesh_store_info_timer_handler(ke_msg_id_t const msgid,
        void const *msg,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id);

/* Default State handlers definition. */
const struct ke_msg_handler appm_default_state[] =
{
    // Note: first message is latest message checked by kernel so default is put on top.
    {KE_MSG_DEFAULT_HANDLER,    (ke_msg_func_t)appm_msg_handler},

    {APP_ADV_TIMEOUT_TIMER,     (ke_msg_func_t)app_adv_timeout_handler},
    {APP_CON_TIMEOUT_TIMER,     (ke_msg_func_t)app_con_timeout_handler},

    {GAPM_DEVICE_READY_IND,     (ke_msg_func_t)gapm_device_ready_ind_handler},
    {GAPM_CMP_EVT,              (ke_msg_func_t)gapm_cmp_evt_handler},
    {GAPM_ADV_REPORT_IND,       (ke_msg_func_t)gapm_adv_report_ind_handler},
    {GAPM_ADDR_SOLVED_IND,      (ke_msg_func_t)gapm_addr_solved_ind_handler},
    {GAPC_CON_RSSI_IND,         (ke_msg_func_t)app_get_current_rssi_rsp},
    {GAPC_GET_DEV_INFO_REQ_IND, (ke_msg_func_t)gapc_get_dev_info_req_ind_handler},
    {GAPC_SET_DEV_INFO_REQ_IND, (ke_msg_func_t)gapc_set_dev_info_req_ind_handler},
    {GAPC_CONNECTION_REQ_IND,   (ke_msg_func_t)gapc_connection_req_ind_handler},
    {GAPC_CMP_EVT,              (ke_msg_func_t)gapc_cmp_evt_handler},
    {GAPC_DISCONNECT_IND,       (ke_msg_func_t)gapc_disconnect_ind_handler},

    {GAPM_WHITE_LIST_SIZE_IND,  (ke_msg_func_t)gapc_white_list_size_ind_handler},

    //DYC added to rsp the slave update param req
    {GAPC_PARAM_UPDATE_REQ_IND, (ke_msg_func_t)gapc_param_update_req_ind_handler},
    //DYC added for master get peer info
    {GAPC_PEER_FEATURES_IND,    (ke_msg_func_t)gapc_peer_features_ind_handler},

    {GAPM_USE_ENC_BLOCK_IND,    (ke_msg_func_t)app_enc_block_ind_handler},
#if BLE_APP_MESH
    {APP_MESH_STORE_INFO_TIMER, (ke_msg_func_t)app_mesh_store_info_timer_handler},
#endif
    {BUTTON_PRESSED_EVENT,      (ke_msg_func_t)app_button_process},

};

/* Specifies the message handlers that are common to all states. */
const struct ke_state_handler appm_default_handler = KE_STATE_HANDLER(appm_default_state);

/* Defines the place holder for the states of all the task instances. */
ke_state_t appm_state[APP_IDX_MAX];

#endif //(BLE_APP_PRESENT)

/// @} APPTASK
