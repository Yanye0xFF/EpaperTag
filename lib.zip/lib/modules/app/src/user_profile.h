/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_PROFILE_H_
#define USER_PROFILE_H_

#include <stdint.h>
#include <stdbool.h>

#include "ke_task.h"
#include "ke_msg.h"

#include "gattc_task.h"
#include "rwprf_config.h"

#ifndef USER_PROFILE_API_ENABLE
#define USER_PROFILE_API_ENABLE (1)
#endif

#ifndef PROFILE_TEST_ENABLE
#define PROFILE_TEST_ENABLE (0)
#endif

#define MAX_PEER_PRF_NUM (10)       //for client





#if USER_PROFILE_API_ENABLE

//inner function interface
bool check_user_svc_list(void);
struct prf_task_cbs* get_user_profile_default_itf(void);
void flush_all_user_svc_list(void);
#if PROFILE_TEST_ENABLE
void test_profile(void);
void test_profile_send_ntf(void);
void test_profile_client(void);
void test_profile_client_disc_all_svc(void);
#endif




/*
@ op_type ,only support: GATTC_NOTIFY / GATTC_INDICATE   GATTC_WRITE / GATTC_WRITE_NO_RESPONSE
*/
struct user_prf_pkt
{
    void        *packet;
    uint8_t     packet_size;
    uint8_t     op_type;
    uint8_t     att_idx;
    uint8_t     att_type;
    uint16_t    prf_id;
    uint16_t    seq_num;
};

/*
*   USER_API
*/
//For Client profile
enum prf_client_elem_type
{
    PRF_CLIENT_CHAR_TYPE,
    PRF_CLIENT_DESC_TYPE,
};

void user_profile_disc_all_svc(ke_task_id_t src_task, uint8_t conidx);
void user_profile_disc_svc(ke_task_id_t src_task, uint8_t conidx, uint8_t uuid_len, uint8_t *uuid);
void store_peer_prf_info(struct gattc_sdp_svc_ind const *ind, uint8_t nb_chars, void *chars_elem,
                         uint8_t nb_descs, void *descs_elem);

void regist_peer_prf_info(uint8_t conidx,uint16_t prf_id);
uint16_t user_profile_get_handle_from_peer_db(uint8_t type,uint8_t idx);
void user_profile_send_value_cmd(uint8_t conidx,struct user_prf_pkt *pkt_param);
void user_profile_read_value_cmd(uint8_t conidx,uint8_t type, uint8_t idx,uint8_t prf_id);
void user_profile_clr_peer_db(void);
uint8_t user_profile_is_peer_db_valid(void);
uint8_t user_profile_get_peer_svc_grp_num(void);



//For Server profile
typedef void (*user_prf_init_fnct)(void);
typedef void (*user_prf_destroy_fnct)(void);
typedef void (*user_prf_create_fnct)(uint8_t conidx);
typedef void (*user_prf_cleanup_fnct)(uint8_t conidx, uint8_t reason);

struct user_prf_task_cbs
{
    user_prf_init_fnct    init;
    user_prf_destroy_fnct destroy;
    user_prf_create_fnct  create;
    user_prf_cleanup_fnct cleanup;
};

typedef struct __svc_req__
{
    uint8_t  operation;
    uint8_t  sec_lvl;
    uint16_t prf_id;
    uint16_t app_task;
    uint16_t start_hdl;
} user_svc_req_t;

typedef struct __svc_cfg__
{
    uint16_t svc_uuid;
    struct attm_desc *svc_att_db;
    uint8_t *db_ext_uuid128;
    uint8_t svc_att_nb;
    void *svc_db_func;
} user_svc_cfg_t;

typedef enum
{
    ERR_OK,
    ERR_NO_MEM,
    ERR_OVER_PRF_MAX_NUM,
} prf_err_t;

uint16_t user_get_prf_task_num(uint16_t prf_id);
uint16_t user_get_prf_start_hdl(uint16_t prf_id);

uint16_t user_get_free_prf_id(void);
prf_err_t user_add_svc_to_list(user_svc_req_t *req,user_svc_cfg_t *cfg_param,struct user_prf_task_cbs *prf_cbs);
void user_del_svc_from_list(uint16_t prf_id);
void user_profile_reset_pkt_num(uint16_t profile_id);
uint16_t user_profile_get_pkt_num(uint16_t profile_id);

void user_profile_send_ntf(uint8_t conidx, struct user_prf_pkt *pkt_param);
void user_destroy_all_user_svc_db(void);
void user_change_svc_uuid(uint8_t prf_id,uint8_t idx,uint8_t *uuid,uint8_t uuid_len);
uint8_t user_get_free_prf_num(void);



#endif //end of #if USER_PROFILE_API_ENABLE



#endif // APP_HT_H_
