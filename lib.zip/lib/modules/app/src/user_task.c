#include <stdint.h>
#include <stdio.h>
#include "ke_msg.h"
#include "ke_task.h"
#include "ke_mem.h"
#include "ke_queue.h"
#include "ke_event.h"

#include "arch.h"
#include "user_task.h"
#include "user_msg_q.h"


#define TASK_DBG FR_DBG_OFF
#define TASK_LOG FR_LOG(TASK_DBG)

#define TASK_ASSERT(v) do { \
    if (!(v)) {             \
        printf("%s %s \n", __FILE__, __LINE__); \
        while (1) {};   \
    }                   \
} while (0);



struct ke_task_desc const null_task_desc  __attribute__((section("front_stack"))) =
{
    NULL,NULL,NULL,0,0,
};
#define TASK_NULL (&null_task_desc)



//֧���û������Լ���task
/// KE TASK element structure
struct ke_task_elem
{
    struct ke_task_desc const * p_desc;
};

/// KE TASK environment structure
struct ke_task_env_tag
{
    struct ke_task_elem *task_list;
};

//jump_table is fixed, so this point is fixed
struct ke_task_env_tag *ke_task_env_patch  __attribute__((section("front_stack"))) = (struct ke_task_env_tag *)0x200001a0;

uint8_t __attribute__((section("adv_sleep_code"))) ke_task_create(uint8_t task_type, struct ke_task_desc const * p_task_desc)
{
    uint8_t status = KE_TASK_OK;


    GLOBAL_INT_DISABLE();

    do
    {
        if(ke_task_env_patch->task_list[task_type].p_desc != TASK_NULL
           && ke_task_env_patch->task_list[task_type].p_desc != NULL)
        {
            status = KE_TASK_ALREADY_EXISTS;
            break;
        }

        // Save task descriptor
        ke_task_env_patch->task_list[task_type].p_desc = p_task_desc;
    }
    while(0);

    GLOBAL_INT_RESTORE();

    return (status);
}

uint8_t __attribute__((section("adv_sleep_code"))) ke_task_delete(uint8_t task_type)
{
    uint8_t status = KE_TASK_OK;

    if( task_type >= TASK_USER_START && task_type <= TASK_MAX )
    {
        if( ke_task_env_patch->task_list[task_type].p_desc != TASK_NULL
            && ke_task_env_patch->task_list[task_type].p_desc != NULL)
        {
            ke_free((void *)(ke_task_env_patch->task_list[task_type].p_desc->default_handler->msg_table));
            ke_free((void *)(ke_task_env_patch->task_list[task_type].p_desc->default_handler));
            ke_free((void *)(ke_task_env_patch->task_list[task_type].p_desc));
        }
    }

    GLOBAL_INT_DISABLE();

    do
    {
        // Clear task descriptor to task_null
        if( ke_task_env_patch->task_list[task_type].p_desc != TASK_NULL
            && ke_task_env_patch->task_list[task_type].p_desc != NULL)
        {
            ke_task_env_patch->task_list[task_type].p_desc = TASK_NULL;
        }
    }
    while(0);

    GLOBAL_INT_RESTORE();

    return (status);
}

bool cmp_dest_id(struct co_list_hdr const * msg, uint32_t dest_id)
{
    return ((struct ke_msg*)msg)->dest_id == dest_id;
}

/// Kernel environment definition
struct ke_env_tag
{
    /// Queue of sent messages but not yet delivered to receiver
    struct co_list queue_sent;
    /// Queue of messages delivered but not consumed by receiver
    struct co_list queue_saved;
} *ke_env_patch  __attribute__((section("front_stack"))) = (struct ke_env_tag *)0x2000078c;

void ke_task_saved_update(ke_task_id_t const ke_task_id)
{
    struct ke_msg * msg;
    //CPU_SR cpu_sr;
    struct co_list restore_list;

    co_list_init(&restore_list);

    for(;;)
    {
        // if the state has changed look in the Save queue if a message
        // need to be handled
        msg = (struct ke_msg*) ke_queue_extract(&ke_env_patch->queue_saved,
                                                &cmp_dest_id,
                                                (uint32_t) ke_task_id);

        if (msg == NULL) break;

        // Insert it back in the sent queue
        co_list_push_back(&restore_list, (struct co_list_hdr *)msg);
    }

    if(!co_list_is_empty(&restore_list))
    {
        GLOBAL_INT_DISABLE();
        restore_list.last->next = ke_env_patch->queue_sent.first;
        ke_env_patch->queue_sent.first = restore_list.first;
        if(ke_env_patch->queue_sent.last == NULL)
        {
            ke_env_patch->queue_sent.last = restore_list.last;
        }
        GLOBAL_INT_RESTORE();

        // trigger the event
        ke_event_set(KE_EVENT_KE_MESSAGE);
    }

    return;
}

void __attribute__((section("adv_sleep_code"))) ke_state_set(ke_task_id_t const id, ke_state_t const state_id)
{
    int idx = KE_IDX_GET(id);
    int type = KE_TYPE_GET(id);
    struct ke_task_desc const * p_task_desc = NULL;
    ke_state_t *ke_stateid_ptr = NULL;

    // sanity checks
    // ASSERT_ERR(type < (TASK_GAPC+1+__jump_table.prf_max));

    //if(type < (TASK_GAPC+1+__jump_table.prf_max))
    {
        p_task_desc = ke_task_env_patch->task_list[type].p_desc;
    }

    ASSERT_INFO( (p_task_desc != NULL && p_task_desc != TASK_NULL ), type, idx);
    ASSERT_INFO((idx < p_task_desc->idx_max), idx, p_task_desc->idx_max);

    // If the idx found is out of range return NULL
    if(idx < p_task_desc->idx_max)
    {
        // Get the state
        ke_stateid_ptr = &p_task_desc->state[idx];

        ASSERT_ERR(ke_stateid_ptr);

        // set the state
        if (*ke_stateid_ptr != state_id)
        {
            *ke_stateid_ptr = state_id;

            // if the state has changed update the SAVE queue
            ke_task_saved_update(id);
        }
    }
}


ke_state_t __attribute__((section("adv_sleep_code"))) ke_state_get(ke_task_id_t const id)
{
    int idx = KE_IDX_GET(id);
    int type = KE_TYPE_GET(id);
    struct ke_task_desc const * p_task_desc = NULL;
    ke_state_t state = 0xFF;

    //ASSERT_ERR(type < (TASK_GAPC+1+__jump_table.prf_max));

    //if(type < (TASK_GAPC+1+__jump_table.prf_max))
    {
        p_task_desc = ke_task_env_patch->task_list[type].p_desc;
    }

    ASSERT_INFO( (p_task_desc != NULL && p_task_desc != TASK_NULL ), type, idx);
    ASSERT_INFO((idx < p_task_desc->idx_max), idx, p_task_desc->idx_max);

    // If the idx found is out of range return NULL
    if(idx < p_task_desc->idx_max)
    {
        state = p_task_desc->state[idx];
    }

    // Get the state
    return state;
}





/*******Below is wrapped task func********/
#if USER_TASK_API_ENABLE

struct os_task_desc
{
    /// Pointer to the state handler table (one element for each state).
    struct os_state_handler* state_handler;
    /// Pointer to the default state handler (element parsed after the current state).
    struct os_state_handler* default_handler;
    /// Pointer to the state table (one element for each instance).
    ke_state_t* state;
    /// Maximum number of states in the task.
    uint16_t state_max;
    /// Maximum index of supported instances of the task.
    uint16_t idx_max;
};


uint8_t os_get_free_task_type(void)
{
    uint8_t task_type = TASK_USER_START;
    for(; task_type<TASK_MAX; task_type++)
    {
        if(ke_task_env_patch->task_list[task_type].p_desc == NULL
           || ke_task_env_patch->task_list[task_type].p_desc == TASK_NULL)
            return task_type;
    }
    return TASK_NONE;
}
uint8_t os_get_free_task_id_num(void)
{
    uint8_t num = 0;
    uint8_t task_type = TASK_USER_START;
    for(; task_type<TASK_MAX; task_type++)
    {
        if(ke_task_env_patch->task_list[task_type].p_desc == NULL
           || ke_task_env_patch->task_list[task_type].p_desc == TASK_NULL)
            num++;
    }
    return num;
}


static int os_default_task_func(ke_msg_id_t const msgid, void const *param,
                                ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    os_task_func_t task_func;
    struct ke_msg * msg =ke_param2msg(param);
    os_event_t evt;
    evt.event_id = msg->id;
    evt.param = msg->param;
    evt.param_len = msg->param_len;
    evt.src_task_id = msg->src_id;

//TASK_LOG("evt:%d,%p,%d,%d\r\n",evt.event_id,evt.param,evt.param_len,evt.src_task_id);

    task_func = (os_task_func_t)(ke_task_env_patch->task_list[dest_id].p_desc->default_handler->msg_table[0].func);
    return (task_func(&evt));
}


struct os_state_handler *from_task_func_to_state_handle(os_task_func_t task_func)
{
    struct ke_msg_handler *msg_hdl = (struct ke_msg_handler *)ke_malloc( sizeof(struct ke_msg_handler)<<1
                                     ,KE_MEM_NON_RETENTION);
    if(msg_hdl == NULL)
        return NULL;
    else
    {
        msg_hdl->id = KE_MSG_DEFAULT_HANDLER;
        msg_hdl->func = (ke_msg_func_t)task_func;
        ((struct ke_msg_handler *)(msg_hdl + 1))->id = KE_MSG_DEFAULT_HANDLER;
        ((struct ke_msg_handler *)(msg_hdl + 1))->func = os_default_task_func;
    }

    struct os_state_handler *tmp_state_hdl = (struct os_state_handler *)ke_malloc(sizeof(struct os_state_handler)
            ,KE_MEM_NON_RETENTION);
    if(tmp_state_hdl == NULL)
    {
        ke_free(msg_hdl);
        return NULL;
    }

    tmp_state_hdl->msg_table = msg_hdl;
    tmp_state_hdl->msg_cnt = 2;

    return tmp_state_hdl;
}

static struct os_task_desc * os_build_task_desc(os_task_func_t task_func)
{
    struct os_state_handler *tmp_state_hdl = from_task_func_to_state_handle(task_func);
    if(tmp_state_hdl == NULL)
        return NULL;

    struct os_task_desc *tmp_desc = (struct os_task_desc *)ke_malloc(sizeof(struct os_task_desc)
                                    ,KE_MEM_NON_RETENTION);
    if(tmp_desc == NULL)
    {
        ke_free(tmp_state_hdl->msg_table);
        ke_free(tmp_state_hdl);
        return NULL;
    }
    TASK_LOG("tmp_desc:%p\r\n",tmp_desc);

    tmp_desc->state_handler = NULL;
    tmp_desc->default_handler = tmp_state_hdl;
    tmp_desc->state = NULL;
    tmp_desc->state_max = 1;
    tmp_desc->idx_max = 1;
    TASK_LOG("build_desc_out\r\n");
    return tmp_desc;
}


uint8_t os_task_create_x(os_task_func_t task_func,uint8_t *task_id,uint8_t fixed_task_id)
{
    uint8_t tmp_id;
    if(fixed_task_id == 0)
        tmp_id =  os_get_free_task_type();
    else
        tmp_id = fixed_task_id;

    uint8_t task_create_ret = 0;

    TASK_LOG("tmp_id:%d\r\n",tmp_id);

    if(tmp_id == TASK_NONE)
        return KE_TASK_ID_FULL;

    struct os_task_desc * desc = os_build_task_desc(task_func);
    TASK_LOG("malloc desc ok:%p\r\n",desc);

    if(desc == NULL)
        return KE_TASK_MEM_NULL;

    task_create_ret = ke_task_create(tmp_id, (struct ke_task_desc *)desc);
    TASK_LOG("create ret:%d\r\n",task_create_ret);

    if(task_create_ret == KE_TASK_OK)
    {
        *task_id = tmp_id;
    }
    else
    {
        ke_free(desc->default_handler->msg_table);
        ke_free(desc->default_handler);
        ke_free(desc);
    }

    return task_create_ret;
}
uint8_t os_task_create(os_task_func_t task_func,uint8_t *task_id)
{
    return os_task_create_x(task_func,task_id,0);
}





#if (TASK_TEST_ENABLE)

uint8_t temp_id[3] = {TASK_NONE,TASK_NONE,TASK_NONE};
void user_task_test2_0(void);

int task0_func(os_event_t *msg)
{
    switch(msg->event_id)
    {
        case 0:
        {
            printf("%p,%d\r\n",msg->param,msg->param_len);
            printf("h0f0:");
            if(msg->param_len != 0)
                printf("%d",*(uint8_t *)msg->param);
            printf("\r\n");

            if(msg->src_task_id == TASK_NONE)
            {
                uint8_t *evt;
                evt = ke_msg_alloc(1,temp_id[0],temp_id[0],1);
                *evt = 11;
                ke_msg_send(evt);
            }
            else
            {
                user_task_test2_0();
                printf("delete_all_task\r\n");
            }
        }
        break;
        case 1:
        {
            printf("h0f1:%d\r\n",*(uint8_t *)msg->param);
            uint8_t *evt;
            evt = ke_msg_alloc(0,temp_id[1],temp_id[0],1);
            *evt = 12;
            ke_msg_send(evt);
        }
        break;

        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}
int task1_func(os_event_t *msg)
{
    switch(msg->event_id)
    {
        case 0:
        {
            printf("h1f0:%d\r\n",*(uint8_t *)msg->param);
            uint8_t *evt;
            evt = ke_msg_alloc(1,temp_id[1],temp_id[1],1);
            *evt = 13;
            ke_msg_send(evt);
        }
        break;
        case 1:
        {
            printf("h1f1:%d\r\n",*(uint8_t *)msg->param);
            uint8_t *evt;
            evt = ke_msg_alloc(0,temp_id[2],temp_id[1],1);
            *evt = 14;
            ke_msg_send(evt);
        }
        break;

        default:
            break;
    }

    return (KE_MSG_CONSUMED);
}
int task2_func(os_event_t *msg)
{
    switch(msg->event_id)
    {
        case 0:
        {
            printf("h2f0:%d\r\n",*(uint8_t *)msg->param);

            uint8_t value = 15;
            os_event_t evt;
            evt.event_id = 1;
            evt.param_len = sizeof(value);
            evt.param = &value;
            evt.src_task_id = temp_id[2];
            os_msg_post(temp_id[2],&evt);
        }
        break;
        case 1:
        {
            printf("h2f1:%d\r\n",*(uint8_t *)msg->param);
            uint8_t value = 16;

            os_event_t evt;
            evt.event_id = 0;
            evt.param_len = 0;
            evt.param = NULL;
            evt.src_task_id = temp_id[2];
            os_msg_post(temp_id[0],&evt);
        }
        break;
        default:
            break;
    }

    return (KE_MSG_CONSUMED);
}



void user_task_test1(void)
{

    printf("initing\r\n");
    printf("task_free_num:%d,next_task_type:%d\r\n",os_get_free_task_id_num(),os_get_free_task_type());

    os_task_create(task0_func,&temp_id[0]);
    os_task_create(task1_func,&temp_id[1]);
    os_task_create(task2_func,&temp_id[2]);
    printf("after task create\r\n");
    printf("task occupied:%d,%d,%d\r\n",temp_id[0],temp_id[1],temp_id[2]);
    printf("task_free_num:%d,next_task_type:%d\r\n",os_get_free_task_id_num(),os_get_free_task_type());
    os_task_delete(temp_id[0]);
    os_task_delete(temp_id[1]);
    os_task_delete(temp_id[2]);
    printf("after task free\r\n");
    printf("task_free_num:%d,next_task_type:%d\r\n",os_get_free_task_id_num(),os_get_free_task_type());
    ;
}

void user_task_test2(void)
{
    if ( os_task_create( task0_func,&temp_id[0] ) != KE_TASK_OK )
    {
        printf("task0 create fail \r\n");
        goto _exit;
    }
    if ( os_task_create( task1_func,&temp_id[1] ) != KE_TASK_OK )
    {
        printf("task1 create fail \r\n");
        goto _exit;
    }
    if ( os_task_create( task2_func,&temp_id[2] ) != KE_TASK_OK )
    {
        printf("task2 create fail \r\n");
        goto _exit;
    }

    printf("created_task_id:%d,%d,%d\r\n",temp_id[0],temp_id[1],temp_id[2]);

    uint8_t *msg;
    msg = ke_msg_alloc(0,temp_id[0],TASK_NONE,1);
    *msg = 10;
    ke_msg_send(msg);

_exit:
    ;
}
void user_task_test2_0(void)
{
    os_task_delete(temp_id[0]);
    os_task_delete(temp_id[1]);
    os_task_delete(temp_id[2]);
}

#endif      // end of #if (TASK_TEST_ENABLE)


#endif      //end of #if USER_TASK_API_ENABLE



