#include <stdint.h>
#include <stdio.h>
#include "co_utils.h"

//const char c_lib_hex2char[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

uint8_t hex4bit_to_ascii_char(uint8_t hex_value)
{
    if(hex_value < 10)
        return (hex_value + '0');
    else
        return ( (hex_value-10) + 'a');
    //return c_lib_hex2char[hex_value];
}
uint8_t hex4bit_to_big_ascii_char(uint8_t hex_value)
{
    if(hex_value < 10)
        return (hex_value + '0');
    else
        return ( (hex_value-10) + 'A');
    //return c_lib_hex2char[hex_value];
}

void hex_arr_to_ascii_str(uint8_t *str, const uint8_t hex_arr[],uint8_t arr_len)
{
    for(uint8_t i = 0; i < arr_len; i++)
    {
        sprintf((char *)(str+i*2),"%02X",hex_arr[i]);
    }
}
void ascii_str_to_hex_arr(uint8_t hex_arr[],uint8_t *str, uint8_t arr_len)
{
    for(uint8_t i = 0; i < arr_len; i++)
    {
        hex_arr[i] = (uint8_t)ascii_strn2val((const char *)(str+i*2),16,2);
        //   printf("asII:%x\r\n",addr[i]);
    }
}

void int_to_ascii_str(uint8_t *str, const uint32_t int_value)
{
    sprintf((char *)str,"%d",int_value);
}



char char2int(const char c)
{
    if(c>='0' && c<='9')
        return c-'0';
    if((c>='a' && c<='f') || (c>='A' && c<='F'))
        return (c&0x7)+9;
    return (char)(-1);
}


