#include "rwip_config.h"

#if BLE_APP_RTCTS

#include "gapm_task.h"

#include "rtcts_task.h"

void app_rtcts_init(void)
{

}

void app_rtcts_add_rtctss(void)
{
    struct gapm_profile_task_add_cmd *req = KE_MSG_ALLOC(GAPM_PROFILE_TASK_ADD_CMD,
                                            TASK_GAPM, TASK_APP,
                                            gapm_profile_task_add_cmd);

    // Fill message
    req->operation   = GAPM_PROFILE_TASK_ADD;
    req->sec_lvl     = PERM(SVC_AUTH, ENABLE);
    req->prf_task_id = TASK_ID_RTCTS;
    req->app_task    = TASK_APP;
    req->start_hdl   = 0;

    // Send the message
    ke_msg_send(req);
}

void app_rtcts_enable_prf(uint8_t conidx)
{
    printf("rtcts connected to 0x%02x.\r\n", conidx);
}

//extern uint8_t sbc_avaliable_queue;
//extern void sbc_send_data(void);
static int app_rtcts_send_rsp_handler(ke_msg_id_t const msgid,
                                      struct rtcts_send_rsp_t const *rsp,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    if(rsp->status != 0x00)
    {
        printf("error: 0x%02x.\r\n", rsp->status);
    }
    return KE_MSG_CONSUMED;
}

/// Default State handlers definition
const struct ke_msg_handler app_rtcts_msg_handler_list[] =
{
    {RTCTS_SEND_RSP,            (ke_msg_func_t)app_rtcts_send_rsp_handler},
};

const struct ke_state_handler app_rtcts_table_handler =
{&app_rtcts_msg_handler_list[0], (sizeof(app_rtcts_msg_handler_list)/sizeof(struct ke_msg_handler))};

#endif  //BLE_APP_RTCTS
