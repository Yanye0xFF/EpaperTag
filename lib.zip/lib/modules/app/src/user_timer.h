/**
 ****************************************************************************************
 *
 * @file app_ht.h
 *
 * @brief Health Thermometer Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef USER_TIME_H_
#define USER_TIME_H_

#include <stdint.h>
#include <stdbool.h>

#ifndef USER_TIMER_API_ENABLE
#define USER_TIMER_API_ENABLE (1)
#endif

#ifndef TIME_TEST_ENABLE
#define TIME_TEST_ENABLE (0)
#endif




typedef void(* os_timer_func_t)(void *parg);

typedef struct os_timer_struct
{
    struct os_timer_struct *timer_next;
    uint32_t timer_period;      //for loop OR period =0 for single run.
    os_timer_func_t timer_func;
    void *timer_arg;
    uint16_t timer_id;
} os_timer_t;



#if USER_TIMER_API_ENABLE
void check_timer_handle(uint16_t timer_id);

#if TIME_TEST_ENABLE
//for test
void user_timer_test(void);
#endif


/*
* USER_API
*/
void os_timer_setfn(os_timer_t *ptimer, os_timer_func_t pfunction, void *parg);
void os_timer_arm(os_timer_t *ptimer,uint32_t ms, bool repeat_flag);
void os_timer_disarm(os_timer_t *ptimer);

#endif   //end of #if USER_TIMER_API_ENABLE



#endif // APP_HT_H_
