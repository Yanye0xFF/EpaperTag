#include <stdint.h>
#include <stdio.h>

#include "co_bt.h"
#include "co_math.h"

#include "gapc_task.h"

#define APP_DB_COUNT_MAX        CFG_MAX_CON
#define APP_DB_KEY_TABLE_MAX    8
#define APP_DB_ENV_STATIC       1

#define APP_KEY_VALID_BDADDR    CO_BIT(0)
#define APP_KEY_VALID_BONDED    CO_BIT(1)
#define APP_KEY_VALID_LTK       CO_BIT(2)
#define APP_KEY_VALID_CSRK      CO_BIT(3)
#define APP_KEY_VALID_IRK       CO_BIT(4)

struct app_key_table_t
{
    uint8_t valid;

    /// Peer address type
    uint8_t peer_addr_type;
    /// Peer BT address
    struct bd_addr peer_addr;

    uint8_t auth;

    struct gapc_ltk ltk;

    struct gap_sec_key irk;

    /// Local CSRK value
    struct gap_sec_key lcsrk;
    /// Local signature counter value
    uint32_t lsign_counter;

    /// Remote CSRK value
    struct gap_sec_key rcsrk;
    /// Remote signature counter value
    uint32_t rsign_counter;
};

struct app_db_t
{
    uint8_t used;
    uint8_t conidx;

    struct app_key_table_t key;
};

#if APP_DB_ENV_STATIC
struct app_key_table_t app_db_key_table_static[APP_DB_KEY_TABLE_MAX];
struct app_db_t app_db_env_static[APP_DB_COUNT_MAX];
#endif

struct app_db_t *app_db_env = app_db_env_static;

uint8_t app_db_find_dev_by_bdaddr(struct bd_addr *bdaddr, uint8_t addr_type);

uint8_t app_db_alloc_dev(struct bd_addr *bdaddr, uint8_t addr_type, uint8_t conidx)
{
    uint8_t i;

    /*
        1. �������е�env�в����Ƿ��ж�Ӧ�ĵ�ַ�������ֱ�Ӳ��ã�����ʹ��֮ǰ��key
        2. ���û���ҵ��ͷ���һ��û�б�ռ�õĿռ䣬���ҳ�ʼ��key��TBD�������ʼ��
            key��������flash�е�key���ݿ���в��ң�����ҵ��Ͳ��ô洢�����ݳ�ʼ����
            ���û�����ʼ��Ϊû��key���ڡ�
    */

    i = app_db_find_dev_by_bdaddr(bdaddr, addr_type);
    if(i == GAP_INVALID_CONIDX)
    {
        for(i=0; i<APP_DB_COUNT_MAX; i++)
        {
            if(app_db_env[i].used == false)
            {
                break;
            }
        }

        if(i != APP_DB_COUNT_MAX)
        {
            app_db_env[i].used = true;
            app_db_env[i].conidx = conidx;
            memset((void *)&app_db_env[i].key, 0, sizeof(struct app_key_table_t));
            app_db_env[i].key.valid = APP_KEY_VALID_BDADDR;
            app_db_env[i].key.peer_addr_type = addr_type;
            memcpy((void *)&app_db_env[i].key.peer_addr, (void *)bdaddr, 6);
        }
        else
        {
            i = GAP_INVALID_CONIDX;
        }
    }
    else
    {
        app_db_env[i].used = true;
    }

    return i;
}

uint8_t app_db_alloc_dev_from_irk(struct bd_addr *bdaddr, uint8_t addr_type, uint8_t conidx, struct gap_sec_key *key)
{
    uint8_t i;

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if((app_db_env[i].key.valid & APP_KEY_VALID_IRK)
           &&(memcmp((void *)key, (void *)&app_db_env[i].key.irk, sizeof(struct gap_sec_key)) == 0))
        {
            break;
        }
    }

    if(i == APP_DB_COUNT_MAX)
    {
        return GAP_INVALID_CONIDX;
    }
    else
    {
        app_db_env[i].used = true;
        app_db_env[i].conidx = conidx;
        memcpy((void *)&app_db_env[i].key.peer_addr, (void *)bdaddr, 6);
        return i;
    }
}

void app_db_release_dev(uint8_t conidx)
{
    uint8_t i;

    /*
        TBD���������Ч��key��������Ҫ��key���浽flash�У�����������в���
    */

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if((app_db_env[i].used) && (app_db_env[i].conidx == conidx))
        {
            app_db_env[i].used = false;
            break;
        }
    }
}

uint8_t app_db_find_dev_by_bdaddr(struct bd_addr *bdaddr, uint8_t addr_type)
{
    uint8_t i;

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if(app_db_env[i].key.valid & APP_KEY_VALID_BDADDR)
        {
            if((app_db_env[i].key.peer_addr_type == addr_type)
               &&((memcmp((void *)bdaddr, (void *)&app_db_env[i].key.peer_addr, 6))==0))
            {
                break;
            }
        }
    }

    if(i == APP_DB_COUNT_MAX)
    {
        i = GAP_INVALID_CONIDX;
    }

    return i;
}

uint8_t app_db_find_dev_by_conidx(uint8_t conidx)
{
    uint8_t i;

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if((app_db_env[i].used) && (app_db_env[i].conidx == conidx))
        {
            break;
        }
    }

    if(i == APP_DB_COUNT_MAX)
    {
        i = GAP_INVALID_CONIDX;
    }

    return i;
}

void app_db_store_key(uint8_t conidx, uint8_t key_type, void *key)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return;
    }

    switch(key_type)
    {
        case GAPC_LTK_EXCH:
            memcpy((void *)&app_db_env[i].key.ltk, key, sizeof(struct gapc_ltk));
            app_db_env[i].key.valid |= APP_KEY_VALID_LTK;
            break;
        case GAPC_IRK_EXCH:
            memcpy((void *)&app_db_env[i].key.irk, key, sizeof(struct gap_sec_key));
            app_db_env[i].key.valid |= APP_KEY_VALID_IRK;
            break;
    }
}

uint8_t app_db_load_key(uint8_t conidx, uint8_t key_type, void *key)
{
    uint8_t ret = false;
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return ret;
    }

    switch(key_type)
    {
        case GAPC_LTK_EXCH:
            if(app_db_env[i].key.valid & APP_KEY_VALID_LTK)
            {
                memcpy(key, (void *)&app_db_env[i].key.ltk, sizeof(struct gapc_ltk));
                ret = true;
            }
            break;
    }

    return ret;
}

uint8_t app_db_check_ediv_rand(struct gapc_encrypt_req_ind *param, uint8_t conidx)
{
    uint8_t ret = false;
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return ret;
    }

    if(app_db_env[i].key.valid & APP_KEY_VALID_LTK)
    {
        if ((param->ediv == app_db_env[i].key.ltk.ediv) &&
            !memcmp(&param->rand_nb.nb[0], &app_db_env[i].key.ltk.randnb.nb[0], sizeof(struct rand_nb)))
        {
            ret = true;
        }
    }

    return ret;
}

uint8_t app_db_set_auth(uint8_t conidx, uint8_t auth)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return false;
    }

    app_db_env[i].key.auth = auth;

    return true;
}

uint8_t app_db_get_auth(uint8_t conidx, uint8_t *auth)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return false;
    }

    *auth = app_db_env[i].key.auth;

    return true;
}

uint8_t app_db_set_bonded(uint8_t conidx, bool bonded)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return false;
    }

    if(bonded)
    {
        app_db_env[i].key.valid |= APP_KEY_VALID_BONDED;
    }
    else
    {
        app_db_env[i].key.valid &= (~APP_KEY_VALID_BONDED);
    }

    return true;
}

uint8_t app_db_get_bonded(uint8_t conidx)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return false;
    }

    if(app_db_env[i].key.valid & APP_KEY_VALID_BONDED)
    {
        return true;
    }
    else
    {
        return false;
    }
}

uint8_t app_db_get_irk_count(void)
{
    uint8_t i, count=0;

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if(app_db_env[i].key.valid & APP_KEY_VALID_IRK)
        {
            count++;
        }
    }

    return count;
}

void app_db_fill_irks(struct gap_sec_key *keys)
{
    uint8_t i;

    for(i=0; i<APP_DB_COUNT_MAX; i++)
    {
        if(app_db_env[i].key.valid & APP_KEY_VALID_IRK)
        {
            memcpy((void *)keys, (void *)&app_db_env[i].key.irk, sizeof(struct gap_sec_key));
            keys++;
        }
    }
}

uint8_t app_db_fill_connect_cfm(uint8_t conidx, struct gapc_connection_cfm *cfm)
{
    uint8_t i;

    i = app_db_find_dev_by_conidx(conidx);
    if(i == GAP_INVALID_CONIDX)
    {
        return false;
    }

    cfm->auth = app_db_env[i].key.auth;
    if(app_db_env[i].key.valid & APP_KEY_VALID_LTK)
    {
        cfm->ltk_present = true;
    }

    if(app_db_env[i].key.valid & APP_KEY_VALID_CSRK)
    {
        cfm->lsign_counter = app_db_env[i].key.lsign_counter;
        memcpy((void*)&cfm->lcsrk, (void *)&app_db_env[i].key.lcsrk, sizeof(struct gap_sec_key));
        cfm->rsign_counter = app_db_env[i].key.rsign_counter;
        memcpy((void*)&cfm->rcsrk, (void *)&app_db_env[i].key.rcsrk, sizeof(struct gap_sec_key));
    }
}

void app_db_env_init(void)
{
    memset((void *)app_db_env, 0, sizeof(struct app_db_t) * APP_DB_COUNT_MAX);
}

