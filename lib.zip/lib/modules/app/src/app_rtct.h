#include "rwip_config.h"

#if BLE_APP_RTCTS

void app_rtcts_init(void);
void app_rtcts_add_rtctss(void);
void app_rtcts_enable_prf(uint8_t conidx);

extern const struct ke_state_handler app_rtcts_table_handler;

#endif  //BLE_APP_RTCTS

