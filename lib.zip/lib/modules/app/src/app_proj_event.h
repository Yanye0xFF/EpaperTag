/**
****************************************************************************************
*
* @file app_template_proj.h
*
* @brief Template application header file.
*
* Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
*
* <bluetooth.support@diasemi.com> and contributors.
*
****************************************************************************************
*/

#ifndef APP_PROJ_EVENT_H_
#define APP_PROJ_EVENT_H_

/**
 ****************************************************************************************
 * @addtogroup APP
 * @ingroup RICOW
 *
 * @brief
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwble_config.h"
#include "app_task.h"                  // application task
#include "gapc_task.h"                 // gap functions and messages
#include "gapm_task.h"                 // gap functions and messages
#include "app.h"                       // application definitions
#include "co_error.h"                  // error code definitions
#include "app_sec.h"
#include "ke_msg.h"


/****************************************************************************
Define device name. Used in Advertise string
*****************************************************************************/

void * get_stored_info_req(uint8_t info_type);



/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
void app_init_ind_func(void);

void app_connection_paring_info_ind_func(void * buf,uint32_t len,uint8_t info_type);
void app_connection_master_encrypted_ind_func(uint8_t conidx);
void app_connection_slave_encrypted_ind_func(uint8_t conidx);
void app_device_ready_ind_func(void);
void app_reset_complete_ind_func(void);
void app_set_dev_config_complete_ind_func(void);
void app_adv_complete_ind_func(struct gapm_cmp_evt const *param);
void app_scanning_completed_ind_func(uint8_t status);
void app_connect_failed_ind_func(uint8_t status);
void app_get_info_ind_func(uint8_t conidx, void *param,uint8_t operation);
void app_connection_success_ind_func(uint8_t conidx,struct gapc_connection_req_ind const *arg);
void app_connection_req_ind_func(uint8_t conidx,struct gapc_connection_req_ind const *arg);
void app_update_params_rejected_ind_func(uint8_t conidx,uint8_t status);
void app_update_params_complete_ind_func(uint8_t conidx);
void app_connection_master_encrypt_compeleted_ind_func(uint8_t conidx , uint8_t status);
void app_adv_report_ind_func(struct gapm_adv_report_ind *param);
void app_disconnect_ind_func(ke_task_id_t task_id, struct gapc_disconnect_ind const *param);
void app_svc_added_ind_func(struct gapm_profile_added_ind *param);
void app_db_init_complete_ind_func(void);
void app_update_params_update_ind_func(uint8_t conidx,struct gapc_param_updated_ind *param);
void app_addr_resolve_result_ind_func(uint8_t conidx, uint8_t status, struct gapm_addr_solved_ind const *param);

#endif //APP_TEMPLATE_PROJ_H_
