#ifndef _ANCS_PROFILE_CLIENT_H
#define _ANCS_PROFILE_CLIENT_H

enum ancs_client_char_idx
{
    ANCS_CHAR_IDX_NTF_CTRL,      //18
    ANCS_CHAR_IDX_NTF_SRC,      //27
    ANCS_CHAR_IDX_DATA_SRC,      //33
    ANCS_CHAR_MAX,
};
#define NTF_CENTER_UUID1       {0xd9, 0xd9, 0xaa, 0xfd, 0xbd, 0x9b, 0x21, 0x98, \
                                            0xa8, 0x49, 0xe1, 0x45, 0xf3,0xd8, 0xd1, 0x69}
#define NTF_CENTER_UUID2       {0xbd, 0x1d, 0xa2, 0x99, 0xe6, 0x25, 0x58, 0x8c, \
                                            0xd9, 0x42, 0x01, 0x63, 0x0d,0x12, 0xbf, 0x9f}
#define NTF_CENTER_UUID3       {0xfb, 0x7b, 0x7c, 0xce, 0x6a, 0xb3, 0x44, 0xbe, \
                                            0xb5, 0x4b, 0xd6, 0x24, 0xe9,0xc6, 0xea, 0x22}
enum demo_client_desc_idx
{
    ANCS_DESC_IDX_NTF_SRC,      //19
    ANCS_DESC_IDX_DATA_SRC,      //54
    ANCS_DESC_MAX,
};

extern uint16_t ancs_profile_client_id;
void ancs_prf_client_add_to_db_list(void);
void ancs_prf_client_disc_svc(uint8_t conidx);
void ancs_enable_ntf(uint8_t conidx);

#endif  //_TSK_TEMPLATE_H
