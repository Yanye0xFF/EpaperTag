/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdio.h>
#include "arch.h"
#include "user_profile.h"
#include "attm.h"       //for struct attm_desc
#include "gattc_task.h"     //for prf_task_func operation
#include "gapm_task.h"      //for marco GAPM_PROFILE_TASK_ADD
#include "att.h"        //for UUID marcos

#include "gapc_task.h"        //for ble api
#include "app.h"        //

#include "user_msg_q.h" //for os_msg_post
#include "user_mem.h"
#include "prf_types.h"        //for ble api
#include "app_sec.h"
#include "ancs_profile_client.h"

#ifdef CFG_PRF_IPHONE_ANCS


struct prf_char_def_uuid128 ancs_client_elem_char[ANCS_CHAR_MAX] =
{
    [ANCS_CHAR_IDX_NTF_CTRL]  =      //18
    { ATT_UUID_128_LEN,  NTF_CENTER_UUID1,     ATT_MANDATORY,0,0xff},
    [ANCS_CHAR_IDX_NTF_SRC]  =      //27
    { ATT_UUID_128_LEN,  NTF_CENTER_UUID2,     ATT_MANDATORY,0,0xff},
    [ANCS_CHAR_IDX_DATA_SRC]  =      //33
    { ATT_UUID_128_LEN,  NTF_CENTER_UUID3,     ATT_MANDATORY,0,0xff},
};

struct prf_char_desc_def_uuid128 ancs_client_elem_desc[ANCS_DESC_MAX] =
{
    [ANCS_DESC_IDX_NTF_SRC]   = {ATT_UUID_16_LEN, ATT_UUID_ARRAY(ATT_DESC_CLIENT_CHAR_CFG), ATT_OPTIONAL, ANCS_CHAR_IDX_NTF_SRC,0xff},     //19
    [ANCS_DESC_IDX_DATA_SRC]   = {ATT_UUID_16_LEN, ATT_UUID_ARRAY(ATT_DESC_CLIENT_CHAR_CFG), ATT_OPTIONAL, ANCS_CHAR_IDX_DATA_SRC,0xff},     //54
};
void __attribute__((weak)) ancs_prf_client_recv_value(uint8_t conidx, struct gattc_event_ind *param)
{
    ;
}
uint16_t ancs_profile_client_id = 0;
static uint8_t registed_num = 0;
static int ancs_profile_client_task_func(os_event_t *msg)
{
    printf("ancs_prf_tsk:%x\r\n",msg->event_id);
    switch(msg->event_id)
    {
        case GATTC_READ_IND:    //0xc09
        {
            ;
        }
        break;
        case GATTC_SDP_SVC_IND:   //0xC1A
        {
            store_peer_prf_info(msg->param, ANCS_CHAR_MAX, &ancs_client_elem_char[0], ANCS_DESC_MAX, &ancs_client_elem_desc[0]);
        }
        break;
        case GATTC_EVENT_IND:    //0xC0C
        {
            struct gattc_event_ind *param = (struct gattc_event_ind *)msg->param;
            ancs_prf_client_recv_value(KE_IDX_GET(msg->src_task_id),param);
        }
        break;
        case GATTC_CMP_EVT:     //0xC00
        {
            struct gattc_cmp_evt *param = (struct gattc_cmp_evt *)msg->param;
            switch(param->operation)
            {
                case GATTC_SDP_DISC_SVC_ALL:
                    ;
                    break;
                case GATTC_SDP_DISC_SVC:
                    if(user_profile_get_peer_svc_grp_num()>0)
                    {
                        regist_peer_prf_info(KE_IDX_GET(msg->src_task_id),ancs_profile_client_id);
                        app_sec_send_security_req( KE_IDX_GET(msg->src_task_id) );
                    }
                    break;
                case GATTC_REGISTER:
                    registed_num++;
                    if(registed_num >= user_profile_get_peer_svc_grp_num())
                    {
                        ancs_enable_ntf(KE_IDX_GET(msg->src_task_id));
                    }
                    //printf("Client prf reg done,hdl:%d,%d\r\n",user_profile_get_handle_from_peer_db(PRF_CLIENT_CHAR_TYPE,ANCS_CHAR_IDX_NTF_CTRL)
                    //,user_profile_get_handle_from_peer_db(PRF_CLIENT_DESC_TYPE,ANCS_DESC_IDX_NTF_SRC));
                    break;
                default:
                    break;
            }
            //printf("cmp_evt,operation:%d,status:%x,seqnum:%d\r\n",param->operation,param->status,param->seq_num);
        }
        break;
        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}

static void create2(uint8_t conidx)
{
    printf("create2\r\n");

    registed_num = 0;
    if( user_profile_is_peer_db_valid() )
    {
        regist_peer_prf_info(conidx,ancs_profile_client_id);
    }
}

static void cleanup2(uint8_t conidx, uint8_t reason)
{
    printf("cleanup2:%d,reason(ll code):%X\r\n",conidx,reason);
    /**
    Important:  If you don't want to rediscovery all peer svc. don't free peer_db();
    if peer_db() is not free, then inner will keep the allocated memory for it.
    **/
    //user_profile_clr_peer_db();
}
void ancs_enable_ntf(uint8_t conidx)
{
    if(user_profile_is_peer_db_valid())
    {
        uint8_t data[2];
        data[0] = 0x01;
        data[1] = 0x00;
        struct user_prf_pkt pkt_param;
        pkt_param.att_idx = ANCS_DESC_IDX_NTF_SRC;
        pkt_param.att_type = PRF_CLIENT_DESC_TYPE;
        pkt_param.op_type = GATTC_WRITE;
        pkt_param.prf_id = ancs_profile_client_id;
        pkt_param.packet = data;
        pkt_param.packet_size = 2;
        user_profile_send_value_cmd(conidx,&pkt_param);

        pkt_param.att_idx = ANCS_DESC_IDX_DATA_SRC;
        user_profile_send_value_cmd(conidx,&pkt_param);
    }
}


void ancs_prf_client_disc_svc(uint8_t conidx)
{
    uint8_t ancs_svc_uuid[]= {0xd0,0x00,0x2d,0x12,0x1e,0x4b,0x0f,0xa4,0x99,0x4e,0xce,0xb5,0x31,0xf4,0x05,0x79};
    if( !user_profile_is_peer_db_valid() )
        user_profile_disc_svc(user_get_prf_task_num(ancs_profile_client_id),conidx,ATT_UUID_128_LEN,ancs_svc_uuid);
    else
    {
        if(app_env.encrypted == false)
            app_sec_send_security_req(conidx);
    }
}




//when device is ready ,call this, then call add_svc
void ancs_prf_client_add_to_db_list(void)
{
    user_svc_req_t req;
    req.app_task = TASK_APP;
    req.prf_id = user_get_free_prf_id();
    req.operation   = GAPM_PROFILE_TASK_ADD;
    req.sec_lvl     = 0;
    req.start_hdl   = 0;

    user_svc_cfg_t cfg;
    cfg.svc_uuid = 0;
    cfg.svc_att_db = NULL;          //must be NULL;
    cfg.svc_att_nb = 0;
    cfg.svc_db_func = ancs_profile_client_task_func;
    cfg.db_ext_uuid128 = NULL;

    struct user_prf_task_cbs prf_cbs;
    prf_cbs.init = NULL;
    prf_cbs.destroy = NULL;
    prf_cbs.create = create2;
    prf_cbs.cleanup = cleanup2;

    if(user_add_svc_to_list(&req,&cfg,&prf_cbs) == ERR_OK)
        ancs_profile_client_id = req.prf_id;
}


#endif






