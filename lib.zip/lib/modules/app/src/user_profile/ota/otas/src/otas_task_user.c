#include "rwip_config.h"

#if BLE_OTA_SERVER

#include "gap.h"
#include "gattc_task.h"
#include "attm.h"
#include "atts.h"
#include "otas_user.h"
#include "otas_task_user.h"

#include "prf_utils.h"

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref  GATTC_WRITE_REQ_IND message.
 * The message is redirected from TASK_SVC because at profile enable, the ATT handle is
 * register for TASK_FINDT. In the handler, an ATT Write Response/Error Response should
 * be sent for ATT protocol, but Alert Level Characteristic only supports WNR so no
 * response PDU is needed.
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_write_req_ind_handler(ke_msg_id_t const msgid,
                                       struct gattc_write_req_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(src_id);
    uint16_t notify_state;
    // Allocate write confirmation message.
    struct gattc_write_cfm *cfm = KE_MSG_ALLOC(GATTC_WRITE_CFM,
                                  src_id, dest_id, gattc_write_cfm);

    // Get the address of the environment
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);

    uint16_t rx_handle;

    // Fill in the parameter structure
    cfm->handle = param->handle;
    cfm->status = PRF_APP_ERROR;

    rx_handle = otas_env->otas_shdl + OTAS_IDX_RX_VALUE;
    if(otas_env->enable_read == false)
    {
        rx_handle -= OTAS_IDX_TX_COUNT;
    }

    //Check if Alert Level is valid
    if(param->handle == rx_handle)
    {
        cfm->status = GAP_ERR_NO_ERROR;

        // Allocate the alert value change indication
        struct otas_recv_data_ind *ind = KE_MSG_ALLOC_DYN(OTAS_RECV_DATA_IND,
                                         prf_dst_task_get(&(otas_env->prf_env), conidx),
                                         dest_id, otas_recv_data_ind, param->length);
        ASSERT_ERR(ind != NULL);
        // Fill in the parameter structure
        ind->conidx = conidx;
        ind->length = param->length;
        memcpy(ind->buffer, (uint8_t *)&param->value[0], ind->length);

        // Send the message
        ke_msg_send(ind);
    }
    else if(param->handle == (otas_env->otas_shdl + OTAS_IDX_NTF_CFG))
    {
        cfm->status = GAP_ERR_NO_ERROR;
        memcpy((uint8_t *)&notify_state, (uint8_t *)&param->value[0], sizeof(uint16_t));
        if(notify_state == PRF_CLI_STOP_NTFIND)
        {
            otas_env->env[conidx]->ntf_state &= (~OTAS_NOTIFY_ENABLE);
        }
        else if(notify_state == PRF_CLI_START_NTF)
        {
            otas_env->env[conidx]->ntf_state |= OTAS_NOTIFY_ENABLE;
        }
        else
        {
            cfm->status = GATT_ERR_WRITE;
        }
    }

    // Send the message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles reception of the read request from peer device
 *
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_read_req_ind_handler(ke_msg_id_t const msgid,
                                      struct gattc_read_req_ind const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(src_id);
    uint16_t notify_state;
    // Get the address of the environment
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);

    if((otas_env->enable_read == true)
       &&(param->handle == (otas_env->otas_shdl + OTAS_IDX_TX_VALUE)))
    {
        // send report update response
        struct otas_read_data_req *req = KE_MSG_ALLOC(OTAS_READ_DATA_REQ,
                                         prf_dst_task_get(&(otas_env->prf_env), conidx),
                                         dest_id, otas_read_data_req);
        req->conidx = conidx;
        ke_msg_send(req);

        return KE_MSG_CONSUMED;
    }

    // Send data to peer device
    struct gattc_read_cfm* cfm = KE_MSG_ALLOC_DYN(GATTC_READ_CFM, src_id, dest_id, gattc_read_cfm, sizeof(uint16_t));
    cfm->length = sizeof(uint16_t);
    cfm->handle = param->handle;
    cfm->status = PRF_APP_ERROR;

    if(param->handle == (otas_env->otas_shdl + OTAS_IDX_NTF_CFG))
    {
        cfm->status = ATT_ERR_NO_ERROR;
        if(otas_env->env[conidx]->ntf_state & OTAS_NOTIFY_ENABLE)
        {
            notify_state = PRF_CLI_START_NTF;
        }
        else
        {
            notify_state = PRF_CLI_STOP_NTFIND;
        }
        memcpy(cfm->value, &notify_state, sizeof(uint16_t));
    }

    // Send value to peer device.
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int otas_send_rsps_handler(ke_msg_id_t const msgid,
                                  struct otas_send_rsp const *param,
                                  ke_task_id_t const dest_id,
                                  ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(src_id);
    // Get the address of the environment
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);
    // Allocate the GATT notification message
    struct gattc_send_evt_cmd *send_ntf;
    uint8_t *buffer;

    if((otas_env->env[conidx]->ntf_state & OTAS_NOTIFY_ENABLE) != OTAS_NOTIFY_ENABLE)
    {
        // send report update response
        struct otas_send_rsp_result *rsp = KE_MSG_ALLOC(OTAS_SEND_RSP_RESULT,
                                           src_id,
                                           dest_id, otas_send_rsp_result);
        rsp->conidx = conidx;
        rsp->status = GATT_ERR_INVALID_PERM;
        ke_msg_send(rsp);

        return KE_MSG_CONSUMED;
    }

    send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                KE_BUILD_ID(TASK_GATTC, param->conidx), prf_src_task_get(&(otas_env->prf_env), param->conidx),
                                gattc_send_evt_cmd, param->length);

    // Fill in the parameter structure
    send_ntf->operation = GATTC_NOTIFY;
    send_ntf->handle    = otas_env->otas_shdl + OTAS_IDX_NTF_VALUE;
    // pack measured value in database
    send_ntf->length    = param->length;

    buffer = send_ntf->value;
    memcpy(buffer, param->buffer, param->length);

    // send notification to peer device
    ke_msg_send(send_ntf);

    return KE_MSG_CONSUMED;
}

static int otas_read_data_rsp_handler(ke_msg_id_t const msgid,
                                      struct otas_read_data_rsp const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);
    // Send data to peer device
    struct gattc_read_cfm* cfm = KE_MSG_ALLOC_DYN(GATTC_READ_CFM, KE_BUILD_ID(TASK_GATTC, param->conidx), dest_id, gattc_read_cfm, param->length);

    cfm->handle = otas_env->otas_shdl + OTAS_IDX_TX_VALUE;
    cfm->length = param->length;
    cfm->status = param->result;
    memcpy(&cfm->value[0], &param->buffer[0], param->length);

    ke_msg_send(cfm);

    return KE_MSG_CONSUMED;
}

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref GATTC_CMP_EVT message.
 * This generic event is received for different requests, so need to keep track.
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_cmp_evt_handler(ke_msg_id_t const msgid,
                                 struct gattc_cmp_evt const *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);

    if (param->operation == GATTC_NOTIFY)
    {
        uint8_t conidx = KE_IDX_GET(src_id);

        // send report update response
        struct otas_send_rsp_result *rsp = KE_MSG_ALLOC(OTAS_SEND_RSP_RESULT,
                                           prf_dst_task_get(&(otas_env->prf_env), conidx),
                                           dest_id, otas_send_rsp_result);
        rsp->conidx = conidx;
        rsp->status = param->status;
        ke_msg_send(rsp);
    }

    return KE_MSG_CONSUMED;
}

/**
 ****************************************************************************************
 * @brief Handles reception of the attribute info request message.
 *
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_att_info_req_ind_handler(ke_msg_id_t const msgid,
        struct gattc_att_info_req_ind *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    struct gattc_att_info_cfm * cfm = KE_MSG_ALLOC(GATTC_ATT_INFO_CFM, src_id, dest_id, gattc_att_info_cfm);;
    struct otas_env_tag *otas_env = PRF_ENV_GET(OTAS, otas);
    uint16_t rx_handle;

    rx_handle = otas_env->otas_shdl + OTAS_IDX_RX_VALUE;
    if(otas_env->enable_read == false)
    {
        rx_handle -= OTAS_IDX_TX_COUNT;
    }

    //Send att_info response
    cfm->handle = param->handle;

    // Scan Refresh Notification Configuration
    if(param->handle == otas_env->otas_shdl + OTAS_IDX_NTF_CFG)
    {
        cfm->length = 2;
        cfm->status = ATT_ERR_NO_ERROR;
    }
    else if(param->handle == rx_handle)
    {
        cfm->length = 300;
        cfm->status = ATT_ERR_NO_ERROR;
    }
    else
    {
        cfm->length = 0;
        cfm->status = ATT_ERR_WRITE_NOT_PERMITTED;
    }

    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// Default State handlers definition
const struct ke_msg_handler otas_default_state_user[] =
{
    {GATTC_WRITE_REQ_IND,               (ke_msg_func_t)gattc_write_req_ind_handler},
    {GATTC_READ_REQ_IND,                (ke_msg_func_t)gattc_read_req_ind_handler},
    {GATTC_ATT_INFO_REQ_IND,            (ke_msg_func_t)gattc_att_info_req_ind_handler},
    {GATTC_CMP_EVT,                     (ke_msg_func_t)gattc_cmp_evt_handler},
    {OTAS_READ_DATA_RSP,                (ke_msg_func_t)otas_read_data_rsp_handler},
    {OTAS_SEND_RSP,                     (ke_msg_func_t)otas_send_rsps_handler},
};

// Specifies the message handlers that are common to all states.
const struct ke_state_handler otas_default_handler_user = KE_STATE_HANDLER(otas_default_state_user);

#endif // BLE_OTA_SERVER

