/**
 ****************************************************************************************
 *
 * @file tips.c
 *
 * @brief Time Profile Server implementation.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup TIPS
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "rwip_config.h"

#if (BLE_OTA_SERVER)
#include "attm.h"
#include "otas_user.h"
#include "otas_task_user.h"
#include "prf_utils.h"

const uint8_t OTAS_VERSION_USER[2] = {0x00, 0x01};

/*
 * OTAS ATTRIBUTES
 ****************************************************************************************
 */
/// Full OTAS Database Description - Used to add attributes into the database
const struct attm_desc otas_att_db_user[OTAS_IDX_NB] =
{
    // Update Over The AIR Service Declaration
    [OTAS_IDX_SVC]                          =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    // OTA Information Characteristic Declaration
    [OTAS_IDX_VERSION_INFO_CHAR]            =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, 0},
    // OTA Information Characteristic Value
    [OTAS_IDX_VERSION_INFO_VAL]             =   {ATT_CHAR_OTAS_VERSION_INFO, PERM(RD, ENABLE), 0, sizeof(uint16_t)},

    // Notify Characteristic Declaration
    [OTAS_IDX_NTF_CHAR]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, OTAS_IDX_NTF_VALUE},
    // Notify Characteristic Value
    [OTAS_IDX_NTF_VALUE]                    =   {ATT_CHAR_OTA_NTF, PERM(NTF, ENABLE), PERM(RI, ENABLE), OTAS_NOTIFY_DATA_SIZE},
    // Notify Characteristic - Client Char. Configuration Descriptor
    [OTAS_IDX_NTF_CFG]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor
    [OTAS_IDX_NTF_USER_DESC]                =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, OTAS_NTF_USER_DESC_LEN},

    // Tx Characteristic Declaration
    [OTAS_IDX_TX_CHAR]                      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, OTAS_IDX_TX_VALUE},
    // Tx Characteristic Value
    [OTAS_IDX_TX_VALUE]                     =   {ATT_CHAR_OTA_TX, PERM(RD, ENABLE), PERM(RI, ENABLE), OTAS_MAX_DATA_SIZE},

    // Rx Characteristic Declaration
    [OTAS_IDX_RX_CHAR]                      =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, OTAS_IDX_RX_VALUE},
    // Rx Characteristic Value
    [OTAS_IDX_RX_VALUE]                     =   {ATT_CHAR_OTA_RX, PERM(WRITE_REQ, ENABLE)|PERM(WRITE_COMMAND, ENABLE), PERM(RI, ENABLE), OTAS_MAX_DATA_SIZE},
};

/**
 ****************************************************************************************
 * @brief Initialization of the OTAS module.
 * This function performs all the initializations of the Profile module.
 *  - Creation of database (if it's a service)
 *  - Allocation of profile required memory
 *  - Initialization of task descriptor to register application
 *      - Task State array
 *      - Number of tasks
 *      - Default task handler
 *
 * @param[out]    env        Collector or Service allocated environment data.
 * @param[in|out] start_hdl  Service start handle (0 - dynamically allocated), only applies for services.
 * @param[in]     app_task   Application task number.
 * @param[in]     sec_lvl    Security level (AUTH, EKS and MI field of @see enum attm_value_perm_mask)
 * @param[in]     param      Configuration parameters of profile collector or service (32 bits aligned)
 *
 * @return status code to know if profile initialization succeed or not.
 ****************************************************************************************
 */
static uint8_t otas_init(struct prf_task_env* env, uint16_t* start_hdl, uint16_t app_task, uint8_t sec_lvl, struct otas_db_cfg* params)
{
    // Service content flag
    uint32_t cfg_flag= OTAS_TX_RX_NTF_MAX;
    // DB Creation Status
    uint8_t status = ATT_ERR_NO_ERROR;
    // Total number of attributes
    uint8_t tot_nb_att = OTAS_IDX_NB;
    uint16_t handle;

    // Allocate TIPS required environment variable
    struct otas_env_tag* otas_env =
        (struct otas_env_tag* ) ke_malloc(sizeof(struct otas_env_tag), KE_MEM_ATT_DB);
    memset(otas_env, 0, sizeof(struct otas_env_tag));

    env->env = (prf_env_t*) otas_env;

    //------------------ create the attribute database for the profile -------------------

    if(params->enable_read == false)
    {
        cfg_flag &= (~OTAS_IDX_TX_MASK);
        tot_nb_att -= OTAS_IDX_TX_COUNT;
    }

    otas_env->enable_read = params->enable_read;

    // Check that attribute list can be allocated.
    status = attmdb_reserve_handle_range(start_hdl, tot_nb_att);

    if (status == ATT_ERR_NO_ERROR)
    {
        /*---------------------------------------------------*
         * Current Time Service Creation
         *---------------------------------------------------*/
        status = attm_svc_create_db(start_hdl, ATT_SVC_OTA, (uint8_t *)&cfg_flag,
                                    OTAS_IDX_NB, NULL, env->task, &otas_att_db_user[0],
                                    (sec_lvl & (PERM_MASK_SVC_DIS | PERM_MASK_SVC_AUTH | PERM_MASK_SVC_EKS)));

        // Update index
        otas_env->otas_shdl = *start_hdl;
        *start_hdl += tot_nb_att;

        // Set OTAS Tx Client Char. Information Char. Value
        if(status == GAP_ERR_NO_ERROR)
        {
            handle = otas_env->otas_shdl + OTAS_IDX_NTF_USER_DESC;
            status = attmdb_att_set_value(handle, OTAS_NTF_USER_DESC_LEN, 0, (uint8_t *)OTAS_NTF_USER_DESC_STR);

            handle = otas_env->otas_shdl + OTAS_IDX_VERSION_INFO_VAL;
            status = attmdb_att_set_value(handle, sizeof(uint16_t), 0, (uint8_t *)OTAS_VERSION_USER);
        }

        otas_env->prf_env.app_task    = app_task
                                        | (PERM_GET(sec_lvl, SVC_MI) ? PERM(PRF_MI, ENABLE) : PERM(PRF_MI, DISABLE));
        // Multi Instantiated task
        otas_env->prf_env.prf_task    = env->task | PERM(PRF_MI, ENABLE);

        // initialize environment variable
        env->id                     = TASK_ID_OTAS;
        env->desc.idx_max           = __jump_table.conn_max;
        env->desc.state             = otas_env->state;
        env->desc.default_handler   = &otas_default_handler_user;

        /* Put OTAS in disabled state */
        ke_state_set(env->task, OTAS_IDLE);
    }
    else if(otas_env != NULL)
    {
        ke_free(otas_env);
    }

    return status;
}

/**
 ****************************************************************************************
 * @brief Destruction of the OTAS module - due to a reset for instance.
 * This function clean-up allocated memory (attribute database is destroyed by another
 * procedure)
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 ****************************************************************************************
 */
static void otas_destroy(struct prf_task_env* env)
{
    uint8_t idx;
    struct otas_env_tag* otas_env = (struct otas_env_tag*) env->env;

    // cleanup environment variable for each task instances
    for(idx = 0; idx < __jump_table.conn_max ; idx++)
    {
        if(otas_env->env[idx] != NULL)
        {
            ke_free(otas_env->env[idx]);
        }
    }

    // free profile environment variables
    env->env = NULL;
    ke_free(otas_env);
}

/**
 ****************************************************************************************
 * @brief Handles Connection creation
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 ****************************************************************************************
 */
static void otas_create(struct prf_task_env* env, uint8_t conidx)
{
    struct otas_env_tag* otas_env = (struct otas_env_tag*) env->env;

    otas_env->env[conidx] = (struct otas_cnx_env*)
                            ke_malloc(sizeof(struct otas_cnx_env), KE_MEM_ATT_DB);

    memset(otas_env->env[conidx], 0, sizeof(struct otas_cnx_env));
    otas_env->env[conidx]->ntf_state = OTAS_NOTIFY_ENABLE;

    /* Put TIS in idle state */
    ke_state_set(KE_BUILD_ID(env->task, conidx), OTAS_IDLE);
}

/**
 ****************************************************************************************
 * @brief Handles Disconnection
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 * @param[in]        reason     Detach reason
 ****************************************************************************************
 */
static void otas_cleanup(struct prf_task_env* env, uint8_t conidx, uint8_t reason)
{
    struct otas_env_tag* otas_env = (struct otas_env_tag*) env->env;

    // clean-up environment variable allocated for task instance
    if(otas_env->env[conidx] != NULL)
    {
        ke_free(otas_env->env[conidx]);
        otas_env->env[conidx] = NULL;
    }
}

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// OTAS Task interface required by profile manager
const struct prf_task_cbs otas_itf_user =
{
    (prf_init_fnct) otas_init,
    otas_destroy,
    otas_create,
    otas_cleanup,
};

/*
 * EXPORTED FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

const struct prf_task_cbs* otas_prf_itf_get_user(void)
{
    return &otas_itf_user;
}

#endif


