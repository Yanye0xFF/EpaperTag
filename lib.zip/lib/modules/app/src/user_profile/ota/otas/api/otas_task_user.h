#ifndef _OTAS_TASK_H
#define _OTAS_TASK_H

#if BLE_OTA_SERVER

#include <stdint.h>
#include <stdbool.h>

#include "atts.h"
#include "prf_types.h"
#include "gap.h"
#include "prf.h"

#define OTAS_MAX_DATA_SIZE              300
#define OTAS_NOTIFY_DATA_SIZE           20

/// Possible states of the TIPS task
enum
{
    /// idle state
    OTAS_IDLE,
    /// connected state
    OTAS_BUSY,

    /// Number of defined states.
    OTAS_STATE_MAX
};

/// Messages for OTA Profile Server
enum
{
    ///Inform APP reiceve data from client
    OTAS_RECV_DATA_IND = KE_FIRST_MSG(TASK_ID_OTAS),

    ///Inform APP read data from client
    OTAS_READ_DATA_REQ,

    OTAS_READ_DATA_RSP,

    OTAS_SEND_RSP,
    OTAS_SEND_RSP_RESULT,
};

///Parameters of the @ref TIPS_CREATE_DB_REQ message
struct otas_db_cfg
{
    uint8_t enable_read;
};

struct otas_recv_data_ind
{
    uint8_t conidx;

    uint16_t length;
    uint8_t buffer[__ARRAY_EMPTY];
};

struct otas_read_data_req
{
    uint8_t conidx;
};

struct otas_read_data_rsp
{
    uint8_t conidx;
    uint8_t result;

    uint16_t length;
    uint8_t buffer[__ARRAY_EMPTY];
};

struct otas_send_rsp
{
    uint8_t conidx;

    uint16_t length;
    uint8_t buffer[__ARRAY_EMPTY];
};

struct otas_send_rsp_result
{
    uint8_t conidx;

    uint8_t status;
};

extern const struct ke_state_handler otas_default_handler_user;

#endif //BLE_OTA_SERVER
#endif //_OTAS_TASK_H
