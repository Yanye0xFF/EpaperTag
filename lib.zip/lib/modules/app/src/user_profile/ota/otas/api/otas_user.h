#ifndef _OTAS_H
#define _OTAS_H

#if BLE_OTA_SERVER

#include <stdint.h>
#include <stdbool.h>

#include "atts.h"
#include "prf_types.h"
#include "gap.h"
#include "prf.h"

#define OTAS_NTF_USER_DESC_LEN       0x0C
#define OTAS_NTF_USER_DESC_STR       "OTA Response"

// only allow one client connects to server at the same time
#define OTAS_IDX_MAX                BLE_CONNECTION_MAX

#define OTAS_TX_RX_NTF_MAX              0x7FF
#define OTAS_IDX_TX_MASK                0x180
#define OTAS_IDX_TX_COUNT               2

enum
{
    OTAS_IDX_SVC,

    OTAS_IDX_VERSION_INFO_CHAR,
    OTAS_IDX_VERSION_INFO_VAL,

    OTAS_IDX_NTF_CHAR,
    OTAS_IDX_NTF_VALUE,
    OTAS_IDX_NTF_CFG,
    OTAS_IDX_NTF_USER_DESC,

    OTAS_IDX_TX_CHAR,
    OTAS_IDX_TX_VALUE,

    OTAS_IDX_RX_CHAR,
    OTAS_IDX_RX_VALUE,

    OTAS_IDX_NB,
};

enum
{
    OTAS_TX_CHAR,
    OTAS_RX_CHAR,

    OTAS_CHAR_MAX,
};

///Database Configuration - Bit Field Flags
enum
{
    OTAS_SUP            = 0x00,
    OTAS_NOTIFY_ENABLE  = 0x01,
};


/// Time Profile Server Instance Environment variable
struct otas_cnx_env
{
    /// NTF State
    uint8_t ntf_state;
};

/// Update On The Air Profile Server. Environment variable
struct otas_env_tag
{
    /// profile environment
    prf_env_t prf_env;

    /// CTS Start Handle
    uint16_t otas_shdl;

    uint8_t enable_read;

    /// Environment variable pointer for each connections
    struct otas_cnx_env* env[OTAS_IDX_MAX];

    /// State of different task instances
    ke_state_t state[OTAS_IDX_MAX];
};

const struct prf_task_cbs* otas_prf_itf_get_user(void);

#endif //BLE_OTA_SERVER

#endif //_OTAS_H

