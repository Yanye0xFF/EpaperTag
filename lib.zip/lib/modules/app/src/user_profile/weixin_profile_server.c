/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdio.h>
#include "arch.h"
#include "rwip_config.h"

#include "user_profile.h"
#include "attm.h"       //for struct attm_desc
#include "attm_db.h"
#include "gattc.h"
#include "gattc_task.h"     //for prf_task_func operation
#include "gapm_task.h"      //for marco GAPM_PROFILE_TASK_ADD
#include "att.h"        //for UUID marcos

#include "app.h"        //for ble api

#include "user_msg_q.h" //for os_msg_post
#include "user_mem.h"
#include "prf_types.h"
#include "system.h"

#include "weixin_profile_server.h"

#ifdef CFG_PRF_WEIXIN_AIRSYNC

static uint16_t demo_profile_id;
uint16_t weixin_profile_id;
typedef struct pkt
{
    bool need_aggregation;
    uint16_t totlen;
    uint16_t current_recvd_len;
    uint8_t *buf;
} weixin_recv_pkt_t;

weixin_recv_pkt_t gWeiXinRecvPkt = {0};


void airsync_profile_send_ntf(uint8_t conidx,struct user_prf_pkt *pkt_param)
{
    uint16_t totlen = pkt_param->packet_size;
    uint8_t *buf_start = pkt_param->packet;
    uint16_t max_payload = (gattc_get_mtu(0) - 3);
    while( totlen > max_payload )
    {
        pkt_param->packet = buf_start;
        pkt_param->packet_size = max_payload;
        user_profile_send_ntf(conidx,pkt_param);
        buf_start += max_payload;
        totlen -= max_payload;
    }
    pkt_param->packet = buf_start;
    pkt_param->packet_size = totlen;
    user_profile_send_ntf(conidx,pkt_param);
}


enum
{
    DEMO_IDX_SVC,

    DEMO_IDX_NTF_CHAR,
    DEMO_IDX_NTF_VALUE,
    DEMO_IDX_NTF_CFG,
    DEMO_IDX_NTF_USER_DESC,


    DEMO_IDX_IND_CHAR,
    DEMO_IDX_IND_VALUE,
    DEMO_IDX_IND_CFG,
    DEMO_IDX_IND_USER_DESC,

    DEMO_IDX_NTF_CHAR1,
    DEMO_IDX_NTF_VALUE1,
    DEMO_IDX_NTF_CFG1,
    DEMO_IDX_NTF_USER_DESC1,

    WEIXIN_IDX_NB,
};

struct attm_desc weixin_att_db[WEIXIN_IDX_NB] =
{
    // Update Over The AIR Service Declaration
    [DEMO_IDX_SVC]                          =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    // Notify Characteristic Declaration            13
    [DEMO_IDX_NTF_CHAR]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, DEMO_IDX_NTF_VALUE},
    // Notify Characteristic Value                  14
    [DEMO_IDX_NTF_VALUE]                    =   {ATT_UUID_16(0xFA10), PERM(NTF, ENABLE) | PERM(WRITE_COMMAND, ENABLE), PERM(RI, ENABLE), 20},             //PERM(IND, ENABLE)
    // Notify Characteristic - Client Char. Configuration Descriptor    15      fixed  2byte
    [DEMO_IDX_NTF_CFG]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor      16
    [DEMO_IDX_NTF_USER_DESC]                =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 20},

    // Notify Characteristic Declaration            13
    [DEMO_IDX_IND_CHAR]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, DEMO_IDX_IND_VALUE},
    // Notify Characteristic Value                  14
    [DEMO_IDX_IND_VALUE]                    =   {ATT_UUID_16(0xFA11), PERM(IND, ENABLE) | PERM(WRITE_REQ, ENABLE), PERM(RI, ENABLE), 20},             //PERM(IND, ENABLE)
    // Notify Characteristic - Client Char. Configuration Descriptor    15      fixed  2byte
    [DEMO_IDX_IND_CFG]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor      16
    [DEMO_IDX_IND_USER_DESC]                =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 20},

    // Notify Characteristic Declaration            13
    [DEMO_IDX_NTF_CHAR1]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, DEMO_IDX_NTF_VALUE1},
    // Notify Characteristic Value                  14
    [DEMO_IDX_NTF_VALUE1]                    =   {ATT_UUID_16(0xFA13), PERM(NTF, ENABLE), PERM(RI, ENABLE), 20},             //PERM(IND, ENABLE)
    // Notify Characteristic - Client Char. Configuration Descriptor    15      fixed  2byte
    [DEMO_IDX_NTF_CFG1]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor      16
    [DEMO_IDX_NTF_USER_DESC1]                =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 20},
};

static int demo_profile_task_func(os_event_t *msg)
{
    //printf("prf_func:%x\r\n",msg->event_id);
    switch(msg->event_id)
    {
        //before write, ask peer max receving length.
        case GATTC_ATT_INFO_REQ_IND:    //0xc17
        {
            struct gattc_att_info_req_ind *param = (struct gattc_att_info_req_ind *)msg->param;

            struct gattc_att_info_cfm cfm;
            cfm.handle = param->handle;
            switch(param->handle - user_get_prf_start_hdl(demo_profile_id) )
            {
                case DEMO_IDX_NTF_CFG:
                    cfm.length = 2;
                    cfm.status = ATT_ERR_NO_ERROR;
                    break;
                case DEMO_IDX_NTF_USER_DESC:
                    cfm.length = 0xC;
                    cfm.status = ATT_ERR_NO_ERROR;
                    break;
                default:
                    cfm.length = 0;
                    cfm.status = ATT_ERR_WRITE_NOT_PERMITTED;
                    break;
            }
            os_event_t evt;
            evt.event_id = GATTC_ATT_INFO_CFM;
            evt.src_task_id = user_get_prf_task_num(demo_profile_id);
            evt.param = &cfm;
            evt.param_len = sizeof(struct gattc_att_info_cfm);
            os_msg_post(msg->src_task_id,&evt);

            printf("ATT_INFO_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(demo_profile_id));

        }
        break;
        case GATTC_WRITE_REQ_IND:   //0xc15
        {
            struct gattc_write_req_ind *param = (struct gattc_write_req_ind *)msg->param;

            struct gattc_write_cfm cfm;
            cfm.handle = param->handle;
            cfm.status = PRF_APP_ERROR;

            os_event_t evt;
            evt.event_id = GATTC_WRITE_CFM;
            evt.src_task_id = user_get_prf_task_num(demo_profile_id);
            evt.param = &cfm;
            evt.param_len = sizeof(struct gattc_write_cfm);
            os_msg_post(msg->src_task_id,&evt);

            printf("WRITE_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(demo_profile_id));
            show_reg2(param->value,param->length,1);
        }
        break;
        case GATTC_READ_REQ_IND:    //0xc13
        {
            struct gattc_read_req_ind *param = (struct gattc_read_req_ind *)msg->param;
            struct gattc_read_cfm* cfm = (struct gattc_read_cfm*)ke_malloc(sizeof(struct gattc_read_cfm)+sizeof(uint16_t)
                                         ,KE_MEM_NON_RETENTION);
            cfm->handle = param->handle;
            cfm->status = 0x00;
            cfm->length = sizeof(uint16_t);
            uint16_t tmp_value;

            if( (param->handle - user_get_prf_start_hdl(demo_profile_id)) == DEMO_IDX_NTF_CFG )
                //tmp_value =  PRF_CLI_START_NTF; //PRF_CLI_STOP_NTFIND;
                tmp_value = 0x3344;

            memcpy(cfm->value, &tmp_value, sizeof(uint16_t));
            printf("%x,%x\r\n",cfm->value[0],cfm->value[1]);

            os_event_t evt;
            evt.event_id = GATTC_READ_CFM;
            evt.src_task_id = user_get_prf_task_num(demo_profile_id);
            evt.param = cfm;
            evt.param_len = sizeof(struct gattc_read_cfm)+sizeof(uint16_t);
            os_msg_post(msg->src_task_id,&evt);

            ke_free(cfm);
            printf("READ_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(demo_profile_id));

        }
        break;
        case GATTC_CMP_EVT:     //0xc00, only for NTF or INTF
        {
            struct gattc_cmp_evt *param = (struct gattc_cmp_evt *)msg->param;
            switch(param->operation)
            {
                case GATTC_NOTIFY:
                    printf("NTF done,");
                    break;
                case GATTC_INDICATE:
                    printf("IND done,");
                    break;
                default:
                    break;
            }
            printf("%x,%d\r\n",param->status,param->seq_num);
        }
        break;
        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}


void __attribute__((weak)) airsync_profile_peer_read(uint8_t conidx,uint8_t handle)
{
    ;
}
void __attribute__((weak)) airsync_profile_peer_cfg_ind(uint8_t conidx, uint8_t *buf,uint16_t len)
{
    ;
}
void __attribute__((weak)) airsync_profile_peer_write(uint8_t conidx, uint8_t *buf,uint16_t len)
{
    ;
}
void airsync_profile_send_read_rsp(uint8_t conidx, uint8_t handle,uint8_t *buf,uint16_t len)
{
    struct gattc_read_cfm* cfm = (struct gattc_read_cfm*)ke_malloc(sizeof(struct gattc_read_cfm)+len
                                 ,KE_MEM_NON_RETENTION);
    cfm->handle = handle;
    cfm->status = 0x00;
    cfm->length = len;
    memcpy(cfm->value, buf, len);
    os_event_t evt;
    evt.event_id = GATTC_READ_CFM;
    evt.src_task_id = user_get_prf_task_num(weixin_profile_id);
    evt.param = cfm;
    evt.param_len = sizeof(struct gattc_read_cfm)+len;
    os_msg_post(KE_BUILD_ID(TASK_GATTC,conidx) , &evt);

    ke_free(cfm);
}
/*
*profile 1*
*/
struct attm_desc weixin_airsync_att_db[AIRSYNC_IDX_NB] =
{
    // Update Over The AIR Service Declaration
    [AIRSYNC_IDX_SVC]                          =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    // Notify Characteristic Declaration            13
    [AIRSYNC_IDX_WRITE_CHAR]                   =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, AIRSYNC_IDX_WRITE_VALUE},
    // Notify Characteristic Value                 14
    [AIRSYNC_IDX_WRITE_VALUE]                  =   {ATT_UUID_16(0xFEC7), PERM(WRITE_REQ, ENABLE), PERM(RI, ENABLE), 300},

    [AIRSYNC_IDX_IND_CHAR]                     =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, AIRSYNC_IDX_IND_VALUE},
    // Notify Characteristic Value                  14
    [AIRSYNC_IDX_IND_VALUE]                    =   {ATT_UUID_16(0xFEC8), PERM(IND, ENABLE), PERM(RI, ENABLE), 300},
    // Notify Characteristic - Client Char. Configuration Descriptor    15      fixed  2byte
    [AIRSYNC_IDX_IND_CFG]                      =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},

    // Notify Characteristic Declaration            13
    [AIRSYNC_IDX_READ_CHAR]                    =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, AIRSYNC_IDX_READ_VALUE},
    // Notify Characteristic Value                  14
    [AIRSYNC_IDX_READ_VALUE]                   =   {ATT_UUID_16(0xFEC9), PERM(RD, ENABLE), PERM(RI, ENABLE), 300},
};

static int airsync_profile_task_func(os_event_t *msg)
{
    //printf("prf_func1:%x\r\n",msg->event_id);
    switch(msg->event_id)
    {
        case GATTC_READ_REQ_IND:    //0xc13
        {
            struct gattc_read_req_ind *param = (struct gattc_read_req_ind *)msg->param;
            airsync_profile_peer_read(KE_IDX_GET(msg->src_task_id),param->handle);
        }
        break;
        case GATTC_WRITE_REQ_IND:   //0xc15
        {
            struct gattc_write_req_ind *param = (struct gattc_write_req_ind *)msg->param;

            struct gattc_write_cfm cfm;
            cfm.handle = param->handle;
            cfm.status = GAP_ERR_NO_ERROR;

            os_event_t evt;
            evt.event_id = GATTC_WRITE_CFM;
            evt.src_task_id = user_get_prf_task_num(weixin_profile_id);
            evt.param = &cfm;
            evt.param_len = sizeof(struct gattc_write_cfm);
            os_msg_post(msg->src_task_id,&evt);

            //printf("WRITE_REQ,hdl:%d,%d\r\n",param->handle,user_get_prf_start_hdl(weixin_profile_id));
            //show_reg2(param->value,param->length,1);

            if( (param->handle - user_get_prf_start_hdl(weixin_profile_id)) == AIRSYNC_IDX_IND_CFG )
            {
                airsync_profile_peer_cfg_ind(KE_IDX_GET(msg->src_task_id),param->value,param->length);
            }

            if( (param->handle - user_get_prf_start_hdl(weixin_profile_id)) == AIRSYNC_IDX_WRITE_VALUE )
            {
                if(gWeiXinRecvPkt.need_aggregation == false)
                {
                    if(param->value[0] == WEXIN_PRF_FIX_MAGIC && param->value[1] == WEXIN_PRF_FIX_VER)
                    {
                        weixin_pkt_t *req = (weixin_pkt_t *)param->value;
                        uint16_t req_len = TO_LITTLE_EDN_16(req->len);
                        if(req_len > param->length )
                        {
                            gWeiXinRecvPkt.need_aggregation = true;
                            gWeiXinRecvPkt.totlen = req_len;
                            gWeiXinRecvPkt.buf = (uint8_t *)os_malloc(req_len,KE_MEM_NON_RETENTION);
                            memcpy(gWeiXinRecvPkt.buf,param->value,param->length);
                            gWeiXinRecvPkt.current_recvd_len += param->length;
                        }
                        else
                        {
                            gWeiXinRecvPkt.need_aggregation = false;
                            gWeiXinRecvPkt.buf = param->value;
                            gWeiXinRecvPkt.totlen = param->length;
                        }
                    }
                }
                else
                {
                    memcpy(gWeiXinRecvPkt.buf + gWeiXinRecvPkt.current_recvd_len,param->value,param->length);
                    gWeiXinRecvPkt.current_recvd_len += param->length;
                    if(gWeiXinRecvPkt.current_recvd_len == gWeiXinRecvPkt.totlen)
                    {
                        gWeiXinRecvPkt.need_aggregation = false;
                    }
                }

                if(gWeiXinRecvPkt.need_aggregation == false)
                {
                    airsync_profile_peer_write(KE_IDX_GET(msg->src_task_id),gWeiXinRecvPkt.buf,gWeiXinRecvPkt.totlen);
                    if(gWeiXinRecvPkt.buf != param->value)
                    {
                        os_free(gWeiXinRecvPkt.buf);
                        memset((void *)&gWeiXinRecvPkt,0,sizeof(gWeiXinRecvPkt));
                    }
                }
            }
        }
        break;

        default:
            break;
    }
    return (KE_MSG_CONSUMED);
}

//when device is ready ,call this, then call add_svc
void airsync_prf_add_to_db_list(void)
{
    user_svc_req_t req;
    req.app_task = TASK_APP;
    req.prf_id = user_get_free_prf_id();
    req.operation   = GAPM_PROFILE_TASK_ADD;
    req.sec_lvl     = PERM(SVC_AUTH, ENABLE);
    req.start_hdl   = 0;

    user_svc_cfg_t cfg;
    cfg.svc_uuid = ATT_UUID_16(0xFEBA);
    cfg.svc_att_db = weixin_att_db;
    cfg.svc_att_nb = WEIXIN_IDX_NB;
    cfg.svc_db_func = demo_profile_task_func;
    cfg.db_ext_uuid128 = NULL;

    if(user_add_svc_to_list(&req,&cfg,NULL) == ERR_OK)
        demo_profile_id = req.prf_id;


    req.app_task = TASK_APP;
    req.prf_id = user_get_free_prf_id();
    req.operation   = GAPM_PROFILE_TASK_ADD;
    req.sec_lvl     = PERM(SVC_AUTH, ENABLE);
    req.start_hdl   = 0;

    cfg.svc_uuid = ATT_UUID_16(0xFEE7);
    cfg.svc_att_db = weixin_airsync_att_db;
    cfg.svc_att_nb = AIRSYNC_IDX_NB;
    cfg.svc_db_func = airsync_profile_task_func;
    cfg.db_ext_uuid128 = NULL;
    if(user_add_svc_to_list(&req,&cfg,NULL) == ERR_OK)
        weixin_profile_id = req.prf_id;
}

#endif

