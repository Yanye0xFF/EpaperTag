#ifndef _WEXIN_PROFILE_SERVER_H
#define _WEXIN_PROFILE_SERVER_H
#include <stdint.h>
#include "user_profile.h"

#define WEXIN_PRF_FIX_MAGIC 0xFE
#define WEXIN_PRF_FIX_VER 0x01

#define WEXIN_CMD_ID_REQ_AUTH       10001
#define WEXIN_CMD_ID_REQ_SENDDATA   10002
#define WEXIN_CMD_ID_REQ_INIT       10003

#define WEXIN_CMD_ID_RSP_AUTH       20001
#define WEXIN_CMD_ID_RSP_SENDDATA   20002
#define WEXIN_CMD_ID_RSP_INIT       20003

#define WEXIN_CMD_ID_PUSH_RECV_DATA         30001
#define WEXIN_CMD_ID_PUSH_SWITCH_VIEW       30002
#define WEXIN_CMD_ID_PUSH_SWITCH_BACK_GRROUND       30003

#define WEXIN_CMD_ID_ERR_DECODE       29999

enum EmErrorCode
{
    EEC_system = -1,
    EEC_needAuth = -2,
    EEC_sessionTimeout = -3,
    EEC_decode = -4,
    EEC_deviceIsBlock = -5,
    EEC_serviceUnAvalibleInBackground = -6,
    EEC_deviceProtoVersionNeedUpdate = -7,
    EEC_phoneProtoVersionNeedUpdate = -8,
    EEC_maxReqInQueue = -9,
    EEC_userExitWxAccount = -10,
};

typedef struct fixhead
{
    uint8_t magic_number;
    uint8_t ver;
    uint16_t len;
    uint16_t cmd_id;
    uint16_t seq;
    uint8_t value[];
} weixin_pkt_t;


enum
{
    AIRSYNC_IDX_SVC,

    AIRSYNC_IDX_WRITE_CHAR,
    AIRSYNC_IDX_WRITE_VALUE,

    AIRSYNC_IDX_IND_CHAR,
    AIRSYNC_IDX_IND_VALUE,
    AIRSYNC_IDX_IND_CFG,

    AIRSYNC_IDX_READ_CHAR,
    AIRSYNC_IDX_READ_VALUE,

    AIRSYNC_IDX_NB,
};


extern uint16_t weixin_profile_id;

void airsync_prf_add_to_db_list(void);
void airsync_profile_send_ntf(uint8_t conidx,struct user_prf_pkt *pkt_param);
void airsync_profile_send_read_rsp(uint8_t conidx,uint8_t handle,uint8_t *buf,uint16_t len);
//weak functions
/*
void __attribute__((weak)) airsync_profile_peer_read(uint8_t conidx,uint8_t handle);
void __attribute__((weak)) airsync_profile_peer_cfg_ind(uint8_t conidx,uint8_t *buf,uint16_t len);
void __attribute__((weak)) airsync_profile_peer_write(uint8_t conidx,uint8_t *buf,uint16_t len);
*/

#endif  //_TSK_TEMPLATE_H
