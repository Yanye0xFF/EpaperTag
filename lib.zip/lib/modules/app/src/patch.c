#include <stdint.h>
#include "rwip.h"
#include "rwip_config.h"
#include "hci.h"
#include "patch.h"

#include "ke_timer.h"
#include "ke_mem.h"

#include "system.h"
#include "gpio.h"
#include "user_sys.h"

#include "exti.h"
#include "button.h"
#include "pmu.h"
#include "reg_blecore.h"
#include "apb2spi.h"
#include "lld_evt.h"

#include "app.h"
#include "app_api.h"
#include "app_task.h"
#include "patch.h"
#include "co_utils.h"
#include "llc_task.h"
#include "llc_util.h"
#include "co_hci.h"

#include "co_llcp.h"
#include "llc_llcp.h"
#include "co_list.h"

#include "ll.h"
#include "lld.h"
#include "lld_data.h"
#include "llc.h"
#include "llm.h"
#include "ea.h"
#include "reg_ble_em_tx_desc.h"
#include "reg_ble_em_rx_desc.h"
#include "reg_ble_em_cs.h"

#include "em_buf.h"
#include "user_mem.h"
#include "flash.h"
#include "watchdog.h"
#include "jump_table.h"
#include "lvd.h"


typedef void(*FUNC)(void);

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */
extern void lld_sleep_mul_64(uint32_t *low, uint32_t *high, uint32_t mul1, uint32_t mul2);
extern uint32_t lld_sleep_div_64(uint32_t low, uint32_t high, uint32_t div);
extern void rwble_event_isr(void);

static int hci_le_rd_local_p256_public_key_cmd_handler_patch(ke_msg_id_t const msgid,
        void const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id);

static int hci_acl_data_tx_handler_patch(ke_msg_id_t const msgid,
        struct hci_acl_data_tx const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id);


/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */     //__attribute__((at(PATCH_MAP_BASE_ADDR)))
static uint32_t patch_map_code[8] __attribute__((at(0x20000900))) =
{
    //SVC #N
    //NOP
    0xBF00DF00, //0
    0xBF00DF00, //1     for con_param_update
    0xBF00DF02, //2     for lld_evt_elt_insert
    0xBF00BF00, //3     for Master connection winoffset for 1st pkt two nop
    0xBF00DF00, //4     //for malloc
    0xBF00DF00, //5     //for free
    0x00fa0fa0, //6    //9c4-2500, bb8-3000
    0x0,
    //(uint32_t)hci_le_rd_local_p256_public_key_cmd_handler_patch,
    //(uint32_t)hci_acl_data_tx_handler_patch,
};

extern uint16_t lp_frequency;
/**
PATCH 0
**/
void lld_evt_winsize_change_patch(struct lld_evt_tag *evt)
{
    /*
     * Get RX windows size in us (drift included)
     * New window size is winsize + drift before and after calculated window (=> x2)
     */
    uint32_t winsize = ((evt->evt.conn.sca_drift) << 1);
    // RX Windows size value put in the control structure
    uint16_t winsize_cs;
    if( evt->evt.conn.sync_win_size & BLE_RXWIDE_BIT)
    {
        winsize += ((evt->evt.conn.sync_win_size & BLE_RXWINSZ_MASK)*SLOT_SIZE);
    }
    else
    {
        winsize += evt->evt.conn.sync_win_size;
    }
    // Sanity Check
    if (winsize < LLD_EVT_DEFAULT_RX_WIN_SIZE)
    {
        // RX Windows size cannot be lower than default size
        winsize = LLD_EVT_DEFAULT_RX_WIN_SIZE;
    }
    /*
     * Check if half window value + new drift is still less than interval/2
     * Note: Drift is put before and after rx window so it shall be multiply by 2
     */

    //winsize /= 5;
    //winsize *= 6;
    if(winsize < 400)
    {
        winsize = 400;
    }

    if (winsize >= ((((uint32_t)evt->interval) * SLOT_SIZE * (evt->evt.conn.latency+1)) - LLD_EVT_IFS_DURATION))
    {
        // Window size is bigger than interval - T_IFS, so ask for link disconnection
        LLD_EVT_FLAG_SET(evt, DELETE);
    }
    else
    {
        // Convert to a CS compatible value
        if (winsize > (BLE_RXWINSZ_MASK / 2))
        {
            // Compute the value in slot count (round number of slots)
            winsize_cs = BLE_RXWIDE_BIT | (((winsize + (SLOT_SIZE - 1)) / SLOT_SIZE));
        }
        else
        {
            // Use the value given in us
            winsize_cs = (uint16_t)winsize;
        }
        // Write the value into the control structure
        ble_rxwincntl_set(evt->conhdl, winsize_cs);

        evt->evt.conn.sync_win_size = winsize_cs;
    }
}


#include "lld.h"
#if 1
/**
PATCH 7
**/
bool __attribute__((weak)) app_mesh_ecc_p256_info_load(uint8_t *sec_key, uint8_t *pub_key_x, uint8_t *pub_key_y)
{
    return true;
}

static int hci_le_rd_local_p256_public_key_cmd_handler_patch(ke_msg_id_t const msgid,
        void const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
//   printf("rd_local_p256_public_key_cmd_handler_patch\r\n");

    // TODO [SECCON] check that calculation not currently on-going to send an error.
    // Send the command complete event
    llm_common_cmd_status_send(src_id, CO_ERROR_NO_ERROR);

    // Not currently used
    // Need to get a 32 Byte random number - which we will use as the secret key.
    // We then ECC multiply this by the Base Points, to get a new Public Key.
    //
#ifdef CFG_APP_MESH
    {
        uint8_t blocking = 0x00; // Select non blocking mechanism
        uint8_t* secret_key256 = &llm_le_env.secret_key256[0];
        struct hci_le_generate_p256_public_key_cmp_evt *event = KE_MSG_ALLOC(HCI_LE_EVENT, 0, HCI_LE_META_EVT_CODE,hci_le_generate_p256_public_key_cmp_evt);

        if(app_mesh_ecc_p256_info_load(secret_key256, &(event->public_key.x[0]), &(event->public_key.y[0])))
        {
//           printf("A\r\n");
            // fill event parameters
            event->subcode = HCI_LE_RD_LOC_P256_PUB_KEY_CMP_EVT_SUBCODE;
            event->status = CO_ERROR_NO_ERROR;
            // Send HCI Public Key P256 Complete Event.
            hci_send_2_host(event);
        }
        else
        {
            KE_MSG_FREE(event);
            set_patch7_func_idx(PATCH7_hci_le_rd_local_p256_public_key_cmp_evt_handler);

            // Could not write new secret key to NVDS
            ecc_gen_new_secret_key(secret_key256);

            llm_le_env.cur_ecc_multiplication = LLM_PUBLIC_KEY_GENERATION;
            ecc_gen_new_public_key(secret_key256, blocking);

            // request to continue the algo
            ke_event_set(KE_EVENT_BLE_SEC_CON);
        }
    }
#else
    {
        uint8_t public_key_patch[] =
        {
            0x93, 0xb9, 0x78, 0xbf, 0x48, 0xbe, 0x55, 0x1a, 0xdd, 0x4a, 0x6d, 0xcc, 0x69, 0x5d, 0xe5, 0xc4,
            0x46, 0xb0, 0x28, 0x0f, 0x9f, 0x12, 0xc2, 0x6b, 0x10, 0xb2, 0x8e, 0x59, 0x51, 0x96, 0x3d, 0xc9,
            0xd9, 0xa7, 0xa5, 0xe0, 0x3b, 0x18, 0xe3, 0x7b, 0x0a, 0x02, 0xda, 0xae, 0xe6, 0x52, 0xf6, 0xb8,
            0x95, 0x8d, 0x43, 0xc5, 0xac, 0xfc, 0x5f, 0xfd, 0xe3, 0x95, 0x89, 0x44, 0xd6, 0x71, 0x37, 0x45,
        };
        struct hci_le_generate_p256_public_key_cmp_evt *event = KE_MSG_ALLOC(HCI_LE_EVENT, 0, HCI_LE_META_EVT_CODE,hci_le_generate_p256_public_key_cmp_evt);

        // fill event parameters
        event->subcode = HCI_LE_RD_LOC_P256_PUB_KEY_CMP_EVT_SUBCODE;
        event->status = CO_ERROR_NO_ERROR;
        //ecc_point_multiplication_cmplt256(&(event->public_key.x[0]), &(event->public_key.y[0]));
        memcpy(&(event->public_key.x[0]), public_key_patch, 2*PUBLIC_KEY_P256_LEN);

        // Send HCI Public Key P256 Complete Event.
        hci_send_2_host(event);
    }
#endif
    return (KE_MSG_CONSUMED);
}
#endif

#ifdef CFG_APP_MESH
static int hci_le_rd_local_p256_public_key_cmp_evt_handler_patch(ke_msg_id_t const msgid,
        struct hci_rd_local_p256_public_key_cmp_evt const *cmp_evt,
        ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
//   printf("rd_local_p256_public_key_cmp_evt_handler_patch\r\n");
    // Current process state
    memcpy(&gapm_env.public_key.x[0],&cmp_evt->public_key[0],32);
    memcpy(&gapm_env.public_key.y[0],&cmp_evt->public_key[32],32);

    set_patch7_func_idx(PATCH7_hci_le_rd_local_p256_public_key_cmd_handler);
    app_mesh_ecc_p256_info_update(&llm_le_env.secret_key256[0], &(gapm_env.public_key.x[0]), &(gapm_env.public_key.y[0]));

    // End of reset procedure
#if 0
    //gapm_end_of_reset(cmp_evt->status);
#else
    // reset operation is finished, inform upper layers.
    gapm_send_complete_evt(GAPM_OP_CFG, RW_ERR_HCI_TO_HL(cmp_evt->status));

    // reset correctly finished.
    if(cmp_evt->status == CO_ERROR_NO_ERROR)
    {
        // set state to idle
        ke_state_set(TASK_GAPM, GAPM_IDLE);
    }
#endif

    return (KE_MSG_CONSUMED);

}
#endif

/**
PATCH 2
**/
void lld_evt_elt_insert_patch_sub(struct ea_elt_tag *elt)
{
    GLOBAL_INT_DISABLE();
    struct lld_evt_wait_tag *new_wait_elt;
    struct lld_evt_wait_tag *scan_wait_list = (struct lld_evt_wait_tag *)co_list_pick(&lld_evt_env.elt_wait);

    while (scan_wait_list != NULL)
    {
        if(scan_wait_list->elt_ptr == elt)
        {
            break;
        }
        scan_wait_list = (struct lld_evt_wait_tag *)scan_wait_list->hdr.next;
    }

    if(scan_wait_list == NULL)
    {
        new_wait_elt = (struct lld_evt_wait_tag *)ke_malloc(sizeof(struct lld_evt_wait_tag), KE_MEM_ENV);
        new_wait_elt->elt_ptr = elt;
        co_list_push_back(&lld_evt_env.elt_wait,&new_wait_elt->hdr);
    }
    GLOBAL_INT_RESTORE();
}

__asm void lld_evt_elt_insert_patch(void)
{
    extern lld_evt_elt_insert_patch_sub

    MOV     r0, r4
    BL      lld_evt_elt_insert_patch_sub
    POP     {r4-r6,pc}
}

static int llc_con_upd_req_ind_handler_patch(ke_msg_id_t const msgid,
        void const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    uint16_t conhdl = KE_IDX_GET(dest_id);
#ifndef REMOVE_CODE_IN_MESH
    switch (ke_state_get(dest_id))
    {
        case LLC_FREE:
        case LLC_STOPPING:
        case LLC_DISC:
            break;
        case LLC_CONNECTED:
        {
            struct hci_le_con_update_cmd *param_req_hci = (struct hci_le_con_update_cmd *)llc_util_get_operation_ptr(conhdl, LLC_OP_PARAM_UPD_HCI);
            struct llc_env_tag *llc_env_ptr = llc_env[conhdl];
#if (BLE_CENTRAL)
            if ((lld_get_mode(conhdl) == LLD_EVT_MST_MODE) && GETF(llc_env_ptr->llc_status, LLC_STAT_FEAT_EXCH) && (!(llc_env_ptr->feats_used.feats[0] & BLE_CON_PARAM_REQ_PROC_FEATURE)))
            {
                struct llcp_con_up_req con_upd_pdu;
                SETF(llc_env_ptr->llc_status, LLC_STAT_UPDATE_HOST_REQ, true);
                lld_con_update_req(llc_env_ptr->elt, param_req_hci, &con_upd_pdu);
                llc_env_ptr->n_sup_to = param_req_hci->superv_to;
                llc_llcp_con_update_pdu_send(param_req_hci->conhdl, &con_upd_pdu);
            }
            else
#endif
            {
                struct llcp_con_param_req data;

                data.opcode = LLCP_CONNECTION_PARAM_REQ_OPCODE;
                data.interval_min = param_req_hci->con_intv_min;
                data.interval_max = param_req_hci->con_intv_max;
                data.latency = param_req_hci->con_latency;
                data.timeout = param_req_hci->superv_to;
                data.pref_period = 0;
                data.ref_con_event_count = 0;
                data.offset0 = 0xFFFF;
                data.offset1 = 0xFFFF;
                data.offset2 = 0xFFFF;
                data.offset3 = 0xFFFF;
                data.offset4 = 0xFFFF;
                data.offset5 = 0xFFFF;

                lld_con_param_req(llc_env_ptr->elt, &data, param_req_hci);
                SETF(llc_env_ptr->llc_status, LLC_STAT_UPDATE_HOST_REQ, true);
                ke_state_set(dest_id, LLC_CON_PARAM_REQ_WAIT_RSP);

                llc_llcp_con_param_req_pdu_send(conhdl, &data);
                ke_timer_set(LLC_LLCP_RSP_TO, dest_id, LLC_DFT_RSP_TO);
            }
        }
        break;
        default:
        {
            return (KE_MSG_SAVED);
        }
    }
#endif
    return(KE_MSG_CONSUMED);
}
#include "gattc.h"
#include "gattc_task.h"
static int gattc_disc_svc_ind_handler_patch(ke_msg_id_t const msgid, struct gattc_disc_svc_ind *ind,
        ke_task_id_t const dest_id, ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(dest_id);
    uint8_t opcode = gattc_get_operation(conidx, GATTC_OP_SDP);

    // Check if a SDP operation is on-going
    if((opcode == GATTC_SDP_DISC_SVC) || (opcode == GATTC_SDP_DISC_SVC_ALL))
    {
        if(ind->end_hdl == 0xffff)
        {
            printf("NOTICE:s:%d,e:%d\r\n",ind->start_hdl,ind->end_hdl);
            ind->end_hdl = ind->start_hdl + 20;
        }
        // put service info in SDP queue
        co_list_push_back(&(gattc_env[conidx]->client.sdp_data), &(ke_param2msg(ind)->hdr));
    }

    return (KE_MSG_NO_FREE);
}
static ke_msg_func_t ke_task_default_handler_get_patch(ke_msg_id_t const msg_id, ke_task_id_t const task_id, ke_msg_func_t org_func)
{
    switch(msg_id)
    {
        case LLC_CON_UPD_REQ_IND:
            return llc_con_upd_req_ind_handler_patch;
        case GATTC_DISC_SVC_IND:
            return (ke_msg_func_t)gattc_disc_svc_ind_handler_patch;
        default:
            return org_func;
    }
}

#include "gattm_task.h"
#include "attm_db.h"
uint8_t attm_svc_create_db_ext(uint16_t *shdl, uint16_t uuid, uint8_t *cfg_flag, uint8_t max_nb_att,
                               uint8_t *att_tbl, ke_task_id_t const dest_id,
                               const struct attm_desc *att_db, uint8_t svc_perm, const uint8_t *uuids)
{
    uint8_t nb_att = 0;
    uint8_t i;
    uint8_t status = ATT_ERR_NO_ERROR;
    struct gattm_svc_desc* svc_desc;
#ifndef REMOVE_CODE_IN_MESH
    for (i = 1; i<max_nb_att; i++)
    {
        if ((cfg_flag == NULL) || (((cfg_flag[i/8] >> (i%8)) & 1) == 1))
        {
            nb_att++;
        }
    }
    svc_desc = (struct gattm_svc_desc*) ke_malloc(
                   sizeof(struct gattm_svc_desc) + (sizeof(struct gattm_att_desc) * (nb_att)), KE_MEM_NON_RETENTION);

    svc_desc->start_hdl = *shdl;
    svc_desc->nb_att = nb_att;
    svc_desc->task_id = dest_id;

    svc_desc->perm = svc_perm;
    switch(PERM_GET(svc_perm, SVC_UUID_LEN))
    {
        case PERM_UUID_16:
            memcpy(svc_desc->uuid, &uuid, ATT_UUID_16_LEN);
            break;
        case PERM_UUID_32:
            memcpy(svc_desc->uuid, uuids, ATT_UUID_32_LEN);
            uuids += ATT_UUID_32_LEN;
            break;
        case PERM_UUID_128:
            memcpy(svc_desc->uuid, uuids, ATT_UUID_128_LEN);
            uuids += ATT_UUID_128_LEN;
            break;
        default:
            status = ATT_ERR_INVALID_ATTRIBUTE_VAL_LEN;
            ke_free(svc_desc);
            return status;
    }
    nb_att = 0;
    for (i = 1; i<max_nb_att; i++)
    {
        if ((cfg_flag == NULL) || (((cfg_flag[i/8] >> (i%8)) & 1) == 1))
        {
            svc_desc->atts[nb_att].max_len = att_db[i].max_size;
            svc_desc->atts[nb_att].ext_perm = att_db[i].ext_perm;
            svc_desc->atts[nb_att].perm     = att_db[i].perm;
            switch(PERM_GET(svc_desc->atts[nb_att].ext_perm, UUID_LEN))
            {
                case PERM_UUID_16:
                    memcpy(svc_desc->atts[nb_att].uuid, &(att_db[i].uuid), ATT_UUID_16_LEN);
                    break;
                case PERM_UUID_32:
                    memcpy(svc_desc->atts[nb_att].uuid, uuids, ATT_UUID_32_LEN);
                    uuids += ATT_UUID_32_LEN;
                    break;
                case PERM_UUID_128:
                    memcpy(svc_desc->atts[nb_att].uuid, uuids, ATT_UUID_128_LEN);
                    uuids += ATT_UUID_128_LEN;
                    break;
                default:
                    status = ATT_ERR_INVALID_ATTRIBUTE_VAL_LEN;
                    ke_free(svc_desc);
                    return status;
            }
            nb_att++;
        }
    }
    status = attmdb_add_service(svc_desc);
    if(status == ATT_ERR_NO_ERROR)
    {
        *shdl = svc_desc->start_hdl;
        nb_att = 0;
        for (i = 0; (i<max_nb_att) && (att_tbl != NULL); i++)
        {
            if ((cfg_flag == NULL) || (((cfg_flag[i/8] >> (i%8)) & 1) == 1))
            {
                att_tbl[i] = *shdl + nb_att;
                nb_att++;
            }
        }
    }
    ke_free(svc_desc);
#endif
    return status;
}


/**
PATCH 1, fix bug: master transfer data may goto loop
**/
#define DATA_BASE_INDEX (BLE_TX_DESC_CNTL + BLE_TX_DESC_ADV -1)
static uint8_t lld_data_tx_flush_list_patch(struct co_list *list)
{

    uint8_t tx_cnt = 0;
    struct em_buf_node *txnode = NULL;
    struct em_buf_node *txnode_old = NULL;
#ifndef REMOVE_CODE_IN_MESH
    while (1)
    {
        GLOBAL_INT_DISABLE();
        txnode_old = txnode;
        txnode = NULL;
        txnode = (struct em_buf_node *)co_list_pop_front(list);
        GLOBAL_INT_RESTORE();

        if (txnode == NULL)
            break;
        if (txnode == txnode_old)
        {
            printf("CATCH\r\n");
            break;
        }
        if (txnode->idx > DATA_BASE_INDEX)
        {
            tx_cnt++;
            GLOBAL_INT_DISABLE();
            em_buf_tx_free(txnode);
            GLOBAL_INT_RESTORE();
        }
    }
#endif
    return (tx_cnt);
}

void lld_data_tx_flush_patch(struct lld_evt_tag *evt)
{
    uint8_t nb_of_pkt_flushed;
    nb_of_pkt_flushed = lld_data_tx_flush_list_patch(&evt->tx_prog);
    nb_of_pkt_flushed += lld_data_tx_flush_list_patch(&evt->tx_rdy);
    if (nb_of_pkt_flushed > 0)
    {
        llc_common_nb_of_pkt_comp_evt_send(evt->conhdl, nb_of_pkt_flushed);
    }
}


/**
PATCH 4
**/
#include "smp_common.h"
#include "gapc.h"
void smpc_handle_enc_change_evt_patch(uint8_t conidx, uint8_t role, uint8_t status)
{
#ifndef REMOVE_CODE_IN_MESH
    uint8_t int_status = SMP_ERROR_NO_ERROR;
    printf("go:%x\r\n",gapc_env[conidx]->smpc.state);
    switch (gapc_env[conidx]->smpc.state)
    {
        case (SMPC_START_ENC_LTK):
#if (BLE_SECURE_CONNECTIONS==1)
        case (SMPC_PAIRING_SC_W4_ENCRYPTION_CHANGE) :
#endif
        {
#if (BLE_SECURE_CONNECTIONS==1)
            if (smpc_secure_connections_enabled(conidx) == false)
                ASSERT_ERR(gapc_get_operation(conidx, GAPC_OP_SMP) == GAPC_ENCRYPT);
#else
            ASSERT_ERR(gapc_get_operation(conidx, GAPC_OP_SMP) == GAPC_ENCRYPT);
#endif
            gapc_update_state(conidx, GAPC_ENCRYPT_BUSY, false);
            if (status == CO_ERROR_PIN_MISSING)
            {
                int_status = SMP_ERROR_ENC_KEY_MISSING;
            }
            else if (status == CO_ERROR_UNSUPPORTED)
            {
                int_status = SMP_ERROR_ENC_NOT_SUPPORTED;
            }
            else if (status == CO_ERROR_LMP_RSP_TIMEOUT)
            {
                int_status = SMP_ERROR_ENC_TIMEOUT;
            }
            else if (status == CO_ERROR_CON_TIMEOUT)
            {
                int_status = SMP_ERROR_LL_ERROR;
            }
            else
            {
                ASSERT_INFO(status == CO_ERROR_NO_ERROR, status, conidx);
            }

            if (int_status == SMP_ERROR_NO_ERROR)
            {
#if (BLE_SECURE_CONNECTIONS==1)
                if ((smpc_secure_connections_enabled(conidx) == true) &&
                    (gapc_env[conidx]->smpc.state == SMPC_PAIRING_SC_W4_ENCRYPTION_CHANGE))
                {
#if 1 // GF TEMP 19 May
                    // Reset the internal state
                    gapc_env[conidx]->smpc.state = SMPC_STATE_RESERVED;
#endif
                    printf("x2,");

                    struct gapc_bond_ind* ind = KE_MSG_ALLOC(GAPC_BOND_IND,
                                                APP_MAIN_TASK, KE_BUILD_ID(TASK_GAPC, conidx), gapc_bond_ind);

                    ind->info = GAPC_LTK_EXCH;

                    memcpy(&ind->data.ltk.ltk.key[0],&gapc_env[conidx]->smpc.info.pair->key.key[0], sizeof(struct gapc_ltk));
                    memset(&ind->data.ltk.randnb.nb[0],0x00,RAND_NB_LEN);
                    ind->data.ltk.ediv = 0x00;

                    gapc_link_encrypted(conidx);
                    ke_msg_send(ind);

                    if(role == ROLE_MASTER)
                    {
                        smpc_tkdp_rcp_start(conidx, ROLE_MASTER);
                    }
                    else
                    {
                        smpc_tkdp_send_start(conidx, ROLE_SLAVE);
                    }
                }
                else
#endif
                {
                    printf("x1,");
                    gapc_env[conidx]->smpc.state = SMPC_STATE_RESERVED;
                    struct gapc_encrypt_ind* ind = KE_MSG_ALLOC(GAPC_ENCRYPT_IND,
                                                   APP_MAIN_TASK, KE_BUILD_ID(TASK_GAPC, conidx), gapc_encrypt_ind);
                    gapc_link_encrypted(conidx);
                    ind->auth = gapc_auth_get(conidx);
                    ke_msg_send(ind);
                    gapc_send_complete_evt(conidx, GAPC_OP_SMP, int_status);
                }
            }
            else
                gapc_send_complete_evt(conidx, GAPC_OP_SMP, int_status);

        }
        break;

        case (SMPC_START_ENC_STK):
        {
            gapc_update_state(conidx, GAPC_ENCRYPT_BUSY, false);

            ASSERT_ERR(gapc_get_operation(conidx, GAPC_OP_SMP) == GAPC_BOND);
            ASSERT_ERR(gapc_env[conidx]->smpc.info.pair != NULL);

            if (int_status == SMP_ERROR_NO_ERROR)
            {
                if(role == ROLE_MASTER)
                {
                    smpc_tkdp_rcp_start(conidx, ROLE_MASTER);
                }
                else
                {
                    smpc_tkdp_send_start(conidx, ROLE_SLAVE);
                }
            }
            else
            {
                smpc_pairing_end(conidx, role, SMP_ERROR_LL_ERROR, false);
            }
        }
        break;

        default:
        {
        } break;
    }
#endif
}


struct rwip_env_tag
{
    uint16_t prevent_sleep;
    uint8_t wakeup_delay;
    bool sleep_enable;
    bool ext_wakeup_enable;
};
struct lld_sleep_env_tag
{
    uint32_t irq_mask;
};

#define MAX_SLEEP_DURATION_PERIODIC_WAKEUP      0x0320  // 0.5s
#define MAX_SLEEP_DURATION_EXTERNAL_WAKEUP      0x3E80  //10s
uint8_t __attribute__((section("adv_sleep_code"))) rwip_sleep_mode_check_imp(uint32_t *sleep_duratoin)
{
    uint32_t rtc_alarm_counter;
#ifndef  REMOVE_CODE_IN_MESH

    if(*sleep_duratoin < 16)    //30
        return RWIP_SLEEP_MODE_WAKE_UP;
#if 0
    switch(__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK)
    {
        case SYSTEM_OPTION_LP_CLK_32768:
            rtc_alarm_counter = (*sleep_duratoin << 11)/100;
            break;
        case SYSTEM_OPTION_LP_CLK_32K:
            rtc_alarm_counter = *sleep_duratoin * 20;
            break;
        default:
            rtc_alarm_counter = *sleep_duratoin * system_get_rc_clk_patch(true) / 1600;  //18us
            break;
    }
    if((__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK) == SYSTEM_OPTION_LP_CLK_RC)
    {
        rtc_alarm_counter >>= 4;
    }
    else
    {
        rtc_alarm_counter >>= 5;
    }
    if((__jump_table.system_option & SYSTEM_OPTION_LP_CLK_SEL_MSK) != SYSTEM_OPTION_LP_CLK_32768)
    {
        rtc_alarm_counter -= 5;
    }
    else
    {
        rtc_alarm_counter -= 8;
    }
#else       //save code space  dyc
    rtc_alarm_counter = *sleep_duratoin * system_get_rc_clk_patch(true) / 1600;  //18us
    rtc_alarm_counter >>= 4;
    rtc_alarm_counter -= 5;
#endif

//Becaue max rtc_alarm_counter <= 0xffff, so no need to write 0x44,0x45;
    ool_write(0x42, rtc_alarm_counter & 0xFF);  //0x45~0x42: 32bits rtc sleep time * 0.5ms
    ool_write(0x43, (rtc_alarm_counter>>8) & 0xFF);
    //ool_write(0x44, (rtc_alarm_counter>>16) & 0xFF);
    //ool_write(0x45, (rtc_alarm_counter>>24) & 0xFF);

    //*sleep_duratoin += 2000;    //ȷ��Сtimer��Զ������rtcǰ������
    *sleep_duratoin = 0xFFFFFFF;
#endif
    return RWIP_SLEEP_MODE_DEEP;
}

static bool __attribute__((section("adv_sleep_code"))) rwip_check_wakeup_boundary_patch(void)
{
    ble_samp_setf(1);
    while (ble_samp_getf());
    return  ((ble_finetimecnt_get() < 468) ? false : true);
}
static bool __attribute__((section("adv_sleep_code"))) key_press_sleep_check(void)
{
    uint8_t i,j;
    uint8_t index;
    uint8_t button_sel;
    bool result = true;
#if 1
    uint32_t pressed_idx = 0;
    for(i=0; i<32; i+=8)
    {
        index = i/8;
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        for(j=0; j<8; j++)
        {
            if(button_sel & CO_BIT(j))
            {
                system_set_port_mux(index,j,PORT_FUNC_GPIO);
                gpio_set_dir((enum system_port_t)index, (enum system_port_bit_t)j, GPIO_DIR_IN);
                system_set_port_pull( j+ (index<<3), true);
            }
        }

        if(index == GPIO_PORT_A)
            pressed_idx |= ((gpio_porta_read() & button_sel) ^ button_sel);
        else if (index == GPIO_PORT_B)
            pressed_idx |= (((gpio_portb_read() & button_sel) ^ button_sel)<<8);
        else if (index == GPIO_PORT_C)
            pressed_idx |= (((gpio_portc_read() & button_sel) ^ button_sel)<<16);
        else if (index == GPIO_PORT_D)
            pressed_idx |= (((gpio_portd_read() & button_sel) ^ button_sel)<<24);

        for(j=0; j<8; j++)
        {
            if(button_sel & CO_BIT(j))
                system_set_port_mux(index,j,PORT_FUNC_EXT_INT);
        }
    }
    extern uint32_t pressed_button_isr;
    for(i=0; i<32; i++)
    {
        if(pressed_idx & CO_BIT(i))
        {
            if( (pressed_button_isr & pressed_idx) & CO_BIT(i))
                ext_int_set_type(i, EXT_INT_TYPE_HIGH);
            //fputc('x',NULL);
            result = false;
        }
    }

    return result;
#else
    system_set_port_mux(GPIO_PORT_A,GPIO_BIT_4,PORT_FUNC_GPIO);
    gpio_set_dir(GPIO_PORT_A, GPIO_BIT_4, GPIO_DIR_IN);
    if((gpio_porta_read() & BIT(GPIO_BIT_4)) == 0)
    {
        gpio_init();
        return false;
    }
    return true;
#endif
}
#include "ke.h"
#include "rwble.h"
#include "ke_env.h"
static bool ke_timer_check_plus(void)
{
//uint32_t current_ke_time,delta;
    struct ke_env_tag *ke_env = (struct ke_env_tag *)0x2000078c;
    struct ke_timer *first = (struct ke_timer*) ke_env->queue_timer.first;
    if (first != NULL)
    {
//current_ke_time = ((ea_time_get_halfslot_rounded() >> 4) & 0x007FFFFF);
//delta = ((uint32_t)((uint16_t)(first->time - current_ke_time))) << 4;
        if(first->time == ((ea_time_get_halfslot_rounded() >> 4) & 0x007FFFFF))
            return false;
    }
    return true;
}

#include "co_list.h"
#include "ea.h"
struct ea_env_tag
{
    struct co_list elt_wait;
    struct ea_elt_tag *elt_prog;
    struct co_list elt_canceled;
    struct co_list interval_list;
#if (EA_ALARM_SUPPORT)
    struct co_list alarm_list;
#endif
};
void check_finetimer_isr(void)
{
    struct ea_env_tag *ea_env = (struct ea_env_tag *)0x20000724;

    if(co_list_is_empty(&ea_env->elt_wait))
    {
        if (ble_finetgtimintmsk_getf())
        {
            ble_finetgtimintmsk_setf(0);
            ble_intack_clear(BLE_FINETGTIMINTACK_BIT);
        }
    }
    else
    {
        if( CLK_DIFF(ea_time_get_slot_rounded(),ble_finetarget_getf()) > 0 )
        {
            if (!ble_finetgtimintmsk_getf())
            {
                ble_intack_clear(BLE_FINETGTIMINTACK_BIT);
                ble_finetgtimintmsk_setf(1);
                //fputc('T',0);
            }
        }
    }
}

static bool cmp_dest_id(struct co_list_hdr const * msg, uint32_t dest_id)
{
    return ((struct ke_msg*)msg)->dest_id == dest_id;
}
#include "ke_queue.h"
static void check_msg_saved_patch(void)
{
    struct ke_msg * msg = NULL;
    bool map_msg_exist = false;
    struct co_list restore_list;

    static uint32_t check_cnt = 0;
    if(check_cnt++ <0xfffff) {
        return;
    }
    check_cnt = 0;
    //fputc('J',0);
    co_list_init(&restore_list);
    struct ke_env_tag *ke_env = (struct ke_env_tag *)0x2000078c;
    for(;;)
    {
        msg = (struct ke_msg*) ke_queue_extract(&(ke_env->queue_saved),
                                                &cmp_dest_id,
                                                (uint32_t) TASK_LLC);
        if (msg == NULL) break;
        if(msg->src_id == TASK_LLC && msg->dest_id == TASK_LLC && msg->id == LLCP_CHANNEL_MAP_REQ )
        {
            if(map_msg_exist)
            {
                ke_msg_free(msg);
            }
            else
            {
                map_msg_exist = true;
                co_list_push_back(&restore_list, (struct co_list_hdr *)msg);
            }
        }
        else
            co_list_push_back(&restore_list, (struct co_list_hdr *)msg);
    }

    if(!co_list_is_empty(&restore_list))
    {
        restore_list.last->next = ke_env->queue_saved.first;
        ke_env->queue_saved.first = restore_list.first;
        if(ke_env->queue_saved.last == NULL)
            ke_env->queue_saved.last = restore_list.last;
    }

}
enum rwip_sleep_mode_t  __attribute__((section("adv_sleep_code"))) rwip_sleep_patch(void)
{
    enum rwip_sleep_mode_t proc_sleep = RWIP_SLEEP_MODE_WAKE_UP;
#ifndef  REMOVE_CODE_IN_MESH
    uint32_t sleep_duration = MAX_SLEEP_DURATION_EXTERNAL_WAKEUP;
    struct rwip_env_tag *rwip_env = (struct rwip_env_tag *)(0x200001a4);
    do
    {
        check_finetimer_isr();
        check_msg_saved_patch();
        if (!ke_sleep_check())
            break;
        if(!rwip_env->sleep_enable)
            break;
        if (rwip_env->prevent_sleep != 0)
            break;
        if( is_charging())   //charging
            break;
        //key press check
        if (!key_press_sleep_check())
            break;
        if(!rwip_env->ext_wakeup_enable)        //16us
            sleep_duration = MAX_SLEEP_DURATION_PERIODIC_WAKEUP;
        while(!rwip_check_wakeup_boundary_patch());   //must >468,then go down;
        if (!ke_timer_sleep_check(&sleep_duration, rwip_env->wakeup_delay) || !ke_timer_check_plus())     //22us
            break;
        if (!rwble_sleep_check())       //12us
            break;
        if (!ea_sleep_check(&sleep_duration, rwip_env->wakeup_delay))   //19us
            break;
        /*
        #if (H4TL_SUPPORT)
                if (!h4tl_stop())   //13us
                {
                    proc_sleep = RWIP_SLEEP_MODE_WAKE_UP;
                    break;
                }
        #endif
        */
        if(sleep_duration < (__jump_table.wakeup_to_proget + 2))    //10us
        {
            break;
        }
        //above 260us
        sleep_duration -= __jump_table.wakeup_to_proget;
#if (USER_MEM_API_ENABLE)
        sleep_duration +=1;
#endif
        proc_sleep = RWIP_SLEEP_MODE_DEEP;
//        gpio_dbg_toggle(7);

        if(rwip_sleep_mode_check)
        {
            proc_sleep = rwip_sleep_mode_check(&sleep_duration);        //137us
        }


        if(proc_sleep != RWIP_SLEEP_MODE_WAKE_UP)       //14us
        {
            struct lld_sleep_env_tag *lld_sleep_env = (struct lld_sleep_env_tag *)(0x20000190);
            lld_sleep_env->irq_mask = ble_intcntl_get();
            ble_intack_clear(BLE_EVENTINTACK_BIT | BLE_RXINTACK_BIT | BLE_SLPINTACK_BIT | BLE_EVENTAPFAINTMSK_BIT);
            ble_intcntl_set(BLE_SLPINTMSK_BIT);
            if (ble_finetgtimintmsk_getf())
            {
                ble_intack_clear(BLE_FINETGTIMINTACK_BIT);
                ble_finetgtimintmsk_setf(0);
            }
            if(!rwip_env->ext_wakeup_enable)
            {
                ble_extwkupdsb_setf(1);
            }
        }
        //  gpio_dbg_toggle(8);
    }
    while(0);
#endif

    return proc_sleep;
}

/***********DBG patch************/
#include "user_timer.h"
/*
static ke_task_id_t l_timer_arg = 0;
static os_timer_t l_req_timer;
static void l_req_timeout(void *arg)
{
    ;// ke_msg_send_basic(LLC_LENGTH_REQ_IND, l_timer_arg, l_timer_arg);
}
*/

#include "llm_util.h"
void llc_start_patch(struct llc_create_con_req_ind const *param, struct ea_elt_tag *elt)
{
#ifndef REMOVE_CODE_IN_MESH

    // Associted BLE event environment
    struct lld_evt_tag *evt = LLD_EVT_ENV_ADDR_GET(elt);
    struct llc_env_tag *llc_env_ptr;
    uint16_t conhdl = evt->conhdl;
    ke_task_id_t llc_id = KE_BUILD_ID(TASK_LLC, conhdl);
    ASSERT_INFO(llc_env[conhdl] == NULL, conhdl, 0);

    // Check if this llc_env is already used
    if (llc_env[conhdl] == NULL)
    {
        // Allocate a LLC environment structure for the link
        llc_env[conhdl] = (struct llc_env_tag*)ke_malloc(sizeof(struct llc_env_tag), KE_MEM_ENV);
    }

    llc_env_ptr = llc_env[conhdl];

    // Clear peer version info
    memset(&llc_env_ptr->peer_version, 0, sizeof(struct rem_version));
#if (BLE_CENTRAL)
    // Initialize channel map
    llm_util_get_channel_map(&llc_env_ptr->ch_map);
    llm_util_get_channel_map(&llc_env_ptr->n_ch_map);
#if (BLE_CHNL_ASSESS)
    // Channel assessment for Master only
    if(evt->mode == LLD_EVT_MST_MODE)
    {
        // Initialize packet counters
        memset(&llc_env_ptr->chnl_assess, 0, sizeof(struct llc_ch_asses_tag));
        // Set the reassessment counter
        llc_env_ptr->chnl_assess.reassess_count = llm_util_ch_assess_get_reass_cnt();
        // Start timer
        ke_timer_set(LLC_CHNL_ASSESS_TO, llc_id,llm_util_ch_assess_get_assess_timer());
        //Set if latency enable
        if(evt->evt.conn.latency > 1)
        {
            llc_env_ptr->chnl_assess.latency_en = true;
        }
        else
        {
            llc_env_ptr->chnl_assess.latency_en = false;
        }
    }
#endif //(BLE_CHNL_ASSESS)
#endif //(BLE_CENTRAL)
    llc_env_ptr->elt = elt;
    llc_env_ptr->sup_to = param->sup_to;

    // Reset the packet counter
    llc_env_ptr->tx_pkt_cnt = 0;
    llc_env_ptr->enc_state = 0;

    // If the Link Layer connection supervision timer reaches 6 * connInterval before
    // the connection is established, the connection shall be considered lost.
    ke_timer_set(LLC_LE_LINK_SUP_TO, llc_id, (6 * param->con_int) / 8);

    SETF(llc_env_ptr->llc_status, LLC_STAT_TO_PENDING, true);
    SETF(llc_env_ptr->llc_status, LLC_STAT_SYNC_FOUND, false);
    SETF(llc_env_ptr->llc_status, LLC_STAT_UPDATE_PENDING, false);
    SETF(llc_env_ptr->llc_status, LLC_STAT_UPDATE_HOST_REQ, false);
    SETF(llc_env_ptr->llc_status, LLC_STAT_UPDATE_EVT_SENT, false);
    SETF(llc_env_ptr->llc_status, LLC_STAT_VERS_IND_RESTART, false);
    SETF(llc_env_ptr->llc_status, LLC_STAT_PEER_VERS_KNOWN, false);

    // send the command complete event
    llc_le_con_cmp_evt_send(CO_ERROR_NO_ERROR, conhdl, param);

    // Init the timeout reason to NO ERROR
    llc_env_ptr->disc_reason = CO_ERROR_NO_ERROR;

    // Get the supported features
    llm_util_get_supp_features(&llc_env_ptr->feats_used);
    // Features have not been exchanged yet
    SETF(llc_env_ptr->llc_status, LLC_STAT_FEAT_EXCH, false);

    // By default, LLCP commands are not discarded
    SETF(llc_env_ptr->llc_status, LLC_STAT_LLCP_DISCARD, false);


    // Reset the value of the last event counter and the rx status
    llc_env_ptr->rx_status = 0;

    // Reset Operation
    for(uint8_t i = 0; i < LLC_OP_MAX; i++)
    {
        llc_env_ptr->operation[i] = NULL;
    }
    // set the current llc task in connected state
    ke_state_set(llc_id, LLC_CONNECTED);

    // Set the default value for the authenticated payload timeout
    llc_env[conhdl]->auth_payl_to = LLC_DFT_AUTH_PAYL_TO;

    // Set the feature request received flag first check to true
    llc_env_ptr->first_check = true;
    /**
     * LE PING
     * Time out initialization
     */
    // Set an appropriate margin for the authenticated payload timeout
    llc_util_set_auth_payl_to_margin(evt);
    /**
     * DLE
     * Data length extension initialization (core chapter 4.5.10 Data PDU Length Management)
     */
    //By default the request can be sent
    llc_env_ptr->data_len_ext_info.send_req_not_allowed = false;
    //DLE request 7
    //Set data length extension default values
#if (RW_DEBUG)
    //DLE request 7.1
    llc_env_ptr->data_len_ext_info.conn_max_tx_octets       = llm_le_env.data_len_val.conn_initial_max_tx_octets;
    llc_env_ptr->data_len_ext_info.conn_max_rx_octets       = llm_le_env.data_len_val.suppted_max_rx_octets;
    //DLE request 7.2
    llc_env_ptr->data_len_ext_info.conn_max_tx_time         = llm_le_env.data_len_val.conn_initial_max_tx_time;
    llc_env_ptr->data_len_ext_info.conn_max_rx_time         = llm_le_env.data_len_val.suppted_max_rx_time;
#else
    //DLE request 7.1
    llc_env_ptr->data_len_ext_info.conn_max_tx_octets       = llm_le_env.data_len_val.conn_initial_max_tx_octets;
    llc_env_ptr->data_len_ext_info.conn_max_rx_octets       = BLE_MAX_OCTETS;
    //DLE request 7.2
    llc_env_ptr->data_len_ext_info.conn_max_tx_time         = llm_le_env.data_len_val.conn_initial_max_tx_time;
    llc_env_ptr->data_len_ext_info.conn_max_rx_time         = BLE_MAX_TIME;
#endif
    //DLE request 7.3
    llc_env_ptr->data_len_ext_info.conn_rem_max_tx_octets   = BLE_MIN_OCTETS;//27 bytes
    llc_env_ptr->data_len_ext_info.conn_rem_max_rx_octets   = BLE_MIN_OCTETS;//27 bytes
    //DLE request 7.4
    llc_env_ptr->data_len_ext_info.conn_rem_max_tx_time     = BLE_MIN_TIME;//328 us
    llc_env_ptr->data_len_ext_info.conn_rem_max_rx_time     = BLE_MIN_TIME;//328 us

    //DLE request 9
    llc_env_ptr->data_len_ext_info.conn_eff_max_rx_octets   = BLE_MIN_OCTETS;//27 bytes
    llc_env_ptr->data_len_ext_info.conn_eff_max_tx_octets   = BLE_MIN_OCTETS;//27 bytes
    llc_env_ptr->data_len_ext_info.conn_eff_max_tx_time     = BLE_MIN_TIME;//328 us
    llc_env_ptr->data_len_ext_info.conn_eff_max_rx_time     = BLE_MIN_TIME;//328 us

    SETF(llc_env_ptr->data_len_ext_info.data_len_ext_flag, LLC_DLE_EVT_SENT, true);
    SETF(llc_env_ptr->data_len_ext_info.data_len_ext_flag, LLC_DLE_REQ_RCVD, false);


    /**
     * Clear the operation
     */
    llc_util_set_operation_ptr(conhdl, LLC_OP_PARAM_UPD_HCI, NULL);
    llc_util_set_operation_ptr(conhdl, LLC_OP_PARAM_UPD_IND, NULL);
    llc_util_set_operation_ptr(conhdl, LLC_OP_ENCRYPT, NULL);
    llc_util_set_operation_ptr(conhdl, LLC_OP_DLE_UPD, NULL);

    /**
     * DLE
     * Raise an IND to the LLC to send the LLCP LL_LENGTH_REQ with the local parameters
     */

    /**
     * DLE
     * Raise an IND to the LLD to send the LLCP LL_LENGTH_REQ with the local parameters
     */
    // l_timer_arg = llc_id;
    // os_timer_setfn(&l_req_timer,l_req_timeout,NULL);
    // os_timer_arm(&l_req_timer,10,0);
    //ke_msg_send_basic(LLC_LENGTH_REQ_IND, llc_id, llc_id);

#if (BLE_TESTER)
    // No tester features enabled by default
    llc_env_ptr->tester_params.tester_feats = 0x00;
#endif

#endif
}

/***********DBG patch**********/

static int hci_acl_data_tx_handler_patch(ke_msg_id_t const msgid,
        struct hci_acl_data_tx const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
#ifndef REMOVE_CODE_IN_MESH
    uint8_t llid;
    uint8_t length;
    switch(ke_state_get(dest_id))
    {
        case LLC_FREE:
        case LLC_DISC:
        case LLC_STOPPING:
        {
            GLOBAL_INT_DISABLE();
            em_buf_tx_free(param->desc);
            GLOBAL_INT_RESTORE();
            llc_common_nb_of_pkt_comp_evt_send(param->conhdl, 1);
        }
        break;

        default:
        {
            struct llc_env_tag *llc_env_ptr = llc_env[param->conhdl];
            int16_t temp_length = (int16_t)param->length;
            uint16_t temp_data_ptr_val = 0;
            uint16_t temp_buff_idx_val = 0;

            uint8_t tmp_max_tx_octets = llc_env_ptr->data_len_ext_info.conn_eff_max_tx_octets;
            if (llc_env_ptr->enc_state & ENC_TX)
            {
                if(temp_length > llc_env_ptr->data_len_ext_info.conn_eff_max_tx_octets)
                    tmp_max_tx_octets &= (~ BIT(0));
                //make sure the max_tx_octets is even. for encrypted data, start data addr must be even.
            }
            if(param->length == 0)
            {
                GLOBAL_INT_DISABLE();
                em_buf_tx_free(param->desc);
                GLOBAL_INT_RESTORE();
                llc_common_nb_of_pkt_comp_evt_send(param->conhdl, 1);
                break;
            }
            if (llc_env_ptr->enc_state & ENC_TX_FLOW_CONTROLLED)
                return (KE_MSG_SAVED);

            if (temp_length > tmp_max_tx_octets)
            {
                length = tmp_max_tx_octets;
                temp_data_ptr_val = ble_txdataptr_get(param->desc->idx);
                ble_freebuff_setf(param->desc->idx, (uint8_t)false);
                temp_buff_idx_val = ble_buffidx_getf(param->desc->idx);
            }
            else
            {
                length = temp_length;
                temp_length = 0;
                ble_freebuff_setf(param->desc->idx, (uint8_t)true);
            }

            llid = ((param->pb_bc_flag & BLE_TXLLID_MASK)==0)?LLID_START:LLID_CONTINUE;
            if (llc_env_ptr->enc_state & ENC_TX)
            {
                length += MIC_LEN;
            }

            ble_txlen_setf(param->desc->idx, length);
            ble_txllid_setf(param->desc->idx, llid);
            llc_env_ptr->tx_pkt_cnt++;
            lld_data_tx_push(llc_env_ptr->elt, param->desc);

            while(temp_length > 0)
            {
                struct em_buf_node* buf_node = (struct em_buf_node *)em_buf_tx_desc_alloc();
                if(buf_node)
                {
                    temp_length -= tmp_max_tx_octets;

                    if (temp_length > tmp_max_tx_octets)
                    {
                        length = tmp_max_tx_octets;
                    }
                    else
                    {
                        length = temp_length;
                        temp_length = 0;
                    }
                    llid = LLID_CONTINUE;
                    if (llc_env_ptr->enc_state & ENC_TX)
                    {
                        length += MIC_LEN;
                    }

                    temp_data_ptr_val = (temp_data_ptr_val + tmp_max_tx_octets) & BLE_TXDATAPTR_MASK;
                    ble_txlen_setf(buf_node->idx, length);
                    ble_txllid_setf(buf_node->idx, llid);
                    ble_txdataptr_set(buf_node->idx, temp_data_ptr_val);
                    ble_buffidx_setf(buf_node->idx, temp_buff_idx_val);

                    if(!temp_length)
                    {
                        ble_freebuff_setf(buf_node->idx, (uint8_t)true);
                    }
                    lld_data_tx_push(llc_env_ptr->elt, buf_node);
                }
                else
                {
                    llc_common_nb_of_pkt_comp_evt_send(param->conhdl, 1);
                    break;
                }
            }

#if(BLE_PERIPHERAL)
            lld_evt_schedule_next(llc_env_ptr->elt);
#endif
        }
        break;
    }
#endif
    return (KE_MSG_CONSUMED);
}

static uint16_t last_evt_lantency ;
void llc_llcp_con_update_req_ind_patch(uint16_t conhdl, struct llcp_con_up_req *param)
{
    struct llc_env_tag *llc_env_ptr = llc_env[conhdl];
    uint16_t instant = co_btohs(param->instant);
#if defined(PROJ_MICPHONE_KEYSCAN)
    if(param->latency > 88 && param->interv == 6)
    {
        //fputc('X',NULL);
        param->latency = 0;
    }
    if(param->latency > 20 && param->interv == 24)
    {
        // fputc('Y',NULL);
        ;// param->latency = 99;
    }
#endif

    last_evt_lantency = param->latency+1;

    // Check if instant has passed
    if(((uint16_t)((instant - lld_evt_con_count_get(LLD_EVT_ENV_ADDR_GET(llc_env[conhdl]->elt))) % 65536) < 32767)
       && (instant != lld_evt_con_count_get(LLD_EVT_ENV_ADDR_GET(llc_env[conhdl]->elt))))
    {
        // Instant has not passed, so program the LLD to schedule the parameter update
        lld_con_update_ind(llc_env[conhdl]->elt, param);

        llc_env_ptr->n_sup_to = co_btohs(param->timeout);

        // Wait for instant
        ke_state_set(KE_BUILD_ID(TASK_LLC, conhdl), LLC_CON_UPD_WAIT_INSTANT);
    }
    else
    {
        //fputc('Z',NULL);
        llc_util_dicon_procedure(conhdl, CO_ERROR_INSTANT_PASSED);
    }
    //printf("patch:%d,%d\r\n",param->interv,param->latency);
}

#if SLEEP_80K_RAM
static uint8_t patch7_num = PATCH7_hci_le_rd_local_p256_public_key_cmd_handler;
#endif
void __attribute__((section("adv_sleep_code"))) patch_init(void)
{
    ke_task_default_handler_get = ke_task_default_handler_get_patch;
    FPB_SetRemap(0x20000900);          //PATCH_MAP_BASE_ADDR      (uint32_t)(&patch_map_code[0])

    FPB_CompSet(0x00025358, 0x00, 0x06);

    FPB_CompSet(0x0001b084, 0x00, 0x00);    //lld_evt_winsize_change_patch
    //for dbg
    FPB_CompSet(0x0001f2ec, 0x00, 0x01);    //rwip_sleep_patch
    FPB_CompSet(0x00019b58, 0x00, 0x02);    //lld_evt_elt_insert_patch

#if (USER_MEM_API_ENABLE)
    //for malloc/free
    FPB_CompSet(0x000132e4, 0x00, 0x04);        //ke_malloc
    FPB_CompSet(0x000131cc, 0x00, 0x05);        //ke_free
#else
    //FPB_CompSet(0x00021710, 0x00, 0x04);    //smpc_handle_enc_change_evt

#if defined(PROJ_MICPHONE_KEYSCAN)
    FPB_CompSet(0x00016058, 0x00, 0x04);        //llc_llcp_con_update_req_ind,
#else
    FPB_CompSet(0x00016ee0, 0x00, 0x04);        //llc_start, no len_req
#endif

    FPB_CompSet(0x000194b0, 0x00, 0x05);    //lld_data_tx_flush
#endif

    FPB_CompSet(0x00019fac, 0x00, 0x03);        //use two nop to replace "+ (txwinoff << 1)",for master connect recv 1st pkt

#if SLEEP_80K_RAM
    if(patch7_num == PATCH7_hci_acl_data_tx_handler)
        FPB_CompSet(0x00024bc8, 0x00, 0x07);        //replace hci_acl_data_tx_handler
    else
#endif
        FPB_CompSet(0x00024edc, 0x00, 0x07);        //replace hci_le_rd_local_p256_public_key_cmd_handler
    FPB_Enable();
}
void set_patch7_func_idx(uint8_t idx)
{
    if(idx >= PATCH7_end)
        goto _exit;
#if SLEEP_80K_RAM
    patch7_num = idx;
#endif
    if(idx == PATCH7_hci_acl_data_tx_handler)
    {
        patch_map_code[7] = (uint32_t)hci_acl_data_tx_handler_patch;
        FPB_CompSet(0x00024bc8, 0x00, 0x07);
    }
#ifdef CFG_APP_MESH
    else if(idx == PATCH7_hci_le_rd_local_p256_public_key_cmp_evt_handler)
    {
        patch_map_code[7] = (uint32_t)hci_le_rd_local_p256_public_key_cmp_evt_handler_patch;
        FPB_CompSet(0x0002453c, 0x00, 0x07);
    }
#endif
    else
    {
        patch_map_code[7] = (uint32_t)hci_le_rd_local_p256_public_key_cmd_handler_patch;
        FPB_CompSet(0x00024edc, 0x00, 0x07);
    }
_exit:
    ;
}

uint32_t __attribute__((section("adv_sleep_code"))) patch_find_entry(uint32_t lr,uint32_t lr1)
{
    switch(lr)
    {
        case 0x0001b086:            //0
            return (uint32_t)lld_evt_winsize_change_patch;
        case 0x0001f2ee:                //1
            return (uint32_t)rwip_sleep_patch;
        case 0x00019b5a:                //2
            return (uint32_t)lld_evt_elt_insert_patch;
#if (USER_MEM_API_ENABLE)
        case 0x000132e6:                //4
        {
            //printf("lr1:%p\r\n",lr1);
            extern uint32_t record_lr;
            record_lr = lr1;
            return (uint32_t)ke_malloc_user;
        }
        case 0x000131ce:                //5
            return (uint32_t)ke_free_user;
#else
        // case 0x00021712:                //4
        //   return (uint32_t)smpc_handle_enc_change_evt_patch;
        case 0x00016ee2:                //4
            return (uint32_t)llc_start_patch;

#if defined(PROJ_MICPHONE_KEYSCAN)
        case 0x0001605a:                //4
            return (uint32_t)llc_llcp_con_update_req_ind_patch;
#endif
        case 0x000194b2:                //5
            return (uint32_t)lld_data_tx_flush_patch;
#endif
        default:
            return NULL;
    }
}

/*
 * 1. ����У��RCʱ�ӵ�bug
 * 2. ÿ��event��ʼʱҪ��λһ��baseband״̬��
*/
uint32_t __attribute__((section("adv_sleep_code"))) system_get_rc_clk_patch(uint8_t redo)
{
    uint32_t result, tmp = 24000000;
    uint32_t tmp_high, tmp_low;
    uint32_t tmp_freq;
#ifndef  REMOVE_CODE_IN_MESH

    if(redo == false)
        return lp_frequency;

    result = ool_read(PMU_REG_CALI_RESULT_3);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_2);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_1);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_0);

    if(result == 0)
        return lp_frequency;

    lld_sleep_mul_64(&tmp_low, &tmp_high, tmp, __jump_table.lp_clk_calib_cnt);
    tmp_freq = lld_sleep_div_64(tmp_low, tmp_high, result);
    tmp_freq >>= 1;

    if((tmp_freq < 60000) && (tmp_freq > 10000))
        lp_frequency = tmp_freq;
#endif

    return lp_frequency;
}

#ifdef CFG_APP_MESH
void lld_evt_end_isr_patch(bool apfm)
{
    // Pop the element in the programmed environment queue
    struct ea_elt_tag *elt = (struct ea_elt_tag *)co_list_pop_front(&lld_evt_env.elt_prog);

    // Pop the element from the EA
    ea_elt_remove(elt);

    if(elt->env == (void *)0xADA55ADA/*BLE_ADV_TEST_MODE_ELT*/)
    {
        lld_adv_test_end_cb(elt);
        //gpio_portc_write(gpio_portc_read() & 0xFB);
        return;
    }
    if (apfm)
    {
        // Get the associated BLE event
        struct lld_evt_tag *evt = LLD_EVT_ENV_ADDR_GET(elt);
        // Report the APFM error in element internal status
        LLD_EVT_FLAG_SET(evt, APFM);
    }
    else
    {
        // Clear ASAP flag if needed
        if(EA_ASAP_STG_TYPE_GET(elt) != EA_FLAG_NO_ASAP)
        {
            elt->asap_settings = 0;
        }
    }
    lld_evt_end(elt);
}
#endif


#define EA_MAX_INTERVAL_TIME    ((MAX_SLOT_CLOCK >> 1) - 1)
__INLINE bool ea_time_cmp(uint32_t time1, uint32_t time2)
{
    return (((time1 - time2) & MAX_SLOT_CLOCK) > EA_MAX_INTERVAL_TIME);
}
void rwble_finetgtim_isr_ram(void)
{
    while (1)
    {
        uint32_t irq_stat = ble_intstat_get();
        if (irq_stat & BLE_FINETGTIMINTSTAT_BIT)
        {
            ble_intack_clear(BLE_FINETGTIMINTACK_BIT);

            struct ea_env_tag *ea_env = (struct ea_env_tag *)0x20000724;
            struct ea_elt_tag *next_elt = (struct ea_elt_tag *)co_list_pick(&ea_env->elt_wait);
            struct ea_elt_tag *current_elt = ea_env->elt_prog;
            uint32_t current_time = ea_time_get_halfslot_rounded();
            if((current_elt) && (next_elt))
            {
                uint8_t current_threshold = (current_elt->current_prio >= next_elt->current_prio) ?
                                            current_elt->stop_latency2 : current_elt->stop_latency1;
                if(CLK_DIFF(current_time, next_elt->timestamp) <= current_threshold)
                {
                    if(current_elt->ea_cb_stop != NULL)
                    {
                        current_elt->ea_cb_stop(current_elt);
                    }
                    ea_env->elt_prog = NULL;
                }
            }
            while(next_elt != NULL)
            {
                if(ea_time_cmp((next_elt->timestamp - next_elt->start_latency) & MAX_SLOT_CLOCK, current_time)
                   || (ea_env->elt_prog != NULL && ((next_elt->timestamp - next_elt->start_latency)&MAX_SLOT_CLOCK) == current_time) )
                {
                    next_elt = (struct ea_elt_tag *)co_list_pop_front(&ea_env->elt_wait);
                    co_list_push_back(&ea_env->elt_canceled, &next_elt->hdr);
                    next_elt = (struct ea_elt_tag *)co_list_pick(&ea_env->elt_wait);
                    if(next_elt != NULL)
                    {
                        continue;
                    }
                }
                break;
            };
            ea_finetimer_isr();
        }
        else
        {
            break;
        }
    }
}

#include "gapm.h"
#include "gpio_dbg_lib.h"
uint8_t flag_mic_key_press = 0;
//0: no change;     1: change to 0;     2:change to last actual latency
void appm_set_connect_latency_flag(uint8_t value)
{
    if(value < 3)
        flag_mic_key_press = value;
}

static struct rssi_change
{
    bool enable;
    int8_t last_rssi;
    int8_t rssi[4];
    uint8_t rssi_cnt;
} gRssiChange =
{
    .enable = false,
    .last_rssi = -50,
    .rssi = {0},
    .rssi_cnt = 0,
};
void rf_adjust_tx_power(uint8_t val);
void __attribute__((section("adv_sleep_code"))) rwble_event_isr_ram(void)
{
    *(uint32_t *)0x5000000c &= 0xfffffffd;
    for(volatile uint8_t i=0; i<8; i++);
    *(uint32_t *)0x5000000c |= 0x00000002;

#if SLEEP_80K_RAM
    //gpio_dbg_toggle(2);
#endif
#ifdef CFG_APP_MESH
    while (1)
    {
        // Check BLE interrupt status and call the appropriate handlers
        uint32_t irq_stat = ble_intstat_get();

        // End of event interrupt
        if (irq_stat & BLE_EVENTINTSTAT_BIT)
        {
            // Clear the interrupt
            ble_intack_clear(BLE_EVENTINTSTAT_BIT);

            lld_evt_end_isr_patch(false);
        }

        // AFPM interrupt
        if (irq_stat & BLE_EVENTAPFAINTSTAT_BIT)
        {
            // Clear the interrupt
            ble_intack_clear(BLE_EVENTAPFAINTSTAT_BIT);

            lld_evt_end_isr_patch(true);
        }
        else
        {
            break;
        }
    }
#else
    struct ea_elt_tag *elt = (struct ea_elt_tag *)(lld_evt_env.elt_prog.first);
    struct lld_evt_tag *evt = LLD_EVT_ENV_ADDR_GET(elt);

    if(flag_mic_key_press == 1)
    {
        last_evt_lantency = evt->evt.conn.latency;
        evt->evt.conn.latency = 1;
    }
    else if(flag_mic_key_press == 2)
    {
        evt->evt.conn.latency = last_evt_lantency;
    }
    flag_mic_key_press = 0;
    /*
        struct co_list_hdr *head = lld_evt_env.elt_prog.first;
        printf("1:");
        while( head != NULL)
        {
            printf("%p��",head);
            head = head->next;
        }
        printf("\r\n");
    */
    rwble_event_isr();
    /*
        while (1)
        {
            uint32_t irq_stat = ble_intstat_get();
            if (irq_stat & BLE_EVENTINTSTAT_BIT)
            {
                //fputc('X',NULL);
                ble_intack_clear(BLE_EVENTINTSTAT_BIT);
                lld_evt_end_isr(false);
            }
            if (irq_stat & BLE_EVENTAPFAINTSTAT_BIT)
            {
                //fputc('Y',NULL);
                ble_intack_clear(BLE_EVENTAPFAINTSTAT_BIT);
                lld_evt_end_isr(true);
            }
            else
            {
                break;
            }
        }
    */
    /*
        printf("2:");
        head = lld_evt_env.elt_prog.first;
        while( head != NULL)
        {
            printf("%p��",head);
            head = head->next;
        }
        printf("\r\n");
    */
#endif

    if(gRssiChange.enable == true)
    {
        int8_t tmp_rssi = rwip_rf.rssi_convert(ble_rssi_getf(em_buf_rx_current_get()));
        //printf("R:%d\r\n",tmp_rssi);
        if(tmp_rssi < -25)
        {
            gRssiChange.rssi[gRssiChange.rssi_cnt++] = tmp_rssi;
            if(gRssiChange.rssi_cnt>3) gRssiChange.rssi_cnt = 0;

#define ALL_RSSI_LESS(val) (gRssiChange.rssi[0] < val && gRssiChange.rssi[1] < val \
                                && gRssiChange.rssi[2] < val && gRssiChange.rssi[3] < val)
#define ALL_RSSI_OVER(val) (gRssiChange.rssi[0] > val && gRssiChange.rssi[1] > val \
                                && gRssiChange.rssi[2] > val && gRssiChange.rssi[3] > val)

            if (gRssiChange.last_rssi > -50)        // -25 ~ -50                high_lvl:-65
            {
                if(ALL_RSSI_LESS(-65))
                {
                    //printf("R:%d,%d,%d,%d\r\n",gRssiChange.rssi[0],gRssiChange.rssi[1],gRssiChange.rssi[2],gRssiChange.rssi[3]);
                    rf_adjust_tx_power(0x14);
                    gRssiChange.last_rssi = -55;
                }
            }
            else if(gRssiChange.last_rssi > -60)    // -50 ~ -60    low_lvl:-40; high_lvl:-73
            {
                if(ALL_RSSI_LESS(-73))
                {
                    //printf("R:%d,%d,%d,%d\r\n",gRssiChange.rssi[0],gRssiChange.rssi[1],gRssiChange.rssi[2],gRssiChange.rssi[3]);
                    rf_adjust_tx_power(0x20);
                    gRssiChange.last_rssi = -70;
                }
                if(ALL_RSSI_OVER(-40))
                {
                    //printf("R:%d,%d,%d,%d\r\n",gRssiChange.rssi[0],gRssiChange.rssi[1],gRssiChange.rssi[2],gRssiChange.rssi[3]);
                    rf_adjust_tx_power(0x11);
                    gRssiChange.last_rssi = -40;
                }
            }
            else                        // -60 ~        low_lvl:-55;
            {
                if(ALL_RSSI_OVER(-60))
                {
                    //printf("R:%d,%d,%d,%d\r\n",gRssiChange.rssi[0],gRssiChange.rssi[1],gRssiChange.rssi[2],gRssiChange.rssi[3]);
                    rf_adjust_tx_power(0x14);
                    gRssiChange.last_rssi = -55;
                }
            }
        }
    }
    ble_master_soft_rst_setf(1);
}
void rf_enable_adjust_txpwr(bool val)
{
    gRssiChange.enable = val;
}

void __attribute__((section("adv_sleep_code"))) rwble_slp_isr_ram(void)
{
    while (1)
    {
        uint32_t irq_stat = ble_intstat_get();
        if (irq_stat & BLE_SLPINTSTAT_BIT)
        {
            ble_intack_clear(BLE_SLPINTACK_BIT);
            rwip_wakeup();
        }
        else
            break;
    }
    //gpio_dbg_toggle(3);
}

void __attribute__((section("adv_sleep_code"))) rwble_cscnt_isr_ram(void)
{
//   gpio_dbg_toggle(4);
    while (1)
    {
        uint32_t irq_stat = ble_intstat_get();
        if (irq_stat & BLE_CSCNTINTSTAT_BIT)
        {
            ble_intack_clear(BLE_CSCNTINTACK_BIT);
            rwip_wakeup_end();
            ea_finetimer_isr();
        }
        else
            break;
    }
    //  gpio_dbg_toggle(4);
}


#if 1

#if SLEEP_80K_RAM
typedef struct
{
    uint32_t ext_int_type[2];
} sleep_peripheral_value_t;
static sleep_peripheral_value_t sleep_peripheral_value;
#endif
struct ext_int_t *const ext_int_reg_sleep = (struct ext_int_t *)EXTI_BASE;
void __attribute__((weak)) __attribute__((section("adv_sleep_code"))) peripheral_ini_before_sleep(void)
{
    ;
}

void __attribute__((section("adv_sleep_code"))) user_before_sleep(void)
{
#ifndef  REMOVE_CODE_IN_MESH

#if SLEEP_80K_RAM
//   gpio_dbg_toggle(3);
    sleep_peripheral_value.ext_int_type[0] = ext_int_reg_sleep->ext_int_type[0];
    sleep_peripheral_value.ext_int_type[1] = ext_int_reg_sleep->ext_int_type[1];
#endif
    //uart2_putc_noint('s');
    peripheral_ini_before_sleep();
#if 1
    uint8_t i;
    uint8_t index;
    uint8_t button_sel;
    for(i=0; i<32; i+=8)
    {
        index = i/8;
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        // ool_write(PMU_REG_PORTA_IE+index, ool_read(PMU_REG_PORTA_IE+index) | (button_sel));
        // ool_write(PMU_REG_PORTA_OEN+index, ool_read(PMU_REG_PORTA_OEN+index) | (button_sel));
        // ool_write(PMU_REG_PORTA_PUL+index, ool_read(PMU_REG_PORTA_PUL+index) & (~button_sel));
        pmu_enable_ext_wakeup_group((enum system_port_t)index, button_sel);
#if SLEEP_80K_RAM
        stop_gpio_wk_timer();
#endif
    }
    //ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL) | PMU_REG_GPIO_WK_EN);
#endif


#if 1 //����pkvdd��ѹ
    ool_write(0x0f, 0x5d);  //0x49-0.8V, 0101 1101
    //co_delay_100us(1);
    ool_write(0x0f, 0x5f);  //0x4b-0.8v, 0101 1111

    ool_write(0x02, 0xd1);  //1101 0001     0xd1
    //co_delay_100us(1);
    ool_write(0x02, 0xd3);  //1101 0011     0xd3
#endif

    flash_power_down();
    ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) & 0xF0);   //SPI FLASH CS to pmu

#if SLEEP_80K_RAM
#if defined(PROJ_MICPHONE_KEYSCAN)
    ool_write(0x88, 0x7E);  //0xFE
#else
    ool_write(0x88, 0xFE);  //0xFE
#endif
    ool_write(0x89, 0x00);
    //gpio_dbg_toggle(4);
#else
    ool_write(0x88, 0x3a);      //FE,0x08
    ool_write(0x89, 0x00);
#endif
    //ool_write(0x8f, 0xb2);

#endif
}

void __attribute__((section("adv_sleep_code"))) user_after_sleep(void)
{
    uint32_t i;
    uint8_t button_sel;
#ifndef  REMOVE_CODE_IN_MESH

    //ool_write(0x8f, 0x32);
#if SLEEP_80K_RAM
    gpio_dbg_toggle(4);
    ool_write(0x88, 0xFF);
    ool_write(0x89, 0x3F);
#else
    ool_write(0x88, 0x3f);
    ool_write(0x89, 0x3f);
#endif

    ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) | 0x0F);   //SPI FLASH CS to digital
    flash_wakeup();

    patch_init();
//    gpio_dbg_toggle(4);

    //ool_write(0x3d, 0x4c);  //clear & disable RTC

    /*reg = ool_read(PMU_REG_MISC_STATUS);
    reg ^= 0x7F;
    if(reg & PMU_REG_ONKEY_STATUS) {
        rwip_prevent_sleep_set(RW_GPIO_INT_ONGOING);
    }*/

    // ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL) &(~ PMU_REG_GPIO_WK_EN));
    for(i=0; i<32; i+=8)
    {
        button_sel = (__jump_table.gpio_button_sel >> i) & 0xff;
        if(button_sel == 0)
        {
            continue;
        }
        pmu_disable_ext_wakeup_group((enum system_port_t)(i/8), button_sel);
        /* ���GPIO���ѵ�ԭ�� */
        if( ool_read(PMU_REG_WAKEUP_STATE_0 + i/8) )
        {
            rwip_prevent_sleep_set(RW_GPIO_INT_ONGOING);
#if SLEEP_80K_RAM
            start_gpio_wk_timer();
#endif
        }
    }

#endif
}

void __attribute__((section("adv_sleep_code"))) user_gpio_patch_imp(void)
{
    for(uint8_t i=0; i<32; i++)
    {
        if(__jump_table.gpio_button_sel & CO_BIT(i))
        {
            //ext_int_set_type(i, EXT_INT_TYPE_LOW);
            ext_int_set_control(i, 1000, 4);
        }
    }
}
void __attribute__((section("deep_sleep_code"))) app_set_sysclk(void)
{
    if(__jump_table.system_clk == 0)
    {
        *(uint32_t *)0x50000004 = 0x00000000;
    }
    else if(__jump_table.system_clk == 1)
    {
        *(uint32_t *)0x50000004 = 0x00010001;
    }
    else if(__jump_table.system_clk == 2)
    {
        *(uint32_t *)0x50000004 = 0x00020002;
    }
}
void __attribute__((weak)) __attribute__((section("adv_sleep_code"))) peripheral_ini_after_wakeup(void)
{
    ;
}
void __attribute__((weak)) __attribute__((section("deep_sleep_code"))) low_power_restore0(void)
{
    ;
}

void __attribute__((section("deep_sleep_code"))) low_power_restore_patch_imp(uint8_t index)
{
    if(index == 0)
    {
        //Re set apb2spi clk, pulse it
        //REG_PL_WR(APB2SPI_BASE+0x410, 2);
#if 1 //�ָ�pkvdd��ѹ
//        ool_write(0x0f, 0x75);  //1.2V
        //co_delay_100us(1);
//        ool_write(0x0f, 0x77);
        ool_write(0x02, 0xd1);     // 0xd1
        //co_delay_100us(1);
        ool_write(0x02, 0xd3);     // 0xd3
#endif
        if(user_gpio_init != NULL) //not deep sleep
            low_power_restore0();
    }
    else if(index == 1)
    {
        ool_write(0x4a, 0x00);  //disable rtc wake up
        app_set_sysclk();
#if SLEEP_80K_RAM
        ext_int_reg_sleep->ext_int_type[0] = sleep_peripheral_value.ext_int_type[0];
        ext_int_reg_sleep->ext_int_type[1] = sleep_peripheral_value.ext_int_type[1];
#endif
        NVIC_EnableIRQ(UART0_IRQn);
        NVIC_EnableIRQ(UART1_IRQn);
        //gpio_dbg_init(GPIO_PORT_A,GPIO_BIT_0,PORTA0_FUNC_A0);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_A1);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_A0);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_A2);
        app_set_uart_port();
        wdt_driver_ini();

        if(user_gpio_init != NULL) //not deep sleep
            peripheral_ini_after_wakeup();
    }
    else if(index == 2)
    {
    }
}
#include "keyscan.h"
void  __attribute__((section("adv_sleep_code"))) rf_sleep_patch(void)
{
    if( is_key_scan_enable())
    {
        ool_write(0x54, 0x10);
        ool_write(0x56, 0x2c);
    }
    ble_deepslcntl_set(ble_deepslcntl_get() |
                       BLE_DEEP_SLEEP_ON_BIT |    // RW BLE Core sleep
                       BLE_RADIO_SLEEP_EN_BIT |   // Radio sleep
                       BLE_OSC_SLEEP_EN_BIT);     // Oscillator sleep

#ifdef CFG_RTC_REPLACE_STANDBY  //try to replace standby mode
    ool_write(0x4a, 0x0f);  //enable rtc wake up
    ool_write(0x3d, 0x4c);  //clear timer wake up

    if(__jump_table.system_option & SYSTEM_OPTION_LP_CLK_32768)
    {
        ool_write(0x3d, 0x13);  //enable timer
    }
    else
    {
        ool_write(0x3d, 0x11);  //enable timer
    }

    //ool_write(0x36, 0x09);
    ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL)| BIT(0) );
    if( is_key_scan_enable())
    {
        ool_write(0x54, 0x13);
        ool_write(0x56, 0x3c);
    }
#endif
}
#endif


extern uint8_t const frq_freq_table[];

#ifdef HCI_MODE_ENABLE
static uint8_t rf_modem_config[258] __attribute__((section("front_stack")))=
{
    0xf0, 0x00, //write|size, base_address��add reg0x06:rf power[0x06~0x35]
    0x00, 0x88, 0x80, 0xff, 0x9e, 0x44, 0x10, 0x4c, 0x98, 0x77, 0x00, 0x00, 0x20, 0x70, 0x0c, 0xbf, //0x00~0x0f
    0x00, 0x00, 0x00, 0x70, 0x00, 0xcc, 0x8f, 0x22, 0x0a, 0x04, 0x70, 0x64, 0x55, 0x15, 0x44, 0x1a, //0x10~0x1f
    0x06, 0x06, 0x18, 0x08, 0x08, 0x00, 0x27, 0x00, 0x00, 0x69, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, //0x20~0x2f
    0x00, 0x24, 0x9f, 0x40, 0x49, 0x90, 0xcf, 0x34, 0x3a, 0x13, 0x28, 0x50, 0x88, 0x33, 0xa2, 0xf8, //0x30~0x3f
    0x22, 0x94, 0x0f, 0xd1, 0x80, 0x68, 0x00, 0x00, 0x3f, 0x0f, 0x80, 0x17, 0x8a, 0x12, 0x00, 0x00, //0x40~0x4f
    0x10, 0x00, 0x94, 0x7c, 0x98, 0x14, 0x49, 0x0b, 0x4e, 0x72, 0xb4, 0x94, 0x00, 0x00, 0x00, 0x00, //0x50~0x5f
    0x00, 0xda, 0x4c, 0x4b, 0x33, 0x00, 0x00, 0x00, 0x23, 0x00, 0x14, 0x04, 0x01, 0x00, 0x88, 0x14, //0x60~0x6f
    0xf0, 0x70, //write|size, base_address
    0x83, 0x1c, 0x08, 0x10, 0x16, 0x01, 0xb0, 0x00, 0x63, 0xe4, 0xd6, 0xbe, 0x31, 0x40, 0x0c, 0x09, //0x70~0x7f
    0x36, 0x3a, 0x38, 0x3a, 0x3b, 0x3b, 0x3c, 0x3c, 0x01, 0x01, 0x01, 0x03, 0x03, 0x03, 0x2a, 0x36, //0x80~0x8f,new rx timing
    0x01, 0x01, 0x04, 0x5f, 0x60, 0x01, 0x02, 0x01, 0x3F, 0x3F, 0x07, 0x0c, 0x02, 0x04, 0x3f, 0x80, //0x90~0x9f
    0x00, 0x22, 0x01, 0x0a, 0xc0, 0xbf, 0xbf, 0x3f, 0x0b, 0x15, 0x20, 0xc0, 0x6c, 0x28, 0x14, 0x3c, //0xa0~0xaf
    0x64, 0x64, 0x53, 0x55, 0x25, 0x54, 0x55, 0x15, 0x56, 0x55, 0x15, 0x00, 0x04, 0x64, 0x00, 0x00, //0xb0~0xbf
    0x01, 0x01, 0x01, 0x01, 0x00, 0x02, 0x04, 0x06, 0x0e, 0x16, 0x36, 0x3e, 0x5e, 0x7e, 0x9e, 0x05, //0xc0~0xcf
    0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0xff, 0x01, 0xe0, 0xff, 0x0f, //0xd0~0xdf
    0x9c, 0xe0, //write|size, base_address
    0x00, 0x01, 0x00, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x15, 0x00, 0x00, 0x00, 0x01, //0xe0~0xef
    0x90, 0x4e, 0xc6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xc0, 0x2d, 0x24                          //0xf0~0xff
};
#else
static uint8_t rf_modem_config[258] __attribute__((section("front_stack")))=
{
    0xf0, 0x00, //write|size, base_address��add reg0x06:rf power[0x06~0x35]
    0x00, 0x88, 0x80, 0xff, 0x9e, 0x44, 0x0C, 0x4c, 0x98, 0x77, 0x00, 0x00, 0xb0, 0x70, 0x0c, 0xbf, //0x00~0x0f
    0x00, 0x00, 0x00, 0x70, 0x00, 0xcc, 0x8f, 0x22, 0x0a, 0x04, 0x70, 0x64, 0x55, 0x15, 0x44, 0x1a, //0x10~0x1f
    0x06, 0x06, 0x18, 0x08, 0x08, 0x00, 0x27, 0x00, 0x00, 0x69, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, //0x20~0x2f
    0x00, 0x24, 0x9c, 0x40, 0x49, 0x90, 0xcf, 0x34, 0x3a, 0x13, 0x28, 0x50, 0x88, 0x33, 0xa2, 0xf8, //0x30~0x3f
    0x22, 0x94, 0x0f, 0xd1, 0x80, 0x68, 0x00, 0x00, 0x3f, 0x0f, 0x80, 0x17, 0x8a, 0x12, 0x00, 0x00, //0x40~0x4f
    0x10, 0x00, 0x94, 0x7c, 0x98, 0x14, 0x49, 0x0b, 0x4e, 0x72, 0xb4, 0x94, 0x00, 0x00, 0x00, 0x00, //0x50~0x5f
    0x00, 0xda, 0x4c, 0x4b, 0x33, 0x00, 0x00, 0x00, 0x23, 0x00, 0x14, 0x04, 0x01, 0x00, 0x88, 0x14, //0x60~0x6f
    0xf0, 0x70, //write|size, base_address
    0x83, 0x1c, 0x08, 0x10, 0x16, 0x01, 0xb0, 0x00, 0x63, 0xe4, 0xd6, 0xbe, 0x31, 0x40, 0x0c, 0x09, //0x70~0x7f, reg0x7e:(0x7~0xc),bigger,increase long distance performance
    //0x3a, 0x3e, 0x3c, 0x3e, 0x40, 0x42, 0x44, 0x45, 0x01, 0x01, 0x01, 0x03, 0x03, 0x03, 0x2a, 0x39, //0x80~0x8f,new rx timing
    0x26, 0x2a, 0x28, 0x2a, 0x2b, 0x2b, 0x2c, 0x2c, 0x01, 0x01, 0x01, 0x03, 0x03, 0x03, 0x1a, 0x26, //0x80~0x8f,new rx timing
    0x01, 0x01, 0x04, 0x4f, 0x50, 0x01, 0x02, 0x01, 0x3F, 0x3F, 0x07, 0x0c, 0x02, 0x04, 0x3f, 0x80, //0x90~0x9f
    0x00, 0x22, 0x01, 0x0a, 0xc0, 0xbf, 0xbf, 0x3f, 0x0b, 0x15, 0x20, 0xc0, 0x6c, 0x28, 0x14, 0x3c, //0xa0~0xaf
    0x64, 0x64, 0x53, 0x55, 0x25, 0x54, 0x55, 0x15, 0x56, 0x55, 0x15, 0x00, 0x04, 0x64, 0x00, 0x00, //0xb0~0xbf
    0x01, 0x01, 0x01, 0x01, 0x00, 0x02, 0x04, 0x06, 0x0e, 0x16, 0x36, 0x3e, 0x5e, 0x7e, 0x9e, 0x05, //0xc0~0xcf
    //0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0xff, 0x01, 0xe0, 0xff, 0x0f, //0xd0~0xdf
    0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0x63, 0xff, 0x01, 0xe0, 0xff, 0x0f, //0xd0~0xdf
    0x9c, 0xe0, //write|size, base_address
    0x00, 0x01, 0x00, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x15, 0x00, 0x00, 0x00, 0x01, //0xe0~0xef
    0x90, 0x4e, 0xc6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xc0, 0x2d, 0x24                          //0xf0~0xff

};
#endif

void rf_set_tx_power(uint8_t val)
{
    if( val>0x28 || val <0x02 )
        return;
    if(rf_modem_config[8] == val)
        return;
    rf_modem_config[8] = val;   //copy to burst write ram.
}

void rf_adjust_tx_power(uint8_t val)
{
    rf_modem_config[8] = val;
    printf("txp:%x\r\n",val);

    REG_PL_WR(0x500000bc,0x00);     //change spi write select, write modem reg.
    ble_spiptr_setf(0x68);          //set spi transfer source addr offset,from exchange mem offset 0x68.
    rwip_rf.reg_wr(0x06, val);
    // copy val to exchange mem, offset 0x68: { byte0(0x80+1),byte1(0x06),byte2(value)}
    //spi write actual modem reg and act at once
}

// 0: VBAT;   1: digital 1.2V
void rf_set_tx_power_source(uint8_t val)
{
    if(val == 0)
        rf_modem_config[0x5b+2] = 0x94; //enhance tx power,  tx power from vbat, 3V. will affect mic data.
    else
        rf_modem_config[0x5b+2] = 0x14; //enhance tx power,  tx power from v_digital 1.2V.
}


void rf_set_lna_gain(uint8_t val)
{
    if( val>0x0c || val <0x05 )
        return;
    rf_modem_config[0x7e+4] = val;
}
/*
void printf_rf_val(void)
{
    printf("rf:%x,%x,%x\r\n",rf_modem_config[0x40+2],rf_modem_config[0x41+2],rf_modem_config[0x42+2]);
}
*/
void __attribute__((section("adv_sleep_code"))) rf_get_param_ready_patch(void)
{
    ble_master_soft_rst_setf(1);
    memcpy((void *)0x40002068, rf_modem_config, sizeof(rf_modem_config));
}

void __attribute__((section("adv_sleep_code"))) rf_init_patch(struct rwip_rf_api *api)
{
    extern void rf_init_api(struct rwip_rf_api *api);
    extern void rf_init_rf_controller(void);

    rf_init_api(api);
    rf_init_rf_controller();
    //reset will casue error.
    rwip_rf.reset = ( void(*)(void) )(rf_init_patch);
    rwip_rf.sleep = rf_sleep_patch;
    memcpy((void *)0x40002068, rf_modem_config, 10);

    ble_spiptr_setf(0x68);
    //launch SPI transfer
    ble_spigo_setf(1);
    //wait for transfer to be completed
    while (!ble_spicomp_getf());

    ble_spiptr_setf(0x68+0x02+0x70);
    //launch SPI transfer
    ble_spigo_setf(1);
    //wait for transfer to be completed
    while (!ble_spicomp_getf());

    ble_spiptr_setf(0x68+0x02+0x70+0x02+0x70);
    //launch SPI transfer
    ble_spigo_setf(1);

    //wait for transfer to be completed
    while (!ble_spicomp_getf());


    REG_PL_WR(0x500000bc,0x04); //sys_reg2f,bit2, static_en
    ble_spiptr_setf(0x68);
#ifdef HCI_MODE_ENABLE

    rwip_rf.reg_wr(0x00, 0x2C); //a0:a1, 0x00, 0x22,
    rwip_rf.reg_wr(0x01, 0x22);
    rwip_rf.reg_wr(0x02, 0x2C); //bb:bf,0x00, 0x04, 0x64, 0x00, 0x00
#else
    rwip_rf.reg_wr(0x00, 0x25); //a0:a1, 0x00, 0x22,
    rwip_rf.reg_wr(0x01, 0x22);
    rwip_rf.reg_wr(0x02, 0x25); //bb:bf,0x00, 0x04, 0x64, 0x00, 0x00
#endif
    rwip_rf.reg_wr(0x03, 0x04);
    rwip_rf.reg_wr(0x04, 0x64);
    rwip_rf.reg_wr(0x05, 0x00);
    rwip_rf.reg_wr(0x06, 0x00);
    REG_PL_WR(0x500000bc,0x00); //sys_reg2f,bit3, fll_cfg_en


    memcpy((uint8_t *)(EM_FT_OFFSET + EM_BASE_ADDR), frq_freq_table, 40);
#ifdef FOR_NORDIC_HELMET
    REG_PL_WR(0x40000070,REG_PL_RD(0x40000070)|BIT(24));
#endif
}

//change sleep RC, type0: normal clock;     type1: lower-pow clock
void set_sleep_rc_source(uint8_t src)
{
    if(src == 0)
        ool_write(0x14, ool_read(0x14) & 0xfe);
    else
        ool_write(0x14, ool_read(0x14) | 0x01);
}
#if 1
//for sleep timing mainly
void app_pmu_init(void)
{
//0x10 & 0x00 , will change aldo voltage,  reg[0x00] is 0x80 as default.
    ool_write(0x0d, 0x86);  //disable 32K osc
    //ool_write(0x10, 0x14);  //BG trim 1000=1.2V 0100=1.05V,0x14,0x18
    ool_write(0x8f, 0x32);  //isolation control

    ool_write(PMU_REG_ANA_CLK_EN, 0x00);
    //ool_write(0x0a, 0x00);
    ool_write(0x0a, 0x40);
    ool_write(0x08, 0x0);

    ool_write(0x3d, ool_read(0x3d) & 0xfe);     //disable RTC

#ifdef CFG_RTC_REPLACE_STANDBY
    //use rtc to wake up from shut down mode
    ool_write(0x3e, 0x00);  //rtc counter initial value
    ool_write(0x3f, 0x00);
    ool_write(0x40, 0x00);
    ool_write(0x41, 0x00);

    ool_write(0x42, 0x46);  //0x45~0x42: 32bits rtc sleep time * 0.5ms
    ool_write(0x43, 0xF0);
    ool_write(0x44, 0x00);
    ool_write(0x45, 0x00);

    ool_write(0x54, ool_read(0x54) & 0xFE); //disable baseband deep sleep
    //ool_write(0x8f, ool_read(0x8f) | 0x80); //pk vdd reg enable keep ram power on
#endif

    ool_write(0x86, 0x15);

    ool_write(PMU_REG_TWEXT, 0xf0);
    ool_write(PMU_REG_TWMIX, 0x00);
    ool_write(PMU_REG_TWOSC, 0x00);
    ool_write(PMU_REG_TWRM, 0x00);

    ool_write(0x27, 0x01);  //sleep isolation enable
    ool_write(0x28, 0x26);  //wake up isolation release

    ool_write(0x29, 0x02);  //BUCK
    ool_write(0x2c, 0x0e);  //power on disable
    ool_write(0x2b, 0x05);  //DLDO
    ool_write(0x2e, 0x09);
    ool_write(0x2f, 0x09);
    ool_write(0x30, 0x09);  //pkvddh(analog)
    ool_write(0x31, 0x07);
    ool_write(0x32, 0x07);
    ool_write(0x33, 0x07);

    ool_write(0x8b, 0x4f);  //power on reset delay to core in standby and shutdown mode, 0x28
    //ool_write(0x8c, 0x5c);  //0x2c
    ool_write(0x8d, 0x50);    //0x2e
    ool_write(0x8e, 0x0e);  //enter sleep delay

    ool_write(0x54, 0x13);

    ool_write(0x56, 0x38);      //solve rf ini  lock issue
    ool_write(0x56, 0x3c);      //[7:5] keyscan interval is max; [4] ,keyscan clk en
    ool_write(0xa9, 0xf0);   //disable led pullup to save current
}
#endif

