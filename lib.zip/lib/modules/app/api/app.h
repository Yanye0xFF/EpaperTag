/**
 ****************************************************************************************
 *
 * @file app.h
 *
 * @brief Application entry point
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef APP_H_
#define APP_H_

/**
 ****************************************************************************************
 * @addtogroup APP
 * @ingroup RICOW
 *
 * @brief Application entry point.
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"     // SW configuration

#if (BLE_APP_PRESENT)

#include <stdint.h>          // Standard Integer Definition
#include "gapm_task.h"            // GAPC Definitions
#include "gapc_task.h"

#include <co_bt.h>           // Common BT Definitions
#include "arch.h"            // Platform Definitions
#include "gapc.h"            // GAPC Definitions
#include "app_task.h"
#include "app_sec.h"

/// Maximal length of the Device Name value
#define APP_DEVICE_NAME_LENGTH_MAX      (ADV_DATA_LEN - 5)//26, (18), for at,name_payload_len:25
/// Advertising data maximal length
#define APP_ADV_DATA_MAX_SIZE           (ADV_DATA_LEN - 3)
/// Scan Response data maximal length
#define APP_SCAN_RESP_DATA_MAX_SIZE     (SCAN_RSP_DATA_LEN)

/// Advertising channel map - 37, 38, 39
#define APP_ADV_CHMAP           (0x07)
/// Advertising minimum interval - 40ms (32*1.25ms)
#define APP_ADV_INT_MIN         (0x20)
/// Advertising maximum interval - 80ms (64*1.25ms)
#define APP_ADV_INT_MAX         (0x40)
/// Fast advertising interval
#define APP_ADV_FAST_INT        (32)

#define APP_SCAN_INT            (64)  //(64*0.625ms)
#define APP_SCAN_WIN            (16)  //(16*0.625ms)

#define APP_DFLT_CON_DURATION   7000 //(500*10ms)
#define APP_CONN_INT_MIN        32  //(64*1.25ms)
#define APP_CONN_INT_MAX        32  //(64*1.25ms)

#define APP_CONN_LATENCY        0
#define APP_CONN_SU_TO          300 //(300*10ms)

#define APP_CONN_CE_MIN         0x04
#define APP_CONN_CE_MAX         0x04



/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */
enum store_info_type
{
    PARING_INFO_TYPE_LTK,
    PARING_INFO_TYPE_BOND_FLAG,
    PARING_INFO_TYPE_PEER_BD_ADDRESS,
    PARING_INFO_TYPE_IRK,
    PARING_INFO_TYPE_TK,
    HID_INFO_TYPE_NTF,
};

typedef struct
{
    void * buf;
    uint32_t len;
    uint8_t info_type;
} store_infot_t;

struct conn_peer_param
{
    uint8_t conidx;
    enum app_sec_bond_t bond;
    struct bd_addr peer_addr;
    uint8_t addr_type;
    uint16_t con_interval;
    /// Connection latency
    uint16_t con_latency;
    /// Link supervision timeout
    uint16_t sup_to;
};
struct conidx_status
{
    uint8_t conidx;
    uint8_t status;
};

struct gapc_param_updated_ind1
{
    uint8_t conidx;
    struct gapc_param_updated_ind ind;
};
struct gapc_peer_features_ind1
{
    uint8_t conidx;
    struct gapc_peer_features_ind ind;
};

struct app_addr_solved_result_ind_t
{
    uint8_t conidx;
    uint8_t status;
    struct gapm_addr_solved_ind const *param;
};

typedef void(* app_callback_func_t)(void * param);

enum app_cb_func_id
{
    APP_EVT_ID_INIT= 0,
    APP_EVT_ID_DEVICE_IS_READY,
    APP_EVT_ID_RESET_COMPLETED,
    APP_EVT_ID_DEV_CFG_COMPLETED,
    APP_EVT_ID_SVC_ADDED,
    APP_EVT_ID_DB_ADDED,
    APP_EVT_ID_SLAVER_CONNECTED,

    APP_EVT_ID_REQ_INFO,
    APP_EVT_ID_GOT_INFO,

    APP_EVT_ID_SLAVER_ENCRYPTED,
    APP_EVT_ID_DISCONNECTED,

    APP_EVT_ID_PARAM_UPDATE_REJECTED,
    APP_EVT_ID_PARAM_UPDATE_IND,
    APP_EVT_ID_PARAM_UPDATED,

    APP_EVT_ID_ADV_END,

    APP_EVT_ID_SCAN_COMPLETED,
    APP_EVT_ID_ADV_REPORT,

    APP_EVT_ID_GOT_PEER_FEATURE,
    APP_EVT_ID_MASTER_GOT_SEC_REQ,
    APP_EVT_ID_SLAVER_GOT_BOND_REQ,

    APP_EVT_ID_MASTER_CONNECTED,
    APP_EVT_ID_MASTER_CONNECT_FAILED,
    APP_EVT_ID_MASTER_ENCRYPTED,
    APP_EVT_ID_MASTER_ENCRYPT_COMPELETED,

    APP_EVT_ID_GOT_AES128_RESULT,

    APP_EVT_ID_ADDR_RESOLVE_RESULT_IND,
    APP_EVT_ID_BOND_CHECK_END,

    APP_EVT_MAX
};

typedef enum
{
    APP_ROLE_NONE = 0,
    APP_ROLE_SLAVE =1,
    APP_ROLE_MASTER =2,
} app_role_t;

/// Application environment structure
struct app_env_tag
{
    uint8_t role;       //0, 1 slave 2 master
    uint8_t conidx;     //latest connection idx
    bool encrypted;
    bool connected[BLE_CONNECTION_MAX];
    /// Last initialized profile
    uint8_t next_svc;
    uint8_t param_update_on_going;
    struct gapc_param_updated_ind con_param;
    app_callback_func_t func[APP_EVT_MAX];
};

typedef enum
{
    /// Initialization state
    APPM_STATUS_INIT = APPM_INIT,
    /// Database create state
    APPM_STATUS_CREATE_DB = APPM_CREATE_DB,
    /// Ready State
    APPM_STATUS_READY = APPM_READY,
    /// Initiating state
    APPM_STATUS_INITIATING = APPM_INITIATING,
    /// Scanning state
    APPM_STATUS_SCANNING = APPM_SCANNING,
    /// Advertising state
    APPM_STATUS_ADVERTISING = APPM_ADVERTISING,
    /// Number of defined states.
    APPM_STATUS_MAX = APPM_STATE_MAX,
} app_status_t;

typedef enum
{
    DEEP_SLEEP_WK_GPIO,
    DEEP_SLEEP_WK_ONKEY,
    DEEP_SLEEP_WK_END,
} deep_sleep_wk_type;


/*
 * GLOBAL VARIABLE DECLARATION
 ****************************************************************************************
 */

/// Application environment
extern struct app_env_tag app_env;
extern uint8_t app_device_name[APP_DEVICE_NAME_LENGTH_MAX];

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

extern void (*appm_init)(void);
void appm_init_imp(void);
void app_set_uart_port(void);


/**
 ****************************************************************************************
 * USER_API
 ****************************************************************************************
 */
#define VER_MAIN 1
#define VER_SUB 5
#define VER_DBG 7

void app_reset_app(void);
void appm_set_device_name(uint8_t *arg,uint8_t size);
void appm_handle_white_list_cmd(struct gapm_white_list_mgt_cmd *cmd);

void appm_set_dev_configuration(struct gapm_set_dev_config_cmd *msg);
bool appm_add_svc(void);


void appm_start_scan(struct gapm_start_scan_cmd *msg);
void appm_stop_scan(void);


void appm_start_advertising(struct gapm_start_advertise_cmd *msg);
void appm_stop_advertising(void);
void appm_start_advertising_default(void *arg);
void appm_start_scan_default(void *arg);
void appm_set_dev_configuration_default(void *arg);



void appm_start_connecting(struct gapm_start_connection_cmd *cmd);
void appm_start_connecting_default(void *arg);

void appm_stop_connecting(void);
void appm_disconnect(uint8_t conidx);

void set_con_param_accpet_flag(bool flag);
void appm_update_param(uint8_t conidx, struct gapc_conn_param *conn_param);
void appm_get_peer_info(uint16_t conidx,uint8_t operation);
void appm_exc_mtu_cmd(uint8_t conidx);

//For master
void appm_start_bond_cmd(uint8_t conidx);
//For master
void app_sec_send_enc_req(uint8_t conidx);

uint8_t appm_get_connect_num(void);
bool appm_get_connect_status(uint8_t conidx);
app_status_t appm_get_current_status(void);

void appm_set_cb_func(uint8_t id, app_callback_func_t func);

uint8_t *ble_get_addr(void);
void ble_set_addr(uint8_t* addr);
void sys_soft_reset(void);

void appm_use_aes128_block(uint8_t *key, uint8_t *plaintext,app_callback_func_t func);

void appm_sleep_stop(void);
void appm_sleep_start(void);
void appm_set_exit_int_gpio(uint32_t exit_int_gpio);
// 10~100 000
void appm_goto_deep_sleep(uint32_t tick_ms,uint32_t wk_key);
void appm_goto_deep_sleep2(deep_sleep_wk_type type,uint32_t tick_ms);

uint32_t appm_get_rand_low4byte_mac(void);

uint8_t app_get_battay_value(void);

//val range [0x02~0x28]
void rf_set_tx_power(uint8_t val);
// 0: VBAT;   1: digital 1.2V
void rf_set_tx_power_source(uint8_t val);

void rf_set_lna_gain(uint8_t val);  //0x05~0x0c
//change sleep RC, type0: normal clock;     type1: lower-pow clock
void set_sleep_rc_source(uint8_t src);
void rf_enable_adjust_txpwr(bool val);

//Weak Function
void peripheral_ini_after_wakeup(void);
void user_ext_int(uint8_t key_group,uint32_t key);
void user_ext_int_release(uint8_t key_group,uint32_t key);

/*
@value
0: 2.1V; 1: 2.3V; 2: 2.5V; 3: 2.7V; 4: 2.9V; 5: 3.1V; 6: 3.3V; 7: 3.5V
*/
void appm_set_aldo_voltage(uint8_t value,uint8_t is_bypass);

//0: no change;     1: change to 0;     2:change to last actual latency
void appm_set_connect_latency_flag(uint8_t value);


#endif //(BLE_APP_PRESENT)


#endif // APP_H_
