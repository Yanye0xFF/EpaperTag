#ifndef _PATCH_H
#define _PATCH_H

#include "rwip.h"

#ifndef SLEEP_80K_RAM
#define SLEEP_80K_RAM (1)
#endif


enum
{
    PATCH7_hci_le_rd_local_p256_public_key_cmd_handler = 0,
#ifdef CFG_APP_MESH
    PATCH7_hci_le_rd_local_p256_public_key_cmp_evt_handler,
#endif
    PATCH7_hci_acl_data_tx_handler,
    PATCH7_end,
};
void set_patch7_func_idx(uint8_t idx);


uint32_t system_get_rc_clk_patch(uint8_t redo);
void user_before_sleep(void);
void user_after_sleep(void);
void rf_sleep_patch(void);
void rf_init_patch(struct rwip_rf_api *api);
void rf_get_param_ready_patch(void);
void low_power_restore_patch_imp(uint8_t index);
void user_gpio_patch_imp(void);


void get_static_p256_public_key(void);

void app_set_sysclk(void);
void app_pmu_init(void);
void patch_init(void);


#endif  //_PATCH_H
