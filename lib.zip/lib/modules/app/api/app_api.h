#ifndef _APP_API_H
#define _APP_API_H

#include <stddef.h>    // standard definitions
#include "prf.h"
#include "rwip.h"
#include "ke_msg.h"
#include "lld_evt.h"
#include "co_math.h"


extern void (*appm_init)(void);
extern void (*app_user_before_sleep_callback)(void);
extern void (*app_user_after_sleep_callback)(void);

extern enum rwip_sleep_mode_t (*rwip_sleep_mode_check)(uint32_t *);
extern void (*low_power_save_patch)(void);
extern void (*low_power_restore_patch)(uint8_t);

extern void (*rf_init)(struct rwip_rf_api *api);
extern void (*rf_get_param_ready)(void);

extern struct prf_task_cbs *(*user_prf_itf_get)(uint8_t);

extern void (*svc_exception_handler)(void);

extern void (*user_gpio_init)(void);
extern void (*user_intc_init)(void);

extern ke_msg_func_t (*ke_task_state_handler_get)(ke_msg_id_t const msg_id, ke_task_id_t const task_id, ke_msg_func_t org_func);
extern ke_msg_func_t (*ke_task_default_handler_get)(ke_msg_id_t const msg_id, ke_task_id_t const task_id, ke_msg_func_t org_func);

extern uint8_t (*lld_evt_assign_min_wakeup_event)(struct lld_evt_tag *evt);

void app_boot(void);
void app_boot_load_data(uint8_t *dest, uint32_t src, uint32_t len);
void app_boot_save_data(uint32_t dest, uint8_t *src, uint32_t len);
uint32_t app_boot_get_curr_storage_base(void);
uint32_t app_boot_get_firmwave_version(void);
uint8_t app_boot_get_storage_type(void);

#endif // _APP_API_H


