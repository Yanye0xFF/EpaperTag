#ifndef _LOW_POWER_H
#define _LOW_POWER_H

void low_power_save_keyscan_value(uint8_t index, uint32_t value);
void low_power_save(void);
void low_power_restore(void);

#endif //_LOW_POWER_H

