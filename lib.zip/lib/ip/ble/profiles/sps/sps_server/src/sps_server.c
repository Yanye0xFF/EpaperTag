/**
****************************************************************************************
*
* @file sps_server.c
*
* @brief Serial Port Service receive application.
*
* Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
* program includes Confidential, Proprietary Information and is a Trade Secret of
* Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
* unless authorized in writing. All Rights Reserved.
*
* <bluetooth.support@diasemi.com> and contributors.
*
****************************************************************************************
*/

/**
 ****************************************************************************************
 * @addtogroup SPS_SERVER
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "sps_server_task.h"
#include "sps_server.h"
#include "ke_mem.h"
#include "attm_db.h"
#include "app.h"
#if (BLE_SPS_SERVER)

/*
 * SPS ATTRIBUTES DEFINITION
 ****************************************************************************************
 */
uint8_t spss_uuids[64] =
{
    0xb7, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVICE_UUID
    0xb8, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVER_TX_UUID
    0xba, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07, //SPS_SERVER_RX_UUID
    0xb9, 0x5c, 0x49, 0xd2, 0x04, 0xa3, 0x40, 0x71, 0xa0, 0xb5, 0x35, 0x85, 0x3e, 0xb0, 0x83, 0x07  //SPS_FLOW_CTRL_UUID
};
/// Full SPS Database Description - Used to add attributes into the database
const struct attm_desc spss_att_db[SPS_SERVER_IDX_NB] =
{
    // serial port Service Declaration
    [SPS_PRIM_SVC]                  =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    //In client side, this attribute is for rx
    [SPS_SERVER_TX_DATA_CHAR]       =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, SPS_SERVER_TX_DATA_VAL},
    [SPS_SERVER_TX_DATA_VAL]        =   {0xFFFF, PERM(RD, ENABLE) | PERM(NTF, ENABLE), PERM(RI, ENABLE) | PERM_VAL(UUID_LEN, PERM_UUID_128), 300},
    [SPS_SERVER_TX_DATA_CFG]        =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE)| PERM(WRITE_COMMAND, ENABLE), 0, sizeof(uint16_t)},
    [SPS_SERVER_TX_DATA_DESC]       =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, SPS_SERVER_TX_DESC_LEN},

    //In client side, this attribute is for tx
    [SPS_SERVER_RX_DATA_CHAR]       =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, SPS_SERVER_RX_DATA_VAL},
    [SPS_SERVER_RX_DATA_VAL]        =   {0xFFFF, PERM(RD, ENABLE) | PERM(WRITE_COMMAND, ENABLE) | PERM(WRITE_REQ, ENABLE), PERM(RI, ENABLE) | PERM_VAL(UUID_LEN, PERM_UUID_128), 300},
    [SPS_SERVER_RX_DATA_CFG]        =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE)| PERM(WRITE_COMMAND, ENABLE), 0, sizeof(uint16_t)},
    [SPS_SERVER_RX_DATA_DESC]       =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, SPS_SERVER_RX_DESC_LEN},

    [SPS_FLOW_CTRL_CHAR]            =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, SPS_FLOW_CTRL_VAL},
    [SPS_FLOW_CTRL_VAL]             =   {0xFFFF, PERM(RD, ENABLE) | PERM(NTF, ENABLE) | PERM(WRITE_COMMAND, ENABLE), PERM(RI, ENABLE) | PERM_VAL(UUID_LEN, PERM_UUID_128), sizeof(uint16_t)},
    [SPS_FLOW_CTRL_CFG]             =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE)| PERM(WRITE_COMMAND, ENABLE), 0, sizeof(uint16_t)},
    [SPS_FLOW_CTRL_DESC]            =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, SPS_SERVER_FLOW_CTRL_DESC_LEN},
};

/*
 * LOCAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initialization of the SPSS module.
 * This function performs all the initializations of the Profile module.
 *  - Creation of database (if it's a service)
 *  - Allocation of profile required memory
 *  - Initialization of task descriptor to register application
 *      - Task State array
 *      - Number of tasks
 *      - Default task handler
 *
 * @param[out]    env        Collector or Service allocated environment data.
 * @param[in|out] start_hdl  Service start handle (0 - dynamically allocated), only applies for services.
 * @param[in]     app_task   Application task number.
 * @param[in]     sec_lvl    Security level (AUTH, EKS and MI field of @see enum attm_value_perm_mask)
 * @param[in]     param      Configuration parameters of profile collector or service (32 bits aligned)
 *
 * @return status code to know if profile initialization succeed or not.
 ****************************************************************************************
 */
static uint8_t spss_init (struct prf_task_env* env, uint16_t* start_hdl, uint16_t app_task, uint8_t sec_lvl,  void* params)
{
    // Service content flag
    uint32_t cfg_flag= SPSS_CFG_FLAG_MAX;
    // DB Creation Status
    uint8_t status = ATT_ERR_NO_ERROR;
    // Total number of attributes
    uint8_t tot_nb_att = SPS_SERVER_IDX_NB;
    uint16_t handle;

    // Allocate TIPS required environment variable
    struct spss_env_tag* spss_env =
        (struct spss_env_tag* ) ke_malloc(sizeof(struct spss_env_tag), KE_MEM_ATT_DB);

    env->env = (prf_env_t*) spss_env;

    // Check that attribute list can be allocated.
    status = attmdb_reserve_handle_range(start_hdl, tot_nb_att);

    if (status == ATT_ERR_NO_ERROR)
    {
        /*---------------------------------------------------*
         * Serial Port Service Creation
         *---------------------------------------------------*/
        status = attm_svc_create_db_ext(start_hdl, 0xFFFF, (uint8_t *)&cfg_flag,
                                        SPS_SERVER_IDX_NB, NULL, env->task, &spss_att_db[0],
                                        sec_lvl, spss_uuids);

        // Update index
        spss_env->spss_shdl = *start_hdl;
        *start_hdl += SPS_SERVER_IDX_NB;

        // Set OTAS Tx Client Char. Information Char. Value
        if(status == GAP_ERR_NO_ERROR)
        {
            handle = spss_env->spss_shdl + SPS_SERVER_TX_DATA_DESC;
            status = attmdb_att_set_value(handle, SPS_SERVER_TX_DESC_LEN, 0, (uint8_t *)SPS_SERVER_TX_DESC);

            handle = spss_env->spss_shdl + SPS_SERVER_RX_DATA_DESC;
            status = attmdb_att_set_value(handle, SPS_SERVER_RX_DESC_LEN, 0, (uint8_t *)SPS_SERVER_RX_DESC);

            handle = spss_env->spss_shdl + SPS_FLOW_CTRL_DESC;
            status = attmdb_att_set_value(handle, SPS_SERVER_FLOW_CTRL_DESC_LEN, 0, (uint8_t *)SPS_SERVER_FLOW_CTRL_DESC);
        }

        spss_env->prf_env.app_task    = app_task
                                        | (PERM_GET(sec_lvl, SVC_MI) ? PERM(PRF_MI, ENABLE) : PERM(PRF_MI, DISABLE));
        // Multi Instantiated task
        spss_env->prf_env.prf_task    = env->task | PERM(PRF_MI, ENABLE);

        // initialize environment variable
        env->id                     = TASK_ID_SPSS;
        env->desc.idx_max           = __jump_table.conn_max;
        env->desc.state             = spss_env->state;
        env->desc.state_handler     = sps_server_state_handler;

        /* Put SPSS in disabled state */
        for(uint8_t i=0; i<__jump_table.conn_max; i++)
        {
            ke_state_set(KE_BUILD_ID(env->task, i), SPS_SERVER_IDLE);
        }
    }

    return status;
}

/**
 ****************************************************************************************
 * @brief Destruction of the SPSS module - due to a reset for instance.
 * This function clean-up allocated memory (attribute database is destroyed by another
 * procedure)
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 ****************************************************************************************
 */
static void spss_destroy(struct prf_task_env* env)
{

}

/**
 ****************************************************************************************
 * @brief Handles Connection creation
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 ****************************************************************************************
 */
static void spss_create(struct prf_task_env* env, uint8_t conidx)
{
    appm_exc_mtu_cmd(conidx);
}

/**
 ****************************************************************************************
 * @brief Handles Disconnection
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 * @param[in]        reason     Detach reason
 ****************************************************************************************
 */
static void spss_cleanup(struct prf_task_env* env, uint8_t conidx, uint8_t reason)
{

}

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// SPSS Task interface required by profile manager
const struct prf_task_cbs spss_itf =
{
    (prf_init_fnct) spss_init,
    spss_destroy,
    spss_create,
    spss_cleanup,
};


/*
 * GLOBAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

const struct prf_task_cbs* spss_prf_itf_get(void)
{
    return &spss_itf;
}



#endif // BLE_SPS_SERVER

/// @} SPS_SERVER

