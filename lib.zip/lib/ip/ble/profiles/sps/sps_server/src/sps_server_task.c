/**
 ****************************************************************************************
 *
 * @file sps_server_task.c
 *
 * @brief Serial Port Service Device profile task.
 *
 * Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
 *
 * <bluetooth.support@diasemi.com> and contributors.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup SPS_SERVER_TASK
 * @{
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdio.h>
#include "rwble_config.h"
#include "prf_utils.h"
#include "sps_server.h"
#include "sps_server_task.h"
#include "gattc_task.h"
#include "gapc_task.h"
#include "attm_db.h"
#include "atts.h"
#include "app_spss.h"

#include "gpio.h"
#include "system.h"
#include "gattc.h"


#if BLE_SPS_SERVER

//Flags
//Transmission bussy flag counting the expected GATTC_NOTIFY indications
//uint8_t tx_busy_flag __attribute__((section("retention_mem_area0"),zero_init)); //@RETENTION MEMORY

/*
 * Profile functions
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref SPS_SERVER_ENABLE_REQ message.
 * The handler enables the Serial Port Service Device profile.
 * @param[in] msgid Id of the message received .
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int sps_server_enable_req_handler(ke_msg_id_t const msgid,
        struct sps_server_enable_req const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);

    //Reset flags
    //tx_busy_flag = 0;

    // Go to active state
    ke_state_set(prf_src_task_get(&(spss_env->prf_env), param->conidx), SPS_SERVER_ACTIVE);

    //Send response to application
    struct sps_server_enable_cfm * cfm = KE_MSG_ALLOC(SPS_SERVER_ENABLE_CFM, prf_dst_task_get(&(spss_env->prf_env), param->conidx),
                                         prf_src_task_get(&(spss_env->prf_env), param->conidx), sps_server_enable_cfm);

    cfm->data_hdl = spss_env->spss_shdl + SPS_SERVER_TX_DATA_VAL;
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}


/**
 ****************************************************************************************
 * @brief Handles reception of the @ref SPS_SERVER_ENABLE_REQ message.
 * The handler enables the Serial Port Service Device profile.
 * @param[in] msgid Id of the message received .
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gapc_disconnect_ind_handler(ke_msg_id_t const msgid,
                                       struct gapc_disconnect_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);

    //Go to idle state
    ke_state_set(prf_src_task_get(&(spss_env->prf_env), param->conidx), SPS_SERVER_IDLE);
    return (KE_MSG_CONSUMED);
}


/**
 ****************************************************************************************
 * @brief Handles reception of the @ref gattc_cmp_evt message.
 * The handler enables the Serial Port Service Device profile.
 * @param[in] msgid Id of the message received .
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_cmp_evt_handler(ke_msg_id_t const msgid,
                                 struct gattc_cmp_evt const *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id)
{
    //uint8_t *data_ptr;
    //unsigned read_amount;
    //uint8_t res;

    if(param->operation == GATTC_NOTIFY)
    {
        /*tx_busy_flag--;
        if ((tx_busy_flag == 0) && (ble_flags.txAllowed == TRUE))
        {
            if ((read_amount = app_item_count(&uarttoble_buffer)) > TX_WAIT_LEVEL)
            {
                if (read_amount > TX_SIZE)
                {
                    read_amount = TX_SIZE;
                }
                read_amount = (read_amount<TX_START_FRAME_DATA_SIZE    ? read_amount : (((read_amount-TX_START_FRAME_DATA_SIZE) / TX_CONTINUE_FRAME_DATA_SIZE)*TX_CONTINUE_FRAME_DATA_SIZE + TX_START_FRAME_DATA_SIZE));
                read_amount = app_get_item_address(&uarttoble_buffer, &data_ptr, read_amount);
                res = attmdb_att_set_value(sps_server_env.shdl + SPS_SERVER_TX_DATA_VAL, sizeof(uint8_t) * read_amount, data_ptr);
                if (res == ATT_ERR_NO_ERROR)
                {
                    app_release_items(&uarttoble_buffer, read_amount);
                    prf_server_send_event((prf_env_struct *)&sps_server_env, false, sps_server_env.shdl + SPS_SERVER_TX_DATA_VAL);
                    tx_busy_flag++;
                    app_check_uart_xon();
                }
            }
        }*/
    }
    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Send first part of data in buffer @ref sps_server_send_notify_flow_control_state_req message.
 * @param[in] msgid Id of the message received
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int sps_server_init_ble_tx_req_handler(ke_msg_id_t const msgid,
        struct sps_server_init_ble_tx_req const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);
    //uint8_t *data_ptr;
    //unsigned read_amount;
    //uint8_t res;

    if (ke_state_get(prf_src_task_get(&(spss_env->prf_env), param->conidx))==SPS_SERVER_ACTIVE)
    {
        /*if ((tx_busy_flag == 0) && (ble_flags.txAllowed == TRUE))
        {
            if ((read_amount = app_item_count(&uarttoble_buffer)) > 0)
            {
                if (read_amount > TX_SIZE)
                {
                    read_amount = TX_SIZE;
                }
                read_amount = (read_amount<TX_START_FRAME_DATA_SIZE ? read_amount : (((read_amount-TX_START_FRAME_DATA_SIZE) / TX_CONTINUE_FRAME_DATA_SIZE)*TX_CONTINUE_FRAME_DATA_SIZE + TX_START_FRAME_DATA_SIZE));
                read_amount = app_get_item_address(&uarttoble_buffer, &data_ptr, read_amount);
                res = attmdb_att_set_value(sps_server_env.shdl + SPS_SERVER_TX_DATA_VAL, sizeof(uint8_t) * read_amount, data_ptr);
                if (res == ATT_ERR_NO_ERROR)
                {
                    app_release_items(&uarttoble_buffer, read_amount);
                    prf_server_send_event((prf_env_struct *)&sps_server_env, false, sps_server_env.shdl + SPS_SERVER_TX_DATA_VAL);
                    tx_busy_flag++;
                    app_check_uart_xon();
                }
            }
        }*/
    }

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Send flow control state @ref sps_server_send_notify_flow_control_state_req message.
 * @param[in] msgid Id of the message received
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int sps_server_send_notify_flow_control_state_req_handler(ke_msg_id_t const msgid,
        struct sps_server_send_notify_flow_control_state_req const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)

{
    // Get the address of the environment
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);
    // Allocate the GATT notification message
    struct gattc_send_evt_cmd *send_ntf;

    // Set value in data base
    //attmdb_att_set_value(spss_env->spss_shdl + SPS_FLOW_CTRL_VAL, sizeof(param->flow_control_state), 0, (uint8_t*) &(param->flow_control_state ));

    send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                KE_BUILD_ID(TASK_GATTC, param->conidx), prf_src_task_get(&(spss_env->prf_env), param->conidx),
                                gattc_send_evt_cmd,sizeof(uint16_t));

    // Fill in the parameter structure
    send_ntf->operation = GATTC_NOTIFY;
    send_ntf->handle    = spss_env->spss_shdl + SPS_FLOW_CTRL_VAL;

    send_ntf->length = sizeof(uint16_t);
    memcpy(send_ntf->value,&param->flow_control_free_len,sizeof(uint16_t));

    ke_msg_send(send_ntf);
    //Increase busy flag
    //tx_busy_flag++;

    return (KE_MSG_CONSUMED);
}


/**
 ****************************************************************************************
 * @brief Handles reception of the @ref GATT_WRITE_CMD_IND message.
 * Receive and proces incoming data
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_write_cmd_ind_handler(ke_msg_id_t const msgid,
                                       struct gattc_write_req_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    uint8_t status = GAP_ERR_NO_ERROR;
    // Get the address of the environment
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);

    if (param->handle == spss_env->spss_shdl + SPS_SERVER_TX_DATA_CFG)
    {
        //atts_write_rsp_send(KE_IDX_GET(dest_id), param->handle, ATT_ERR_NO_ERROR);
    }
    else if (param->handle == (spss_env->spss_shdl + SPS_SERVER_RX_DATA_VAL))
    {
        // send data to the application
        //app_ble_push((uint8_t*)&(param->value[0]), param->length);

        //struct sps_server_rx_data_ind *ind;
        //ind = (struct sps_server_rx_data_ind *)KE_MSG_ALLOC_DYN(SPS_SERVER_RX_DATA_IND, TASK_APP, dest_id, sps_server_rx_data_ind, param->length);
        //ind->length = param->length;
        //memcpy(ind->data, param->value, param->length);
        //ke_msg_send((void *)ind);
        uint8_t i;
        if(spss_recv_data_ind_func != NULL)
            spss_recv_data_ind_func((void *)param);
        else
        {
            printf("RX: ");
            for(i=0; i<param->length; i++)
            {
                printf("0x%02x, ", param->value[i]);
            }
            printf("\r\n");
        }
    }
    else if (param->handle == (spss_env->spss_shdl + SPS_FLOW_CTRL_VAL))
    {
        //update ble flow control flag
    }
    else if (param->handle == (spss_env->spss_shdl + SPS_FLOW_CTRL_CFG))
    {
        //provide ble flow control state when flow control att is configured to 0x0100
        if (param->value[0]==0x01 && param->value[1]==0x00)
        {
            struct sps_server_request_flow_control_ind * msg = KE_MSG_ALLOC(SPS_SERVER_REQ_FLOW_CONTROL_IND,
                    prf_dst_task_get(&(spss_env->prf_env), KE_IDX_GET(dest_id)),
                    dest_id, sps_server_request_flow_control_ind);

            ke_msg_send(msg);
        }
        //atts_write_rsp_send(KE_IDX_GET(dest_id), param->handle, ATT_ERR_NO_ERROR);
    }

    //Send write response
    struct gattc_write_cfm *cfm = KE_MSG_ALLOC(
                                      GATTC_WRITE_CFM, src_id, dest_id, gattc_write_cfm);
    cfm->handle = param->handle;
    cfm->status = status;
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int gattc_read_req_ind_handler(ke_msg_id_t const msgid,
                                      struct gattc_read_req_ind const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);
    struct gattc_read_cfm* cfm;

    if(param->handle == spss_env->spss_shdl + SPS_SERVER_TX_DATA_VAL)
    {
        cfm = KE_MSG_ALLOC_DYN(GATTC_READ_CFM, src_id, dest_id, gattc_read_cfm, 2);
        cfm->length = 2;
        cfm->handle = param->handle;
        cfm->status = ATT_ERR_NO_ERROR;

        cfm->value[0] = 'a';
        cfm->value[1] = 'b';

        ke_msg_send(cfm);
    }
    else
    {
        // Send data to peer device
        cfm = KE_MSG_ALLOC(GATTC_READ_CFM, src_id, dest_id, gattc_read_cfm);
        cfm->length = 0;
        cfm->handle = param->handle;
        cfm->status = PRF_APP_ERROR;

        ke_msg_send(cfm);
    }

    return (KE_MSG_CONSUMED);
}


void sps_server_tx_data(uint8_t conidx, uint8_t *data, uint16_t len)
{
    uint16_t pack_size = MIN(len,gattc_get_mtu(0) - 3);
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);
    struct gattc_send_evt_cmd *send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                          KE_BUILD_ID(TASK_GATTC, conidx), prf_src_task_get(&(spss_env->prf_env), conidx),
                                          gattc_send_evt_cmd, pack_size);
    send_ntf->operation = GATTC_NOTIFY;
    send_ntf->handle    = spss_env->spss_shdl + SPS_SERVER_TX_DATA_VAL;

    send_ntf->length = pack_size;
    memcpy(send_ntf->value, data, pack_size);
    ke_msg_send((void *)send_ntf);
}



static int sps_server_tx_data_req_handler(ke_msg_id_t const msgid,
        struct sps_server_tx_data_req const *param,
        ke_task_id_t const dest_id,
        ke_task_id_t const src_id)
{
    struct spss_env_tag *spss_env = PRF_ENV_GET(SPSS, spss);
    // Allocate the GATT notification message
    struct gattc_send_evt_cmd *send_ntf;

    send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                KE_BUILD_ID(TASK_GATTC, param->conidx), prf_src_task_get(&(spss_env->prf_env), param->conidx),
                                gattc_send_evt_cmd, param->length);

    // Fill in the parameter structure
    send_ntf->operation = GATTC_NOTIFY;
    send_ntf->handle    = spss_env->spss_shdl + SPS_SERVER_TX_DATA_VAL;

    send_ntf->length = param->length;
    memcpy(send_ntf->value, param->data, param->length);

    ke_msg_send((void *)send_ntf);

    return (KE_MSG_CONSUMED);
}

/*
 * TASK DESCRIPTOR DEFINITIONS
 ****************************************************************************************
 */

/// IDLE State handlers definition
const struct ke_msg_handler sps_server_idle[] =
{
    {SPS_SERVER_ENABLE_REQ,                 (ke_msg_func_t)sps_server_enable_req_handler}
};

/// ACTIVE State handlers definition
const struct ke_msg_handler sps_server_active[] =
{
    {GAPC_DISCONNECT_IND,                   (ke_msg_func_t)gapc_disconnect_ind_handler},
    {GATTC_CMP_EVT,                         (ke_msg_func_t)gattc_cmp_evt_handler},
    {GATTC_WRITE_REQ_IND,                   (ke_msg_func_t)gattc_write_cmd_ind_handler},
    {GATTC_READ_REQ_IND,                    (ke_msg_func_t)gattc_read_req_ind_handler},
    {SPS_SERVER_INIT_BLE_TX_REQ,            (ke_msg_func_t)sps_server_init_ble_tx_req_handler},
    {SPS_SERVER_SEND_FLOW_CONTROL_REQ,      (ke_msg_func_t)sps_server_send_notify_flow_control_state_req_handler},
    {SPS_SERVER_TX_DATA_REQ,                (ke_msg_func_t)sps_server_tx_data_req_handler},
};

/// Specifies the message handler structure for every input state
const struct ke_state_handler sps_server_state_handler[SPS_SERVER_STATE_MAX] =
{
    /// DISABLE State message handlers.
    [SPS_SERVER_DISABLED]  = KE_STATE_HANDLER_NONE,
    /// IDLE State message handlers.
    [SPS_SERVER_IDLE]      = KE_STATE_HANDLER(sps_server_idle),
    /// ACTIVE State message handlers.
    [SPS_SERVER_ACTIVE]    = KE_STATE_HANDLER(sps_server_active),
};

#endif /*#if BLE_SPS_SERVER*/

/// @} SPS_SERVER_TASK
