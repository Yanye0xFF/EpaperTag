/**
 ****************************************************************************************
 *
 * @file sps_client.c
 *
 * @brief SPS transmit implementation.
 *
 * Copyright (C) 2012. Dialog Semiconductor Ltd, unpublished work. This computer
 * program includes Confidential, Proprietary Information and is a Trade Secret of
 * Dialog Semiconductor Ltd.  All use, disclosure, and/or reproduction is prohibited
 * unless authorized in writing. All Rights Reserved.
 *
 * <bluetooth.support@diasemi.com> and contributors.
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup SPS_CLIENT
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwble_config.h"
#include "sps_client.h"
#include "sps_client_task.h"
#include "prf_utils.h"

#if (0)

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

struct sps_client_env_tag **sps_client_envs __attribute__((section("exchange_mem_case1")));

static const struct ke_task_desc TASK_DESC_SPS_CLIENT = {sps_client_state_handler, &sps_client_default_handler, sps_client_state, SPS_CLIENT_STATE_MAX, SPS_CLIENT_IDX_MAX};

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief sps_client_init  init sps_client
 * @param[in] void
 * @return void
 ****************************************************************************************
 */
void sps_client_init(void)
{
    // Reset all the profile role tasks
    PRF_CLIENT_RESET(sps_client_envs, SPS_CLIENT);
}

/**
 ****************************************************************************************
 * @brief     When all handels received correctly it can send and receive data or flow control else it returns an error
 * @param[in] env_tag enviroment
 * @param[in] con_inf Connection information
 * @param[in] status
 * @return    void
 ****************************************************************************************
 */
void sps_client_enable_cfm_send(struct sps_client_env_tag *sps_client_env, struct prf_con_info *con_info, uint8_t status)
{
    //format response to app
    struct sps_client_enable_cfm * cfm = KE_MSG_ALLOC(SPS_CLIENT_ENABLE_CFM,
                                         con_info->appid, con_info->prf_id,
                                         sps_client_enable_cfm);

    cfm->conhdl = gapc_get_conhdl(con_info->conidx);
    cfm->status = status;

    if (status == PRF_ERR_OK)
    {
        cfm->sps_client  = sps_client_env->sps_server;

        // Register SPS_CLIENT task in gatt for indication/notifications
        prf_register_atthdl2gatt(&(sps_client_env->con_info), &(sps_client_env->sps_server.svc));

        //Set value 0x0100 to CFG
        uint8_t val[]= {0x01,0x00};
        prf_gatt_write(con_info, sps_client_env->sps_server.chars[SPS_SERVER_TX_DATA].val_hdl+1, val, sizeof(val),GATTC_WRITE);
        prf_gatt_write(con_info, sps_client_env->sps_server.chars[SPS_FLOW_CTRL].val_hdl+1, val, sizeof(val),GATTC_WRITE);

        // Go to connected state
        ke_state_set(con_info->prf_id, SPS_CLIENT_CONNECTED);
    }
    else
    {
        PRF_CLIENT_ENABLE_ERROR(sps_client_envs, con_info->prf_id, SPS_CLIENT);
    }

    ke_msg_send(cfm);
}

#endif //BLE_SPS_CLIENT

#if BLE_SPS_CLIENT
/*
 * LOCAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */
/**
 ****************************************************************************************
 * @brief Initialization of the SPSC module.
 * This function performs all the initializations of the Profile module.
 *  - Creation of database (if it's a service)
 *  - Allocation of profile required memory
 *  - Initialization of task descriptor to register application
 *      - Task State array
 *      - Number of tasks
 *      - Default task handler
 *
 * @param[out]    env        Collector or Service allocated environment data.
 * @param[in|out] start_hdl  Service start handle (0 - dynamically allocated), only applies for services.
 * @param[in]     app_task   Application task number.
 * @param[in]     sec_lvl    Security level (AUTH, EKS and MI field of @see enum attm_value_perm_mask)
 * @param[in]     param      Configuration parameters of profile collector or service (32 bits aligned)
 *
 * @return status code to know if profile initialization succeed or not.
 ****************************************************************************************
 */
static uint8_t spsc_init (struct prf_task_env* env, uint16_t* start_hdl, uint16_t app_task, uint8_t sec_lvl,  void* params)
{
    uint8_t idx;
    //-------------------- allocate memory required for the profile  ---------------------

    struct spsc_env_tag* spsc_env =
        (struct spsc_env_tag* ) ke_malloc(sizeof(struct spsc_env_tag), KE_MEM_ATT_DB);

    // allocate BASC required environment variable
    env->env = (prf_env_t*) spsc_env;

    spsc_env->prf_env.app_task = app_task
                                 | (PERM_GET(sec_lvl, SVC_MI) ? PERM(PRF_MI, ENABLE) : PERM(PRF_MI, DISABLE));
    spsc_env->prf_env.prf_task = env->task | PERM(PRF_MI, ENABLE);

    // initialize environment variable
    env->id                     = TASK_ID_SPSC;
    env->desc.idx_max           = __jump_table.conn_max;
    env->desc.state             = spsc_env->state;
    env->desc.default_handler   = &sps_client_default_handler;
    env->desc.state_handler     = sps_client_state_handler;

    for(idx = 0; idx < __jump_table.conn_max ; idx++)
    {
        // service is ready, go into an Idle state
        ke_state_set(KE_BUILD_ID(env->task, idx), SPS_CLIENT_IDLE);
    }

    return GAP_ERR_NO_ERROR;
}

/**
 ****************************************************************************************
 * @brief Destruction of the SPSC module - due to a reset for instance.
 * This function clean-up allocated memory (attribute database is destroyed by another
 * procedure)
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 ****************************************************************************************
 */
static void spsc_destroy(struct prf_task_env* env)
{
    //uint8_t idx;
    //struct spsc_env_tag* spsc_env = (struct spsc_env_tag*) env->env;
}

/**
 ****************************************************************************************
 * @brief Handles Connection creation
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 ****************************************************************************************
 */
static void spsc_create(struct prf_task_env* env, uint8_t conidx)
{
    /* Put BAS Client in Idle state */
    ke_state_set(KE_BUILD_ID(env->task, conidx), SPS_CLIENT_READY);
}

/**
 ****************************************************************************************
 * @brief Handles Disconnection
 *
 * @param[in|out]    env        Collector or Service allocated environment data.
 * @param[in]        conidx     Connection index
 * @param[in]        reason     Detach reason
 ****************************************************************************************
 */
static void spsc_cleanup(struct prf_task_env* env, uint8_t conidx, uint8_t reason)
{
    /* Put BAS Client in Free state */
    ke_state_set(KE_BUILD_ID(env->task, conidx), SPS_CLIENT_IDLE);
}

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */

/// SPSC Task interface required by profile manager
const struct prf_task_cbs spsc_itf =
{
    spsc_init,
    spsc_destroy,
    spsc_create,
    spsc_cleanup,
};

/*
 * GLOBAL FUNCTIONS DEFINITIONS
 ****************************************************************************************
 */

const struct prf_task_cbs* spsc_prf_itf_get(void)
{
    return &spsc_itf;
}

/**
 ****************************************************************************************
 * @brief     When all handels received correctly it can send and receive data or flow control else it returns an error
 * @param[in] env_tag enviroment
 * @param[in] con_inf Connection information
 * @param[in] status
 * @return    void
 ****************************************************************************************
 */
void sps_client_enable_cfm_send(struct spsc_env_tag *sps_client_env, uint8_t conidx, uint8_t status)
{
    //format response to app
    struct sps_client_enable_cfm * cfm = KE_MSG_ALLOC(SPS_CLIENT_ENABLE_CFM,
                                         prf_dst_task_get(&sps_client_env->prf_env, conidx),
                                         prf_src_task_get(&sps_client_env->prf_env, conidx),
                                         sps_client_enable_cfm);

    cfm->conidx = conidx;
    cfm->status = status;

    if (status == ATT_ERR_NO_ERROR)
    {
        cfm->sps_client  = sps_client_env->sps_server;

        // Register SPS_CLIENT task in gatt for indication/notifications
        prf_register_atthdl2gatt(&sps_client_env->prf_env, conidx, &(sps_client_env->sps_server.svc));

        //Set value 0x0100 to CFG
        uint8_t val[]= {0x01,0x00};
        prf_gatt_write(&sps_client_env->prf_env, conidx, sps_client_env->sps_server.chars[SPS_SERVER_TX_DATA].val_hdl+1, val, sizeof(val),GATTC_WRITE);
        prf_gatt_write(&sps_client_env->prf_env, conidx, sps_client_env->sps_server.chars[SPS_FLOW_CTRL].val_hdl+1, val, sizeof(val),GATTC_WRITE);

        // Go to connected state
        ke_state_set(prf_src_task_get(&sps_client_env->prf_env, conidx), SPS_CLIENT_CONNECTED);
    }
    else
    {
        ke_state_set(prf_src_task_get(&sps_client_env->prf_env, conidx), SPS_CLIENT_IDLE);
    }

    ke_msg_send(cfm);
}

#endif //BLE_SPS_CLIENT

/// @} SPS_CLIENT
