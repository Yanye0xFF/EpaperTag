#ifndef _RTCTS_TASK_H
#define _RTCTS_TASK_H

#include "rwip_config.h"

#if BLE_RTCT_SERVER

enum
{
    RTCTS_STATE_IDLE,
};

enum
{
    RTCTS_SEND_KEY = KE_FIRST_MSG(TASK_ID_RTCTS),
    RTCTS_SEND_VOICE,
    RTCTS_SEND_RSP,
};

enum
{
    RTCTS_VOICE_CHANNEL_0,
    RTCTS_VOICE_CHANNEL_1,
    RTCTS_VOICE_CHANNEL_2,
};

struct rtcts_send_key_t
{
    uint8_t conidx;
    uint32_t key;
};

struct rtcts_send_voice_t
{
    uint8_t conidx;

    uint8_t channel;
    uint8_t len;
    uint8_t *data;
};

struct rtcts_send_rsp_t
{
    uint8_t conidx;

    uint8_t status;
};

extern const struct ke_state_handler rtcts_default_handler;

#endif  //BLE_RTCT_SERVER
#endif  //_RTCTS_TASK_H
