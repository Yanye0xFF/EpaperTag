#ifndef _RTCTS_H
#define _RTCTS_H

#include "rwip_config.h"

#if BLE_RTCT_SERVER

#include "prf.h"
#include "ke_msg.h"

#define RTCTS_IDX_MAX            1

#define RTCTS_KEY_DESC_LEN      0x10
#define RTCTS_KEY_DESC          "Key Press Notify"

#define RTCTS_DAT0_DESC_LEN     0x0F
#define RTCTS_DAT0_DESC         "VOICE DATA SEC0"

#define RTCTS_DAT1_DESC_LEN     0x0F
#define RTCTS_DAT1_DESC         "VOICE DATA SEC1"

#define RTCTS_DAT2_DESC_LEN     0x0F
#define RTCTS_DAT2_DESC         "VOICE DATA SEC2"

#define RTCTS_NOTIFY_DATA_SIZE  20  //ATT MTU

#define RTCTS_CFG_MAX           0x1FFFF

enum
{
    RTCTS_IDX_SVC,

    RTCTS_IDX_KEY_CHAR,
    RTCTS_IDX_KEY_VALUE,
    RTCTS_IDX_KEY_CFG,
    RTCTS_IDX_KEY_DESC,

    RTCTS_IDX_DAT0_CHAR,
    RTCTS_IDX_DAT0_VALUE,
    RTCTS_IDX_DAT0_CFG,
    RTCTS_IDX_DAT0_DESC,

    RTCTS_IDX_DAT1_CHAR,
    RTCTS_IDX_DAT1_VALUE,
    RTCTS_IDX_DAT1_CFG,
    RTCTS_IDX_DAT1_DESC,

    RTCTS_IDX_DAT2_CHAR,
    RTCTS_IDX_DAT2_VALUE,
    RTCTS_IDX_DAT2_CFG,
    RTCTS_IDX_DAT2_DESC,

    RTCTS_IDX_NB
};

enum
{
    RTCTS_NTF_DISABLE       = 0x00,
    RTCTS_NTF_KEY_ENABLE    = 0x01,
    RTCTS_NTF_DAT0_ENABLE   = 0x02,
    RTCTS_NTF_DAT1_ENABLE   = 0x04,
    RTCTS_NTF_DAT2_ENABLE   = 0x08,
};

/// Remote Control Profile Server. Environment variable
struct rtcts_env_tag
{
    /// profile environment
    prf_env_t prf_env;

    /// CTS Start Handle
    uint16_t rtcts_shdl;

    uint8_t ntf_state[RTCTS_IDX_MAX];

    /// State of different task instances
    ke_state_t state[RTCTS_IDX_MAX];
};

const struct prf_task_cbs* rtcts_prf_itf_get(void);

#endif  //BLE_RTCT_SERVER
#endif  //_RTCTS_H

