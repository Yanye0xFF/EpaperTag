#include "rwip_config.h"

#if BLE_RTCT_SERVER

#include "prf_utils.h"

#include "rtcts.h"
#include "rtcts_task.h"

#include "gattc_task.h"

/**
 ****************************************************************************************
 * @brief Handles reception of the @ref  GATTC_WRITE_REQ_IND message.
 * The message is redirected from TASK_SVC because at profile enable, the ATT handle is
 * register for TASK_FINDT. In the handler, an ATT Write Response/Error Response should
 * be sent for ATT protocol, but Alert Level Characteristic only supports WNR so no
 * response PDU is needed.
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_write_req_ind_handler(ke_msg_id_t const msgid,
                                       struct gattc_write_req_ind const *param,
                                       ke_task_id_t const dest_id,
                                       ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(src_id);
    uint16_t notify_state;
    // Allocate write confirmation message.
    struct gattc_write_cfm *cfm = KE_MSG_ALLOC(GATTC_WRITE_CFM,
                                  src_id, dest_id, gattc_write_cfm);

    // Get the address of the environment
    struct rtcts_env_tag *rtcts_env = PRF_ENV_GET(RTCTS, rtcts);

    // Fill in the parameter structure
    cfm->handle = param->handle;
    cfm->status = PRF_APP_ERROR;

    if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_KEY_CFG))
    {
        cfm->status = GAP_ERR_NO_ERROR;
        memcpy((uint8_t *)&notify_state, (uint8_t *)&param->value[0], sizeof(uint16_t));
        if(notify_state == PRF_CLI_STOP_NTFIND)
        {
            rtcts_env->ntf_state[conidx] &= (~RTCTS_NTF_KEY_ENABLE);
        }
        else if(notify_state == PRF_CLI_START_NTF)
        {
            rtcts_env->ntf_state[conidx] |= RTCTS_NTF_KEY_ENABLE;
        }
        else
        {
            cfm->status = GATT_ERR_WRITE;
        }
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT0_CFG))
    {
        cfm->status = GAP_ERR_NO_ERROR;
        memcpy((uint8_t *)&notify_state, (uint8_t *)&param->value[0], sizeof(uint16_t));
        if(notify_state == PRF_CLI_STOP_NTFIND)
        {
            rtcts_env->ntf_state[conidx] &= (~RTCTS_NTF_DAT0_ENABLE);
        }
        else if(notify_state == PRF_CLI_START_NTF)
        {
            rtcts_env->ntf_state[conidx] |= RTCTS_NTF_DAT0_ENABLE;
        }
        else
        {
            cfm->status = GATT_ERR_WRITE;
        }
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT1_CFG))
    {
        cfm->status = GAP_ERR_NO_ERROR;
        memcpy((uint8_t *)&notify_state, (uint8_t *)&param->value[0], sizeof(uint16_t));
        if(notify_state == PRF_CLI_STOP_NTFIND)
        {
            rtcts_env->ntf_state[conidx] &= (~RTCTS_NTF_DAT1_ENABLE);
        }
        else if(notify_state == PRF_CLI_START_NTF)
        {
            rtcts_env->ntf_state[conidx] |= RTCTS_NTF_DAT1_ENABLE;
        }
        else
        {
            cfm->status = GATT_ERR_WRITE;
        }
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT2_CFG))
    {
        cfm->status = GAP_ERR_NO_ERROR;
        memcpy((uint8_t *)&notify_state, (uint8_t *)&param->value[0], sizeof(uint16_t));
        if(notify_state == PRF_CLI_STOP_NTFIND)
        {
            rtcts_env->ntf_state[conidx] &= (~RTCTS_NTF_DAT2_ENABLE);
        }
        else if(notify_state == PRF_CLI_START_NTF)
        {
            rtcts_env->ntf_state[conidx] |= RTCTS_NTF_DAT2_ENABLE;
        }
        else
        {
            cfm->status = GATT_ERR_WRITE;
        }
    }

    // Send the message
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

/**
 ****************************************************************************************
 * @brief Handles reception of the read request from peer device
 *
 * @param[in] msgid Id of the message received (probably unused).
 * @param[in] param Pointer to the parameters of the message.
 * @param[in] dest_id ID of the receiving task instance (probably unused).
 * @param[in] src_id ID of the sending task instance.
 * @return If the message was consumed or not.
 ****************************************************************************************
 */
static int gattc_read_req_ind_handler(ke_msg_id_t const msgid,
                                      struct gattc_read_req_ind const *param,
                                      ke_task_id_t const dest_id,
                                      ke_task_id_t const src_id)
{
    uint8_t conidx = KE_IDX_GET(src_id);
    uint16_t notify_state;
    // Get the address of the environment
    struct rtcts_env_tag *rtcts_env = PRF_ENV_GET(RTCTS, rtcts);

    // Send data to peer device
    struct gattc_read_cfm* cfm = KE_MSG_ALLOC_DYN(GATTC_READ_CFM, src_id, dest_id, gattc_read_cfm, sizeof(uint16_t));
    cfm->length = sizeof(uint16_t);
    cfm->handle = param->handle;
    cfm->status = PRF_APP_ERROR;

    if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_KEY_CFG))
    {
        cfm->status = ATT_ERR_NO_ERROR;
        if(rtcts_env->ntf_state[conidx] & RTCTS_NTF_KEY_ENABLE)
        {
            notify_state = PRF_CLI_START_NTF;
        }
        else
        {
            notify_state = PRF_CLI_STOP_NTFIND;
        }
        memcpy(cfm->value, &notify_state, sizeof(uint16_t));
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT0_CFG))
    {
        cfm->status = ATT_ERR_NO_ERROR;
        if(rtcts_env->ntf_state[conidx] & RTCTS_NTF_DAT0_ENABLE)
        {
            notify_state = PRF_CLI_START_NTF;
        }
        else
        {
            notify_state = PRF_CLI_STOP_NTFIND;
        }
        memcpy(cfm->value, &notify_state, sizeof(uint16_t));
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT1_CFG))
    {
        cfm->status = ATT_ERR_NO_ERROR;
        if(rtcts_env->ntf_state[conidx] & RTCTS_NTF_DAT1_ENABLE)
        {
            notify_state = PRF_CLI_START_NTF;
        }
        else
        {
            notify_state = PRF_CLI_STOP_NTFIND;
        }
        memcpy(cfm->value, &notify_state, sizeof(uint16_t));
    }
    else if(param->handle == (rtcts_env->rtcts_shdl + RTCTS_IDX_DAT2_CFG))
    {
        cfm->status = ATT_ERR_NO_ERROR;
        if(rtcts_env->ntf_state[conidx] & RTCTS_NTF_DAT2_ENABLE)
        {
            notify_state = PRF_CLI_START_NTF;
        }
        else
        {
            notify_state = PRF_CLI_STOP_NTFIND;
        }
        memcpy(cfm->value, &notify_state, sizeof(uint16_t));
    }

    // Send value to peer device.
    ke_msg_send(cfm);

    return (KE_MSG_CONSUMED);
}

static int gattc_cmp_evt_handler(ke_msg_id_t const msgid,
                                 struct gattc_cmp_evt const *param,
                                 ke_task_id_t const dest_id,
                                 ke_task_id_t const src_id)
{
    // Get the address of the environment
    struct rtcts_env_tag *rtcts_env = PRF_ENV_GET(RTCTS, rtcts);

    if (param->operation == GATTC_NOTIFY)
    {
        uint8_t conidx = KE_IDX_GET(src_id);

        // send report update response
        struct rtcts_send_rsp_t *rsp = KE_MSG_ALLOC(RTCTS_SEND_RSP,
                                       prf_dst_task_get(&(rtcts_env->prf_env), conidx),
                                       dest_id, rtcts_send_rsp_t);
        rsp->conidx = conidx;
        rsp->status = param->status;
        ke_msg_send(rsp);
    }

    return KE_MSG_CONSUMED;
}

static int rtcts_send_key_handler(ke_msg_id_t const msgid,
                                  struct rtcts_send_key_t const *param,
                                  ke_task_id_t const dest_id,
                                  ke_task_id_t const src_id)
{
    struct rtcts_env_tag *rtcts_env = PRF_ENV_GET(RTCTS, rtcts);
    struct gattc_send_evt_cmd *send_ntf;

    if(rtcts_env->ntf_state[param->conidx] & RTCTS_NTF_KEY_ENABLE)
    {
        send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                    KE_BUILD_ID(TASK_GATTC, param->conidx), prf_src_task_get(&(rtcts_env->prf_env), param->conidx),
                                    gattc_send_evt_cmd, sizeof(uint32_t));

        send_ntf->operation = GATTC_NOTIFY;
        send_ntf->handle    = rtcts_env->rtcts_shdl + RTCTS_IDX_KEY_VALUE;

        send_ntf->length    = sizeof(uint32_t);
        memcpy(send_ntf->value, (void *)&param->key, sizeof(uint32_t));

        ke_msg_send(send_ntf);
    }

    return (KE_MSG_CONSUMED);
}

static int rtcts_send_voice_handler(ke_msg_id_t const msgid,
                                    struct rtcts_send_voice_t const *param,
                                    ke_task_id_t const dest_id,
                                    ke_task_id_t const src_id)
{
    struct rtcts_env_tag *rtcts_env = PRF_ENV_GET(RTCTS, rtcts);
    struct gattc_send_evt_cmd *send_ntf;
    uint8_t enable = false;
    uint16_t handle;

    switch(param->channel)
    {
        case RTCTS_VOICE_CHANNEL_0:
            if(rtcts_env->ntf_state[param->conidx] & RTCTS_NTF_DAT0_ENABLE)
            {
                enable = true;
                handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT0_VALUE;
            }
            break;
        case RTCTS_VOICE_CHANNEL_1:
            if(rtcts_env->ntf_state[param->conidx] & RTCTS_NTF_DAT1_ENABLE)
            {
                enable = true;
                handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT1_VALUE;
            }
            break;
        case RTCTS_VOICE_CHANNEL_2:
            if(rtcts_env->ntf_state[param->conidx] & RTCTS_NTF_DAT1_ENABLE)
            {
                enable = true;
                handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT2_VALUE;
            }
            break;
    }

    if(enable)
    {
        send_ntf = KE_MSG_ALLOC_DYN(GATTC_SEND_EVT_CMD,
                                    KE_BUILD_ID(TASK_GATTC, param->conidx), prf_src_task_get(&(rtcts_env->prf_env), param->conidx),
                                    gattc_send_evt_cmd, param->len);

        send_ntf->operation = GATTC_NOTIFY;
        send_ntf->handle    = handle;

        send_ntf->length    = param->len;
        memcpy(send_ntf->value, param->data, param->len);

        ke_msg_send(send_ntf);
    }

    return (KE_MSG_CONSUMED);
}

/// Default State handlers definition
const struct ke_msg_handler rtcts_default_state[] =
{
    {GATTC_WRITE_REQ_IND,           (ke_msg_func_t)gattc_write_req_ind_handler},
    {GATTC_READ_REQ_IND,            (ke_msg_func_t)gattc_read_req_ind_handler},
    {GATTC_CMP_EVT,                 (ke_msg_func_t)gattc_cmp_evt_handler},
    {RTCTS_SEND_KEY,                (ke_msg_func_t)rtcts_send_key_handler},
    {RTCTS_SEND_VOICE,              (ke_msg_func_t)rtcts_send_voice_handler},
};

// Specifies the message handlers that are common to all states.
const struct ke_state_handler rtcts_default_handler = KE_STATE_HANDLER(rtcts_default_state);

#endif  //BLE_RTCT_SERVER
