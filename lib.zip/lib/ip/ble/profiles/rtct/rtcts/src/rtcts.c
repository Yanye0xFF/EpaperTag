#include "rwip_config.h"

#if BLE_RTCT_SERVER

#include "ke_mem.h"

#include "rtcts.h"
#include "rtcts_task.h"

#include "att.h"
#include "attm_db.h"

const struct attm_desc rtcts_att_db[RTCTS_IDX_NB] =
{
    // Update Remote Control Service Declaration
    [RTCTS_IDX_SVC]                         =   {ATT_DECL_PRIMARY_SERVICE, PERM(RD, ENABLE), 0, 0},

    // Notify Characteristic Declaration
    [RTCTS_IDX_KEY_CHAR]                    =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, RTCTS_IDX_KEY_VALUE},
    // Notify Characteristic Value
    [RTCTS_IDX_KEY_VALUE]                   =   {ATT_CHAR_RTCT_KEY, PERM(NTF, ENABLE), PERM(RI, ENABLE), RTCTS_NOTIFY_DATA_SIZE},
    // Notify Characteristic - Client Char. Configuration Descriptor
    [RTCTS_IDX_KEY_CFG]                     =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor
    [RTCTS_IDX_KEY_DESC]                    =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, RTCTS_KEY_DESC_LEN},

    // Notify Characteristic Declaration
    [RTCTS_IDX_DAT0_CHAR]                   =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, RTCTS_IDX_DAT0_VALUE},
    // Notify Characteristic Value
    [RTCTS_IDX_DAT0_VALUE]                  =   {ATT_CHAR_RTCT_DATA_0, PERM(NTF, ENABLE), PERM(RI, ENABLE), RTCTS_NOTIFY_DATA_SIZE},
    // Notify Characteristic - Client Char. Configuration Descriptor
    [RTCTS_IDX_DAT0_CFG]                    =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor
    [RTCTS_IDX_DAT0_DESC]                   =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, RTCTS_DAT0_DESC_LEN},

    // Notify Characteristic Declaration
    [RTCTS_IDX_DAT1_CHAR]                   =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, RTCTS_IDX_DAT1_VALUE},
    // Notify Characteristic Value
    [RTCTS_IDX_DAT1_VALUE]                  =   {ATT_CHAR_RTCT_DATA_1, PERM(NTF, ENABLE), PERM(RI, ENABLE), RTCTS_NOTIFY_DATA_SIZE},
    // Notify Characteristic - Client Char. Configuration Descriptor
    [RTCTS_IDX_DAT1_CFG]                    =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor
    [RTCTS_IDX_DAT1_DESC]                   =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, RTCTS_DAT1_DESC_LEN},

    // Notify Characteristic Declaration
    [RTCTS_IDX_DAT2_CHAR]                   =   {ATT_DECL_CHARACTERISTIC, PERM(RD, ENABLE), 0, RTCTS_IDX_DAT2_VALUE},
    // Notify Characteristic Value
    [RTCTS_IDX_DAT2_VALUE]                  =   {ATT_CHAR_RTCT_DATA_2, PERM(NTF, ENABLE), PERM(RI, ENABLE), RTCTS_NOTIFY_DATA_SIZE},
    // Notify Characteristic - Client Char. Configuration Descriptor
    [RTCTS_IDX_DAT2_CFG]                    =   {ATT_DESC_CLIENT_CHAR_CFG, PERM(RD, ENABLE) | PERM(WRITE_REQ, ENABLE), 0, 0},
    // Notify Characteristic - User Descriptor
    [RTCTS_IDX_DAT2_DESC]                   =   {ATT_DESC_CHAR_USER_DESCRIPTION, PERM(RD, ENABLE), 0, RTCTS_DAT2_DESC_LEN},
};

static uint8_t rtcts_init(struct prf_task_env* env, uint16_t* start_hdl, uint16_t app_task, uint8_t sec_lvl, void* params)
{
    // Service content flag
    uint32_t cfg_flag= RTCTS_CFG_MAX;
    // DB Creation Status
    uint8_t status = ATT_ERR_NO_ERROR;
    // Total number of attributes
    uint8_t tot_nb_att = RTCTS_IDX_NB;
    uint16_t handle;

    // Allocate RTCTS required environment variable
    struct rtcts_env_tag* rtcts_env =
        (struct rtcts_env_tag* ) ke_malloc(sizeof(struct rtcts_env_tag), KE_MEM_ATT_DB);

    env->env = (prf_env_t*) rtcts_env;

    //------------------ create the attribute database for the profile -------------------

    // Check that attribute list can be allocated.
    status = attmdb_reserve_handle_range(start_hdl, tot_nb_att);

    if (status == ATT_ERR_NO_ERROR)
    {
        /*---------------------------------------------------*
         * Current Time Service Creation
         *---------------------------------------------------*/
        status = attm_svc_create_db(start_hdl, ATT_SVC_RTCT, (uint8_t *)&cfg_flag,
                                    RTCTS_IDX_NB, NULL, env->task, &rtcts_att_db[0],
                                    (sec_lvl & (PERM_MASK_SVC_DIS | PERM_MASK_SVC_AUTH | PERM_MASK_SVC_EKS)));

        // Update index
        rtcts_env->rtcts_shdl = *start_hdl;
        *start_hdl += tot_nb_att;

        // Set OTAS Tx Client Char. Information Char. Value
        if(status == GAP_ERR_NO_ERROR)
        {
            handle = rtcts_env->rtcts_shdl + RTCTS_IDX_KEY_DESC;
            status = attmdb_att_set_value(handle, RTCTS_KEY_DESC_LEN, 0, (uint8_t *)RTCTS_KEY_DESC);

            handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT0_DESC;
            status = attmdb_att_set_value(handle, RTCTS_DAT0_DESC_LEN, 0, (uint8_t *)RTCTS_DAT0_DESC);

            handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT1_DESC;
            status = attmdb_att_set_value(handle, RTCTS_DAT1_DESC_LEN, 0, (uint8_t *)RTCTS_DAT1_DESC);

            handle = rtcts_env->rtcts_shdl + RTCTS_IDX_DAT2_DESC;
            status = attmdb_att_set_value(handle, RTCTS_DAT2_DESC_LEN, 0, (uint8_t *)RTCTS_DAT2_DESC);
        }

        rtcts_env->prf_env.app_task    = app_task
                                         | (PERM_GET(sec_lvl, SVC_MI) ? PERM(PRF_MI, ENABLE) : PERM(PRF_MI, DISABLE));
        // Multi Instantiated task
        rtcts_env->prf_env.prf_task    = env->task | PERM(PRF_MI, ENABLE);

        // initialize environment variable
        env->id                     = TASK_ID_RTCTS;
        env->desc.idx_max           = RTCTS_IDX_MAX;
        env->desc.state             = rtcts_env->state;
        env->desc.default_handler   = &rtcts_default_handler;

        /* Put OTAS in disabled state */
        ke_state_set(env->task, RTCTS_STATE_IDLE);
    }

    return status;
}

static void rtcts_destroy(struct prf_task_env* env)
{
}

static void rtcts_create(struct prf_task_env* env, uint8_t conidx)
{
}

static void rtcts_cleanup(struct prf_task_env* env, uint8_t conidx, uint8_t reason)
{
}

const struct prf_task_cbs rtcts_itf =
{
    (prf_init_fnct) rtcts_init,
    rtcts_destroy,
    rtcts_create,
    rtcts_cleanup,
};

const struct prf_task_cbs* rtcts_prf_itf_get(void)
{
    return &rtcts_itf;
}

#endif  //BLE_RTCT_SERVER

