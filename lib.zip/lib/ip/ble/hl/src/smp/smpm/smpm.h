/**
 ****************************************************************************************
 *
 * @file smpm.h
 *
 * @brief Header file - SMPM.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef SMPM_H_
#define SMPM_H_

/**
 ****************************************************************************************
 * @addtogroup SMPM Security Manager Protocol Manager
 * @ingroup SMP
 * @brief Security Manager Protocol Manager.
 *
 * This Module allows the 1-instanced modules to communicate with multi-instanced SMPC module.
 * It is only an intermediary between the actual SMPC handling SM behavior, and
 * HCI, GAP, or GATT which only indicate the index of the connection for which
 * SMPC actions are necessary.
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "smp_common.h"       // Firmware Configuration Flags
#include "ke_msg.h"

/*
 * DEFINES
 ****************************************************************************************
 */

// Length of resolvable random address prand part
#define SMPM_RAND_ADDR_PRAND_LEN            (3)
// Length of resolvable random address hash part
#define SMPM_RAND_ADDR_HASH_LEN             (3)

#define GAP_AUTH_SECURE_CONNECTIONS GAP_AUTH_SEC_CON
#define GAP_AUTH_KEY_NOTIFICATION GAP_AUTH_KEY_NOTIF
/*
 * ENUMERATIONS
 ****************************************************************************************
 */


/*
 * STRUCTURES
 ****************************************************************************************
 */


/*
 * GLOBAL VARIABLES DECLARATION
 ****************************************************************************************
 */


/*
 * PUBLIC FUNCTIONS DECLARATION
 ****************************************************************************************
 */



/*
 * PRIVATE FUNCTIONS DECLARATION
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Send an encryption request to the HCI.
 ****************************************************************************************
 */
void smpm_send_encrypt_req(uint8_t *operand_1, uint8_t *operand_2);

/**
 ****************************************************************************************
 * @brief Send a generate Random Number request to the HCI.
 ****************************************************************************************
 */
void smpm_send_gen_rand_nb_req(void);

#if (BLE_SECURE_CONNECTIONS==1)
/**
 ****************************************************************************************
 * @brief Send a generate DH Key request to the HCI.
 ****************************************************************************************
 */
void smpm_send_generate_dh_key(uint8_t *operand_1, uint8_t *operand_2);
#endif
/**
 ****************************************************************************************
 * @brief Check the address type provided by the application.
 *
 * @param[in]  addr_type            Provided address type to check
 * @param[out] true if the address type is valid, false else
 ****************************************************************************************
 */
bool smpm_check_addr_type(uint8_t addr_type);

#endif // (SMPM_H_)

/// @} SMPM
