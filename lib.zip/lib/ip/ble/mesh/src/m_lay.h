/**
 ****************************************************************************************
 * @file m_lay.h
 *
 * @brief Header file for Mesh Layer Defines
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef _M_LAY_H_
#define _M_LAY_H_

/**
 ****************************************************************************************
 * @defgroup M_LAY Mesh Layer Defines
 * @ingroup MESH
 * @brief Mesh Layer Defines
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_defines.h"
#include "m_tb.h"       // Toolbox defines

/*
 * CALLBACK DEFINITIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Definition of function to call for transmission of a PDU through a layer.
 *
 * @param[in] p_buf           Pointer to the buffer containing the received PDU.
 ****************************************************************************************
 */
typedef uint16_t (*m_lay_send_api) (m_tb_buf_t *p_buf);


/**
 ****************************************************************************************
 * @brief Definition of function to call for transmission of a PDU through upper transport layer.
 *
 * @param[in] p_buf           Pointer to the buffer containing the received PDU.
 * @param[in] intf_type       Interface type
 ****************************************************************************************
 */
typedef uint16_t (*m_lay_trans_send_api) (m_tb_buf_t *p_buf, uint8_t intf_type);

/**
 ****************************************************************************************
 * @brief Definition of callback function to call upon reception of a PDU in order to notify
 * upper layer about the received PDU.
 *
 * @param[in] p_buf             Pointer to the buffer containing the received PDU.
 ****************************************************************************************
 */
typedef void (*m_lay_rx_cb) (m_tb_buf_t *p_buf);

/**
 ****************************************************************************************
 * @brief Definition of callback function to call once PDU provided by an upper layer has
 * properly been sent.
 *
 * @param[in] p_buf             Pointer to the buffer containing the sent PDU.
 * @param[in] status            Transmission status.
 ****************************************************************************************
 */
typedef void (*m_lay_sent_cb) (m_tb_buf_t *p_buf, uint16_t status);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
typedef void (*m_lay_friend_rx_cb) (m_tb_buf_t *p_buf, bool seg, uint8_t reas_lid, uint8_t nb_seg);

/*
 * FUNCTION PROTOTYPES
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Mesh layers module memory requirement
 *
 * @note this function is called before init function in order to know memory requirements of the module
 *
 * @param[in] p_cfg    Pointer to mesh stack initialization parameters
 *
 * @return Size of environment required for this mesh module
 ****************************************************************************************
 */
uint16_t m_lay_get_env_size(const m_cfg_t* p_cfg);

/**
 ****************************************************************************************
 * @brief Mesh layers initialization
 *
 * @note called when Mesh stack is initialized or when a SW reset is requested.
 *
 * @param[in] reset True means SW reset, False means task initialization
 * @param[in] p_env Pointer to the environment structure
 * @param[in] p_cfg Pointer to mesh stack initialization parameters
 *
 * @return Size of environment required for this module.
 ****************************************************************************************
 */
uint16_t m_lay_init(bool reset, void* p_env, const m_cfg_t* p_cfg);

/**
 ****************************************************************************************
 * @brief Let the model publish a message over mesh network
 *
 * @note Message status will be reported with model callback (@see m_api_model_sent_cb)
 *
 * @param[in] model_id     Model ID.
 * @param[in] opcode       Operation code of the message
 * @param[in] tx_hdl       Handle value used by model to retrieve which message has been sent
 * @param[in] p_buf        Pointer to the buffer structure that contains message to publish
 * @param[in] trans_mic_64 For a segmented PDU force transport mic to 64 bits
 *
 * @return Execution status code
 ****************************************************************************************
 */
uint16_t m_lay_access_publish(m_lid_t model_lid, uint32_t opcode, uint8_t tx_hdl, m_tb_buf_t *p_buf, bool trans_mic_64);

/**
 ****************************************************************************************
 * @brief Let the model publish a message over mesh network
 *
 * @note Message status will be reported with model callback (@see m_api_model_sent_cb)
 *
 * @param[in] model_id     Model ID.
 * @param[in] opcode       Operation code of the message
 * @param[in] tx_hdl       Handle value used by model to retrieve which message has been sent
 * @param[in] p_buf        Pointer to the buffer structure that contains message to publish
 * @param[in] key_lid      Key information.
 *                         If key_lid & 0x80 != 0, key_lid & 0x7F = network key local index
 *                         else key_lid & 0x7F = application key local index.
 * @param[in] dst          Unicast destination address of the message (source address parameter of received request message)
 * @param[in] trans_mic_64 For a segmented PDU force transport mic to 64 bits
 * @param[in] not_relay    True, send message to an immediate peer; False, accept message to be relayed
 *
 * @return Execution status code
 ****************************************************************************************
 */
uint16_t m_lay_access_rsp_send(m_lid_t model_lid, uint32_t opcode, uint8_t tx_hdl, m_tb_buf_t *p_buf,
                               m_lid_t key_lid, uint16_t dst, bool trans_mic_64, bool not_relay);

/**
 ****************************************************************************************
 * @brief Reply to the Model operation code support (@see m_api_model_opcode_check_cb)
 *
 * @param[in] model_id  Model ID.
 * @param[in] opcode    Operation code checked
 * @param[in] status    M_ERR_NO_ERROR if operation supported by model, other error code to reject
 *
 * @return Execution status code
 ****************************************************************************************
 */
void m_lay_access_opcode_status(m_lid_t model_lid, uint32_t opcode, uint16_t status);

#if (BLE_MESH_LPN)
/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint16_t m_lay_lpn_start(uint32_t poll_timeout, uint32_t poll_intv_ms, uint8_t rx_delay, uint8_t rssi_factor,
                         uint8_t rx_window_factor, uint8_t min_queue_size_log);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint16_t m_lay_lpn_stop(void);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint16_t m_lay_lpn_select_friend(uint16_t friend_addr);
#endif //(BLE_MESH_LPN)

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint16_t m_lay_hb_set_pub_params(uint16_t dst_addr, uint8_t count_log, uint8_t period_log,
                                 uint8_t ttl, uint16_t features, m_lid_t net_key_lid);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint16_t m_lay_hb_set_subs_params(uint16_t src_addr, uint16_t dst_addr, uint8_t period_log);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_lay_hb_get_pub_params(uint16_t *p_dst_addr, uint8_t *p_count_log,
                             uint8_t *p_period_log, uint8_t *p_ttl, uint16_t *p_features,
                             m_lid_t *p_net_key_lid);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_lay_hb_get_subs_params(uint16_t *p_src_addr, uint16_t *p_dst_addr, uint8_t *p_period_log,
                              uint8_t *p_count_log, uint8_t *p_min_hops, uint8_t *p_max_hops);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_lay_hb_feature_update_ind(void);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_lay_hb_net_key_rem_ind(m_lid_t net_key_lid);

#if (BLE_MESH_GATT_PROXY)
/**
 ****************************************************************************************
 * @brief Change state of Mesh GATT Proxy
 *
 * @param[in] enable True to enable GATT Proxy, False to stop GATT Proxy and all on-going connections
 *
 * @return Execution status, M_ERR_NO_ERROR if succeed
 ****************************************************************************************
 */
uint16_t m_lay_proxy_state_set(bool enable);

/**
 ****************************************************************************************
 * @brief Control state of the GATT Proxy Service Advertising state
 *
 * @param[in] enable        True to enable advertising for 60s
 * @param[in] net_key_lid   Network key local identifier used to target a specific Node Identity
 *                          If Invalid LID, interlace Network ID of all available network keys.
 *
 * @return Execution status, M_ERR_NO_ERROR if succeed
 ****************************************************************************************
 */
uint16_t m_lay_proxy_bearer_adv_ctrl(bool enable, m_lid_t net_key_lid);
#endif // (BLE_MESH_GATT_PROXY)

/// @} end of group

#endif //_M_LAY_INT_H_
