/**
 ****************************************************************************************
 * @file m_tb_buf.h
 *
 * @brief Header file for Buffer Manager Toolbox
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef _M_TB_BUF_H_
#define _M_TB_BUF_H_

/**
 ****************************************************************************************
 * @defgroup M_TB_BUF Buffer Manager Toolbox
 * @ingroup MESH
 * @brief Buffer Manager Toolbox
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_al.h"
#include "m_config.h"

/*
 * DEFINES
 ****************************************************************************************
 */

/// Debug Pattern
#define M_TB_BUF_DBG_PATTERN         (0xA55A5AA5)

/*
 * MACROS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Get pointer to data part of a provided buffer.
 *
 * @param[in] p_buf     Pointer to buffer structure.
 *
 * @return Address of data part in the provided buffer.
 ****************************************************************************************
 */
#define M_TB_BUF_DATA(p_buf)        (&(p_buf)->buf[0] + (p_buf)->head_len)

/**
 ****************************************************************************************
 * @brief Get pointer to end of data part of a provided buffer.
 *
 * @param[in] p_buf     Pointer to buffer structure.
 *
 * @return Address to end of data part in the provided buffer.
 ****************************************************************************************
 */
#define M_TB_BUF_TAIL(p_buf)        (&(p_buf)->buf[0] + (p_buf)->head_len + (p_buf)->data_len)

/*
 * TYPEDEFS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Callback executed when a buffer block is properly released.
 *
 * @param[in] block_id  Buffer Block identifier
 ****************************************************************************************
 */
typedef void (*m_tb_buf_block_released_cb)(uint8_t block_id);

/*
 * STRUCTURES
 ****************************************************************************************
 */

/// Buffer information structure
typedef struct m_tb_buf
{
    /// List header for chaining
    co_list_hdr_t hdr;
    /// Length of the head part
    uint16_t      head_len;
    /// Length of the tail part
    uint16_t      tail_len;
    /// Length of the data part
    uint16_t      data_len;
    /// Total size of the buffer array
    uint16_t      buf_len;
    /// Index of block the buffer belongs to
    /// Set to @see M_TB_BUF_DYN_ALLOC if dynamically allocated
    uint8_t       block_id;
    /// Index of the buffer in the block if buffer belongs to a block
    uint8_t       buf_id;
    /// Acquire counter
    uint8_t       acq_cnt;
    /// Dummy Tag that can be used to inform a layer about type of buffer.
    /// Value should not be kept along several layers
    uint8_t       dummy_tag;
    /// Environment variable that can be used for multiple purposes
    uint8_t       env[M_TB_BUF_ENV_SIZE];
#if (BLE_MESH_DBG)
    /// Debug pattern used to verify that content of environment part did not overwritten the
    /// buffer part. Also used to verify that pointed buffer is well a buffer
    uint32_t      pattern;
#endif //(BLE_MESH_DBG)
    /// Data buffer containing the PDU
    /// Length is head_len + tail_len + data_len
    uint8_t       buf[4];
} m_tb_buf_t;

/*
 * FUNCTION PROTOTYPES
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Allocate a block of small or long buffers.
 * Size of small buffers is @see M_TB_BUF_SMALL_SIZE.
 * Size of long buffers is @see M_TB_BUF_LONG_SIZE.
 *
 * @param[out] p_block_id        Pointer to the variable that will contain the index of the allocated
 *                               block.
 * @param[in] nb_bufs            Number of buffers contained in the block.
 * @param[in] small              Indicate if block contains small or long buffers.
 *
 * @return M_ERR_NO_ERROR if block has been successfully allocated.
 *         M_ERR_INVALID_PARAM if provided number of blocks is invalid.
 *         M_ERR_NO_RESOURCES if no more block can be allocated.
 ****************************************************************************************
 */
uint16_t m_tb_buf_block_alloc(uint8_t *p_block_id, uint8_t nb_bufs, bool small);

/**
 ****************************************************************************************
 * @brief Free an existing block. As some of the buffers belonging to the block can be
 * in use, it might happen that the block cannot be freed upon reception of the request.
 * Once all the buffer are released, the block is freed and @see m_api_buf_free_blockd function
 * is called.
 *
 * @param[in] block_id     Index of the block to be freed.
 * @param[in] cb_released  Callback executed when a buffer is released
 * once block has been freed.
 *
 * @return M_ERR_NO_ERROR if block exists and can be freed.
 *         M_ERR_INVALID_PARAM if indicated buffer does not exists.
 ****************************************************************************************
 */
uint16_t m_tb_buf_block_free(uint8_t block_id, m_tb_buf_block_released_cb cb_released);

/**
 ****************************************************************************************
 * @brief Allocate a buffer and specify initial length of head, data and tail parts.
 * If total length of the buffer is higher than @see M_TB_BUF_LONG_SIZE, the buffer will be
 * dynamically allocated.
 * If total length is lower than @see M_TB_BUF_SMALL_SIZE, a small buffer will be allocated.
 * Else a long buffer is used.
 *
 * @param[out] p_bu   f    Pointer to a variable that will contain the address of the allocated
 *                         buffer.
 * @param[in] head_len     Initial Head Length.
 * @param[in] data_len     Initial Data Length.
 * @param[in] tail_len     Initial Tail Length.
 *
 * @return M_ERR_NO_ERROR if buffer can be allocated.
 *         M_ERR_NO_RESOURCES if no more buffers are available.
 ****************************************************************************************
 */
uint16_t m_tb_buf_alloc(m_tb_buf_t **pp_buf, uint16_t head_len, uint16_t data_len, uint16_t tail_len);

/**
 ****************************************************************************************
 * @brief Reserve bytes in the head part in order to increase length of data part.
 *
 * @param[in] p_buf        Pointer to buffer in which length of data part must be increased.
 * @param[in] len          Length to be reserved.
 *
 * @return M_ERR_NO_ERROR if needed length has been reserved.
 *         M_ERR_INVALID_PARAM if provided length is higher than current length of head part.
 ****************************************************************************************
 */
uint16_t m_tb_buf_head_reserve(m_tb_buf_t *p_buf, uint16_t len);

/**
 ****************************************************************************************
 * @brief Release bytes in the data part in order to increase length of head part.
 *
 * @param[in] p_buf        Pointer to buffer in which length of head part must be increased.
 * @param[in] len          Length to be released.
 *
 * @return M_ERR_NO_ERROR if needed length has been released.
 *         M_ERR_INVALID_PARAM if provided length is higher than current length of data part.
 ****************************************************************************************
 */
uint16_t m_tb_buf_head_release(m_tb_buf_t *p_buf, uint16_t len);

/**
 ****************************************************************************************
 * @brief Reserve bytes in the tail part in order to increase length of data part.
 *
 * @param[in] p_buf        Pointer to buffer in which length of data part must be increased.
 * @param[in] len          Length to be reserved.
 *
 * @return M_ERR_NO_ERROR if needed length has been reserved.
 *         M_ERR_INVALID_PARAM if provided length is higher than current length of tail part.
 ****************************************************************************************
 */
uint16_t m_tb_buf_tail_reserve(m_tb_buf_t *p_buf, uint16_t len);

/**
 ****************************************************************************************
 * @brief Release bytes in the data part in order to increase length of tail part.
 *
 * @param[in] p_buf        Pointer to buffer in which length of tail part must be increased.
 * @param[in] len          Length to be released.
 *
 * @return M_ERR_NO_ERROR if needed length has been released.
 *         M_ERR_INVALID_PARAM if provided length is higher than current length of data part.
 ****************************************************************************************
 */
uint16_t m_tb_buf_tail_release(m_tb_buf_t *p_buf, uint16_t len);

/**
 ****************************************************************************************
 * @brief Request to increment value of acquire counter of a buffer during processing of buffer content.
 *
 * @param[in] p_buf        Pointer to acquired buffer
 ****************************************************************************************
 */
void m_tb_buf_acquire(m_tb_buf_t *p_buf);

/**
 ****************************************************************************************
 * @brief Request to release previously acquired buffer. The acquire counter for this buffer
 * is decremented. If the acquire counter value becomes zero, the buffer is freed as no more
 * entity is using the buffer anymore.
 *
 * @param[in] p_buf        Pointer to acquired buffer.
 *
 * @return M_ERR_NO_ERROR if buffer has been released.
 *         M_ERR_COMMAND_DISALLOWED if buffer was free.
 ****************************************************************************************
 */
uint16_t m_tb_buf_release(m_tb_buf_t *p_buf);

/**
 ****************************************************************************************
 * @brief Copy content of a buffer to another buffer.
 *
 * @param[in] p_buf_in        Pointer to the buffer to copy.
 * @param[in] p_buf_out       Pointer to the buffer that will contain content of input buffer.
 * @param[in] length          Length of data to copy
 * @param[in] copy_env        Indicate if environment has to be copied.
 *
 * @return M_ERR_NO_ERROR if copy has been properly performed.
 *         M_ERR_COMMAND_DISALLOWED if the two provided buffers have different sizes.
 ****************************************************************************************
 */
uint16_t m_tb_buf_copy(m_tb_buf_t *p_buf_in, m_tb_buf_t *p_buf_out, uint16_t length, bool copy_env);

/**
 ****************************************************************************************
 * @brief Copy content of a data buffer to the data part of a buffer.
 *
 * @param[in] p_buf       Pointer to the buffer in which indicated data will be copied.
 * @param[in] p_mem       Pointer to data buffer containing the data to copy
 * @param[in] len         Length of data to copy
 *
 * @return M_ERR_NO_ERROR if copy has been properly performed.
 *         M_ERR_COMMAND_DISALLOWED if length of data part in the buffer in different than
 * provided length.
 ****************************************************************************************
 */
uint16_t m_tb_buf_copy_data_from_mem(m_tb_buf_t *p_buf, const uint8_t *p_mem, uint16_t len);

/**
 ****************************************************************************************
 * @brief Copy content of buffer data part in a data buffer.
 *
 * @param[in] p_buf       Pointer to the buffer in which indicated data will be read.
 * @param[in] p_mem       Pointer to data buffer that will contain the read data.
 ****************************************************************************************
 */
void m_tb_buf_copy_data_to_mem(m_tb_buf_t *p_buf, uint8_t *p_mem);


/**
 ****************************************************************************************
 * @brief Initialize a buffer with initial length of head, data and tail parts.
 * Idea is to reuse an already allocated buffer for a different purpose
 *
 * @param[in] p_buf        Pointer to the buffer in which indicated data will be read.
 * @param[in] head_len     Initial Head Length.
 * @param[in] data_len     Initial Data Length.
 * @param[in] tail_len     Initial Tail Length.
 *
 * @return M_ERR_NO_ERROR if copy has been properly performed.
 *         M_ERR_INVALID_PARAM if length fields exceed length of initial buffer
 ****************************************************************************************
 */
uint16_t m_tb_buf_reuse(m_tb_buf_t *p_buf, uint16_t head_len, uint16_t data_len, uint16_t tail_len);

/// @} end of group

#endif //_M_TB_BUF_H_
