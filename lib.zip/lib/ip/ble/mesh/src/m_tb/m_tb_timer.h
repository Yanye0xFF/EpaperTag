/**
 ****************************************************************************************
 * @file m_tb_timer.h
 *
 * @brief Header file for Timer Manager Toolbox
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef _M_TB_TIMER_H_
#define _M_TB_TIMER_H_

/**
 ****************************************************************************************
 * @defgroup M_TB_TIMER Timer Manager
 * @ingroup MESH
 * @brief Timer Manager Toolbox
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_al.h"

/*
 * TYPES
 ****************************************************************************************
 */

/// Pointer to callback function
typedef void (*m_tb_timer_cb_t)(void *);

/*
 * STRUCTURES
 ****************************************************************************************
 */

/// Structure defining the properties of a timer
typedef struct m_tb_timer
{
    /// List element for chaining
    co_list_hdr_t   hdr;
    /// Function to be called upon timer expiration
    m_tb_timer_cb_t cb;
    /// Pointer to be passed to the callback
    void*           p_env;
    /// Expiration time in milliseconds
    uint32_t        time_ms;
    /// Number of wraps
    uint16_t        nb_wrap;
    /// Not used by timer module but by client, this variable is used to save timer period information.
    /// There is no unity to let client use it with any kind of timing step.
    /// It is recommended to use it only to keep period an not other information
    uint16_t        period;
} m_tb_timer_t;

/*
 * FUNCTION PROTOTYPES
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Program a timer to be scheduled in the future.
 *
 * @param[in] p_timer     Pointer to the timer structure.
 *                        "time" parameter is filled by the function based on indicated delay value
 * @param[in] delay       Duration before expiration of the timer (in milliseconds)
 ****************************************************************************************
 */
void m_tb_timer_set(m_tb_timer_t *p_timer, uint32_t delay_ms);

/**
 ****************************************************************************************
 * @brief Clear a programmed timer.
 * This function searches for the timer passed as parameter in the list of programmed
 * timers and extract it from the list.
 *
 * @param[in] p_timer   Pointer to the timer to be cleared
 ****************************************************************************************
 */
void m_tb_timer_clear(m_tb_timer_t *p_timer);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_tb_timer_get_cur_time(uint32_t *p_time_ms, uint16_t *p_nb_wrap);

/// @} end of group

#endif //_M_TB_TIMER_H_
