/**
 ****************************************************************************************
 * @file m_tb_state.h
 *
 * @brief Header file for State Manager Toolbox
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef _M_TB_STATE_H_
#define _M_TB_STATE_H_

/**
 ****************************************************************************************
 * @defgroup M_TB_STATE State Manager
 * @ingroup MESH
 * @brief State Manager Toolbox
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_api_int.h"

/*
 * ENUMERATION
 ****************************************************************************************
 */

/// Provisioning state values
enum m_tb_state_prov_state
{
    /// The node is not provisioned
    M_TB_STATE_PROV_STATE_UNPROV = 0x00,
    /// The node is being provisioned
    M_TB_STATE_PROV_STATE_BEING_PROV,
    /// The node is provisioned
    M_TB_STATE_PROV_STATE_PROV
};

/*
 * FUNCTION PROTOTYPES
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Set enabled state for the mesh profile
 *
 * @param[in] enabled       True if mesh profile has been enabled, else False
 ****************************************************************************************
 */
void m_tb_state_set_enabled(bool enabled);

/**
 ****************************************************************************************
 * @brief Set provisioning state
 *
 * @param[in] prov_state    Provisioning state (@see m_tb_state_prov_state)
 ****************************************************************************************
 */
void m_tb_state_set_prov_state(uint8_t prov_state);

/**
 ****************************************************************************************
 * @brief Set default TTL state value
 *
 * @param[in] default_ttl   Default TTL state value
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_default_ttl(uint8_t default_ttl);

/**
 ****************************************************************************************
 * @brief Set secure network beacon state value
 *
 * @param[in] bcn_state     Secure network beacon state value
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_beacon_state(uint8_t bcn_state);

#if (BLE_MESH_GATT_PROXY)
/**
 ****************************************************************************************
 * @brief Set GATT proxy state value
 *
 * @param[in] gatt_proxy_state     GATT proxy state value
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_gatt_proxy_state(uint8_t gatt_proxy_state);
#endif //(BLE_MESH_GATT_PROXY)

#if (BLE_MESH_RELAY)
/**
 ****************************************************************************************
 * @brief Set relay state value
 *
 * @param[in] relay_state          Relay state value
 * @param[in] relay_retx_state     Relay retransmission parameters
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_relay_state(uint8_t relay_state, uint8_t relay_retx_state);
#endif //(BLE_MESH_RELAY)

#if (BLE_MESH_FRIEND)
/**
 ****************************************************************************************
 * @brief Set friend state value
 *
 * @param[in] friend_state        Friend state value
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_friend_state(uint8_t friend_state);
#endif //(BLE_MESH_FRIEND)

/**
 ****************************************************************************************
 * @brief Set network transmit state value
 *
 * @param[in] net_tx_params        Network transmit state
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_net_tx_state(uint8_t net_tx_params);

/**
 ****************************************************************************************
 * @brief Set attention timer state
 *
 * @param[in] attention_state       Attention timer duration (attention state)
 *
 * @return Error status
 ****************************************************************************************
 */
void m_tb_state_set_attention_state(uint8_t attention_state);

#if (BLE_MESH_LPN)
/**
 ****************************************************************************************
 * @brief Indicate that a friendship has been established with a friend node
 *
 * @param[in] estab     True if friendship has been established, false if it has been lost
 ****************************************************************************************
 */
void m_tb_state_set_lpn_state(bool estab);
#endif //(BLE_MESH_LPN)

/**
 ****************************************************************************************
 * @brief Return if mesh profile is enabled or not.
 ****************************************************************************************
 */
bool m_tb_state_is_enabled(void);

/**
 ****************************************************************************************
 * @brief Return provisioning state (@see m_tb_state_prov_state)
 ****************************************************************************************
 */
uint8_t m_tb_state_get_prov_state(void);

/**
 ****************************************************************************************
 * @brief Return default TTL state value
 ****************************************************************************************
 */
uint8_t m_tb_state_get_default_ttl(void);

/**
 ****************************************************************************************
 * @brief Return secure network beacon state value
 ****************************************************************************************
 */
uint8_t m_tb_state_get_beacon_state(void);

/**
 ****************************************************************************************
 * @brief Return GATT proxy state value
 ****************************************************************************************
 */
uint8_t m_tb_state_get_gatt_proxy_state(void);

/**
 ****************************************************************************************
 * @brief Return relay state value
 ****************************************************************************************
 */
uint8_t m_tb_state_get_relay_state(uint8_t *p_relay_retx_state);

/**
 ****************************************************************************************
 * @brief Return friend state value (@see m_tb_state_friend_state)
 ****************************************************************************************
 */
uint8_t m_tb_state_get_friend_state(void);

/**
 ****************************************************************************************
 * @brief Return network transmit state value
 ****************************************************************************************
 */
uint8_t m_tb_state_get_net_tx_state(void);

/**
 ****************************************************************************************
 * @brief Get network transmit state
 ****************************************************************************************
 */
void m_tb_state_get_net_tx_params(uint8_t *p_tx_count, uint16_t *p_intv_slots);

/**
 ****************************************************************************************
 * @brief Get Attention timer state
 ****************************************************************************************
 */
uint8_t m_tb_state_get_attention_state(void);

#if (BLE_MESH_LPN)
/**
 ****************************************************************************************
 * @brief Return if friendship with a Friend node has been established.
 ****************************************************************************************
 */
bool m_tb_state_get_lpn_state(void);
#endif //(BLE_MESH_LPN)

/**
 ****************************************************************************************
 * @brief Get if a feature is supported or not.
 *
 * @param[in] feature  Mesh feature bit (@see enum m_api_feat)
 *
 * @return True if application supports the feature, False if not supported
 ****************************************************************************************
 */
bool m_tb_state_is_feature_sup(uint8_t feature);

#if (BLE_MESH_DBG)
/**
 ****************************************************************************************
 * @brief Get bit field of supported features
 *
 * @return feature bit field (@see enum m_api_feat)
 ****************************************************************************************
 */
uint8_t m_tb_state_get_features(void);
#endif //(BLE_MESH_DBG)

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
uint8_t m_tb_state_get_hb_feat_upd(void);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_tb_state_iv_update_ind(uint32_t time_ms, uint16_t nb_wrap);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
bool m_tb_state_is_iv_update_auth(void);

/// @} end of group

#endif //_M_TB_STATE_H_
