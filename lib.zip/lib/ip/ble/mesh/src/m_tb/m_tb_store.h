/**
 ****************************************************************************************
 * @file m_tb_store.h
 *
 * @brief Header file for Storage Manager Toolbox
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef _M_TB_STORE_H_
#define _M_TB_STORE_H_

/**
 ****************************************************************************************
 * @defgroup M_TB_STORE Store Manager
 * @ingroup MESH
 * @brief Storage Manager Toolbox
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_api_int.h"

/*
 * ENUMERATION
 ****************************************************************************************
 */

/// Update types
enum m_tb_store_upd_type
{
    /// Network key updated
    M_TB_STORE_UPD_TYPE_NET_KEY_UPDATED,
    /// Network key deleted
    M_TB_STORE_UPD_TYPE_NET_KEY_DELETED,

    /// Application key updated
    M_TB_STORE_UPD_TYPE_APP_KEY_UPDATED,
    /// Application key deleted
    M_TB_STORE_UPD_TYPE_APP_KEY_DELETED,

    /// Model publication parameters updated
    M_TB_STORE_UPD_TYPE_PUBLI_PARAM,
    /// Model subscription list updated
    M_TB_STORE_UPD_TYPE_SUBS_LIST,
    /// Model/application key binding updated
    M_TB_STORE_UPD_TYPE_BINDING,

    /// State updated
    M_TB_STORE_UPD_TYPE_STATE,
};

/// State types
enum m_tb_store_state_type
{
    /// Primary element unicast address
    M_TB_STORE_TYPE_UNICAST_ADDR         = 0,
    /// Default TTL state
    M_TB_STORE_TYPE_DEFAULT_TTL_STATE,
    /// Secure network beacon state
    M_TB_STORE_TYPE_SEC_BCN_STATE,
    /// Network transmit state
    M_TB_STORE_TYPE_NET_TX_STATE,
    /// Relay state
    M_TB_STORE_TYPE_RELAY_STATE,
    /// GATT proxy state
    M_TB_STORE_TYPE_GATT_PROXY_STATE,
    /// Friend state
    M_TB_STORE_TYPE_FRIEND_STATE,
    /// Device key
    M_TB_STORE_TYPE_DEV_KEY,
    /// IV and SEQ values
    M_TB_STORE_TYPE_IV_SEQ,
};

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Definition of callback function to call upon reception of a page of composition data
 *
 * @param[in] page      Page number of the composition data
 * @param[in] length    Page length
 * @param[in] p_data    Pointer to page content
 ****************************************************************************************
 */
typedef void (*m_tb_store_cb_compo_data_t)(uint8_t page, uint8_t length, uint8_t *p_data);

/**
 ****************************************************************************************
 * @brief Definition of callback function to call at end of load procedure
 ****************************************************************************************
 */
typedef void (*m_tb_store_cb_load_t)(uint16_t status);

/*
 * FUNCTION PROTOTYPES
 ****************************************************************************************
 */

#if (BLE_MESH_DBG)
#if (BLE_MESH_STORAGE_WVT)
/**
 ****************************************************************************************
 * @brief Configure storage manager behavior
 ****************************************************************************************
 */
void m_tb_store_set_config(uint32_t config);
#else
#define m_tb_store_set_config(config)
#endif //(BLE_MESH_STORAGE_WVT)
#endif //(BLE_MESH_DBG)

/**
 ****************************************************************************************
 * @brief Request the storage manager to retrieve and load stored data.
 ****************************************************************************************
 */
uint16_t m_tb_store_load(uint16_t length, uint8_t *p_data, m_tb_store_cb_load_t cb_load);

#if (BLE_MESH_STORAGE_NONE)
#define m_tb_store_update_ind(upd_type, dummy)
#else
/**
 ****************************************************************************************
 * @brief Inform the storage manager about an update of a parameter that need to be stored
 *
 * @param[in] upd_type      Update type (@see enum m_tb_store_upd_type)
 * @param[in] dummy         Dummy parameter whose meaning depends on update type value
 ****************************************************************************************
 */
void m_tb_store_update_ind(uint8_t upd_type, uint32_t dummy);
#endif //(BLE_MESH_STORAGE_NONE)

/**
 ****************************************************************************************
 * @brief Get a page of composition data
 *
 * @param[in] page      Page number of the composition data
 * @param[in] cb        Callback function called one the requested page is available
 ****************************************************************************************
 */
void m_tb_store_get_compo_data(uint8_t page, m_tb_store_cb_compo_data_t cb);

/**
 ****************************************************************************************
 * @brief Function called upon reception of a page of composition data
 *
 * @param[in] page      Page number of the composition data
 * @param[in] length    Page length
 * @param[in] p_data    Pointer to page content
 ****************************************************************************************
 */
void m_tb_store_rx_compo_data(uint8_t page, uint8_t length, uint8_t *p_data);

/// @} end of group

#endif //_M_TB_STORE_H_
