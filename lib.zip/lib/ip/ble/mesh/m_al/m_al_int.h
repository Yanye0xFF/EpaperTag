/**
 ****************************************************************************************
 *
 * @file m_al_int.h
 *
 * @brief Header file for Mesh Abstraction Layer internals
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef M_AL_INT_
#define M_AL_INT_

/**
 ****************************************************************************************
 * @defgroup M_AL Mesh Abstraction Layer
 * @ingroup MESH
 * @brief  Mesh Abstraction Layer
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "m_config.h"    // Mesh Configuration
#include "prf.h"         // Profile defines
#include "m_al.h"        // Mesh Abstraction Layer
#include "co_bt.h"       // Bluetooth defines

/*
 * DEFINES
 ****************************************************************************************
 */

#define M_AL_IDX_MAX        (1)

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// Message IDs for internal mesh messages
enum mesh_int_msg_id
{
    MESH_FIRST_INT_MSG = TASK_FIRST_MSG(TASK_ID_MESH) + 200,
    /// Kernel message sent when timer set by mesh stack expires
    MESH_TIMER_IND = MESH_FIRST_INT_MSG,
    /// Kernel message sent when advertising has been properly performed
    MESH_ADV_TX_DONE,
    /// Timer used to renew the mesh transmission address
    MESH_ADV_RENEW_IND,
    /// Kernel message sent by abstraction layer to itself in order to simulate feedback
    /// from BLE stack for start scan operation
    MESH_START_SCAN_CMP_EVT,
    /// Generation of P256 public key
    MESH_GEN_PUB_KEY_IND,
    /// Generation of DH-Key
    MESH_GEN_DH_KEY_IND,
};

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */


/// Structure for Timer Abstraction Layer environment
typedef struct m_al_timer_env
{
    /// Last read local time value
    uint32_t last_time_loc;
    /// Clock (in milliseconds)
    uint32_t clock_ms;
    /// Number of time the clock has wrapped since wake-up time
    uint16_t nb_wrap;
} m_al_timer_env_t;

/// Advertising environment definition
typedef struct m_al_adv_env
{
    /// Set of callback executed when an event occurs on advertising bearer
    const m_al_adv_cb_t*     p_cb_evts;
    /// Status of the scanning
    uint8_t                  scan_state;
    /// Identifier of bearer that handle packet transmission / reception
    m_lid_t                  bearer_lid;

    /// Non resolvable random address used for advertising packet transmission
    uint8_t                  tx_bd_addr[BD_ADDR_LEN];
} m_al_adv_env_t;

/// Structure Delayed job execution
typedef struct m_al_djob_env
{
    /// Job queue to execute
    co_list_t job_queue;
} m_al_djob_env_t;


/// Structure for security environment
typedef struct m_al_sec_env
{
    /// Call-back to read Public key
    m_al_sec_pub_key_res_cb     cb_pub_key;
    /// Call-back for DH-Key generation
    m_al_sec_ecdh_secret_res_cb cb_dh_key;

    /// Private P-256 Key Value
    uint8_t                     private_key[M_PRIVATE_KEY_LEN];
    /// Public P-256 Key Value
    uint8_t                     public_key[M_PUB_KEY_X_LEN + M_PUB_KEY_Y_LEN];
    /// Key Pair valid
    bool                        key_pair_valid;
} m_al_sec_env_t;

/// Mesh Abstraction layer Environment Variable
typedef struct _m_al_env_t
{
    /// Profile environment
    prf_env_t         prf_env;
    /// Mesh task state
    ke_state_t        state[M_AL_IDX_MAX];
    /// Security module environment
    m_al_sec_env_t    sec;
    /// Timer Environment
    m_al_timer_env_t  timer;
    /// Advertising environment
    m_al_adv_env_t    adv;
    /// Delayed Job environment
    m_al_djob_env_t   djob;
} m_al_env_t;


/*
 * GLOBAL VARIABLE
 ****************************************************************************************
 */
extern m_al_env_t* p_m_al_env;

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * Initialize encryption block for Mesh abstraction layer
 *
 * @param[in] reset     Initialization due to a reset
 ****************************************************************************************
 */
void m_al_sec_init(bool reset);

/**
 ****************************************************************************************
 * Request HL to execute an AES function
 *
 * @param[in] key       128 bits key
 * @param[in] val       128 bits value to encrypt with AES
 ****************************************************************************************
 */
void m_al_sec_aes_req(const uint8_t* key, const uint8_t* val);

/**
 ****************************************************************************************
 * Initialize timer block for Mesh abstraction layer
 *
 * @param[in] reset Initialization due to a reset
 ****************************************************************************************
 */
void m_al_timer_init(bool reset);

/**
 ****************************************************************************************
 * Initialize Advertising block for Mesh abstraction layer
 *
 * @param[in] reset Initialization due to a reset
 ****************************************************************************************
 */
void m_al_adv_init(bool reset);

/**
 ****************************************************************************************
 * @brief TODO [LT]
 ****************************************************************************************
 */
void m_al_adv_scan_started_handler(void);

/**
 ****************************************************************************************
 * Initialize delayed job block for Mesh abstraction layer
 *
 * @param[in] reset Initialization due to a reset
 ****************************************************************************************
 */
void m_al_djob_init(bool reset);

/// @} M_AL

#endif /* M_AL_INT_ */
