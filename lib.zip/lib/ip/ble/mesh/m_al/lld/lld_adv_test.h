/**
 ****************************************************************************************
 *
 * @file lld_adv_test.h
 *
 * @brief Declaration of functions used for advertising test mode driver
 *
 * Copyright (C) RivieraWaves 2017-2018
 *
 ****************************************************************************************
 */

#ifndef LLD_ADV_TEST_H_
#define LLD_ADV_TEST_H_

/**
 ****************************************************************************************
 * @addtogroup LLDADVTEST
 * @ingroup LLD
 * @brief Advertising test mode driver
 *
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "rwip_config.h"

#if (BLE_EMB_PRESENT && BLE_ADV_TEST_MODE)
#include "ea.h"

/*
 * MACROS
 ****************************************************************************************
 */

/*
 * DEFINES
 ****************************************************************************************
 */
/// Unique tag that represents ADV Test mode driver data
#define BLE_ADV_TEST_MODE_ELT    (0xADA55ADA)

/// Allows an adv interval of 10ms
#define BLE_ADV_TEST_INTERVAL_MIN (0x10)
/*
 * MACROS
 ****************************************************************************************
 */

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Start Advertising test mode
 *
 * @param[in] interval  Interval of the advertising (slots unit)
 * @param[in] chmap     Advertising channel map
 * @param[in] nb_tx     Number of transmission per advertising channel to perform
 * @param[in] addr      BD Address to transmit (if zero, use device public address)
 * @param[in] data_len  Length of advertising data.
 * @param[in] data      Advertising data.
 * @param[in] msg_id    Message Identifier to trigger when requested advertising is over
 * @param[in] dst_id    Task Identifier that will handle end message
 *
 * @return CO_ERROR_NO_ERROR if succeed else see error code.
 ****************************************************************************************
 */
uint8_t lld_adv_test_start(uint16_t interval, uint8_t chmap, uint8_t nb_tx, const uint8_t* addr,
                           uint8_t data_len, const uint8_t* data, uint16_t msg_id, uint16_t dst_id);

/**
 ****************************************************************************************
 * @brief End of Advertising test mode event (driver internal use)
 *
 * @param[in] elt  Event arbiter information
 *
 ****************************************************************************************
 */
void lld_adv_test_end_cb(struct ea_elt_tag* elt);


/**
 ****************************************************************************************
 * @brief Initialize advertising test mode driver
 *
 * @param[in] reset  True if reset False if boot init
 *
 ****************************************************************************************
 */
void lld_adv_test_init(bool reset);

#endif // (BLE_EMB_PRESENT && BLE_ADV_TEST_MODE)

#endif // LLD_ADV_TEST_H_

/// @} LLDADVTEST
