#ifndef _M_TB_STORE_HDR_H
#define _M_TB_STORE_HDR_H

#include "m_defines.h"
#include "m_tb_store.h"
#include "co_math.h"

/*
 * DEFINES
 ****************************************************************************************
 */

/// Sequence number offset - When sequence number is provided, an offset is applied in order
/// to take in account that packets might have been sent without storage entity knowledge.
#define M_TB_STORE_SEQ_OFFSET                       (100)

/// Stored data provided by the application is divided in several section whose mapping is
/// provided below:
///
///  0                           2                            4
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |                          STATES                         |
/// |                                                         |
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |                  NETWORK KEY INFORMATION                |
/// |                                                         |
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |                APPLICATION KEY INFORMATION              |
/// |                                                         |
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |                  MODEL PUBLI INFORMATION                |
/// |                                                         |
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |                   MODEL SUBS INFORMATION                |
/// |                                                         |
/// |---------------------------------------------------------|
/// |                      SECTION HEADER                     |
/// |---------------------------------------------------------|
/// |                                                         |
/// |               MODEL/KEY BINDING INFORMATION             |
/// |                                                         |
/// |---------------------------------------------------------|

#define M_TB_STORE_SECTION_PATTERN      (0xBAABFAFA)

/*
 * ENUMERATIONS
 ****************************************************************************************
 */

/// Configuration bitfield
/// 31                    1               0
/// ---------------------------------------
/// | RFU                 | UPDATE IND EN |
/// ---------------------------------------
enum m_tb_store_config
{
    /// Enable/disable sending of update indication
    M_TB_STORE_CONFIG_UPD_IND_EN_POS = 0,
    M_TB_STORE_CONFIG_UPD_IND_EN_BIT = CO_BIT(M_TB_STORE_CONFIG_UPD_IND_EN_POS),
};

/// Section types
enum m_tb_store_sect_type
{
    /// Miscellaneous states
    M_TB_STORE_SECT_TYPE_STATE          = 0,
    /// Network key information
    M_TB_STORE_SECT_TYPE_NET_KEY,
    /// Application key information
    M_TB_STORE_SECT_TYPE_APP_KEY,
    /// Publication parameters
    M_TB_STORE_SECT_TYPE_PUBLI_INFO,
    /// Subscription list
    M_TB_STORE_SECT_TYPE_SUBS_LIST,
    /// Binding
    M_TB_STORE_SECT_TYPE_BINDING,
};

/// Network key entry information bitfield
/// 7     4         3     2       0
/// -------------------------------
/// | RFU | PHASE 2 | UPD | FLAGS |
/// -------------------------------
enum m_tb_store_netkey_info
{
    /// Flags
    M_TB_STORE_NETKEY_INFO_FLAGS_LSB  = 0,
    M_TB_STORE_NETKEY_INFO_FLAGS_MASK = 0x03,

    /// Update key present
    M_TB_STORE_NETKEY_INFO_UPD_POS    = 2,
    M_TB_STORE_NETKEY_INFO_UPD_BIT    = CO_BIT(M_TB_STORE_NETKEY_INFO_UPD_POS),

    /// Phase 2
    M_TB_STORE_NETKEY_INFO_P2_POS     = 3,
    M_TB_STORE_NETKEY_INFO_P2_BIT     = CO_BIT(M_TB_STORE_NETKEY_INFO_P2_POS),
};

/// Application key entry information bitfield
/// 7     1     0
/// -------------
/// | RFU | UPD |
/// -------------
enum m_tb_store_appkey_info
{
    /// Update key present
    M_TB_STORE_APPKEY_INFO_UPD_POS = 0,
    M_TB_STORE_APPKEY_INFO_UPD_BIT = CO_BIT(M_TB_STORE_APPKEY_INFO_UPD_POS),
};

/// Publication parameters entry information bitfield
/// 7        6         0
/// --------------------
/// |   RFU  |  VENDOR |
/// --------------------
enum m_tb_store_publi_info
{
    /// SIG or vendor model ID
    M_TB_STORE_PUBLI_INFO_VENDOR_POS = 0,
    M_TB_STORE_PUBLI_INFO_VENDOR_BIT = CO_BIT(M_TB_STORE_PUBLI_INFO_VENDOR_POS),
};

/// Subscription list entry information bitfield
/// 7        6         0
/// --------------------
/// | VENDOR | NB_ADDR |
/// --------------------
enum m_tb_store_subs_info
{
    /// Number of addresses in the subscription list
    M_TB_STORE_SUBS_INFO_NB_ADDR_LSB  = 0,
    M_TB_STORE_SUBS_INFO_NB_ADDR_MASK = 0x7F,

    /// SIG or vendor model ID
    M_TB_STORE_SUBS_INFO_VENDOR_POS   = 7,
    M_TB_STORE_SUBS_INFO_VENDOR_BIT   = CO_BIT(M_TB_STORE_SUBS_INFO_VENDOR_POS),
};

/// Model/application key binding entry information bitfield
/// 7        1            0
/// -----------------------
/// | VENDOR | NB_APP_IDS |
/// -----------------------
enum m_tb_store_binding_info
{
    /// Number of application keys bound with the model
    M_TB_STORE_BINDING_INFO_NB_APP_IDS_LSB  = 0,
    M_TB_STORE_BINDING_INFO_NB_APP_IDS_MASK = 0x7F,

    /// SIG or vendor model ID
    M_TB_STORE_BINDING_INFO_VENDOR_POS      = 7,
    M_TB_STORE_BINDING_INFO_VENDOR_BIT      = CO_BIT(M_TB_STORE_BINDING_INFO_VENDOR_POS),
};

/// Loading procedure states
enum m_tb_store_load_state
{
    /// Wait for reception of stored data
    M_TB_STORE_LOAD_STATE_WAIT_DATA = 0,
    /// Loading data
    M_TB_STORE_LOAD_STATE_LOADING,
};

/*
 * STRUCTURES
 ****************************************************************************************
 */

/// Section header structure
typedef struct m_tb_store_hdr
{
    /// Total length of section
    uint16_t length;
    /// Section type (@see enum m_tb_store_sect_type)
    uint8_t  type;
    /// Number of entries in the section
    uint8_t  nb_entries;
    /// Pattern
    uint32_t pattern;
} m_tb_store_hdr_t;

/// Entry structure
typedef struct m_tb_store_entry
{
    /// Entry length
    uint8_t length;
} m_tb_store_entry_t;

/// State entry structure
typedef struct m_tb_store_state
{
    /// Entry length
    uint8_t length;
    /// Type
    uint8_t type;
    /// State value
    uint8_t val[M_KEY_LEN];
} m_tb_store_state_t;

/// State entry structure for IV and SEQ values
typedef struct m_tb_store_state_iv_seq
{
    /// Entry length
    uint8_t length;
    /// Type
    uint8_t type;
    /// Last IV update time (wrap)
    uint16_t nb_wrap;
    /// Last IV update time (clock)
    uint32_t clock_ms;
    /// IV
    uint32_t iv;
    /// SEQ
    uint32_t seq;
} m_tb_store_state_iv_seq_t;

/// Network key information entry structure if network key is not being updated
typedef struct m_tb_store_netkey
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_net_key_info)
    uint8_t  info;
    /// NetKey ID
    uint16_t netkey_id;
    /// Network Key
    uint8_t  key[M_KEY_LEN];
} m_tb_store_netkey_t;

/// Network key information entry structure if network key is being updated
typedef struct m_tb_store_netkey_upd
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_net_key_info)
    uint8_t  info;
    /// NetKey ID
    uint16_t netkey_id;
    /// Network Key
    uint8_t  key[M_KEY_LEN];
    /// New network key
    uint8_t  new_key[M_KEY_LEN];
} m_tb_store_netkey_upd_t;

/// Application key information entry structure if application key is not being updated
typedef struct m_tb_store_appkey
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_app_key_info)
    uint8_t  info;
    /// NetKey ID
    uint16_t netkey_id;
    /// AppKey ID
    uint16_t appkey_id;
    /// Application Key
    uint8_t  key[M_KEY_LEN];
} m_tb_store_appkey_t;

/// Application key information entry structure if application key is being updated
typedef struct m_tb_store_appkey_upd
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_app_key_info)
    uint8_t  info;
    /// NetKey ID
    uint16_t netkey_id;
    /// AppKey ID
    uint16_t appkey_id;
    /// Application Key
    uint8_t  key[M_KEY_LEN];
    /// New application key
    uint8_t  new_key[M_KEY_LEN];
} m_tb_store_appkey_upd_t;

/// Model publication parameter entry structure if publication address is not a virtual address
typedef struct m_tb_store_publi
{
    /// Entry length
    uint8_t  length;
    /// Information
    uint8_t  info;
    /// Element address (@see enum m_tb_store_publi_info)
    uint16_t element_addr;
    /// Model ID
    uint32_t model_id;
    /// Publication address
    uint16_t addr;
    /// AppKey ID
    uint16_t appkey_id;
    /// TTL
    uint8_t  ttl;
    /// Period
    uint8_t  period;
    /// Retransmission parameters
    uint8_t  retx_params;
    /// Friend credentials
    uint8_t  friend_cred;
} m_tb_store_publi_t;

/// Model publication parameter entry structure if publication address is a virtual address
typedef struct m_tb_store_publi_virt
{
    /// Entry length
    uint8_t  length;
    /// Information
    uint8_t  info;
    /// Element address (@see enum m_tb_store_publi_info)
    uint16_t element_addr;
    /// Model ID
    uint32_t model_id;
    /// Publication address
    uint16_t addr;
    /// AppKey ID
    uint16_t appkey_id;
    /// TTL
    uint8_t  ttl;
    /// Period
    uint8_t  period;
    /// Retransmission parameters
    uint8_t  retx_params;
    /// Friend credentials
    uint8_t  friend_cred;
    /// Label UUID
    uint8_t  label_uuid[M_LABEL_UUID_LEN];
} m_tb_store_publi_virt_t;

/// Model subscription list entry structure
typedef struct m_tb_store_subs
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_subs_info)
    uint8_t  info;
    /// Element address
    uint16_t element_addr;
    /// Model ID
    uint32_t model_id;
    /// List
    uint8_t  list[__ARRAY_EMPTY];
} m_tb_store_subs_t;

/// Model/Application key binding entry structure
typedef struct m_tb_store_binding
{
    /// Entry length
    uint8_t  length;
    /// Information (@see enum m_tb_store_binding_info)
    uint8_t  info;
    /// Element address
    uint16_t element_addr;
    /// Model ID
    uint32_t model_id;
    /// List of AppKey IDs
    uint16_t appkey_ids[__ARRAY_EMPTY];
} m_tb_store_binding_t;

/// Load information structures
typedef struct m_tb_store_load_info
{
    /// Callback called at end of load procedure
    m_tb_store_cb_load_t cb_load;

    /// Pointer to currently handled section
    m_tb_store_hdr_t     *p_section;
    /// Pointer to currently handled section entry
    m_tb_store_entry_t   *p_entry;
    /// Remaining length of data to parse in a section
    uint16_t             rem_section_len;
    /// Number of remaining sections to parse
    uint8_t              rem_nb_section;
    /// Padding
    uint8_t              pad;
    /// Data
    uint8_t              data[__ARRAY_EMPTY];
} m_tb_store_load_info_t;

/// Structure for Storage Manager environment
typedef struct m_tb_store_env
{
    /// Callback called upon reception of composition data from the application
    m_tb_store_cb_compo_data_t cb_compo_data;
    /// Load information
    m_tb_store_load_info_t     *p_load_info;
#if (BLE_MESH_DBG)
    /// Configuration
    uint32_t                   config;
#endif //(BLE_MESH_DBG)
} m_tb_store_env_t;

/*
 * MACROS
 ****************************************************************************************
 */

/// Get first entry in a section
#define M_TB_STORE_GET_FIRST_ENTRY(p_section)                                           \
                (m_tb_store_entry_t *)((uint32_t)p_section + sizeof(m_tb_store_hdr_t))

/// Get next entry in a section
#define M_TB_STORE_GET_NEXT_ENTRY(p_entry)                                              \
                (m_tb_store_entry_t *)((uint32_t)p_entry + p_entry->length)

/// Get next section
#define M_TB_STORE_GET_NEXT_SECTION(p_section)                                          \
                (m_tb_store_hdr_t *)((uint32_t)p_section + p_section->length)

#endif


