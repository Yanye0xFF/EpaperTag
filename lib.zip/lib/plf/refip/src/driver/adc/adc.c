#include <stdint.h>
#include "reg_access.h"
#include "co_math.h"
#include "apb2spi.h"
#include "system.h"
#include "adc.h"
#include "gpio.h"
#include "user_sys.h"


#define ADC_BASE    0x50090000
//ADC_CNTL
#define ADCFF_RX_FULL_STATUS       CO_BIT(12)
#define ADCFF_RX_HFULL_STATUS      CO_BIT(13)
#define ADCFF_RX_EMPTY_STATUS      CO_BIT(14)
#define ADCFF_HEMPTY_STATUS        CO_BIT(15)

#define ADCFF_RX_FULL_ENABLE       CO_BIT(16)
#define ADCFF_RX_HFULL_ENABLE      CO_BIT(17)
#define ADCFF_RX_EMPTY_ENABLE      CO_BIT(18)
#define ADCFF_HEMPTY_ENABLE        CO_BIT(19)

#define ADC_CNTL        (ADC_BASE)
#define ADC_STAT        (ADC_BASE + 0x04)
#define ADC_DATA_BASE   (ADC_BASE + 0x08)
#define ADC_RX_DATA     (ADC_BASE + 0x18)

/**
 ****************************************************************************************
 * @brief ����adc����ؼĴ���.
 ****************************************************************************************
 */
//type, 0:vbat;  1, normal adc;
static void adc_config(uint8_t type)
{
    ool_write(0x14,(ool_read(0x14) | CO_BIT(6)) & ~(CO_BIT(7)) & ~(CO_BIT(5)));     //disable SARADC auto start, set REF to 0.9VDDA
    ool_write(0x15,((ool_read(0x15) & ~(0x1f)) | CO_BIT(5)) & ~(CO_BIT(6)));        //enable SARADC, disable input buffer, set clock to CLK_OOL_DIV_ADC

    ool_write(0x16,(ool_read(0x16) & ~(0x1f)) | CO_BIT(5));                         //

    ool_write(0x17,0x88);
    ool_write(0x18,0x40);
    ool_write(0x1d,(ool_read(0x1d) | (CO_BIT(4))) & ~(CO_BIT(6)) & ~(CO_BIT(5))); //set to 1, controled by digtal
    ool_write(0x19,((ool_read(0x19) & ~(CO_BIT(7))) | CO_BIT(5) | CO_BIT(6)) & ~(CO_BIT(3)) & ~(CO_BIT(4)));//adc pd set to 0

    ool_write(0x1a,0x27);
    ool_write(0x1b,0x58);
    ool_write(0x1c,0x63);

    if(type == 0)
    {
        //case0:
        ool_write(0x15,ool_read(0x15)| BIT(4) | BIT(2) ); //ADD
        ool_write(0x1c,ool_read(0x1c)| BIT(2) ); //ADDs

        ool_write(0x19,( ool_read(0x19) & ~(BIT(5)) )  ); //ADD
        ool_write(0x37,(ool_read(0x37) & 0xf0) | 0x0B ); //ADD

        //case3: use internal bandgap reference as saradc ref signal, and the ref can be 1.2,1.3,1.4,1.5V seperately
        ool_write(0x18,ool_read(0x18)| BIT(7)  ); //ADD
        ool_write(0x1a,ool_read(0x1a) & ~(0xf0) | 0xc0);
    }
    else if(type == 1)
    {

        //case1:input pad signal passes through internal buf and sample unit consecutively
        ool_write(0x15,ool_read(0x15)| BIT(6)|BIT(0) ); //ADD
        ool_write(0x16,ool_read(0x16)& ~(BIT(1)|BIT(0)) ); //ADDs

        ool_write(0x19,( ool_read(0x19) & ~(BIT(5)) ) | BIT(3) ); //ADD
    }
    /*
    //case2: input pad signal passes throuth internal resistor divider and sample unit consecutively
    ool_write(0x19,ool_read(0x19)& ~(BIT(5)) ); //ADD
    ool_write(0x19,ool_read(0x19) | BIT(4) ); //ADD
    ool_write(0x18,ool_read(0x18) & ~(0x7f) | 0x34  ); //ADD
    ool_write(0x15,ool_read(0x15) | BIT(4)  ); //ADD
    */
}

#include "prf.h"
#include "system.h"

struct system_regs_t *const system_regs_x = (struct system_regs_t *)SYSTEM_REG_BASE;

void adc_enable(uint8_t channels)
{
#define PORT_FUNC_ADC       PORTC0_FUNC_ADC0
    uint8_t i;
    uint8_t chnl_num = 0;

    for(i=0; i<8; i++)
    {
        if(channels & CO_BIT(i))
        {
            chnl_num++;
            system_set_port_mux(GPIO_PORT_C, i, PORT_FUNC_ADC);
            //gpio_set_dir(GPIO_PORT_C, i, GPIO_DIR_IN);
            //system_set_port_pull(GPIO_PORT_C*8+i,true);
        }
    }

    system_set_port_pull(channels << (GPIO_PORT_C * 8), false);
    //system_regs_x->reserved1 &= (~(1<<(channels << (GPIO_PORT_C * 8))));
    //system_regs_x->reserved1 |=  (1<<(channels << (GPIO_PORT_C * 8)));

    if(chnl_num == 1)
        REG_PL_WR(ADC_CNTL, (1<<4) | (1<<5) |(1<<6) |CO_BIT(8));    //adc enable, step = 1
    else
        REG_PL_WR(ADC_CNTL, (1<<4) |CO_BIT(8));    //adc enable, step = 1

    pmu_set_gpio_pull(GPIO_PORT_C, channels, false);
    pmu_set_gpio_input(GPIO_PORT_C, channels, true);
    pmu_set_gpio_output(GPIO_PORT_C, channels, false);
    pmu_set_gpio_to_PMU(GPIO_PORT_C, channels);

    adc_config(1);
}

void adc_disable(void)
{
    REG_PL_WR(ADC_CNTL, 0);
    ool_write(0x15, 0);
    ool_write(0x1a,ool_read(0x1a) & ~ BIT(1));
    ool_write(0x19,ool_read(0x19) | BIT(7) ); //ADD
}

void adc_get_values(uint8_t channles, uint16_t *buffer)
{
    uint32_t adc_data;
    uint8_t i;

    for(i=0; i<8;)
    {
        adc_data = REG_PL_RD(ADC_DATA_BASE+i*2);
        if((0x01<<i) & channles)
        {
            *buffer++ = adc_data & 0x3ff;
        }

        if((0x02<<i) & channles)
        {
            *buffer++ = (adc_data>>16) & 0x3ff;
        }

        i += 2;
    }

}

uint16_t adc_get_value(uint8_t channel_idx)
{
    uint32_t adc_data;
    uint8_t i;

    i = channel_idx / 2;
    adc_data = REG_PL_RD(ADC_DATA_BASE+i*4);

    if(channel_idx % 2)
    {
        return (adc_data>>16) & 0x3ff;
    }
    else
    {
        return adc_data & 0x3ff;
    }
}


uint16_t get_vbat_value(void)
{
    uint8_t aldo_value = ((ool_read(0x00) & 0xE0) >>5);

    REG_PL_WR(ADC_CNTL, (1<<4) | (1<<5) |(1<<6) |CO_BIT(8));    //adc enable, step = 1
    adc_config(0);
    co_delay_100us(2);
    uint16_t tmp = REG_PL_RD(ADC_DATA_BASE)&0x3ff;

    adc_disable();
    // return ( ((tmp*422000)/(3725 + 45 *vchg_trim_value))*30) >>9;
    //return ( ((tmp*422000)/(3725 + 45 *vchg_trim_value))*30) >>9;
    return  (((tmp*(35 + aldo_trim_value + 4*aldo_value)/(42+4*aldo_value))*3000)>>9) - 74;     //-74 is adjust
}


#if (ADC_TEST_ENABLE)
void test_adc(void)
{
    adc_enable(0x0c);
    uint16_t buff[8] = {0};

    adc_get_values(0x0c, buff);
    printf("values:%d,%d,%d,%d,%d,%d,%d,%d\r\n",buff[0],buff[1]
           ,buff[2],buff[3],buff[4],buff[5],buff[6],buff[7]);
    adc_get_values(0x0c, buff);
    printf("values:%d,%d,%d,%d,%d,%d,%d,%d\r\n",buff[0],buff[1]
           ,buff[2],buff[3],buff[4],buff[5],buff[6],buff[7]);
    adc_get_values(0x0c, buff);
    printf("values:%d,%d,%d,%d,%d,%d,%d,%d\r\n",buff[0],buff[1]
           ,buff[2],buff[3],buff[4],buff[5],buff[6],buff[7]);
}

#endif



