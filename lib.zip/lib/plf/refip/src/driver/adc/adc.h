#ifndef _ADC_H
#define _ADC_H

void adc_enable(uint8_t channels);
void adc_disable(void);
void adc_get_values(uint8_t channles, uint16_t *buffer);
uint16_t adc_get_value(uint8_t channel_idx);
uint16_t get_vbat_value(void);


#ifndef ADC_TEST_ENABLE
#define ADC_TEST_ENABLE 0
#endif
#if ADC_TEST_ENABLE
void test_adc();
#endif

#endif

