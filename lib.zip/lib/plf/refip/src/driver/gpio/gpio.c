#include <stdint.h>
#include "gpio.h"
#include "jump_table.h"
#include "system.h"
#include "exti.h"
#include "co_math.h"
#include "app_api.h"
#include "rwip.h"

void gpio_init(void)
{
    uint32_t i;

    for(i=0; i<32; i++)
    {
        if(__jump_table.gpio_button_sel & CO_BIT(i))
        {
            system_set_port_mux(i/8, i%8, PORT_FUNC_EXT_INT);
            system_set_port_pull(i, true);
            //gpio_set_dir(i/8, i%8, GPIO_DIR_IN);
            ext_int_set_type(i, EXT_INT_TYPE_LOW);
            ext_int_set_control(i, 1000, 10);
            ext_int_enable(i);
        }
    }
    if(__jump_table.gpio_button_sel != 0)
    {
        NVIC_EnableIRQ(EXT_INTR_IRQn);
    }

    if(user_gpio_init)
    {
        user_gpio_init();
    }
}

void gpio_set_dir(enum system_port_t port, enum system_port_bit_t bit, uint8_t dir)
{
    switch(port)
    {
        case GPIO_PORT_A:
            gpio_porta_set_dir((gpio_porta_get_dir()&(~(1<<bit)))|(dir<<bit));
            break;
        case GPIO_PORT_B:
            gpio_portb_set_dir((gpio_portb_get_dir()&(~(1<<bit)))|(dir<<bit));
            break;
        case GPIO_PORT_C:
            gpio_portc_set_dir((gpio_portc_get_dir()&(~(1<<bit)))|(dir<<bit));
            break;
        case GPIO_PORT_D:
            gpio_portd_set_dir((gpio_portd_get_dir()&(~(1<<bit)))|(dir<<bit));
            break;
        default:
            break;
    }
}

