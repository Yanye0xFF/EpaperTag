#ifndef _GPIO_H
#define _GPIO_H

#include <stdint.h>
#include "plf.h"
#include "system.h"

#define GPIO_PORTA_DATA         (GPIOAB_BASE + 0x00)
#define GPIO_PORTB_DATA         (GPIOAB_BASE + 0x04)
#define GPIO_PORTA_DIR          (GPIOAB_BASE + 0x08)
#define GPIO_PORTB_DIR          (GPIOAB_BASE + 0x0c)
#define GPIO_PORTC_DATA         (GPIOCD_BASE + 0x00)
#define GPIO_PORTD_DATA         (GPIOCD_BASE + 0x04)
#define GPIO_PORTC_DIR          (GPIOCD_BASE + 0x08)
#define GPIO_PORTD_DIR          (GPIOCD_BASE + 0x0c)

#define GPIO_DIR_IN         1
#define GPIO_DIR_OUT        0

__INLINE void gpio_porta_write(uint8_t value)
{
    REG_PL_WR(GPIO_PORTA_DATA, value);
}


__INLINE void gpio_portb_write(uint8_t value)
{
    REG_PL_WR(GPIO_PORTB_DATA, value);
}

__INLINE void gpio_portc_write(uint8_t value)
{
    REG_PL_WR(GPIO_PORTC_DATA, value);
}

__INLINE void gpio_portd_write(uint8_t value)
{
    REG_PL_WR(GPIO_PORTD_DATA, value);
}

__INLINE uint8_t gpio_porta_read(void)
{
    return REG_PL_RD(GPIO_PORTA_DATA);
}

__INLINE uint8_t gpio_portb_read(void)
{
    return REG_PL_RD(GPIO_PORTB_DATA);
}

__INLINE uint8_t gpio_portc_read(void)
{
    return REG_PL_RD(GPIO_PORTC_DATA);
}

__INLINE uint8_t gpio_portd_read(void)
{
    return REG_PL_RD(GPIO_PORTD_DATA);
}

__INLINE void gpio_porta_set_dir(uint8_t dir)
{
    REG_PL_WR(GPIO_PORTA_DIR, dir);
}

__INLINE void gpio_portb_set_dir(uint8_t dir)
{
    REG_PL_WR(GPIO_PORTB_DIR, dir);
}

__INLINE void gpio_portc_set_dir(uint8_t dir)
{
    REG_PL_WR(GPIO_PORTC_DIR, dir);
}

__INLINE void gpio_portd_set_dir(uint8_t dir)
{
    REG_PL_WR(GPIO_PORTD_DIR, dir);
}

__INLINE uint8_t gpio_porta_get_dir(void)
{
    return REG_PL_RD(GPIO_PORTA_DIR);
}

__INLINE uint8_t gpio_portb_get_dir(void)
{
    return REG_PL_RD(GPIO_PORTB_DIR);
}

__INLINE uint8_t gpio_portc_get_dir(void)
{
    return REG_PL_RD(GPIO_PORTC_DIR);
}

__INLINE uint8_t gpio_portd_get_dir(void)
{
    return REG_PL_RD(GPIO_PORTD_DIR);
}

void gpio_init(void);
void gpio_set_dir(enum system_port_t port, enum system_port_bit_t bit, uint8_t dir);
void gpio_set_dir_as_high_imp(enum system_port_t port, enum system_port_bit_t bit);

#endif //_GPIO_H

