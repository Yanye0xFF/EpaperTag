#ifndef __GPIO_DBG_LIB_H
#define __GPIO_DBG_LIB_H
#include <stdio.h>

#ifndef GPIO_DBG_ENABLE
#define GPIO_DBG_ENABLE (0)
#endif


void gpio_dbg_init(uint8_t port, uint8_t bit, uint8_t func);
void gpio_dbg_toggle(uint8_t cnt);

#endif //_GPIO_H

