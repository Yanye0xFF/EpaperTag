#include <stdint.h>
#include "system.h"
#include "gpio.h"
#include "gpio_dbg_lib.h"

#if GPIO_DBG_ENABLE
static uint8_t dbg_bit = 0;
static uint8_t dbg_port = 0;
#endif

void __attribute__((section("deep_sleep_code"))) gpio_dbg_init(uint8_t port, uint8_t bit, uint8_t func)
{
#if GPIO_DBG_ENABLE
    dbg_port = port;
    dbg_bit = bit;
    system_set_port_mux(dbg_port, dbg_bit, func);
    gpio_set_dir(dbg_port, dbg_bit, GPIO_DIR_OUT);
    gpio_porta_write(gpio_porta_read() & ~(BIT(dbg_bit)) );
#endif
}

void gpio_dbg_toggle(uint8_t cnt)
{
#if GPIO_DBG_ENABLE
    for(uint8_t i=0; i<cnt; i++)
    {
        switch(dbg_port)
        {
            case GPIO_PORT_A:
                gpio_porta_write(gpio_porta_read() | BIT(dbg_bit) );
                gpio_porta_write(gpio_porta_read() & ~(BIT(dbg_bit)) );
                break;
            case GPIO_PORT_B:
                gpio_portb_write(gpio_portb_read() | BIT(dbg_bit) );
                gpio_portb_write(gpio_portb_read() & ~(BIT(dbg_bit)) );
                break;
            case GPIO_PORT_C:
                gpio_portc_write(gpio_portc_read() | BIT(dbg_bit) );
                gpio_portc_write(gpio_portc_read() & ~(BIT(dbg_bit)) );
                break;
            case GPIO_PORT_D:
                gpio_portd_write(gpio_portd_read() | BIT(dbg_bit) );
                gpio_portd_write(gpio_portd_read() & ~(BIT(dbg_bit)) );
                break;
            default:
                break;
        }
    }
#endif
}



