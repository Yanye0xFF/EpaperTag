/**
 ****************************************************************************************
 *
 * @file uart2.h
 *
 * @brief UART2 Driver for HCI over UART2 operation.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef _UART2_H_
#define _UART2_H_

/**
 ****************************************************************************************
 * @defgroup UART2 UART2
 * @ingroup DRIVERS
 * @brief UART2 driver
 *
 * @{
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdbool.h>          // standard boolean definitions
#include <stdint.h>           // standard integer functions
#include "rwip.h"

/*
 * ENUMERATION DEFINITIONS
 *****************************************************************************************
 */

/*  BAUD_RATE */
#define BAUD_RATE_921600                 11
#define BAUD_RATE_460800                 10
#define BAUD_RATE_230400                 9
#define BAUD_RATE_115200                 8
#define BAUD_RATE_57600                  7
#define BAUD_RATE_38400                  6
#define BAUD_RATE_19200                  5
#define BAUD_RATE_14400                  4
#define BAUD_RATE_9600                   3
#define BAUD_RATE_4800                   2
#define BAUD_RATE_2400                   1
#define BAUD_RATE_1200                   0

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initializes the UART2 to default values.
 *****************************************************************************************
 */
void uart2_init(uint8_t bandrate);

#ifndef CFG_ROM
/**
 ****************************************************************************************
 * @brief Enable UART2 flow.
 *****************************************************************************************
 */
void uart2_flow_on(void);

/**
 ****************************************************************************************
 * @brief Disable UART2 flow.
 *****************************************************************************************
 */
bool uart2_flow_off(void);
#endif //CFG_ROM

/**
 ****************************************************************************************
 * @brief Finish current UART2 transfers
 *****************************************************************************************
 */
void uart2_finish_transfers(void);

/**
 ****************************************************************************************
 * @brief Starts a data reception.
 *
 * @param[out]   bufptr      Pointer to the RX buffer
 * @param[in]    size        Size of the expected reception
 * @param[in]    callback    Pointer to the function called back when transfer finished
 *****************************************************************************************
 */
void uart2_read(uint8_t *bufptr, uint32_t size, rwip_eif_callback, void *dummy);

/**
 ****************************************************************************************
 * @brief Starts a data transmission.
 *
 * @param[in]    bufptr Pointer to the TX buffer
 * @param[in]    size   Size of the transmission
 * @param[in]    callback    Pointer to the function called back when transfer finished
 *****************************************************************************************
 */
void uart2_write(uint8_t *bufptr, uint32_t size, rwip_eif_callback, void *dummy);

#if defined(CFG_ROM)
/**
 ****************************************************************************************
 * @brief Poll UART2 on reception and transmission.
 *
 * This function is used to poll UART2 for reception and transmission.
 * It is used when IRQ are not used to detect incoming bytes.
 *****************************************************************************************
 */
void uart2_poll(void);
#endif //CFG_ROM

/**
 ****************************************************************************************
 * @brief Serves the data transfer interrupt requests.
 *
 * It clears the requests and executes the appropriate callback function.
 *****************************************************************************************
 */
void uart2_isr(void);

void uart2_putc_noint(uint8_t c);


/// @} UART2
#endif /* _UART2_H_ */
