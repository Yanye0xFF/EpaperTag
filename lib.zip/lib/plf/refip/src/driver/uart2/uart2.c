#include <stddef.h>
#include "uart2.h"
#include "reg_uart.h"
#include "plf.h"
#include "rwip.h"
#include "arch.h"
#include "system.h"

#define UART_CLK        14745600
#define UART_FIFO_TRIGGER (UART_FIFO_RX_TRIGGER|UART_FIFO_TX_TRIGGER)

/*
 * STRUCT DEFINITIONS
 *****************************************************************************************
 */
/* TX and RX channel class holding data used for asynchronous read and write data
 * transactions
 */
/// UART2 TX RX Channel
struct uart2_txrxchannel
{
    /// call back function pointer
    rwip_eif_callback callback;
};

/// UART2 environment structure
struct uart2_env_tag
{
    /// rx channel
    struct uart2_txrxchannel rx;
    uint32_t rxsize;
    uint8_t *rxbufptr;
    /// error detect
    uint8_t errordetect;
    /// external wakeup
    bool ext_wakeup;
};

/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
/// uart2 environment structure
static struct uart2_env_tag uart2_env;

/*
****************************************************************************************
*                  #define ARM_BAUD_460800                 460800    10
*                  #define ARM_BAUD_230400                 230400    9
*                  #define ARM_BAUD_115200                 115200    8
*                  #define ARM_BAUD_57600                  57600     7
*                  #define ARM_BAUD_38400                  38400     6
*                  #define ARM_BAUD_19200                  19200     5
*                  #define ARM_BAUD_14400                  14400     4
*                  #define ARM_BAUD_9600                   9600      3
*                  #define ARM_BAUD_4800                   4800      2
*                  #define ARM_BAUD_2400                   2400      1
*                  #define ARM_BAUD_1200                   1200      0
*
*
****************************************************************************************
*/
const uint16_t uart2_baud_map[12] =
{
    12,24,48,96,144,192,384,576,1152,2304,4608,9216
};

volatile struct uart_reg_t * const uart2_reg = (volatile struct uart_reg_t *)UART2_BASE;

int uart2_get_baud_divisor(uint8_t baudrate)
{
    int Tmp32;

    Tmp32 = uart2_baud_map[baudrate]*200;

    return (UART_CLK/(16*Tmp32));
}

void uart2_reset_register(void)
{
    volatile uint32_t misc_data;

    REG_PL_WR(&(uart2_reg->u2.ier),0);
    REG_PL_WR(&(uart2_reg->u3.fcr),0x06);
    REG_PL_WR(&(uart2_reg->lcr),0);

    misc_data = REG_PL_RD(&(uart2_reg->lsr));
    misc_data = REG_PL_RD(&(uart2_reg->mcr));
}

void uart2_flush_rxfifo_noint(void)
{
    volatile uint8_t data;

    while (uart2_reg->lsr & 0x01)    //UART_RX_FIFO_AVAILABLE
    {
        data = uart2_reg->u1.data;
    }
}

void uart2_init(uint8_t bandrate)
{
    int uart_baud_divisor;

    /* wait for tx fifo is empty */
    while(!(uart2_reg->lsr & 0x40));

    uart2_reset_register();

    uart_baud_divisor = uart2_get_baud_divisor(bandrate);

    while(!(uart2_reg->lsr & 0x40));

    /* baud rate */
    uart2_reg->lcr.divisor_access = 1;
    uart2_reg->u1.dll.data = uart_baud_divisor & 0xff;
    uart2_reg->u2.dlm.data = (uart_baud_divisor>>8) & 0xff;
    uart2_reg->lcr.divisor_access = 0;

    /*word len*/
    uart2_reg->lcr.word_len = 3;
    uart2_reg->lcr.parity_enable = 0;
    uart2_reg->lcr.even_enable = 0;
    uart2_reg->lcr.stop = 0;

    /*fifo*/
    uart2_reg->u3.fcr.data = UART_FIFO_TRIGGER | FCR_FIFO_ENABLE;

    /*auto flow control*/
    uart2_reg->mcr.afe = 0;

    uart2_flush_rxfifo_noint();

    /*enable recv and line status interrupt*/
    uart2_reg->u2.ier.erdi = 1;
    uart2_reg->u2.ier.erlsi = 1;
}

void uart2_flow_on(void)
{
}

bool uart2_flow_off(void)
{
    return true;
}

void uart2_finish_transfers(void)
{
    /* wait for tx fifo is empty */
    while(!(uart2_reg->lsr & 0x40));
}

void uart2_read(uint8_t *bufptr, uint32_t size, rwip_eif_callback callback, void *dummy)
{
    ASSERT_ERR(uart2_env.rxbufptr == NULL);
    ASSERT_ERR(uart2_env.rxsize == 0);
    ASSERT_ERR(uart2_env.rx.callback == NULL);

    uart2_env.rx.callback = callback;
    uart2_env.rxbufptr = bufptr;
    uart2_env.rxsize = size;

    NVIC_EnableIRQ(UART1_IRQn);
}

void uart2_write(uint8_t *bufptr, uint32_t size, rwip_eif_callback callback, void *dummy)
{
    uint32_t count;

    while (1)
    {
        uart2_finish_transfers();

        count = UART_FIFO_SIZE;

        while (count--&&size!=0)
        {
            uart2_reg->u1.data = *bufptr++;
            size--;
        }

        if (size==0)
        {
            break;
        }
    }

    if(callback)
    {
        callback(dummy, RWIP_EIF_STATUS_OK);
    }
}

void uart2_putc_noint(uint8_t c)
{
    while (!(uart2_reg->lsr & 0x40));
    uart2_reg->u1.data = c;
}

void uart2_isr(void)
{
    uint8_t int_id;
    uint8_t c;
    rwip_eif_callback callback;

    int_id = uart2_reg->u3.iir.int_id;

    if(int_id == 0x04 || int_id == 0x0c )   /* Receiver data available or Character time-out indication */
    {
        ASSERT_ERR(uart2_env.rxbufptr != NULL);
        ASSERT_ERR(uart2_env.rxsize != 0);
        ASSERT_ERR(uart2_env.rx.callback != NULL);
        while(uart2_reg->lsr & 0x01)
        {
            c = uart2_reg->u1.data;
            printf("%02x, ", c);
            *uart2_env.rxbufptr++ = c;
            uart2_env.rxsize--;
            if((uart2_env.rxsize == 0)
               &&(uart2_env.rx.callback))
            {
                NVIC_DisableIRQ(UART1_IRQn);
                callback = uart2_env.rx.callback;
                uart2_env.rx.callback = NULL;
                uart2_env.rxbufptr = NULL;
                callback(NULL, RWIP_EIF_STATUS_OK);
                break;
            }
        }
    }
}


