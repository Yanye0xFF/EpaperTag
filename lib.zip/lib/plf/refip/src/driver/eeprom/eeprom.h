#ifndef _EEPROM_H_
#define _EEPROM_H_

#include <stdint.h>
#include "iic.h"

#define SMART_MODE          10
#define STANDARD_MODE       20

uint8_t eeprom_check_connection(enum iic_channel_t channel);
uint8_t eeprom_mem_detect(enum iic_channel_t channel);

extern uint8_t (*eeprom_read_block)(enum iic_channel_t channel, uint16_t, uint16_t, uint8_t *);
extern uint8_t (*eeprom_write_block)(enum iic_channel_t channel, uint16_t, uint16_t, uint8_t *);

#endif
