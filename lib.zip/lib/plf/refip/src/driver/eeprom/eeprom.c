#include <stdint.h>
#include "co_utils.h"
#include "co_bt.h"
#include "iic.h"
#include "eeprom.h"

#define DEV_ADDR            0xa0
#define RETRY_TIMES         10

uint8_t eeprom_read_block_small(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *pdata);
uint8_t eeprom_write_block_small(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *buf);

uint8_t (*eeprom_read_block)(enum iic_channel_t channel, uint16_t size, uint16_t addr, uint8_t *buf) = eeprom_read_block_small;
uint8_t (*eeprom_write_block)(enum iic_channel_t channel, uint16_t size, uint16_t addr, uint8_t *buf) = eeprom_write_block_small;

uint8_t eeprom_read_block_large(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *pdata)
{
    if((pdata == NULL) || (size == 0))
    {
        return false;
    }

    iic_read_bytes_large(channel, DEV_ADDR, addr, pdata, size);

    return true;
}

uint8_t eeprom_write_block_large(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *buf)
{
    uint16_t i, count;
    uint16_t left;

    if((buf == NULL) || (size == 0))
    {
        return false;
    }

    left = 16 - addr%16;

    if(size <= left)
    {
        iic_write_bytes_large(channel, DEV_ADDR, addr, buf, size);
        return true;
    }

    iic_write_bytes_large(channel, DEV_ADDR, addr, buf, left);

    buf  += left;
    addr += left;
    size -= left;

    count = size>>4;
    left = size%16;

    for(i = 0; i < count; i++)
    {
        iic_write_bytes_large(channel, DEV_ADDR, addr+(i<<4), buf+(i<<4), 16);
        //co_delay_25us(400);
    }

    if (left != 0)
    {
        iic_write_bytes_large(channel, DEV_ADDR, addr+(count<<4), buf+(count<<4), left);
        //co_delay_25us(400);
    }

    return true;
}

uint8_t eeprom_read_block_small(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *pdata)
{
    uint8_t ret = true;

    if((pdata == NULL) || (size == 0))
    {
        return false;
    }

    iic_read_bytes_small(channel, DEV_ADDR, addr, pdata, size);

    return ret;

}
uint8_t eeprom_write_block_small(enum iic_channel_t channel,uint16_t size,uint16_t addr, uint8_t *buf)
{
    uint16_t i, count;
    uint8_t ret = true;
    uint16_t left;

    if((buf == NULL) || (size == 0))
    {
        return false;
    }

    left = 16 - addr%16;

    if(size <= left)
    {
        iic_write_bytes_small(channel, DEV_ADDR, addr, buf, size);
        return ret;
    }

    iic_write_bytes_small(channel, DEV_ADDR, addr, buf, left);
    //co_delay_25us(400);


    buf  += left;
    addr += left;
    size -= left;

    count = size>>4;
    left = size%16;

    for(i = 0; i < count; i++)
    {
        iic_write_bytes_small(channel, DEV_ADDR, addr+(i<<4), buf+(i<<4), 16);
        //co_delay_25us(400);
    }

    if (left != 0)
    {
        iic_write_bytes_small(channel, DEV_ADDR, addr+(count<<4), buf+(count<<4), left);
        //co_delay_25us(400);
    }

    return ret;
}

uint8_t eeprom_version_detect(enum iic_channel_t channel)
{
    uint8_t ret_data = 0xff;

    iic_write_byte_large(channel, DEV_ADDR, 0x0000, 0x03);
    iic_write_byte_large(channel, DEV_ADDR, 0x0001, 0x01);
    iic_write_byte_large(channel, DEV_ADDR, 0x0002, 0x04);

    iic_read_byte_large(channel, DEV_ADDR, 0x0000, &ret_data);
    switch(ret_data)
    {
        case 0x03:
            return SMART_MODE;
        case 0x04:
            return STANDARD_MODE;
        default:
            return false;
    }
}

uint8_t test_size(enum iic_channel_t channel,int n)
{
    uint8_t temp_1;
    uint8_t temp_2;

    switch (n)
    {
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
            iic_read_byte_large(channel, DEV_ADDR, 0000, &temp_1);
            iic_read_byte_large(channel, DEV_ADDR, n, &temp_2);

            if (temp_2 == temp_1)
            {
                iic_write_byte_large(channel, DEV_ADDR,0000, (temp_1 + 1));
                iic_read_byte_large(channel, DEV_ADDR, n, &temp_2);

                if (temp_2 == (temp_1 + 1))
                {
                    iic_write_byte_large(channel, DEV_ADDR,0, temp_1);
                    return true;
                }
            }
            break;
    }
    return false;
}

uint8_t eeprom_mem_detect(enum iic_channel_t channel)
{
    int n;
    uint8_t version;

    version = eeprom_version_detect(channel);

    if (version == false)
    {
        return false;
    }

    if (version == SMART_MODE)
    {
        n = 4096;
        while (n <= 65536)
        {
            if (test_size(channel,n) == true)
            {
                break;
            }
            else
            {
                n *= 2;
            }
        }

        eeprom_read_block = eeprom_read_block_large;
        eeprom_write_block = eeprom_write_block_large;
    }

    return true;
}

uint8_t eeprom_check_connection(enum iic_channel_t channel)
{
    uint8_t i;

    for(i=0; i<RETRY_TIMES; i++)
    {
        iic_write_start(channel, DEV_ADDR);      /* write addr */

        co_delay_25us(40);

        if(!iic_status_get_noack(channel))
            break;

        co_delay_25us(200);
    }

    if(i == RETRY_TIMES)
    {
        return false;
    }
    else
    {
        return eeprom_mem_detect(channel);
    }
}

