#include "system.h"
#include "watchdog.h"
//#include "pskeys.h"
#include "uart.h"

#ifndef KEEP_WDT_CODE
#define KEEP_WDT_CODE    (1)
#endif

/**************************************
*    Watchdog register default value
**************************************/
static uint8_t wdt_enable_flag = true;
#define WDT_S(x)   ( (x)*system_get_pclk()*(48000000/system_get_pclk()) / ( BIT(wd_regs->timer_ctrl.divisor_l+1) * BIT( (*(uint32_t *)0x50000004 & 0x3) ) ) )

wd_regs_t *const wd_regs = (wd_regs_t*)0x50010000;

__attribute__((section("front_stack"))) void wdt_init(uint8_t action_type,uint8_t delay_s)
{
#if (KEEP_WDT_CODE)
    wd_regs->rst_pulse_len.len = 3;
    wd_regs->timer_ctrl.divisor_h = 0x00; // take no function
    wd_regs->timer_ctrl.divisor_l = 0x0e; // divide by 2^(0xd+1) = 16384,   Fix it,0xB~0xE
    wd_regs->timer_ctrl.action = action_type;
    wd_regs->timer_load.load_value = WDT_S(delay_s);//0x05b8;// timer counter, timeout=load_value*16384/sysclk s
// 1tick = 16384/48 = 341.3us
#endif
}

__attribute__((section("front_stack"))) void wdt_feed(void)
{
    wd_regs->timer_counter_rst.rst_value =  0x76;// load the value to restart counter
}

__attribute__((section("front_stack"))) void wdt_start(void)
{
    wd_regs->timer_ctrl.enable = 1;
    wdt_feed();
}

__attribute__((section("front_stack"))) void wdt_stop(void)
{
    wd_regs->timer_ctrl.enable = 0;
    wdt_feed();
}


#include "user_timer.h"
#include "apb2spi.h"

static os_timer_t wdt_timer;
void wdt_timer_func(void *arg)
{
    wdt_feed();
    //fputc('F',NULL);
}

void wdt_driver_ini(void)
{
#if (KEEP_WDT_CODE)
    if(wdt_enable_flag)
    {
        wdt_stop();
        //printf("sys_pclk:%d\r\n",system_get_pclk());
        wdt_init( INT_ACTION,9 );
        wdt_start();
        NVIC_SetPriority(WDT_IRQn, 0);
        NVIC_EnableIRQ(WDT_IRQn);
    }
#endif
}

void os_wdt_begins(void)
{
#if (KEEP_WDT_CODE)
    os_timer_setfn(&wdt_timer,wdt_timer_func,NULL);
    if(wdt_enable_flag)
    {
        wdt_driver_ini();
        os_timer_arm(&wdt_timer,5000,1);
    }
#endif
}

void os_wdt_start(void)
{
#if (KEEP_WDT_CODE)
    // printf("wdt_start\r\n");
    //os_timer_disarm(&wdt_timer);
    wdt_init( INT_ACTION,9 );
    wdt_start();
    os_timer_arm(&wdt_timer,5000,1);
    wdt_enable_flag = true;
#endif
}
void os_wdt_stop(void)
{
#if (KEEP_WDT_CODE)
    //printf("wdt_stop\r\n");
    wdt_enable_flag = false;
    os_timer_disarm(&wdt_timer);
    wdt_stop();
#endif
}

void wdt_isr_ram(unsigned int* hardfault_args)
{
#if (KEEP_WDT_CODE)
    if(wd_regs->timer_inpt_sta.status)
    {
        printf("wdt_rest:%d\r\n\r\n",wd_regs->timer_inpt_sta.status);
        printf("PC    = 0x%.8X\r\n",hardfault_args[6]);
        printf("LR    = 0x%.8X\r\n",hardfault_args[5]);
        printf("R0    = 0x%.8X\r\n",hardfault_args[0]);
        printf("R1    = 0x%.8X\r\n",hardfault_args[1]);
        printf("R2    = 0x%.8X\r\n",hardfault_args[2]);
        printf("R3    = 0x%.8X\r\n",hardfault_args[3]);
        printf("R12   = 0x%.8X\r\n",hardfault_args[4]);
        //printf("PSR   = 0x%.8X\r\n",hardfault_args[7]);
        uart_finish_transfers();
        apb2spi_write(0x4F,0xC5,APB2SPI_TYPE_OOL);
        __set_FAULTMASK(1);
        NVIC_SystemReset();
    }
#endif
}


#if (WDT_TEST_ENABLE)
void test_wdt(void)
{
    wdt_init( RESET_ACTION,5 );
    wdt_start();
}

void test_wdt1(void)
{
    wdt_init( INT_ACTION,5 );
    wdt_start();
    NVIC_SetPriority(WDT_IRQn, 2);
    NVIC_EnableIRQ(WDT_IRQn);
}

#endif



