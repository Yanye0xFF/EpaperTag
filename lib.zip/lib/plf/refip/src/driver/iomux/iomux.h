#ifndef _IOMUX_H
#define _IOMUX_H

#include "system.h"

//#define SET_PORTA_FUNC(n, func)     REG_PL_WR(SYSTEM_PORTA_MUX, REG_PL_RD(SYSTEM_PORTA_MUX) & (~(0xF<<(n*4))) | (PORTA##n##_FUNC_##func << (n*4)))
//#define SET_PORTB_FUNC(n, func)     REG_PL_WR(SYSTEM_PORTB_MUX, REG_PL_RD(SYSTEM_PORTB_MUX) & (~(0xF<<(n*4))) | (PORTB##n##_FUNC_##func << (n*4)))
//#define SET_PORTC_FUNC(n, func)     REG_PL_WR(SYSTEM_PORTC_MUX, REG_PL_RD(SYSTEM_PORTC_MUX) & (~(0xF<<(n*4))) | (PORTC##n##_FUNC_##func << (n*4)))

#endif  //_IOMUX_H

