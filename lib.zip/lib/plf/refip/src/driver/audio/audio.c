#include "system.h"
#include "apb2spi.h"
#include "audio.h"

void audio_codec_hw_set_freq(uint32_t nValue)
{
    uint8_t reg;
    switch (nValue)
    {
        case 44100:
            reg = AUDIO_CODEC_44100;
            break;
        case 8000:
            reg = AUDIO_CODEC_8000;
            break;
        case 48000:
            reg = AUDIO_CODEC_48000;
            break;
        case 32000:
            reg = AUDIO_CODEC_32000;
            break;
        case 22050:
            reg = AUDIO_CODEC_22050;
            break;
        case 16000:
            reg = AUDIO_CODEC_16000;
            break;
    }

    codec_write(0x0b,0x00);
    codec_write(0x0a,reg+0x81);
    codec_write(0x0b,0x03);
}

void audio_codec_enable_adc(void)
{
    codec_write(0x15, codec_read(0x15) & 0xE0); //unmute mic
    codec_write(0x12, codec_read(0x12) & 0xBB);
}

void audio_codec_disable_adc(void)
{
    codec_write(0x15, codec_read(0x15) | 0x1F);
    codec_write(0x12, codec_read(0x12) | 0x44);
}

void audio_codec_enable_dac(void)
{
    codec_write(0x14, 0x00);
    codec_write(0x12, codec_read(0x12)&0xC4);
    codec_write(0x13, 0x00);
}

void audio_codec_disable_dac(void)
{
    codec_write(0x14, 0xff);
    codec_write(0x12, codec_read(0x12)|0x3b);
    codec_write(0x13, 0xff);
}

void speaker_mic_codec_init(void)
{
    codec_write(0x15, 0x2F);    //pd all
    codec_write(0x0c, 0x1f);    //mic bias control
    codec_write(0x0d, 0x03);    //LMIX RMIX PD
    codec_write(0x0e, 0x3c);    //ADC control
    codec_write(0x0f, 0xd1);
    codec_write(0x10, 0x20);
    codec_write(0x11, 0x20);
    codec_write(0x12, 0x00);    //pd
    codec_write(0x13, 0x00);    //mute
    codec_write(0x14, 0x00);    //pd
    codec_write(0x16, 0x00);
    codec_write(0x17, 0x07);
    codec_write(0x18, 0x08);            // BIT(3)|BIT(2)
    codec_write(0x1a, 0x00);
    codec_write(0x00, 0x15);
    codec_write(0x25, 0x00);
    codec_write(0x19, 0xa7);    //gain
    codec_write(0x09, 0x02);    //SLAVE_I2S

    codec_write(0x1d, 0x45);
    codec_write(0x24, 0x00);
    codec_write(0x0b, 0x03);    //set freq to 16000
    audio_codec_hw_set_freq(8000);
}

void audio_codec_init(uint32_t sample_rate)
{
    codec_write(0x15, 0x7F);    //pd all
    codec_write(0x0c, 0x1f);    //mic bias control
    codec_write(0x0d, 0x03);    //LMIX RMIX PD
    codec_write(0x0e, 0x3c);    //ADC control
    codec_write(0x0f, 0xd1);
    codec_write(0x10, 0x20);
    codec_write(0x11, 0x20);
    codec_write(0x12, 0xff);    //pd
    codec_write(0x13, 0xff);    //mute
    codec_write(0x14, 0xff);    //pd
    codec_write(0x15, 0x3f);    //pd all
    codec_write(0x16, 0x00);
    codec_write(0x17, 0x07);
    //0x18 = 0x08--> one line;  =0x0C ---> diff, less noise

#if defined(MIC_DIFF)
    codec_write(0x18, 0x0C);            // BIT(3)|BIT(2)
#else
    codec_write(0x18, 0x08);            // BIT(3)|BIT(2)
#endif

    codec_write(0x1a, 0x00);
    codec_write(0x00, 0x15);
    codec_write(0x25, 0x02);
    codec_write(0x19, 0x77);    //gain,0xB7

    codec_write(0x09, 0x02);    //SLAVE_I2S
    codec_write(0x40, 0x81);    //CODEC_STEREO

#ifdef CFG_DEC_ADPCM_MS
    audio_codec_hw_set_freq(8000);
#else
    audio_codec_hw_set_freq(sample_rate);
#endif
}
//0~0x3F
static uint8_t current_speaker_vol_value = 0x10;
void audio_speaker_codec_init(void)
{
    codec_write(0x10, current_speaker_vol_value);
    codec_write(0x11, current_speaker_vol_value);   //0x25
    codec_write(0x12, 0xc4);
    codec_write(0x13, 0x00);
    codec_write(0x14, 0x00);
    codec_write(0x15, 0x0f);
    codec_write(0x16, 0x00);
    codec_write(0x17, 0x07);
    codec_write(0x18, 0x0c);
    codec_write(0x19, 0xb7);
    codec_write(0x1a, 0x00);
    codec_write(0x1d, 0x45);
    codec_write(0x00, 0x15);
    codec_write(0x24, 0x00);
    codec_write(0x25, 0x00);
    codec_write(0x19, 0xb7);    //gain,
    codec_write(0x09, 0x02);    //SLAVE_I2S
    codec_write(0x40, 0x83);    //CODEC_STEREO
    codec_write(0x0b, 0x03);    //set freq to 16000
#ifdef CFG_DEC_ADPCM_MS
    audio_codec_hw_set_freq(8000);
#else
    audio_codec_hw_set_freq(16000);
#endif
}

void set_speaker_vol(uint8_t val)
{
    if(val > 0x7f)
        val = 0x0;
    if( val <= 0x3f )
    {
        current_speaker_vol_value = val;
        codec_write(0x10, current_speaker_vol_value);
        codec_write(0x11, current_speaker_vol_value);   //0x25
    }
}

uint8_t get_speaker_vol(void)
{
    return current_speaker_vol_value;
}


