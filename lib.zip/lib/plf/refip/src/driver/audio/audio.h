#ifndef _AUDIO_H
#define _AUDIO_H

#include <stdint.h>

#define AUDIO_CODEC_48000     0x00
#define AUDIO_CODEC_44100     0x22
#define AUDIO_CODEC_32000     0x18
#define AUDIO_CODEC_22050     0x36
#define AUDIO_CODEC_16000     0x14
#define AUDIO_CODEC_8000      0x0c

void audio_codec_hw_set_freq(uint32_t nValue);
void audio_codec_enable_adc(void);
void audio_codec_disable_adc(void);
void audio_codec_enable_dac(void);
void audio_codec_disable_dac(void);
void audio_codec_init(uint32_t sample_rate);    //for mic
void audio_speaker_codec_init(void);    //for speaker
void speaker_mic_codec_init(void);  //for mic&speaker



void set_speaker_vol(uint8_t val);
uint8_t get_speaker_vol(void);

#endif  //_AUDIO_H

