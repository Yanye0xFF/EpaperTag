#include <stdint.h>

#include "system.h"
#include "apb2spi.h"
#include "lvd.h"
#include "user_sys.h"

static bool charging_flag = false;

/*
vol value:
0000=1.05,0001=1.1,0010=1.15,0011=1.2,
0100=1.25,0101=1.3,0110=1.35,0111=1.4,
1000=1.45,1001=1.5,1010=1.55,1011=1.6,
1100=1.65,1101=1.7,1110=1.75,1111=1.8

actual trigger voltage is 2* vol
*/

void lvd_set_voltage(uint8_t vol)
{
    ool_write(0x11, (ool_read(0x11) & ~(0xf)) | (vol & 0xf) );
}

void lvd_enable(void)
{
    ool_write(0x3a, ool_read(0x3a) | BIT(2) );          //irq_en
}
void lvd_disable(void)
{
    ool_write(0x3a, ool_read(0x3a) & ~(BIT(2)) );          //irq_en
}
void lvd_clr_irq(void)
{
    ool_write(0x3b, ool_read(0x3b) | BIT(2) );          //clr irq_en
}
void __attribute__((weak)) low_voltage_callback_func(void)
{
    ;
}
void __attribute__((weak)) charge_plug_out_func(void)
{
    ;
}
void __attribute__((weak)) charge_plug_in_func(void)
{
    ;
}
void __attribute__((weak)) charge_over_func(void)
{
    ;
}


static bool low_voltage_detected = false;
void pmu_isr_ram(void)
{
    uint8_t pmu_irq_st = ool_read(0x70);
    //printf("pmu_i:%x\r\n",pmu_irq_st);

    if( pmu_irq_st & BIT(2))
    {
        lvd_clr_irq();
        lvd_disable();
        printf("low_vol detected\r\n");
        low_voltage_detected = true;
        low_voltage_callback_func();
    }

//charging isr
    if( pmu_irq_st & BIT(6))   //full
    {
        ool_write(0x3b, ool_read(0x3b) | BIT(0) );
        charge_over_func();
        //appm_sleep_stop();
    }
    else if( pmu_irq_st & BIT(0))    //plug out
    {
        ool_write(0x3b, ool_read(0x3b) | BIT(6) );
        charging_flag = false;
        charge_plug_out_func();
    }
    else if( pmu_irq_st & BIT(4))    //plug in
    {
        ool_write(0x3b, ool_read(0x3b) | BIT(4) );
        charging_flag = true;
        charge_plug_in_func();
    }
    else
    {
        // printf("pmu_i:%x\r\n",pmu_irq_st);
    }
}
void set_charging_status(uint8_t flag)
{
    charging_flag = flag;
}
void check_charging(void)
{
    if( (ool_read(0x71) & BIT(1) )!= 0)
        charging_flag = true;
}
bool is_charging(void)
{
    return charging_flag;
}

bool is_low_vol_detected(void)
{
    return low_voltage_detected;
}

#if LVD_TEST_ENABLE
void test_lvd(void)
{
    printf("lvd_go\r\n");
    lvd_set_voltage(0xf);
    lvd_enable();
    NVIC_SetPriority(PMU_IRQn, 2);
    NVIC_EnableIRQ(PMU_IRQn);
}

void test_charging(void)
{
    ool_write(0x3a, ool_read(0x3a) | BIT(4) );
    lvd_enable();
    NVIC_SetPriority(PMU_IRQn, 2);
    NVIC_EnableIRQ(PMU_IRQn);
}

#endif

