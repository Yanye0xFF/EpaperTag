#ifndef _LVD_H
#define _LVD_H
#include <stdint.h>

/*
vol value:
0000=1.05,0001=1.1,0010=1.15,0011=1.2,
0100=1.25,0101=1.3,0110=1.35,0111=1.4,
1000=1.45,1001=1.5,1010=1.55,1011=1.6,
1100=1.65,1101=1.7,1110=1.75,1111=1.8

actual trigger voltage is 2* vol
*/
void lvd_set_voltage(uint8_t vol);
void lvd_enable(void);
void lvd_disable(void);
bool is_low_vol_detected(void);
/*weak function*/
void low_voltage_callback_func(void);
void charge_plug_out_func(void);
void charge_plug_in_func(void);
void charge_over_func(void);
/*weak function*/
void set_charging_status(uint8_t flag);



#ifndef LVD_TEST_ENABLE
#define LVD_TEST_ENABLE 0
#endif
#if LVD_TEST_ENABLE
void test_lvd(void);
#endif
bool is_charging(void);
void check_charging(void);
void lvd_clr_irq(void);


#endif  //


