#ifndef _IIC_H
#define _IIC_H

#include <stdint.h>           // standard integer functions

#define IIC_BIT_POWERON     0
#define IIC_BIT_POWEROFF    1
#define IIC_BIT_LVD         3
#define IIC_BIT_TALKON      4
#define IIC_BIT_TALKOFF     5

#define IIC_TRAN_START      0x100
#define IIC_TRAN_STOP       0x200

struct iic_data_t
{
    uint32_t data:8;
    uint32_t start:1;
    uint32_t stop:1;
    uint32_t unused:22;
};

struct iic_status_t
{
    uint32_t trans_done:1;
    uint32_t arb_fail:1;
    uint32_t no_ack:1;
    uint32_t data_req_mst:1;
    uint32_t data_req_slv:1;
    uint32_t bus_atv:1;
    uint32_t sts_scl:1;
    uint32_t sts_sda:1;
    uint32_t rec_full:1;
    uint32_t rec_emp:1;
    uint32_t trans_ful:1;
    uint32_t trans_emp:1;
    uint32_t slv_trans_ful:1;
    uint32_t slv_trans_emp:1;
    uint32_t unused:18;
};

struct iic_control_t
{
    uint32_t trans_done_ie:1;
    uint32_t arb_fail_ie:1;
    uint32_t no_ack_ie:1;
    uint32_t req_mst_ie:1;
    uint32_t req_slv_ie:1;
    uint32_t rec_full_ie:1;
    uint32_t rec_noemp_ie:1;
    uint32_t trans_noful_ie:1;
    uint32_t soft_reset:1;
    uint32_t seven_bit:1;
    uint32_t slv_noful_ie:1;
    uint32_t unused:21;
};

struct iic_clkdiv_t
{
    uint32_t clk_div:9;
    uint32_t unused:23;
};

struct iic_address_t
{
    uint32_t slv_addr:10;
    uint32_t unused:22;
};

struct iic_rxlevel_t
{
    uint32_t rx_level:3;
    uint32_t unused:29;
};

struct iic_txlevel_t
{
    uint32_t tx_level:3;
    uint32_t unused:29;
};

struct iic_rxbytecnt_t
{
    uint32_t rx_byte_cnt:16;
    uint32_t unused:16;
};

struct iic_txbytecnt_t
{
    uint32_t tx_byte_cnt:16;
    uint32_t unused:16;
};

struct iic_slavedata_t
{
    uint32_t slave_data:8;
    uint32_t unused:24;
};

struct iic_reg_t
{
    uint32_t data;
    struct iic_status_t status;
    struct iic_control_t control;
    struct iic_clkdiv_t clkdiv;
    struct iic_address_t address;
    struct iic_rxlevel_t rxlevel;
    struct iic_txlevel_t txlevel;
    struct iic_rxbytecnt_t rx_bytecnt;
    struct iic_txbytecnt_t tx_bytecnt;
    struct iic_slavedata_t slavedata;
};

#define IIC0_REG_BASE           ((volatile struct iic_reg_t *)I2C0_BASE)
#define IIC1_REG_BASE           ((volatile struct iic_reg_t *)I2C1_BASE)

enum iic_channel_t
{
    IIC_CHANNEL_0,
    IIC_CHANNEL_1,
    IIC_CHANNEL_MAX,
};
extern uint8_t iic_slv_addr;

void iic_init(enum iic_channel_t channel, uint16_t speed);
void iic_read_byte_large(enum iic_channel_t channel,uint8_t slave_addr, uint16_t addr, uint8_t *pdata);
void iic_write_bytes_large(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size);
void iic_write_byte_large(enum iic_channel_t channel,uint8_t slave_addr,uint16_t addr, uint8_t data);
void iic_read_bytes_large(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t *pdata, uint16_t size);
void iic_read_byte_small(enum iic_channel_t channel,uint8_t slave_addr, uint16_t addr, uint8_t *pdata);
void iic_write_bytes_small(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size);
void iic_write_byte_small(enum iic_channel_t channel,uint8_t slave_addr,uint16_t addr, uint8_t data);
void iic_read_bytes_small(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t *pdata, uint16_t size);

bool iic_read_byte_small_no_block(enum iic_channel_t channel, uint8_t slave_addr,uint16_t addr,uint8_t * pdata);
bool iic_read_bytes_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size);
bool iic_write_byte_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t data);
bool iic_write_bytes_small_no_block(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size);


void iic_write_start(enum iic_channel_t channel, uint8_t slave_addr);
uint8_t iic_status_get_noack(enum iic_channel_t channel);

void iic_init_x(enum iic_channel_t channel, uint16_t speed);


#endif

