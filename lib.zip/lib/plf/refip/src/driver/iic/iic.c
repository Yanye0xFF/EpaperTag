#include "iic.h"
#include "system.h"

#define DIVIDE_PART_SIZE        5
#define PAGE_COUNTER            3
uint8_t iic_slv_addr = 0x68;
uint16_t iic_speed[IIC_CHANNEL_MAX];
//speed, unit: 1K
void iic_init(enum iic_channel_t channel, uint16_t speed)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    iic_reg->clkdiv.clk_div = (system_get_pclk()*1000000/(speed*1000)-10)/2;
    iic_reg->control.soft_reset = 1;
    iic_reg->control.seven_bit = 1; /*seven bits address*/
    iic_reg->address.slv_addr = iic_slv_addr;

    iic_speed[channel] = speed;
}

void iic_read_byte_small(enum iic_channel_t channel, uint8_t slave_addr,uint16_t addr,uint8_t * pdata)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr|IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);

    *pdata = iic_reg->data&0xff;

    while(iic_reg->status.bus_atv == 1);
}
void iic_read_bytes_small(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size)
{
    uint16_t i, j=0;
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    for (i = 0; i < (size-1); i++)
    {
        iic_reg->data = 0x00;
        while(iic_reg->status.rec_emp != 1)
        {
            buf[j++] = iic_reg->data;
        }
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);

    for(; j<size; j++)
    {
        buf[j] = iic_reg->data;
    }

    while(iic_reg->status.bus_atv == 1);
}

void iic_write_byte_small(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t data)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = addr & 0xff;
    iic_reg->data = data | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
}

void iic_write_bytes_small(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size)
{
    uint16_t i;
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = addr & 0xff;

    for(i=0; i<(size-1); i++)
    {
        iic_reg->data = buf[i++];
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = buf[i] | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
}

void iic_read_byte_large(enum iic_channel_t channel, uint8_t slave_addr,uint16_t addr,uint8_t * pdata)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = (addr>>8) & 0xff;
    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);

    *pdata = iic_reg->data&0xff;

    while(iic_reg->status.bus_atv == 1);

}

//read 5 bytes each time
void iic_read_bytes_large(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t *pdata, uint16_t size)
{
    uint16_t i, j=0;
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    //while(iic_reg->staus.trans_emp != 1);

    iic_reg->data = (addr>>8) & 0xff;
    iic_reg->data = addr & 0xff;
    iic_reg->data = slave_addr | 0x01 | IIC_TRAN_START;
    for (i = 0; i < (size-1); i++)
    {
        iic_reg->data = 0x00;
        while(iic_reg->status.rec_emp != 1)
        {
            pdata[j++] = iic_reg->data;
        }
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);

    for(; j<size; j++)
    {
        pdata[j] = iic_reg->data;
    }

    while(iic_reg->status.bus_atv == 1);
}

void iic_write_byte_large(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t data)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = (addr>>8) & 0xff;
    iic_reg->data = addr & 0xff;
    iic_reg->data = data | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
}

void iic_write_bytes_large(enum iic_channel_t channel, uint8_t slave_addr, uint16_t addr, uint8_t * buf,uint16_t size)
{
    uint16_t i;
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    do
    {
        iic_reg->data = slave_addr | IIC_TRAN_START;
        while(iic_reg->status.trans_emp != 1);
        co_delay_25us(40*10/iic_speed[channel] + 1);
    }
    while(iic_reg->status.no_ack == 1);

    iic_reg->data = (addr>>8) & 0xff;
    iic_reg->data = addr & 0xff;

    for(i=0; i<(size-1); i++)
    {
        iic_reg->data = buf[i];
        while(iic_reg->status.trans_emp != 1);
    }

    iic_reg->data = buf[size-1] | IIC_TRAN_STOP;

    while(iic_reg->status.bus_atv == 1);
}

void iic_write_start(enum iic_channel_t channel, uint8_t slave_addr)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    iic_reg->data = slave_addr | IIC_TRAN_START;
}

uint8_t iic_status_get_noack(enum iic_channel_t channel)
{
    volatile struct iic_reg_t *iic_reg;

    if(channel == IIC_CHANNEL_0)
    {
        iic_reg = IIC0_REG_BASE;
    }
    else
    {
        iic_reg = IIC1_REG_BASE;
    }

    return iic_reg->status.no_ack;
}

