#include <stdint.h>
#include "exti.h"
#include "plf.h"
#include "system.h"
#include "gpio.h"

struct ext_int_t *const ext_int_reg = (struct ext_int_t *)EXTI_BASE;

void ext_int_enable(uint8_t num)
{
    ext_int_reg->ext_int_en |= (1<<num);
}

void ext_int_disable(uint8_t num)
{
    ext_int_reg->ext_int_en &= (~(1<<num));
}

uint32_t ext_int_get_status(void)
{
    return ext_int_reg->ext_int_status;
}

void ext_int_clear_status(uint32_t bit)
{
    ext_int_reg->ext_int_status = bit;
}

void ext_int_set_type(uint8_t num, enum ext_int_type_t type)
{
    uint8_t offset, index;
    uint32_t value;

    index = num / 16;
    offset = (num % 16) << 1;

    value = ext_int_reg->ext_int_type[index];
    value &= (~(EXT_INT_TYPE_MSK<<offset));
    value |= (type << offset);
    ext_int_reg->ext_int_type[index] = value;
}

void ext_int_set_control(uint8_t num, uint32_t clk, uint8_t counter)
{
    uint32_t pclk;

    pclk = system_get_pclk();

    ext_int_reg->ext_int_control[num] = (((pclk/clk-1)<<4) | counter);
}

extern void button_int_isr(uint32_t button);
void ext_int_isr(void)
{
    uint32_t status;

    status = ext_int_get_status();
    ext_int_clear_status(status);

    button_int_isr(status);
}

