#ifndef _EXTI_H
#define _EXTI_H

#include <stdint.h>
#include "plf.h"

#define EXT_INT_TYPE_MSK        0x03
#define EXT_INT_TYPE_LEN        2
enum ext_int_type_t
{
    EXT_INT_TYPE_LOW,
    EXT_INT_TYPE_HIGH,
    EXT_INT_TYPE_POS,
    EXT_INT_TYPE_NEG,
};

struct ext_int_cnt_t
{
    uint32_t counter:4;
    uint32_t prescaler:16;
    uint32_t reserved:12;
};

struct ext_int_t
{
    uint32_t ext_int_en;
    uint32_t ext_int_status;
    uint32_t ext_int_type[2];
    uint32_t ext_int_control[32];
    uint32_t ext_int_raw_status;
};

void ext_int_enable(uint8_t num);
void ext_int_disable(uint8_t num);
uint32_t ext_int_get_status(void);
void ext_int_clear_status(uint32_t status);
void ext_int_set_type(uint8_t num, enum ext_int_type_t type);
void ext_int_set_control(uint8_t num, uint32_t clk, uint8_t counter);

#endif //_EXTI_H

