#ifndef _LED_H
#define _LED_H

#include <stdint.h>

//work with led_cfg(),val:interval.   also it is the patten loop interval
//low power clk:  244hz. 1period = 12ms
//clk_div shall be less than 64
void led_set_div(uint8_t clk_div);
//led:  1~6
//interval: interval between one patten loop and next patten loop. actual: is interval + 1
//patten: bit23: led status lvl, interval is clk_div
//inv: invterl between two loop lvl setting.  0, high lvl.   1 low lvl,
//inv = 0  has bugs/
void led_cfg(uint8_t led, uint8_t interval, uint32_t patten, uint8_t inv);
// led:  bit(1~6)
void led_run(uint8_t led);
void led_stop(uint8_t led);

//For 8016, value 0 -> pin_high;    For 8010, value 1 -> pin_high;
void led_set_pin_value(uint8_t led, uint8_t value);


#endif  //_LED_H

