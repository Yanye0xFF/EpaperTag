#include <stdint.h>
#include "reg_access.h"
#include "system.h"
#include "ssp.h"
#include "plf.h"


struct ssp_cr0
{

    uint32_t dss:4;  /* data size select : = DATASIZE - 1*/

    uint32_t frf:2;  /* frame format */

    uint32_t spo:1;  /* sclk polarity */
    uint32_t sph:1;  /* sclk phase */
    uint32_t scr:8;  /* serial clock rate */
    uint32_t unused:16;
};

struct ssp_cr1
{

    uint32_t rie:1;  /* receive fifo interrupt enable */
    uint32_t tie:1;  /* transmit fifo interrupt enable */
    uint32_t rorie:1;  /* receive fifo overrun interrupt enable */

    uint32_t lbm:1;  /* loop back mode */
    uint32_t sse:1;  /* synchronous serial port enable*/

    uint32_t ms:1;  /* master/slave*/
    uint32_t sod:1;  /* slave ouput enable*/
    uint32_t unused:25;
};

struct ssp_dr
{

    uint32_t data:16;

    uint32_t unused:16;
};

struct ssp_sr
{

    uint32_t tfe:1;  /* transmit fifo empty */
    uint32_t tnf:1;  /* transmit fifo not full */
    uint32_t rne:1;  /* receive fifo not empty */
    uint32_t rff:1;  /* receive fifo full */
    uint32_t bsy:1;  /* ssp busy flag */

    uint32_t unused:27;
};

struct ssp_cpsr
{

    uint32_t cpsdvsr:8;  /* clock prescale divisor 2-254 */

    uint32_t unused:24;
};


struct ssp_iir
{
    uint32_t ris:1;  /* ssp receive fifo service request interrupt status */
    uint32_t tis:1;  /* ssp transmit fifo service request interrupt status */
    uint32_t roris:1;  /* ssp receive fifo overrun interrupt status */

    uint32_t unused:29;
};

struct ssp
{
    struct ssp_cr0 ctrl0;
    struct ssp_cr1 ctrl1; /*is also error clear register*/
    struct ssp_dr data;
    struct ssp_sr status;
    struct ssp_cpsr clock_prescale;
    struct ssp_iir int_indent;
};


volatile struct ssp * const ssp0 = (volatile struct ssp *)(0x50040000);
volatile struct ssp * const ssp1 = (volatile struct ssp *)(0x50048000);

#define SSP_IS_BUSY(x)   ((x)->status.bsy == 1)
#define CLEAR_INTTERUPTS(x)    (*(int *)(&((x)->int_indent)) = 0xff)


void ssp_clear_rx_fifo_x(volatile struct ssp * const ssp)
{
    volatile uint16_t data;

    while(ssp->status.rne == 1)
        data = ssp->data.data;
}

void ssp_init_x(volatile struct ssp * const ssp,uint32_t bit_rate, uint8_t clk_prescale, uint8_t data_size,uint8_t mode)
{
    volatile uint16_t data;

    *(int*)(&(ssp->ctrl0)) = 0; /*reset all*/
    *(int*)(&(ssp->ctrl1)) = 0; /*reset all*/

    CLEAR_INTTERUPTS(ssp);

    ssp->ctrl1.sse = 0;

    /* data size */
    ssp->ctrl0.dss = data_size - 1;

#define MOTO_SPI_FRAME      0x00
#define TI_SS_FRAME         0x01
#define NATIONAL_M_FRAME    0x02

    /* frame type */
    ssp->ctrl0.frf = MOTO_SPI_FRAME;
    ssp->ctrl0.spo = 1;
    ssp->ctrl0.sph = 1;

    ssp->clock_prescale.cpsdvsr = clk_prescale;       //2;
    /* clock rate */
    ssp->ctrl0.scr = system_get_pclk()/(ssp->clock_prescale.cpsdvsr * bit_rate) - 1; //0;

    if(mode == 0x1)
        ssp->ctrl1.sod = 0x0;   //slave mode, slave can send
    else
        ssp->ctrl1.sod = 0x1;   //master mode, slave can't send
    ssp->ctrl1.ms = mode;
    //ssp->ctrl1.lbm = 0;
    //ssp->ctrl1.rorie = 0;
    //ssp->ctrl1.tie = 0;
    //ssp->ctrl1.rie = 0;

    /* enable ssp */
    ssp->ctrl1.sse = 1;

    //clear rx fifo
    while(ssp->status.rne == 1)
        data = ssp->data.data;

    //wait tx fifo to empty
    while(ssp->status.tfe == 0)
        ;

}

void ssp_reconfigure_x(volatile struct ssp * const ssp, uint32_t bit_rate, uint8_t clk_prescale, uint8_t data_size)
{
    ssp->ctrl1.sse = 0;
    ssp->ctrl0.dss = data_size - 1;
    ssp->clock_prescale.cpsdvsr = clk_prescale;
    ssp->ctrl0.scr = system_get_pclk()/(ssp->clock_prescale.cpsdvsr * bit_rate) - 1;
    ssp->ctrl1.sse = 1;
}

void ssp_put_byte_x(volatile struct ssp * const ssp, const uint16_t c)
{
    while(ssp->status.tnf == 0);
    ssp->data.data= c;
}


void ssp_put_byte_y(volatile struct ssp * const ssp, uint8_t *buf)
{
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;

    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
    ssp->data.data= *buf++;
}



void ssp_wait_byte_send_out_x(volatile struct ssp * const ssp)
{
    while(ssp->status.tfe == 0);
}

void ssp_put_data_x(volatile struct ssp * const ssp, const uint8_t *d, uint32_t size)
{
    while(size--)
    {
        while(ssp->status.tnf == 0);
        ssp->data.data = *d++;
    }
}

void ssp_get_data_x(volatile struct ssp * const ssp, unsigned char* buf, uint32_t size)
{
    unsigned char c;

    while(size > 0)
    {
        //while((ssp->status.rne == 0) && (ssp->status.tnf == 1));
        while(ssp->status.rne == 0);
        if(ssp->status.rne != 0)    // receive fifo is not empty
        {
            c = ssp->data.data;
            *buf++ = c;
            size --;
        }
    }

    return;
}

void ssp_enable_x(volatile struct ssp * const ssp)
{
    ssp->ctrl1.sse = 1;
}

void ssp_disable_x(volatile struct ssp * const ssp)
{
    ssp->ctrl1.sse = 0;
}

void ssp_wait_busy_bit_x(volatile struct ssp * const ssp)
{
    while(ssp->status.bsy == 1);
}

void ssp_write_then_read_x(volatile struct ssp * const ssp, unsigned char* tx_buffer, unsigned int n_tx
                           , unsigned char* rx_buffer, unsigned int n_rx)
{
    uint8_t i;
    volatile uint8_t temp;
    ssp_disable_x(ssp);

    for(i=0; i<n_tx; i++)
    {
        ssp->data.data = *tx_buffer++;
    }

    for(i=0; i<n_rx; i++)
    {
        ssp->data.data = 0xFF;
    }
    ssp_enable_x(ssp);
    ssp_wait_busy_bit_x(ssp);

    i=0;

    while(((REG_PL_RD((uint32_t)ssp + 0x0c)&0x4) != 0))     // receive fifo is not empty
    {
        if(i<n_tx)
        {
            temp = ssp->data.data;
        }
        else
        {
            *rx_buffer++ = ssp->data.data;
        }
        i++;
    }
}

//for any byte read only
void ssp_write_then_read_y1(volatile struct ssp * const ssp, unsigned char* tx_buffer, unsigned int n_tx
                            , unsigned char* rx_buffer, unsigned int n_rx)
{
    uint8_t i;
    volatile uint8_t temp;
    ssp_disable_x(ssp);

    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;

    for(i=0; i<n_rx; i++)
    {
        ssp->data.data = 0xFF;
    }
    ssp_enable_x(ssp);
    ssp_wait_busy_bit_x(ssp);

    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;
    for(i=0; i<n_rx; i++)
        *rx_buffer++ = ssp->data.data;
}
//for 27 byte read only
void ssp_write_then_read_y2(volatile struct ssp * const ssp, unsigned char* tx_buffer, unsigned int n_tx
                            , unsigned char* rx_buffer, unsigned int n_rx)
{
    volatile uint8_t temp;
    ssp_disable_x(ssp);

    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = *tx_buffer++;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;

    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;

    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;

    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;

    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;

    ssp->data.data = 0xFF;
    ssp->data.data = 0xFF;
    ssp_enable_x(ssp);

    ssp_wait_busy_bit_x(ssp);

    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;
    temp = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

    *rx_buffer++ = ssp->data.data;
    *rx_buffer++ = ssp->data.data;

}



#if (SPI_TEST_ENABLE)
#include "ssp.h"

void test_spi(volatile struct ssp * const ssp)
{
    if(ssp == ssp1)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_SSP1_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_SSP1_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_SSP1_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_SSP1_DIN);
    }
    else
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_SSP0_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_SSP0_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_SSP0_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_SSP0_DIN);
    }

    ssp_init_x(ssp,150000, 2, 8,0);
    uint32_t id;

    //ssp_reconfigure_x(ssp,150000, 2, 8);
    ssp_clear_rx_fifo_x(ssp);

    ssp_put_byte_x(ssp,0x9F);          //FLASH_READ_IDENTIFICATION
    ssp_put_byte_x(ssp,0xFF);
    ssp_put_byte_x(ssp,0xFF);
    ssp_put_byte_x(ssp,0xFF);

    ssp_enable_x(ssp);
    ssp_get_data_x(ssp,(uint8_t *)&id, 1);
    ssp_get_data_x(ssp,(uint8_t *)&id, 3);
    ssp_wait_busy_bit_x(ssp);
    ssp_disable_x(ssp);

    id = (id & 0xFFFFFF);
    printf("flash id:%x\r\n",id);

    if(ssp == ssp0)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_0, PORTA0_FUNC_A0);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_1, PORTA1_FUNC_A1);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_2, PORTA2_FUNC_A2);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_3, PORTA3_FUNC_A3);

        //set B0~B3  spi.
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_0, PORTB0_FUNC_SSP0_CLK);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_1, PORTB1_FUNC_SSP0_CSN);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_2, PORTB2_FUNC_SSP0_DOUT);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_3, PORTB3_FUNC_SSP0_DIN);
    }
}


void test_spi_master(volatile struct ssp * const ssp)
{
    if(ssp == ssp1)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_4, PORTA4_FUNC_SSP1_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_5, PORTA5_FUNC_SSP1_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, PORTA6_FUNC_SSP1_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, PORTA7_FUNC_SSP1_DIN);
    }
    else
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_4, PORTA4_FUNC_SSP0_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_5, PORTA5_FUNC_SSP0_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, PORTA6_FUNC_SSP0_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, PORTA7_FUNC_SSP0_DIN);
    }

    ssp_init_x(ssp,150000, 2, 8,0);
    uint32_t id;

    //ssp_reconfigure_x(ssp,150000, 2, 8);
    ssp_clear_rx_fifo_x(ssp);
    ssp_enable_x(ssp);
    while(1)
    {
        ssp_put_byte_x(ssp,0x99);          //FLASH_READ_IDENTIFICATION
        ssp_put_byte_x(ssp,0x88);
        ssp_put_byte_x(ssp,0x77);
        ssp_put_byte_x(ssp,0x66);
        printf("master wait\r\n");
        id =0;
        ssp_get_data_x(ssp,(uint8_t *)&id, 4);
        ssp_wait_busy_bit_x(ssp);
        co_delay_100us(10000);
        printf("s:%x,",id);
        id = 0;
    }
    ssp_disable_x(ssp);
    if(ssp == ssp0)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_4, PORTA4_FUNC_A4);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_5, PORTA5_FUNC_A5);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, PORTA6_FUNC_A6);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, PORTA7_FUNC_A7);

        //set B0~B3  spi.
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_0, PORTB0_FUNC_SSP0_CLK);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_1, PORTB1_FUNC_SSP0_CSN);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_2, PORTB2_FUNC_SSP0_DOUT);
        system_set_port_mux(GPIO_PORT_B, GPIO_BIT_3, PORTB3_FUNC_SSP0_DIN);
    }
}

void test_spi_slave(volatile struct ssp * const ssp)
{
    if(ssp == ssp1)
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_4, PORTA4_FUNC_SSP1_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_5, PORTA5_FUNC_SSP1_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, PORTA6_FUNC_SSP1_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, PORTA7_FUNC_SSP1_DIN);
    }
    else
    {
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_4, PORTA4_FUNC_SSP0_CLK);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_5, PORTA5_FUNC_SSP0_CSN);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_6, PORTA6_FUNC_SSP0_DOUT);
        system_set_port_mux(GPIO_PORT_A, GPIO_BIT_7, PORTA7_FUNC_SSP0_DIN);
    }

    ssp_init_x(ssp,150000, 2, 8,1);
    uint32_t id = 0x33333333;

    //ssp_reconfigure_x(ssp,150000, 2, 8);
    ssp_clear_rx_fifo_x(ssp);
    static uint32_t idx =0;
    ssp_enable_x(ssp);
    while(1)
    {
        printf("slave wait\r\n");
        id = 0;
        ssp_get_data_x(ssp,(uint8_t *)&id, 4);
        printf("id:%x\r\n",id);
        idx++;
        if(id != 0x66778899)
            ssp_clear_rx_fifo_x(ssp);
        else
        {
            ssp_put_byte_x(ssp,(idx)&0xff);
            ssp_put_byte_x(ssp,(idx>>8)&0xff);
            ssp_put_byte_x(ssp,(idx>>16)&0xff);
            ssp_put_byte_x(ssp,(idx>>24)&0xff);          //FLASH_READ_IDENTIFICATION
            // ssp->data.data= 0x78;
        }
    }
    ssp_disable_x(ssp);

}

#endif


