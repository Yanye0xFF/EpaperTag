#ifndef _SSP_H
#define _SSP_H

#include <stdint.h>      // standard integer definition


#define SSP_FIFO_SIZE       32

extern volatile struct ssp * const ssp0;
extern volatile struct ssp * const ssp1;

/**NEW API for ssp0,ssp1**/
void ssp_clear_rx_fifo_x(volatile struct ssp * const ssp);
void ssp_init_x(volatile struct ssp * const ssp,uint32_t bit_rate, uint8_t clk_prescale, uint8_t data_size,uint8_t mode);
void ssp_reconfigure_x(volatile struct ssp * const ssp, uint32_t bit_rate, uint8_t clk_prescale, uint8_t data_size);
void ssp_put_byte_x(volatile struct ssp * const ssp, const uint16_t c);
void ssp_wait_byte_send_out_x(volatile struct ssp * const ssp);
void ssp_put_byte_y(volatile struct ssp * const ssp, uint8_t *buf);


void ssp_put_data_x(volatile struct ssp * const ssp, const uint8_t *d, uint32_t size);
void ssp_get_data_x(volatile struct ssp * const ssp, uint8_t* buf, uint32_t size);
void ssp_enable_x(volatile struct ssp * const ssp);
void ssp_disable_x(volatile struct ssp * const ssp);
void ssp_wait_busy_bit_x(volatile struct ssp * const ssp);
void ssp_write_then_read_x(volatile struct ssp * const ssp, uint8_t* tx_buffer, uint32_t n_tx
                           , uint8_t* rx_buffer, uint32_t n_rx);

void ssp_write_then_read_y1(volatile struct ssp * const ssp, uint8_t* tx_buffer, uint32_t n_tx
                            , uint8_t* rx_buffer, uint32_t n_rx);
void ssp_write_then_read_y2(volatile struct ssp * const ssp, uint8_t* tx_buffer, uint32_t n_tx
                            , uint8_t* rx_buffer, uint32_t n_rx);

/**OLD API, implication is in ROM code, only for ssp0**/
void ssp_init(void);
void ssp_reconfigure(uint32_t bit_rate, uint8_t clk_rate, uint8_t data_size);
void ssp_put_byte(const unsigned short c);
void ssp_put_data(const unsigned char *d, int size);
void ssp_get_data(unsigned char* buf, int size);
void ssp_enable(void);
void ssp_disable(void);
void ssp_wait_busy_bit(void);
void ssp_clear_rx_fifo(void);
void ssp_write_then_read (unsigned char* tx_buffer, unsigned int n_tx, unsigned char* rx_buffer, unsigned int n_rx);






#ifndef SPI_TEST_ENABLE
#define SPI_TEST_ENABLE 0
#endif

#if SPI_TEST_ENABLE
void test_spi(volatile struct ssp * const ssp);
void test_spi_master(volatile struct ssp * const ssp);
void test_spi_slave(volatile struct ssp * const ssp);
#endif


#endif

