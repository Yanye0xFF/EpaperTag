#include <stdint.h>
#include "i2s.h"
#include "reg_access.h"
#include "system.h"
#include "decoder_task.h"


#define I2S_PCLK        system_get_pclk()
#define I2S_BCLK        12000000

/*I2SBCLKDIV = Fpclk/ (Fbclk * 2) - 1, if I2S_PCLK==I2S_BCLK, then I2S_BCLK_DIV=0xffff*/
#define I2S_BCLK_DIV  ((I2S_PCLK/(I2S_BCLK*2))-1)


void i2s_fifo_flush(void)
{
    uint8_t i;

    for(i=0; i<64; i++)
    {
        REG_PL_WR(I2S_REG_DATA,0x0);
    }
}

void i2s_init(uint8_t type, uint32_t sample_rate)
{
    uint32_t frm_div;

    frm_div = (I2S_BCLK/(sample_rate*2))-1;

    REG_PL_WR(I2S_REG_BCLK_DIV, I2S_BCLK_DIV);

    REG_PL_WR(I2S_REG_FRM_DIV, frm_div);

    REG_PL_WR(I2S_REG_INTEN, 0);
    if( type & (I2S_SPEAKER) )
        REG_PL_WR(I2S_REG_INTEN, REG_PL_RD(I2S_REG_INTEN)|(I2S_INTEN_TXFFHEMPTY + I2S_INTEN_TXFFEMPTY) );

    if( type & (I2S_MIC) )
        REG_PL_WR(I2S_REG_INTEN, REG_PL_RD(I2S_REG_INTEN)|I2S_INTEN_RXFFHFULL );

#ifdef FT_ATE_TEST_ENABLE
    REG_PL_WR(I2S_REG_INTEN, I2S_INTEN_TXFFHEMPTY + I2S_INTEN_TXFFEMPTY + I2S_INTEN_RXFFHFULL);
#endif

    REG_PL_WR(I2S_REG_CTRL,
              I2S_CTRL_DLYEN |    \
              I2S_CTRL_FMT |      \
              I2S_CTRL_DMATXEN |  \
              I2S_CTRL_DMARXEN |  \
              I2S_CTRL_MODE_MASTER);
}

void i2s_stop(void)
{
    REG_PL_WR(I2S_REG_CTRL,
              I2S_CTRL_FMT |      \
              I2S_CTRL_DMATXEN |  \
              I2S_CTRL_DMARXEN |  \
              I2S_CTRL_MODE_MASTER);

    //REG_PL_WR(I2S_REG_CTRL, REG_PL_RD(I2S_REG_CTRL) & ~I2S_CTRL_EN );
}
void i2s_start(void)
{
    //i2s_fifo_flush();
    REG_PL_WR(I2S_REG_CTRL, I2S_CTRL_EN |       \
              I2S_CTRL_INTEN |    \
              I2S_CTRL_DLYEN |    \
              I2S_CTRL_FMT |      \
              I2S_CTRL_DMATXEN |  \
              I2S_CTRL_DMARXEN |  \
              I2S_CTRL_MODE_MASTER);
}

#ifndef FT_ATE_TEST_ENABLE
#include "user_c_lib.h"
#include "ke_mem.h"
#include "encoder_task.h"
//static uint16_t change_line = 0;

void i2s_isr(void)
{
    uint32_t last = REG_PL_RD(I2S_REG_STATUS) & REG_PL_RD(I2S_REG_INTEN);
    // printf("last:%X ",last);

#if (defined(CFG_SBC)||defined(CFG_ADPCM))
    if(last & I2S_STATUS_RXFFHFULL)
    {
        uint8_t i = 0;
#if 0
        for(i=0; i<32; i++)
        {
            data[i] = REG_PL_RD(I2S_REG_DATA);
            fputc(hex4bit_to_ascii_char( (data[i]>>12)&0x0F), 0);
            fputc(hex4bit_to_ascii_char( (data[i]>>8)&0x0F ), 0);
            fputc(hex4bit_to_ascii_char( (data[i]>>4)&0x0F ), 0);
            fputc(hex4bit_to_ascii_char( (data[i]>>0)&0x0F ), 0);
            // printf("%04X ",data[i]);

        }
        change_line += 64;
        if(change_line>=512)
        {
            change_line = 0;
            fputc('\n', 0);
            // i2s_stop();
        }
#else
        uint16_t data[32];
        for(i=0; i<32; i++)
            data[i] = REG_PL_RD(I2S_REG_DATA);
        encode_store_pcm_data(data, 32);
#endif
    }
#endif

#ifdef CFG_DEC_SBC
    if(last & I2S_STATUS_TXFFHEMPTY)
    {
        uint8_t i;
#define I2S_FIFO_DEPTH      64
        struct co_list_hdr *element;
        struct decoder_pcm_t *pcm;
        uint32_t *tx_data;

        if(co_list_is_empty(&decoder_env.pcm_buffer_list))
        {
            //fputc('F', 0);
            for(i=0; i<(I2S_FIFO_DEPTH/2); i++)
            {
                REG_PL_WR(I2S_REG_DATA, 0x0000);
            }
        }
        else
        {
            element = decoder_env.pcm_buffer_list.first;

            pcm = (struct decoder_pcm_t *)element;
            tx_data = (uint32_t *)&pcm->pcm_data[pcm->pcm_offset];
            last = pcm->pcm_size - pcm->pcm_offset;
            if(last > (I2S_FIFO_DEPTH/2))
            {
                //fputc('X', 0);
                //printf("X:%x,",*tx_data);
                for (i=0; i<(I2S_FIFO_DEPTH/2); i++)
                {
                    REG_PL_WR(I2S_REG_DATA, *tx_data++);
                }
                pcm->pcm_offset += (I2S_FIFO_DEPTH/2);
            }
            else
            {
                //fputc('Y', 0);
                for (i=0; i<last; i++)
                {
                    REG_PL_WR(I2S_REG_DATA, *tx_data++);
                }
                co_list_pop_front(&decoder_env.pcm_buffer_list);
                ke_free((void *)pcm);
                decoder_env.pcm_buffer_counter--;
                decoder_play_next_frame();

                while(!co_list_is_empty(&decoder_env.pcm_buffer_list))
                {
                    element = decoder_env.pcm_buffer_list.first;

                    pcm = (struct decoder_pcm_t *)element;
                    tx_data = (uint32_t *)&pcm->pcm_data[0];
                    last = pcm->pcm_size - pcm->pcm_offset;
                    if((last + i) > (I2S_FIFO_DEPTH/2))
                    {
                        //fputc('Z', 0);
                        for(; i<(I2S_FIFO_DEPTH/2); i++)
                        {
                            REG_PL_WR(I2S_REG_DATA, *tx_data++);
                        }
                        pcm->pcm_offset = (I2S_FIFO_DEPTH/2) - i;
                        break;
                    }
                    else
                    {
                        // fputc('W', 0);
                        last += i;
                        for(; i<last; i++)
                        {
                            REG_PL_WR(I2S_REG_DATA, *tx_data++);
                        }
                        co_list_pop_front(&decoder_env.pcm_buffer_list);
                        ke_free((void *)pcm);
                        decoder_env.pcm_buffer_counter--;
                        decoder_play_next_frame();
                    }
                }
            }
        }
    }
#endif

#ifdef CFG_DEC_ADPCM_MS
    if(last & I2S_STATUS_TXFFHEMPTY)
    {
        uint8_t i;
#define I2S_FIFO_DEPTH      64
        struct co_list_hdr *element;
        struct decoder_pcm_t *pcm;
        uint16_t *tx_data;
        //uint32_t data_codec,data_temp;

        if(co_list_is_empty(&decoder_env.pcm_buffer_list))
        {
            //fputc('F', 0);
            for(i=0; i<(I2S_FIFO_DEPTH/2); i++)
            {
                REG_PL_WR(I2S_REG_DATA, 0x0000);
                /*
                fputc(hex4bit_to_ascii_char( (0x0000>>12)&0x0F), 0);
                fputc(hex4bit_to_ascii_char( (0x0000>>8)&0x0F ), 0);
                fputc(hex4bit_to_ascii_char( (0x0000>>4)&0x0F ), 0);
                fputc(hex4bit_to_ascii_char( (0x0000>>0)&0x0F ), 0);
                change_line += 2;
                if(change_line>=512)
                {
                    change_line = 0;
                    fputc('\n', 0);
                }
                */
            }
        }
        else
        {
            element = decoder_env.pcm_buffer_list.first;

            pcm = (struct decoder_pcm_t *)element;
            tx_data = (uint16_t *)&pcm->pcm_data[pcm->pcm_offset];
            last = pcm->pcm_size - pcm->pcm_offset;
            if(last > (I2S_FIFO_DEPTH/2))
            {
                //fputc('X', 0);
                //printf("X:%x,",*tx_data);
                for (i=0; i<(I2S_FIFO_DEPTH/2); i++)
                {
                    uint32_t tmp_data = *tx_data++;
                    tmp_data &= 0xFFFF;
                    REG_PL_WR(I2S_REG_DATA, tmp_data);
                    /*
                    fputc(hex4bit_to_ascii_char( (tmp_data>>12)&0x0F), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>8)&0x0F ), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>4)&0x0F ), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>0)&0x0F ), 0);
                    change_line += 2;
                    if(change_line>=512)
                    {
                        change_line = 0;
                        fputc('\n', 0);
                    }
                    */
                }
                pcm->pcm_offset += (I2S_FIFO_DEPTH/2);
            }
            else
            {
                //fputc('Y', 0);
                for (i=0; i<last; i++)
                {
                    uint32_t tmp_data = *tx_data++;
                    tmp_data &= 0xFFFF;
                    REG_PL_WR(I2S_REG_DATA, tmp_data);
                    /*
                    fputc(hex4bit_to_ascii_char( (tmp_data>>12)&0x0F), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>8)&0x0F ), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>4)&0x0F ), 0);
                    fputc(hex4bit_to_ascii_char( (tmp_data>>0)&0x0F ), 0);
                    change_line += 2;
                    if(change_line>=512)
                    {
                        change_line = 0;
                        fputc('\n', 0);
                    }
*/
                }
                co_list_pop_front(&decoder_env.pcm_buffer_list);
                ke_free((void *)pcm);
                decoder_env.pcm_buffer_counter--;
                decoder_play_next_frame();

                while(!co_list_is_empty(&decoder_env.pcm_buffer_list))
                {
                    element = decoder_env.pcm_buffer_list.first;

                    pcm = (struct decoder_pcm_t *)element;
                    tx_data = (uint16_t *)&pcm->pcm_data[0];
                    last = pcm->pcm_size - pcm->pcm_offset;
                    if((last + i) > (I2S_FIFO_DEPTH/2))
                    {
                        pcm->pcm_offset = (I2S_FIFO_DEPTH/2) - i;
                        //fputc('Z', 0);
                        for(; i<(I2S_FIFO_DEPTH/2); i++)
                        {
                            uint32_t tmp_data = *tx_data++;
                            tmp_data &= 0xFFFF;
                            REG_PL_WR(I2S_REG_DATA, tmp_data);
/*
                            fputc(hex4bit_to_ascii_char( (tmp_data>>12)&0x0F), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>8)&0x0F ), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>4)&0x0F ), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>0)&0x0F ), 0);
                            change_line += 2;
                            if(change_line>=512)
                            {
                                change_line = 0;
                                fputc('\n', 0);
                            }
                            */
                        }
                        break;
                    }
                    else
                    {
                        //fputc('W', 0);
                        last += i;
                        for(; i<last; i++)
                        {
                            uint32_t tmp_data = *tx_data++;
                            tmp_data &= 0xFFFF;
                            REG_PL_WR(I2S_REG_DATA, tmp_data);
/*
                            fputc(hex4bit_to_ascii_char( (tmp_data>>12)&0x0F), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>8)&0x0F ), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>4)&0x0F ), 0);
                            fputc(hex4bit_to_ascii_char( (tmp_data>>0)&0x0F ), 0);
                            change_line += 2;
                            if(change_line>=512)
                            {
                                change_line = 0;
                                fputc('\n', 0);
                            }
*/
                        }
                        co_list_pop_front(&decoder_env.pcm_buffer_list);
                        ke_free((void *)pcm);
                        decoder_env.pcm_buffer_counter--;
                        decoder_play_next_frame();
                    }
                }
            }
        }
    }
#endif
}
#endif      //FT_ATE_TEST_ENABLE
