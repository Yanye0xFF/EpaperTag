#ifndef _TIMER_H
#define _TIMER_H

#include <stdint.h>
#include "plf.h"
#include "system.h"


#define TIM0  (0x50020000)
#define TIM1  (0x50020000 + 0x20)

enum tim_run_type
{
    TIM_FREE_RUN = 0,
    TIM_PERIODIC = 1
};

struct timer_lvr
{
    uint32_t load: 16;
    uint32_t unused: 16;
};

struct timer_cvr
{
    uint32_t count: 16;
    uint32_t unused: 16;
};
struct timer_cr
{
    uint32_t reserved1: 2;
    uint32_t pselect: 2;
    uint32_t reserved2: 2;
    uint32_t count_mode: 1;
    uint32_t count_enable: 1;
    uint32_t unused: 24;
};

struct timer_icr
{
    uint32_t data: 16;
    uint32_t unused: 16;
};

struct timer_tr
{
    uint32_t test_mode: 1;
    uint32_t test_clock: 1;
    uint32_t unused: 26;
};

struct timer
{
    struct timer_lvr load_value;
    struct timer_cvr count_value;
    struct timer_cr control;
    struct timer_icr interrupt_clear;
    struct timer_tr test;
};

#define TIMER_COUNT_CLOCK  ((system_get_pclk())>>4)
#define TIMER_10MS_COUNT  (TIMER_COUNT_CLOCK/100)
#define TIMER_1MS_COUNT  (TIMER_COUNT_CLOCK/1000)
#define TIMER_10US_COUNT  (TIMER_1MS_COUNT/100)
#define TIMER_1000MS_COUNT  (TIMER_COUNT_CLOCK/1)


void timer_run ( int timer_addr );
void timer_stop ( int timer_addr );
void timer_reload ( int timer_addr );
void timer_clear_interrupt ( int timer_addr );

uint32_t timer_get_current_value(int timer_addr);
uint32_t timer_get_load_value(int timer_addr);
void timer_init( int timer_addr, int count_us,uint8_t run_mode );



#endif

