#include "timer.h"

struct timer_lvr
{
    uint32_t load: 16;
    uint32_t unused: 16;
};

struct timer_cvr
{
    uint32_t count: 16;
    uint32_t unused: 16;
};
struct timer_cr
{
    uint32_t reserved1: 2;
    uint32_t pselect: 2;
    uint32_t reserved2: 2;
    uint32_t count_mode: 1;
    uint32_t count_enable: 1;
    uint32_t unused: 24;
};

struct timer_icr
{
    uint32_t data: 16;
    uint32_t unused: 16;
};

struct timer_tr
{
    uint32_t test_mode: 1;
    uint32_t test_clock: 1;
    uint32_t unused: 26;
};

struct timer
{
    struct timer_lvr load_value;
    struct timer_cvr count_value;
    struct timer_cr control;
    struct timer_icr interrupt_clear;
    struct timer_tr test;
};

void timer_set_interval ( int timer_addr, int count_ms )
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    timerp->control.count_enable = 0;
    timerp->control.count_mode = 1; /* periodic count */
    timerp->control.pselect = 0x01;  /* pclk / 16 */
    timerp->interrupt_clear.data = 0x01; /* clear interrupt */
    timerp->load_value.load = TIMER_1MS_COUNT * count_ms;
}

/*how many us has passed in this round*/
uint32_t timer_get_uscount ( int timer_addr)
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    uint32_t count;

    count = timerp->load_value.load - timerp->count_value.count;
    return ((count) * 1000) / TIMER_1MS_COUNT;

}

void timer_run ( int timer_addr )
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    timerp->control.count_enable = 1;
}

void timer_stop ( int timer_addr )
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    timerp->control.count_enable = 0;
}

void timer_reload ( int timer_addr )
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    timerp->count_value.count = timerp->load_value.load;
}

void timer_clear_interrupt ( int timer_addr )
{
    volatile struct timer *timerp = (volatile struct timer *)timer_addr;
    timerp->interrupt_clear.data = 0x01;
}

