#include <stdint.h>           // standard integer functions
#include "app.h"
#include "pmu.h"

#include "reg_access.h"
#include "keyscan.h"
#include "intc.h"
#include "apb2spi.h"
#include "system.h"
#include "low_power.h"

#include "user_sys.h"
#include "user_msg_q.h"



#if 0
void keyscan_init_x(struct keyscan_param_t *param)
{
    uint8_t reg_new_value;

    ool_write(PMU_REG_KEY_SCAN_FNC, ool_read(PMU_REG_KEY_SCAN_FNC)&(~PMU_REG_KEY_SCAN_EN));//key scan enable

    low_power_save_keyscan_value(0, 0);
    low_power_save_keyscan_value(1, 0);
    low_power_save_keyscan_value(2, 0);
    low_power_save_keyscan_value(3, 0);
    low_power_save_keyscan_value(4, 0);
    system_regs->key_scan_ctrl.int_en = 1;

    ool_write(PMU_REG_KEY_COL_SEL, param->col_en);
    ool_write(PMU_REG_KEY_ROW_SEL0, param->row_en & 0xFF);
    ool_write(PMU_REG_KEY_ROW_SEL1, (param->row_en >> 8) & 0xFF);
    ool_write(PMU_REG_KEY_ROW_SEL2, (param->row_en >> 16) & 0x0F);

#if 1
    reg_new_value = ((param->col_en << 4) | ((param->row_en >> 16) & 0x0F));
//   printf("0x%02X,",reg_new_value);
    ool_write(PMU_REG_PORTA_SEL, ool_read(PMU_REG_PORTA_SEL) & (~reg_new_value));
    ool_write(PMU_REG_PORTA_OEN, ool_read(PMU_REG_PORTA_OEN) | reg_new_value);
    //used to trigger wake up in sleep mode
    //--ool_write(PMU_REG_PORTA_TRIG_MASK, (param->row_en >> 16) & 0x0F);
#endif

    reg_new_value = (param->col_en & 0xF0);
    //  printf("0x%02X,",reg_new_value);

    ool_write(PMU_REG_PORTB_SEL, ool_read(PMU_REG_PORTB_SEL) & (~reg_new_value));
    ool_write(PMU_REG_PORTB_OEN, ool_read(PMU_REG_PORTB_OEN) | reg_new_value);
    //used to trigger wake up in sleep mode
    //ool_write(PMU_REG_PORTB_TRIG_MASK, ool_read(PMU_REG_PORTB_TRIG_MASK) | reg_new_value);

    reg_new_value = (param->row_en & 0xFF);
//   printf("0x%02X,",reg_new_value);
    ool_write(PMU_REG_PORTC_SEL, ool_read(PMU_REG_PORTC_SEL) & (~reg_new_value));
    ool_write(PMU_REG_PORTC_OEN, ool_read(PMU_REG_PORTC_OEN) | reg_new_value);
    //used to trigger wake up in sleep mode
    //--ool_write(PMU_REG_PORTC_TRIG_MASK, ool_read(PMU_REG_PORTC_TRIG_MASK) | reg_new_value);

    reg_new_value = ((param->row_en >> 8) & 0xFF);
    //  printf("0x%02X,",reg_new_value);
    ool_write(PMU_REG_PORTD_SEL, ool_read(PMU_REG_PORTD_SEL) & (~reg_new_value));
    ool_write(PMU_REG_PORTD_OEN, ool_read(PMU_REG_PORTD_OEN) | reg_new_value);
    //used to trigger wake up in sleep mode
    //--ool_write(PMU_REG_PORTD_TRIG_MASK, ool_read(PMU_REG_PORTD_TRIG_MASK) | reg_new_value);

#if 1

    ool_write(PMU_REG_KEY_SCAN_LEN, ((param->col_scan_dur&0x0F)<<4 | (param->col_scan_interval&0x0F))); //key_len
    ool_write(PMU_REG_KEY_SCAN_FNC, (ool_read(PMU_REG_KEY_SCAN_FNC)&(~PMU_REG_KEY_SCAN_VAL)) | param->scan_cnt);

    ool_write(PMU_REG_KEY_SCAN_FNC, ool_read(PMU_REG_KEY_SCAN_FNC)|PMU_REG_KEY_SCAN_EN);//key scan enable

    //enable keyscan trigger wake up
    //ool_write(PMU_REG_SLEEP_CTRL, ool_read(PMU_REG_SLEEP_CTRL) &(~ PMU_REG_GPIO_WK_EN));
    ool_write(PMU_REG_EXTWKUP, ool_read(PMU_REG_EXTWKUP) & (~PMU_REG_EXTWKUP_DSB));
#endif


}
#endif

#if 0
static const uint8_t key_map_table[5][32] =
{
    {0x21, 0x24, 0x25, 0x26, 0x00, 0x00, 0x00, 0x00, 0x27, 0x46, 0x43, 0x00, 0x00, 0x4e, 0x4d, 0x00, 0x3e, 0x1e, 0x1f, 0x20, 0x22, 0x23, 0x2e, 0x41, 0x00, 0x00, 0x00, 0x00, 0x2d, 0x00, 0x42, 0x4c},
    {0x49, 0x48, 0x4a, 0x00, 0xe0, 0x32, 0x3a, 0x3b, 0x05, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x38, 0xe6, 0x45, 0x51, 0x4f, 0x56, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00, 0x19, 0x10, 0x36, 0x37},
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x28, 0x53, 0x54, 0x55, 0x00, 0x00, 0xe4, 0x1d, 0x1b, 0x06, 0x0a, 0x0b, 0x3f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x34, 0xe2, 0x44, 0x2c, 0x62, 0x63, 0x52, 0x00},
    {0x00, 0x29, 0x00, 0x3d, 0x09, 0x0d, 0x0e, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x33, 0x00, 0x31, 0x59, 0x5a, 0x5b, 0x58, 0xe5, 0x00, 0x04, 0x16, 0x07, 0x15, 0x18, 0x0c, 0x12, 0x00, 0x00, 0x00, 0x00},
    {0x13, 0x47, 0x00, 0x5f, 0x60, 0x61, 0x57, 0x00, 0x48, 0x14, 0x1a, 0x08, 0x17, 0x1c, 0x30, 0x40, 0x00, 0x00, 0x00, 0x00, 0x2f, 0x00, 0x2a, 0x5c, 0x5d, 0x5e, 0x00, 0xe1, 0x00, 0x2b, 0x39, 0x3c},
};
/*
  7      6      5        4       3      2      1        0
  R_GUI  R_ALT  R_SHIFT  R_CTRL  L_GUI  L_ALT  L_SHIFT  L_CTRL
*/
#define KEY_MODIFY_R_GUI        (CO_BIT(7))
#define KEY_MODIFY_R_ALT        (CO_BIT(6))
#define KEY_MODIFY_R_SHIFT      (CO_BIT(5))
#define KEY_MODIFY_R_CTRL       (CO_BIT(4))
#define KEY_MODIFY_L_GUI        (CO_BIT(3))
#define KEY_MODIFY_L_ALT        (CO_BIT(2))
#define KEY_MODIFY_L_SHIFT      (CO_BIT(1))
#define KEY_MODIFY_L_CTRL       (CO_BIT(0))

#define KEY_MAX_SIZE        6

uint8_t key_value_tmp[KEY_MAX_SIZE];
uint8_t key_value_old[2][KEY_MAX_SIZE];
uint8_t key_value_len_old = 0;
uint8_t key_modify_value = 0;

void update_key_value(uint8_t len, uint8_t *data, uint8_t index);
#endif
//static uint8_t first_isr4_flag = 0;
#ifdef KEEP_KEYSCAN_ISR_CODE

void keyscan_0_isr()
{
//    printf("0.");

    uint32_t value;
    //  uint8_t i, j=0;
    value = system_regs->key_scan_value[0];
    low_power_save_keyscan_value(0, value);

    //printf("isr0: %x\r\n", value);

    if(value == 0 && sleep_flag_after_key_release == true)
        appm_sleep_start();
    else
        appm_sleep_stop();

    os_event_t evt;
    evt.event_id = ( (value == 0)?0x101:0x100 );
    evt.param_len = sizeof(value);
    evt.param = &value;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);

}
void keyscan_1_isr()
{
//    printf("1.");

    uint32_t value;
    value = system_regs->key_scan_value[1];
    low_power_save_keyscan_value(1, value);

    if(value == 0 && sleep_flag_after_key_release == true)
        appm_sleep_start();
    else
        appm_sleep_stop();

    //printf("isr1: %x\r\n", value);

    os_event_t evt;
    evt.event_id = ( (value == 0)?0x201:0x200 );
    evt.param_len = sizeof(value);
    evt.param = &value;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);
}
void keyscan_2_isr()
{
//    printf("2.");

    uint32_t value;
//    uint8_t i, j=0;
    value = system_regs->key_scan_value[2];
    low_power_save_keyscan_value(2, value);
    //printf("isr2: %x\r\n", value);

    if(value == 0 && sleep_flag_after_key_release == true)
        appm_sleep_start();
    else
        appm_sleep_stop();

    //printf("2, %d.\r\n", i);
    os_event_t evt;
    evt.event_id = ( (value == 0)?0x301:0x300 );
    evt.param_len = sizeof(value);
    evt.param = &value;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);
}

void keyscan_3_isr()
{
    uint32_t value;
//printf("3."); 
    value = system_regs->key_scan_value[3];
    low_power_save_keyscan_value(3, value);

    if(value == 0 && sleep_flag_after_key_release == true)
        appm_sleep_start();
    else
        appm_sleep_stop();
    //printf("isr3: %x\r\n", value);

    os_event_t evt;
    evt.event_id = ( (value == 0)?0x401:0x400 );
    evt.param_len = sizeof(value);
    evt.param = &value;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);

}


void keyscan_4_isr(void)
{
    uint32_t value;
//printf("4.");
    value = system_regs->key_scan_value[4];
    if(first_isr4_flag == 0)
    {
        first_isr4_flag = 1;
        goto _exit;
    }
    low_power_save_keyscan_value(4, value);
    //printf("isr4: %x\r\n", value);

    if(value == 0 && sleep_flag_after_key_release == true)
        appm_sleep_start();
    else
        appm_sleep_stop();

    //printf("4, %x.\r\n", value);
    os_event_t evt;
    evt.event_id = ( (value == 0)?0x501:0x500 );
    evt.param_len = sizeof(value);
    evt.param = &value;
    evt.src_task_id = TASK_NONE;
    os_msg_post(exint_task_id,&evt);
_exit:
    ;
}
#endif
bool is_key_scan_enable(void)
{
    return ( (ool_read(PMU_REG_KEY_SCAN_FNC) & PMU_REG_KEY_SCAN_EN ) != 0 );
}
void key_scan_disable(void)
{
    ool_write(PMU_REG_KEY_SCAN_FNC, ool_read(PMU_REG_KEY_SCAN_FNC)& (~ PMU_REG_KEY_SCAN_EN));//key scan enable
}



void keyscan_reinit(struct keyscan_param_t *param)
{
    //first_isr4_flag = 0;
    keyscan_init(param);
}

#if KEYSCAN_TEST_ENABLE
//uint8_t key_value_current_cnt;
//uint8_t key_custom_value;
void test_keyscan(void)
{
    struct keyscan_param_t param;
    //key_custom_value = 0;
    //key_value_current_cnt = 0;

    uart_reset_register();

    //uint32_t row_en;    //A3:A0  D7:D0  C7:C0;  not use A2 because it can't wk during sleep
    //uint8_t col_en;     //B7-B4  A7-A4
    param.row_en = 0x0003C; //20 ge
    param.col_en = 0x0F;//4 ge
    param.col_scan_dur = 2;
    param.col_scan_interval = 1;
    param.scan_cnt = 1;
    keyscan_init(&param);
}
#endif



