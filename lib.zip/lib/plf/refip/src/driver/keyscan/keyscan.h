#ifndef _KEYSCAN_H
#define _KEYSCAN_H

#include <stdint.h>
#include "pmu.h"

struct keyscan_param_t
{
    uint32_t row_en;    //A3:A0  D7:D0  C7:C0;  not use A2 because it can't sleep
    uint8_t col_en;     //B7-B4  A7-A4
    uint8_t col_scan_dur;
    uint8_t col_scan_interval;
    uint8_t scan_cnt;   //scan times for each loop
};

void keyscan_init(struct keyscan_param_t *param);
bool is_key_scan_enable(void);
void key_scan_disable(void);
void keyscan_reinit(struct keyscan_param_t *param);



#ifndef KEYSCAN_TEST_ENABLE
#define KEYSCAN_TEST_ENABLE (0)
#endif


#if KEYSCAN_TEST_ENABLE
void test_keyscan(void);
#endif

#endif

