#include "gpio.h"
#include "pwm.h"
#include <stdint.h>           // standard integer functions
#include "system.h"
#include "reg_access.h"

/*
one count means:
@48M 21ns
@24M 41ns
@12M 83ns

high_count:1~0xffffffff
low_count:1~0xffffffff
high_count + low_count <=0xffffffff

*/
void pwm_set_param(uint8_t pwm_num,uint32_t high_count,uint32_t low_count)
{
    REG_PL_WR(PTC0_RPTC_HRC + (pwm_num << 4),low_count);
    REG_PL_WR(PTC0_RPTC_LRC + (pwm_num << 4),high_count + low_count);
}



void pwm_start(uint8_t pwm_num)
{
    REG_PL_WR(PTC0_RPTC_CNTR + (pwm_num << 4),0);
    REG_PL_WR(PTC0_RPTC_CTRL + (pwm_num << 4),0x09);
}
void pwm_stop(uint8_t pwm_num)
{
    REG_PL_WR(PTC0_RPTC_CTRL + (pwm_num << 4),0x00);
}

#if PWM_TEST_ENABLE
void test_pwm(void)
{
    system_set_port_mux(GPIO_PORT_A,GPIO_BIT_2,PORTA2_FUNC_PWM2);
    system_set_port_mux(GPIO_PORT_A,GPIO_BIT_3,PORTA3_FUNC_PWM3);
    pwm_set_param(2,3,200);
    pwm_set_param(3,200,100);
    printf("pwm_go\r\n");

    pwm_start(2);
    pwm_start(3);

    co_delay_100us(10000);
    pwm_stop(2);
    pwm_stop(3);

    co_delay_100us(5000);
    pwm_set_param(2,100,2);
    pwm_set_param(3,10,300);
    pwm_start(2);
    pwm_start(3);
    co_delay_100us(10000);
    pwm_stop(2);
    pwm_stop(3);
}
#endif


