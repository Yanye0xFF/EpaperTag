#ifndef _PWM_H
#define _PWM_H

#include "plf.h"

#define PTC0_RPTC_CNTR      (PWM_BASE+0x00)
#define PTC0_RPTC_HRC       (PWM_BASE+0x04)
#define PTC0_RPTC_LRC       (PWM_BASE+0x08)
#define PTC0_RPTC_CTRL      (PWM_BASE+0x0c)

#define PTC1_RPTC_CNTR      (PWM_BASE+0x10)
#define PTC1_RPTC_HRC       (PWM_BASE+0x14)
#define PTC1_RPTC_LRC       (PWM_BASE+0x18)
#define PTC1_RPTC_CTRL      (PWM_BASE+0x1c)

#define PTC2_RPTC_CNTR      (PWM_BASE+0x20)
#define PTC2_RPTC_HRC       (PWM_BASE+0x24)
#define PTC2_RPTC_LRC       (PWM_BASE+0x28)
#define PTC2_RPTC_CTRL      (PWM_BASE+0x2c)

#define PTC3_RPTC_CNTR      (PWM_BASE+0x30)
#define PTC3_RPTC_HRC       (PWM_BASE+0x34)
#define PTC3_RPTC_LRC       (PWM_BASE+0x38)
#define PTC3_RPTC_CTRL      (PWM_BASE+0x3c)

#define PTC4_RPTC_CNTR      (PWM_BASE+0x40)
#define PTC4_RPTC_HRC       (PWM_BASE+0x44)
#define PTC4_RPTC_LRC       (PWM_BASE+0x48)
#define PTC4_RPTC_CTRL      (PWM_BASE+0x4c)

#define PTC5_RPTC_CNTR      (PWM_BASE+0x50)
#define PTC5_RPTC_HRC       (PWM_BASE+0x54)
#define PTC5_RPTC_LRC       (PWM_BASE+0x58)
#define PTC5_RPTC_CTRL      (PWM_BASE+0x5c)

#define PTC6_RPTC_CNTR      (PWM_BASE+0x60)
#define PTC6_RPTC_HRC       (PWM_BASE+0x64)
#define PTC6_RPTC_LRC       (PWM_BASE+0x68)
#define PTC6_RPTC_CTRL      (PWM_BASE+0x6c)

#define PTC7_RPTC_CNTR      (PWM_BASE+0x70)
#define PTC7_RPTC_HRC       (PWM_BASE+0x74)
#define PTC7_RPTC_LRC       (PWM_BASE+0x78)
#define PTC7_RPTC_CTRL      (PWM_BASE+0x7c)

/*
one count means:
@48M 21ns
@24M 41ns
@12M 83ns

high_count:1~0xffffffff
low_count:1~0xffffffff
high_count + low_count <=0xffffffff

*/
void pwm_set_param(uint8_t pwm_num,uint32_t high_count,uint32_t low_count);
void pwm_start(uint8_t pwm_num);
void pwm_stop(uint8_t pwm_num);


#ifndef PWM_TEST_ENABLE
#define PWM_TEST_ENABLE 0
#endif
#if PWM_TEST_ENABLE
void test_pwm();
#endif


#endif

