#include <stdint.h>
#include "system.h"
#include "plf.h"
#include "apb2spi.h"
#include "pmu.h"
#include "jump_table.h"

struct system_regs_t *const system_regs = (struct system_regs_t *)SYSTEM_REG_BASE;

void FPB_CompSet(uint32_t address, uint8_t map_type, uint8_t index)
{
    FPB->COMP[index] = (FPB->COMP[index] & (~(FPB_COMP_ADDR_Msk|FPB_COMP_REPLACE_Msk)))
                       | (0x1) | (address & FPB_COMP_ADDR_Msk) | (map_type << FPB_COMP_REPLACE_Pos);
}

const uint8_t system_clk_map[] = {48, 24, 12};
static uint8_t system_clk = 12;
uint32_t system_get_pclk(void)
{
    return system_clk*1000000;
}

void system_set_pclk(uint8_t clk)
{
    system_regs->clk_cfg.sys_clk_sel = clk;
    system_clk = system_clk_map[clk];
}

void system_set_port_pull(uint32_t num, uint8_t pull)
{
    if(pull)
    {
        system_regs->port_pull &= (~(1<<num));
    }
    else
    {
        system_regs->port_pull |= (1<<num);
    }
}

void system_set_port_mux(uint8_t port, uint8_t bit, uint8_t func)
{
    uint32_t value;

    value = system_regs->port_mux[port];

    value &= (~(SYSTEM_PORT_MUX_MSK<<(SYSTEM_PORT_MUX_LEN*bit)));
    value |= (func << (SYSTEM_PORT_MUX_LEN*bit));

    system_regs->port_mux[port] = value;
}

void system_calibration_set_cnt(uint16_t counter)
{
    counter--;

    ool_write(PMU_REG_CALI_CNT_0, counter & 0xFF);
    ool_write(PMU_REG_CALI_CNT_1, (counter>>8) & 0xFF);
}

void system_calibration_start(void)
{
    ool_write(PMU_REG_CALI_CTRL, ool_read(PMU_REG_CALI_CTRL) | PMU_REG_CALI_START);
}

void system_calibration_stop(void)
{
    ool_write(PMU_REG_CALI_CTRL, ool_read(PMU_REG_CALI_CTRL) & (~PMU_REG_CALI_START));
}

extern void lld_sleep_mul_64(uint32_t *low, uint32_t *high, uint32_t mul1, uint32_t mul2);
extern uint32_t lld_sleep_div_64(uint32_t low, uint32_t high, uint32_t div);
uint16_t lp_frequency __attribute__((section("front_stack"))) = 32000;
uint32_t system_get_rc_clk(uint8_t redo)
{
    uint32_t result, tmp = 24000000;
    uint32_t tmp_high, tmp_low;

    if(redo == false)
    {
        return lp_frequency;
    }

    result = ool_read(PMU_REG_CALI_RESULT_3);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_2);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_1);
    result <<= 8;

    result |= ool_read(PMU_REG_CALI_RESULT_0);

    //result += 0xbd;

    lld_sleep_mul_64(&tmp_low, &tmp_high, tmp, __jump_table.lp_clk_calib_cnt);
    lp_frequency = lld_sleep_div_64(tmp_low, tmp_high, result);

    lp_frequency >>= 1;

    return lp_frequency;
}

