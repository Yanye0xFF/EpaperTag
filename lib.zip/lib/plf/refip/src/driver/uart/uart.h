/**
 ****************************************************************************************
 *
 * @file uart.h
 *
 * @brief UART Driver for HCI over UART operation.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef _UART_H_
#define _UART_H_

/**
 ****************************************************************************************
 * @defgroup UART UART
 * @ingroup DRIVERS
 * @brief UART driver
 *
 * @{
 *
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdbool.h>          // standard boolean definitions
#include <stdint.h>           // standard integer functions
#include "rwip.h"

/*
 * ENUMERATION DEFINITIONS
 *****************************************************************************************
 */

/*  BAUD_RATE */
#define BAUD_RATE_921600                 11
#define BAUD_RATE_460800                 10
#define BAUD_RATE_230400                 9
#define BAUD_RATE_115200                 8
#define BAUD_RATE_57600                  7
#define BAUD_RATE_38400                  6
#define BAUD_RATE_19200                  5
#define BAUD_RATE_14400                  4
#define BAUD_RATE_9600                   3
#define BAUD_RATE_4800                   2
#define BAUD_RATE_2400                   1
#define BAUD_RATE_1200                   0

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Initializes the UART to default values.
 *****************************************************************************************
 */
void uart_init(uint8_t bandrate);

#ifndef CFG_ROM
/**
 ****************************************************************************************
 * @brief Enable UART flow.
 *****************************************************************************************
 */
void uart_flow_on(void);

/**
 ****************************************************************************************
 * @brief Disable UART flow.
 *****************************************************************************************
 */
bool uart_flow_off(void);
#endif //CFG_ROM

/**
 ****************************************************************************************
 * @brief Finish current UART transfers
 *****************************************************************************************
 */
void uart_finish_transfers(void);

/**
 ****************************************************************************************
 * @brief Starts a data reception.
 *
 * @param[out]   bufptr      Pointer to the RX buffer
 * @param[in]    size        Size of the expected reception
 * @param[in]    callback    Pointer to the function called back when transfer finished
 *****************************************************************************************
 */
void uart_read(uint8_t *bufptr, uint32_t size, rwip_eif_callback, void *dummy);

/**
 ****************************************************************************************
 * @brief Starts a data transmission.
 *
 * @param[in]    bufptr Pointer to the TX buffer
 * @param[in]    size   Size of the transmission
 * @param[in]    callback    Pointer to the function called back when transfer finished
 *****************************************************************************************
 */
void uart_write(uint8_t *bufptr, uint32_t size, rwip_eif_callback, void *dummy);

#if defined(CFG_ROM)
/**
 ****************************************************************************************
 * @brief Poll UART on reception and transmission.
 *
 * This function is used to poll UART for reception and transmission.
 * It is used when IRQ are not used to detect incoming bytes.
 *****************************************************************************************
 */
void uart_poll(void);
#endif //CFG_ROM

/**
 ****************************************************************************************
 * @brief Serves the data transfer interrupt requests.
 *
 * It clears the requests and executes the appropriate callback function.
 *****************************************************************************************
 */
void uart_isr(void);
void uart_reset_register(void);

void uart_putc_noint(uint8_t c);
void uart_put_data_noint(const uint8_t *d, int size);
void uart_get_data_noint(uint8_t *buf, int size);
int uart_get_data_nodelay_noint(uint8_t *buf, int size);

/// @} UART
#endif /* _UART_H_ */
