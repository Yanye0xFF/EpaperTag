#ifndef _PMU_H
#define _PMU_H

#include "co_math.h"
#include "system.h"

#define PMU_REG_ANA_CLK_EN          0x09

#define PMU_REG_STM                 0x1d
#define PMU_REG_STM_FIRST_PO        0x03

#define PMU_REG_SLEEP_CTRL          0x36
#define PMU_REG_STANDBY_EN          (CO_BIT(0))
#define PMU_REG_SHUTDOWN_EN         (CO_BIT(1))
#define PMU_REG_SHUTDOWN_MODE1_EN   (CO_BIT(2))   //0: shutdown gpio without power, 1: shutdown gpio with power
#define PMU_REG_GPIO_WK_EN          (CO_BIT(3))
#define PMU_REG_OOL_CLK_DIV_MSK     0xF0

#define PMU_REG_TONKEY              0x39
#define PMU_REG_TONKEY_MSK          0x07
#define PMU_REG_TONKEY_POS          0
enum PMU_TONKEY_T
{
    PMU_TONKEY_3S,
    PMU_TONKEY_4S,
    PMU_TONKEY_5S,
    PMU_TONKEY_0_1S,
    PMU_TONKEY_1S,
    PMU_TONKEY_1_5S,
    PMU_TONKEY_2S,
    PMU_TONKEY_0_0_8S,
};

#define PMU_REG_ISR_ENABLE          0x3a
#define PMU_REG_ISR_BAT_EN          (CO_BIT(0))
#define PMU_REG_ISR_POWER_OFF_EN    (CO_BIT(1))
#define PMU_REG_ISR_LVD_EN          (CO_BIT(2))
#define PMU_REG_ISR_OTP_EN          (CO_BIT(3))     //�¶ȹ���
#define PMU_REG_ISR_ACOK_EN         (CO_BIT(4))
#define PMU_REG_ISR_CALI_EN         (CO_BIT(5))
#define PMU_REG_ISR_ACOFF_EN        (CO_BIT(6))
#define PMU_REG_HW_PO_EN            (CO_BIT(7))     //�Ƿ�ʹ��onkeyӲ�������ػ��жϣ���������������ػ��Ļ���һλ�������

#define PMU_REG_ISR_CLR             0x3b
#define PMU_REG_CLR_BAT             (CO_BIT(0))
#define PMU_REG_CLR_POWER_OFF       (CO_BIT(1))
#define PMU_REG_CLR_LVD             (CO_BIT(2))
#define PMU_REG_CLR_OTP             (CO_BIT(3))     //�¶ȹ���
#define PMU_REG_CLR_ACOK            (CO_BIT(4))
#define PMU_REG_CLR_CALI            (CO_BIT(5))
#define PMU_REG_CLR_ACOFF           (CO_BIT(6))

#define PMU_REG_RTC_SETTINGS        0x3d
#define PMU_REG_PO_MODE             (CO_BIT(7))     //1: switch mode, 0: press mode
enum PMU_ON_OFF_MODE_T
{
    PMU_ON_OFF_MODE_PRESS,
    PMU_ON_OFF_MODE_SWITCH,
};

#define PMU_REG_SLP_VAL_0           0x4b
#define PMU_REG_SLP_VAL_1           0x4c
#define PMU_REG_SLP_VAL_2           0x4d
#define PMU_REG_SLP_VAL_3           0x4e

#define PMU_REG_SYSTEM_STATUS       0x4F
#define PMU_REG_SYS_PO_MAGIC        0x5A
#define PMU_REG_SYS_WK_MAGIC        0xC3

#define PMU_REG_TWEXT               0x50
#define PMU_REG_TWMIX               0x51
#define PMU_REG_TWOSC               0x52
#define PMU_REG_TWRM                0x53
#define PMU_REG_EXTWKUP             0x54
#define PMU_REG_EXTWKUP_SL_START    (CO_BIT(0))
#define PMU_REG_EXTWKUP_SL_END      (CO_BIT(1))
#define PMU_REG_EXTWKUP_DSB         (CO_BIT(7))

#define PMU_REG_CRM_CLK_SEL         0x57
#define PMU_REG_CRM_LP_CLK_SEL_MSK  0xC0
#define PMU_REG_CRM_LP_CLK_32768    0x80
#define PMU_REG_CRM_LP_CLK_32K      0x40
#define PMU_REG_CRM_LP_CLK_RC       0x00
#define PMU_REG_CRM_SAR_CLK_SEL_MSK 0x30
#define PMU_REG_CRM_SAR_CLK_32768   0x20
#define PMU_REG_CRM_SAR_CLK_32K     0x10
#define PMU_REG_CRM_SAR_CLK_RC      0x00
#define PMU_REG_CRM_CALI_CLK_EN     (CO_BIT(3))
#define PMU_REG_CRM_SAR_CLK_EN      (CO_BIT(2))

#define PMU_REG_PORTA_SEL           0x58
#define PMU_REG_PORTB_SEL           0x59
#define PMU_REG_PORTC_SEL           0x5a
#define PMU_REG_PORTD_SEL           0x5b
#define PMU_REG_PORTA_IE            0x5c
#define PMU_REG_PORTB_IE            0x5d
#define PMU_REG_PORTC_IE            0x5e
#define PMU_REG_PORTD_IE            0x5f
#define PMU_REG_PORTA_OEN           0x60
#define PMU_REG_PORTB_OEN           0x61
#define PMU_REG_PORTC_OEN           0x62
#define PMU_REG_PORTD_OEN           0x63
#define PMU_REG_PORTA_PUL           0x64
#define PMU_REG_PORTB_PUL           0x65
#define PMU_REG_PORTC_PUL           0x66
#define PMU_REG_PORTD_PUL           0x67
#define PMU_REG_CALI_CNT_0          0x68
#define PMU_REG_PORTA_TRIG_MASK     0x69
#define PMU_REG_PORTB_TRIG_MASK     0x6a
#define PMU_REG_PORTC_TRIG_MASK     0x6b
#define PMU_REG_PORTD_TRIG_MASK     0x6c

#define PMU_REG_CALI_CNT_1          0x6d
#define PMU_REG_CALI_CTRL           0x6f
#define PMU_REG_CALI_START          CO_BIT(7)

#define PMU_REG_ISR_STATUS          0x70
#define PMU_REG_ISR_ACOFF_STATE     (CO_BIT(0))
#define PMU_REG_ISR_POWER_OFF_STATE (CO_BIT(1))
#define PMU_REG_ISR_LVD_STATE       (CO_BIT(2))
#define PMU_REG_ISR_OTP_STATE       (CO_BIT(3))
#define PMU_REG_ISR_ACOK_STATE      (CO_BIT(4))
#define PMU_REG_ISR_CALI_STATE      (CO_BIT(5))
#define PMU_REG_ISR_BAT_STATE       (CO_BIT(6))

#define PMU_REG_MISC_STATUS         0x71
#define PMU_REG_ALARM_A_INT         (CO_BIT(0))
#define PMU_REG_ACOK_STATUS         (CO_BIT(1))
#define PMU_REG_BAT_STATUS          (CO_BIT(2))
#define PMU_REG_POFWARN_STATUS      (CO_BIT(3))
#define PMU_REG_OTP_STATUS          (CO_BIT(4))
#define PMU_REG_BVDDA_STATUS        (CO_BIT(5))
#define PMU_REG_ONKEY_STATUS        (CO_BIT(6))

#define PMU_REG_SLP_CNTVAL_0        0x72
#define PMU_REG_SLP_CNTVAL_1        0x73
#define PMU_REG_SLP_CNTVAL_2        0x74
#define PMU_REG_SLP_CNTVAL_3        0x75

#define PMU_REG_WAKEUP_STATE_0      0x78
#define PMU_REG_WAKEUP_STATE_1      0x79
#define PMU_REG_WAKEUP_STATE_2      0x7a
#define PMU_REG_WAKEUP_STATE_3      0x7b

#define PMU_REG_CALI_RESULT_0       0x7c
#define PMU_REG_CALI_RESULT_1       0x7d
#define PMU_REG_CALI_RESULT_2       0x7e
#define PMU_REG_CALI_RESULT_3       0x7f

/*
  COL --> OUTPUT
  COL[3:0] => PORTA[7:4]
  COL[7:4] => PORTB[7:4]
*/
#define PMU_REG_KEY_COL_SEL             0x80

/*
  ROW --> INPUT
  ROW[7:0]   => PORTC[7:0]
  ROW[15:8]  => PORTD[7:0]
  ROW[19:16] => PORTA[3:0]
*/
#define PMU_REG_KEY_ROW_SEL0            0x81
#define PMU_REG_KEY_ROW_SEL1            0x82
#define PMU_REG_KEY_ROW_SEL2            0x83

/*
  BIT[7:4] --> during clk counter for each column scan
  BIT[3:0] --> during clk between contiguous column scan
*/
#define PMU_REG_KEY_SCAN_LEN            0x84

/*
  BIT7 --> enable key scan
  BIT[3:0] --> generate interrupt after N times scan
*/
#define PMU_REG_KEY_SCAN_FNC            0x85
#define PMU_REG_KEY_SCAN_VAL            0x0f
#define PMU_REG_KEY_SCAN_H              CO_BIT(4)
#define PMU_REG_KEY_SCAN_MAP            CO_BIT(5)
#define PMU_REG_KEY_SCAN_EN             CO_BIT(7)

//led control and cfg
#define PMU_REG_LED_CTRL0               0x90
#define PMU_LED_ENABLE_MASK             0x1f
#define PMU_LED0_ENABLE                 CO_BIT(0)
#define PMU_LED1_ENABLE                 CO_BIT(1)
#define PMU_LED2_ENABLE                 CO_BIT(2)
#define PMU_LED3_ENABLE                 CO_BIT(3)
#define PMU_LED4_ENABLE                 CO_BIT(4)

#define PMU_REG_LED_CTRL1               0x91
#define PMU_LED_INV_MASK                0x1f
#define PMU_LED0_INV                    CO_BIT(0)
#define PMU_LED1_INV                    CO_BIT(1)
#define PMU_LED2_INV                    CO_BIT(2)
#define PMU_LED3_INV                    CO_BIT(3)
#define PMU_LED4_INV                    CO_BIT(4)

#define PMU_LED_CTRL_DIV_MASK           0xe0
#define PMU_LED_DIV_LOW_MASK            0x07
#define PMU_LED_DIV_HIGH_MASK           0x38

#define PMU_REG_LED0_PATTEN0            0x92
#define PMU_REG_LED0_PATTEN1            0x93
#define PMU_REG_LED0_PATTEN2            0x94
#define PMU_REG_LED0_INTERVAL           0x95
#define PMU_REG_LED1_PATTEN0            0x96
#define PMU_REG_LED1_PATTEN1            0x97
#define PMU_REG_LED1_PATTEN2            0x98
#define PMU_REG_LED1_INTERVAL           0x99
#define PMU_REG_LED2_PATTEN0            0x9a
#define PMU_REG_LED2_PATTEN1            0x9b
#define PMU_REG_LED2_PATTEN2            0x9c
#define PMU_REG_LED2_INTERVAL           0x9d
#define PMU_REG_LED3_PATTEN0            0x9e
#define PMU_REG_LED3_PATTEN1            0x9f
#define PMU_REG_LED3_PATTEN2            0xa0
#define PMU_REG_LED3_INTERVAL           0xa1
#define PMU_REG_LED4_PATTEN0            0xa2
#define PMU_REG_LED4_PATTEN1            0xa3
#define PMU_REG_LED4_PATTEN2            0xa4
#define PMU_REG_LED4_INTERVAL           0xa5

#define PMU_REG_LED_PORT_DBG            0xa7
#define PMU_POATA_LED                   CO_BIT(0)
#define PMU_POATB_LED                   CO_BIT(1)
#define PMU_POATC_LED                   CO_BIT(2)
#define PMU_POATD_LED                   CO_BIT(3)
#define PMU_DBG                         CO_BIT(7)

#define PMU_REG_LED_DAT_SEL             0xa8
#define PMU_LED_DAT_MASK                0x0f
#define PMU_LED_SEL_MASK                0xf0

#define PMU_REG_LED_OEN_PULL            0xa9
#define PMU_LED_OEN_MASK                0x0f
#define PMU_LED_PULL_MASK               0xf0

#define PMU_REG_LED_IE                  0xaa

#define PMU_REG_GPIOA_V                 0xac
#define PMU_REG_GPIOB_V                 0xad
#define PMU_REG_GPIOC_V                 0xae
#define PMU_REG_GPIOD_V                 0xaf

void pmu_enable_ext_wakeup(enum system_port_t port, enum system_port_bit_t bit);
void pmu_disable_ext_wakeup(enum system_port_t port, enum system_port_bit_t bit);
void pmu_enable_ext_wakeup_group(enum system_port_t port, uint8_t bits);
void pmu_disable_ext_wakeup_group(enum system_port_t port, uint8_t bits);

void pmu_enable_isr(uint8_t isr_map);
void pmu_disable_isr(uint8_t isr_map);
uint8_t pmu_get_isr_state(void);
void pmu_clear_isr_state(uint8_t state_map);
uint8_t pmu_first_power_on(uint8_t clear);
void pmu_set_on_off_mode(uint8_t mode, uint8_t time);
void pmu_init(void);
void pmu_power_off(uint8_t gpio_wakeup);
void pmu_isr(void);

#endif  //_PMU_H


