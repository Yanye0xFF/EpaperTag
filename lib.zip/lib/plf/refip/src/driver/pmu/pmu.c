#include "pmu.h"
#include "apb2spi.h"

void pmu_enable_ext_wakeup(enum system_port_t port, enum system_port_bit_t bit)
{
    uint8_t sel_reg = PMU_REG_PORTA_SEL;
    uint8_t msk_reg = PMU_REG_PORTA_TRIG_MASK;

    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) & (~(1<<bit))));

    msk_reg += port;
    ool_write(msk_reg, (ool_read(msk_reg) | (1<<bit)));
}

void pmu_disable_ext_wakeup(enum system_port_t port, enum system_port_bit_t bit)
{
    uint8_t sel_reg = PMU_REG_PORTA_SEL;
    uint8_t msk_reg = PMU_REG_PORTA_TRIG_MASK;

    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) | (1<<bit)));

    msk_reg += port;
    ool_write(msk_reg, (ool_read(msk_reg) & (~(1<<bit))));
}

void pmu_enable_ext_wakeup_group(enum system_port_t port, uint8_t bits)
{
    uint8_t sel_reg = PMU_REG_PORTA_SEL;
    uint8_t msk_reg = PMU_REG_PORTA_TRIG_MASK;

    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) & (~bits)));

    msk_reg += port;
    ool_write(msk_reg, (ool_read(msk_reg) | bits));
}

void pmu_disable_ext_wakeup_group(enum system_port_t port, uint8_t bits)
{
    uint8_t sel_reg = PMU_REG_PORTA_SEL;
    uint8_t msk_reg = PMU_REG_PORTA_TRIG_MASK;

    sel_reg += port;
    ool_write(sel_reg, (ool_read(sel_reg) | bits));

    msk_reg += port;
    ool_write(msk_reg, (ool_read(msk_reg) & (~bits)));
}

void pmu_process_wakeup(void)
{

}

