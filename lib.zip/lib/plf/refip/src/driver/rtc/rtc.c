#include <stdint.h>
#include "ea.h"
#include "rtc.h"


uint32_t rtc_get_time_10ms(void)
{
    return ((ea_time_get_halfslot_rounded() >> 4) & RTC_10MS_MAX_CNT);
}

uint32_t rtc_get_time(void)
{
    return ea_time_get_halfslot_rounded();
}


