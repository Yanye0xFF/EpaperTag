#ifndef _RTC_H
#define _RTC_H
#include <stdint.h>

#define RTC_MAX_CNT   ((uint32_t)0x07FFFFFF)
#define RTC_10MS_MAX_CNT   ((uint32_t)0x007FFFFF)

uint32_t rtc_get_time_10ms(void);
uint32_t rtc_get_time(void);

#endif

