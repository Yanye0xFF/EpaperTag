/**
 ****************************************************************************************
 *
 * @file intc.c
 *
 * @brief Definition of the Interrupt Controller (INTCTRL) API.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup INTC
 * @{
 ****************************************************************************************
 */

/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "compiler.h"        // for inline functions
#include "arch.h"            // arch definition
#include "co_math.h"         // math library definition
#include "app_api.h"
#if defined(CFG_BT)
#include "rwip_config.h"     // stack configuration
#include "rwbt.h"            // rwbt core
#endif //CFG_BT
#if defined(CFG_BLE)
#include "rwble.h"           // rwble core
#endif //CFG_BLE
#include "intc.h"            // interrupt controller
#include "reg_intc.h"        // intc registers
#if PLF_UART
#include "uart.h"            // uart definitions
#endif //PLF_UART

#include "system.h"

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */
/// locally define this type to be able to qualify the array.
typedef void (*void_fn)(void);

void intc_init(void)
{
    NVIC_SetPriorityGrouping(4);    //3.0 indicates three bits of pre-emption priority, no bit of subpriority
    NVIC->ICER[0] = 0xFFFFFFFF;     //disable all interrupt;
    NVIC->ICER[1] = 0xFFFFFFFF;     //disable all interrupt;
    NVIC->ICPR[0] = 0xFFFFFFFF;     //clear all pending interrupt;
    NVIC->ICPR[1] = 0xFFFFFFFF;     //clear all pending interrupt;

    NVIC_SetPriority(SVCall_IRQn, 0);  //make sure SVC,  used by FPB implementation, has the highest priority

    NVIC_SetPriority(BLE_SW_IRQn, 1);
    NVIC_SetPriority(BLE_FINETGTIM_IRQn, 1);
    NVIC_SetPriority(BLE_GROSSTGTIM_IRQn, 1);
    NVIC_SetPriority(BLE_ERROR_IRQn, 1);
    NVIC_SetPriority(BLE_CRYPT_IRQn, 1);
    NVIC_SetPriority(BLE_EVENT_IRQn, 1);
    NVIC_SetPriority(BLE_SLP_IRQn, 1);
    NVIC_SetPriority(BLE_RX_IRQn, 1);
    NVIC_SetPriority(BLE_CSCNT_IRQn, 1);

    NVIC_SetPriority(UART0_IRQn, 2);
    NVIC_SetPriority(UART1_IRQn, 2);

    NVIC_SetPriority(KEYSCAN0_IRQn, 2);
    NVIC_SetPriority(KEYSCAN1_IRQn, 2);
    NVIC_SetPriority(KEYSCAN2_IRQn, 2);
    NVIC_SetPriority(KEYSCAN3_IRQn, 2);
    NVIC_SetPriority(KEYSCAN4_IRQn, 2);

    NVIC_SetPriority(EXT_INTR_IRQn, 2);

    NVIC_EnableIRQ(BLE_SW_IRQn);
    NVIC_EnableIRQ(BLE_FINETGTIM_IRQn);
    NVIC_EnableIRQ(BLE_GROSSTGTIM_IRQn);
    NVIC_EnableIRQ(BLE_ERROR_IRQn);
    NVIC_EnableIRQ(BLE_CRYPT_IRQn);
    NVIC_EnableIRQ(BLE_EVENT_IRQn);
    NVIC_EnableIRQ(BLE_SLP_IRQn);
    NVIC_EnableIRQ(BLE_RX_IRQn);
    NVIC_EnableIRQ(BLE_CSCNT_IRQn);

    NVIC_EnableIRQ(KEYSCAN0_IRQn);
    NVIC_EnableIRQ(KEYSCAN1_IRQn);
    NVIC_EnableIRQ(KEYSCAN2_IRQn);
    NVIC_EnableIRQ(KEYSCAN3_IRQn);
    NVIC_EnableIRQ(KEYSCAN4_IRQn);

    NVIC_EnableIRQ(EXT_INTR_IRQn);

    if(user_intc_init)
    {
        user_intc_init();
    }
}

/*void SVC_Handler(void)
{
    svc_exception_handler();
}*/
/// @} INTC
