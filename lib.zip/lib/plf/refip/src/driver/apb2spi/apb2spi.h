#ifndef _APB2SPI_H
#define _APB2SPI_H

#include <stdint.h>

#define APB2SPI_TYPE_CODEC      0
#define APB2SPI_TYPE_OOL        1
#define APB2SPI_TYPE_NVRAM      2

void apb2spi_write(uint16_t addr, uint8_t data, uint8_t type);
#define ool_write(addr, data)       apb2spi_write((addr), (data), APB2SPI_TYPE_OOL)
#define nvram_write(addr, data)     apb2spi_write((addr), (data), APB2SPI_TYPE_NVRAM)
#define codec_write(addr, data)     apb2spi_write((addr), (data), APB2SPI_TYPE_CODEC)

uint8_t apb2spi_read(uint16_t addr, uint8_t type);
#define ool_read(addr)              apb2spi_read((addr), APB2SPI_TYPE_OOL)
#define nvram_read(addr)            apb2spi_read((addr), APB2SPI_TYPE_NVRAM)
#define codec_read(addr)            apb2spi_read((addr), APB2SPI_TYPE_CODEC)

void apb2spi_init(void);

#endif//_APB2SPI_H

