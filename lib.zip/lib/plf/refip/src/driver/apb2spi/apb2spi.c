#include "apb2spi.h"
#include "reg_access.h"
#include "plf.h"
#include "arch.h"

#define APB2SPI_CMD             (APB2SPI_BASE+0x400)
#define APB2SPI_WDATA           (APB2SPI_BASE+0x404)
#define APB2SPI_RDATA           (APB2SPI_BASE+0x408)
#define APB2SPI_ADDR            (APB2SPI_BASE+0x40c)
#define APB2SPI_SPI_CLK_DIV     (APB2SPI_BASE+0x410) //spi clk = master clk/(value*2)
#define APB2SPI_NVM_CLK_DIV     (APB2SPI_BASE+0x414) //spi clk = master clk/(value*2)

#define NVRAM_CLK_ENABLE        (1<<5)
#define SPI_SLAVE_SELECT        (1<<4)    //1: codec, 0: ool and nvram
#define SPI_WR_SELECT           (1<<3)    //1: write, 0: read
#define CLEAR_SPI_CMD           (1<<2)
#define SPI_BUS_STATUS          (1<<1)    //1: busy, 0: finish
#define SPI_BUS_START           (1<<0)    //wirte 1 to start

#define AP2SPI_NVRAM_OFFSET     0x200

void apb2spi_write(uint16_t addr, uint8_t data, uint8_t type)
{
    uint32_t value;
    CPU_SR cpu_sr;

    GLOBAL_INT_DISABLE();
    value = REG_PL_RD(APB2SPI_CMD);
    switch(type)
    {
        case APB2SPI_TYPE_CODEC:
            value |= SPI_SLAVE_SELECT;
            break;
        case APB2SPI_TYPE_OOL:
            value &= (~SPI_SLAVE_SELECT);
            break;
        case APB2SPI_TYPE_NVRAM:
            addr += AP2SPI_NVRAM_OFFSET;
            value &= (~SPI_SLAVE_SELECT);
            value |= NVRAM_CLK_ENABLE;
            break;
        default:
            GLOBAL_INT_RESTORE();
            return;
    }

    value |= (SPI_WR_SELECT|SPI_BUS_START);

    REG_PL_WR(APB2SPI_WDATA, data);
    REG_PL_WR(APB2SPI_ADDR, addr);
    REG_PL_WR(APB2SPI_CMD, value);
    while((REG_PL_RD(APB2SPI_CMD)&SPI_BUS_STATUS)==0);
    REG_PL_WR(APB2SPI_CMD, REG_PL_RD(APB2SPI_CMD)|CLEAR_SPI_CMD);
    if(type == APB2SPI_TYPE_NVRAM)
    {
        REG_PL_WR(APB2SPI_CMD, REG_PL_RD(APB2SPI_CMD)&(~NVRAM_CLK_ENABLE));
    }

    GLOBAL_INT_RESTORE();
}

uint8_t apb2spi_read(uint16_t addr, uint8_t type)
{
    uint32_t value;
    uint8_t data;
    CPU_SR cpu_sr;

    GLOBAL_INT_DISABLE();
    value = REG_PL_RD(APB2SPI_CMD);
    switch(type)
    {
        case APB2SPI_TYPE_CODEC:
            value |= SPI_SLAVE_SELECT;
            break;
        case APB2SPI_TYPE_OOL:
            value &= (~SPI_SLAVE_SELECT);
            break;
        case APB2SPI_TYPE_NVRAM:
            addr += AP2SPI_NVRAM_OFFSET;
            value &= (~SPI_SLAVE_SELECT);
            value |= NVRAM_CLK_ENABLE;
            break;
        default:
            GLOBAL_INT_RESTORE();
            return 0;
    }

    value &= (~SPI_WR_SELECT);
    value |= SPI_BUS_START;

    REG_PL_WR(APB2SPI_ADDR, addr);
    REG_PL_WR(APB2SPI_CMD, value);
    while((REG_PL_RD(APB2SPI_CMD)&SPI_BUS_STATUS)==0);
    data = REG_PL_RD(APB2SPI_RDATA);
    REG_PL_WR(APB2SPI_CMD, REG_PL_RD(APB2SPI_CMD)|CLEAR_SPI_CMD);
    if(type == APB2SPI_TYPE_NVRAM)
    {
        REG_PL_WR(APB2SPI_CMD, REG_PL_RD(APB2SPI_CMD)&(~NVRAM_CLK_ENABLE));
    }

    GLOBAL_INT_RESTORE();
    return data;
}

void apb2spi_init(void)
{
    REG_PL_WR(APB2SPI_SPI_CLK_DIV, 4);
    REG_PL_WR(APB2SPI_NVM_CLK_DIV, 2);
}

/*void nvram_test(void)
{
    uint16 i;

    for(i=0; i<512; i++) {
        nvram_write(i, (i+0x55)&0xff);
    }

    for(i=0; i<512; i++) {
        if(nvram_read(i) != ((i+0x55)&0xff)) {
            co_printf("nvram_test failed at 0x%04x.\r\n", i);
            //return;
        }
    }
    co_printf("nvram_test success.\r\n");
}*/

