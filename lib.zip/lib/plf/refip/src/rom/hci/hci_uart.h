/**
 ****************************************************************************************
 *
 * @file hci_uart.h
 *
 * @brief HCIH EIF transport module header file.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef HCI_UART_H_
#define HCI_UART_H_

/**
 ****************************************************************************************
 * @addtogroup HCI_UART HCIH EIF
 * @ingroup HCI
 * @brief HCIH EIF module.
 *
 * This module creates the abstraction between UART driver and HCI generic functions
 * (designed for any transport layer).
 *
 * @{
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include <stdint.h>

/*
 * DEFINES
 ****************************************************************************************
 */
///HCI Transport Header length - change if different transport
#define HCI_TRANSPORT_HDR_LEN                       0x01

///UART header: command message type
#define HCI_CMD_MSG_TYPE                            0x01

///UART header: event message type
#define HCI_EVT_MSG_TYPE                            0x04



/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
/**
 ****************************************************************************************
 * @brief HCIH EIF transport initialization.
 *
 * Puts the UART driver in reception, waiting for simple 1 byte message type. Space for
 * reception is allocated with ke_msg_alloc and the pointer is handed to uart_env.rx. RX
 * interrupt is enabled.
 *****************************************************************************************
 */
void hci_uart_init(void);

/**
 ****************************************************************************************
 * @brief HCIH EIF write function.
 * @param[in] buf   Pointer to the message to be transmitted.
 * @param[in] len   Byte length of buffer to write.
 *****************************************************************************************
 */
void hci_uart_write(uint8_t *buf, uint16_t len);

/**
 ****************************************************************************************
 * @brief Actions after UART TX.
 *
 * Analyzes the status value and sets the hci environment state to TX_DONE/ERR
 * accordingly. This allows the higher function calling uart_write to have feedback
 * and decide the following action (repeat/abort tx in case of error, continue otherwise).
 *
 * @param[in]  status UART Tx status: ok or error.
 *****************************************************************************************
 */
void hci_uart_tx_done(int status);

/**
 ****************************************************************************************
 * @brief Function called at each RX interrupt.
 *
 * According to HCI RX state, the received data is treated differently: message type,
 * header or payload. Once payload is obtained (if existing) the appropriate hci unpacking
 * function is called thus generating a ke_msg for the appropriate task.
 *
 * @param[in]  status UART RX status: ok or error
 *****************************************************************************************
 */
void hci_uart_rx_done(int status);

/// @} HCI_UART

#endif // HCI_UART_H_
