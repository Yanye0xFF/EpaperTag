/**
 ****************************************************************************************
 *
 * @file hci.h
 *
 * @brief This file contains definitions related to the HCI module.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef HCI_H_
#define HCI_H_

/**
 ****************************************************************************************
 * @addtogroup HCI HCI
 * @ingroup ROOT
 * @brief HCI module handling communication between lower and higher layers in split
 * architecture.
 *
 *@{
 * This is the following convention for HCI transport functions:
 *     - Functions referring to Commands/events to be sent through HCI transport layer
 *       contain 'send' in their name.
 *
 *     - Functions referring to Commands/events to be from HCI transport layer reception
 *       to FW targets contain 'dispatch' in their name.
 *
 *     - Suffixes 'pk' and 'unpk' are used for command/event packing and unpacking
 *       functions, which generally bear a similar name to the command name in the SIG
 *       specification.
 *
 *     - All commands and events are described by structures, defined in llm/c_task.h.
 *       The structures may sometimes present padded space for alignment, therefore
 *       for those messages described with such structures, specific packing/unpacking
 *       functions can be found. All the rest are handled by 'basic' or 'aligned'
 *       named functions.
 *
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "hci_msg.h"
#include "hci_uart.h"


/*
 * DEFINES
 ****************************************************************************************
 */
/// HCI command packets
#define HCI_NB_CMD_PKTS            1

///Maximum size for the command parameters
#define HCI_MAX_CMD_LENGTH         255

///Maximum size for the events
#define HCI_MAX_EVT_LENGTH         32

/// Offset of the event header in the buffer
#define HCI_EVT_HDR_OFFSET         1

///Maximum number of commands in ROM
#define HCI_CMD_OPCODE_NB_MAX      12

///HCI Command Opcode byte length
#define HCI_CMD_OPCODE_LEN         0x02

///HCI Event code byte length
#define HCI_EVT_CODE_LEN           0x01

///HCI Command/Event parameter length field byte length
#define HCI_CMDEVT_PARLEN_LEN      0x01

///HCI Command header length
#define HCI_CMD_HDR_LEN            HCI_CMD_OPCODE_LEN + HCI_CMDEVT_PARLEN_LEN

///HCI Event header length
#define HCI_EVT_HDR_LEN            HCI_EVT_CODE_LEN + HCI_CMDEVT_PARLEN_LEN

///HCI Command Complete Event minimum parameter length: 1(nb_pk)+2(opcode)
#define HCI_CCEVT_HDR_PARLEN       0x03

///HCI Command Complete Event header length:1(code)+1(len)+1(pk)+2(opcode)
#define HCI_CCEVT_HDR_LEN          HCI_EVT_HDR_LEN + HCI_CCEVT_HDR_PARLEN

///HCI Basic Command Complete Event packet length
#define HCI_CCEVT_BASIC_LEN        HCI_CCEVT_HDR_LEN + 1

/*
 * MACROS
 ****************************************************************************************
 */

/// Macro to extract OCF from OPCODE
#define HCI_OP2OCF(opcode)        ((opcode) & 0x03FF)

/// Macro to extract OGF from OPCODE
#define HCI_OP2OGF(opcode)        ((opcode) >> 10 & 0x003F)

/// Macro to create OPCODE from OGF and OCF
#define HCI_OPCODE(ocf, ogf)      (((ogf) << 10) | ocf)

/*
 * TYPE DEFINITIONS
 ****************************************************************************************
 */

///HCI enumeration of possible Command OGF values.
enum HCI_OGF
{
    ///HCI Link Control Commands Group OGF code
    LK_CNTL_OGF = 0x01,
    ///HCI Link Policy Commands Group OGF code - none in BLE
    LK_POL_OGF,
    ///HCI Controller and Baseband Commands Group OGF code
    CNTLR_BB_OGF,
    ///HCI Information Parameters Commands Group OGF code
    INFO_PAR_OGF,
    ///HCI Status Commands Group OGF code
    STAT_OGF,
    ///HCI Test Commands Group OGF code - none in BLE
    TEST_OGF,
    ///HCI Low Energy Commands Group OGF code
    LE_CNTLR_OGF=0x08,
    ///HCI Debug Commands Group OGF code
    DBG_OGF = 0x3F
};


///HCI TX states
enum HCI_TX_STATE
{
    ///HCI TX Start State - when packet is ready to be sent
    HCI_STATE_TX_ONGOING,
    ///HCI TX Done State - TX ended with no error
    HCI_STATE_TX_IDLE
};

///HCI RX states
enum HCI_RX_STATE
{
    ///HCI RX Start State - receive message type
    HCI_STATE_RX_START,
    ///HCI RX Header State - receive message header
    HCI_STATE_RX_HDR,
    ///HCI RX Header State - receive (rest of) message payload
    HCI_STATE_RX_PAYL,
    ///HCI RX Header State - receive error
    HCI_STATE_RX_ERR
};


///HCI Command header components structure
struct hci_cmd_hdr
{
    ///OGF - command group code
    uint8_t ogf;
    ///OCF - command index in group
    uint8_t ocf;
    ///Flag for opcode known or not at its reception in LL
    uint8_t known_opcode;
    ///Parameter length - the number of bytes of the command parameters
    uint8_t parlen;
};


///HCI Environment context structure
struct hci_env_tag
{
    ///Rx state - can be receiving message type, header, payload or error
    uint8_t  rx_state;
    ///Latest received message type: CMD/EVT/ACL.
    uint8_t  curr_msg_type;
    ///Latest received message header, 4 byte buffer for other configuration.
    uint8_t  curr_hdr_buff[4];
    ///Pointer to space reserved for received payload.
    uint8_t *curr_payl_buff;
    ///Space reserved for command reception, with params
    uint8_t  cmd_buf[HCI_MAX_CMD_LENGTH];
    ///Space reserved for event transmission, with params
    uint8_t  evt_buf[HCI_MAX_EVT_LENGTH];
    ///Last command header received
    struct   hci_cmd_hdr chdr;
};


/*
 * GLOBAL VARIABLE DECLARATIONS
 ****************************************************************************************
 */
///HCI environment structure external global variable declaration
extern struct hci_env_tag hci_env;

extern const uint16_t hci_cmd_opcodes[HCI_CMD_OPCODE_NB_MAX];


/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */
/**
****************************************************************************************
* @brief HCI initialization function: initializes states and transport.
*****************************************************************************************
*/
void hci_init(void);

/**
 ****************************************************************************************
 * @brief Function called in HCIH EIF reception routine to dispatch a KE message for a
 *        command. Uses the hci_env command header OGF and OCF components.
 * @param[in]  payl Pointer to receiver buffer payload
 *****************************************************************************************
 */
void hci_cmd_dispatch(uint8_t * payl);

/**
 ****************************************************************************************
 * @brief Trigger sending of HCI event
 *
 *  Function called to trigger sending of HCI event in current event buffer.
 *
 * @param[in]  Length of HCI event
 *****************************************************************************************
 */
void hci_push(uint8_t length);

/// @} HCI

#endif // HCI_H_
