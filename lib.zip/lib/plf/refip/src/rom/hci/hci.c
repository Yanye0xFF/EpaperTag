/**
 ****************************************************************************************
 *
 * @file hci.c
 *
 * @brief HCI module source file.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup HCI
 * @{
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "co_error.h"
#include "co_utils.h"
#include "co_endian.h"

#include "hci.h"
#include "hci_uart.h"
#include "hci_msg.h"


/*
 * MACROS
 ****************************************************************************************
 */

/// Macro to get OCF of a known command
#define OCF(cmd)        (HCI_OP2OCF(HCI_##cmd##_CMD_OPCODE))



/*
 * GLOBAL VARIABLE DEFINITIONS
 ****************************************************************************************
 */
///HCI environment context
struct hci_env_tag hci_env;

/*LOWER LAYERS USE*/
///HCI Table with handled command opcodes for check
const uint16_t hci_cmd_opcodes[HCI_CMD_OPCODE_NB_MAX]=
{
    // Legacy commands
    HCI_RESET_CMD_OPCODE,
    HCI_RD_LOCAL_VER_INFO_CMD_OPCODE,

    // DBG commands
    HCI_DBG_RD_MEM_CMD_OPCODE,
    HCI_DBG_WR_MEM_CMD_OPCODE,
    HCI_DBG_DEL_PAR_CMD_OPCODE,
    HCI_DBG_FLASH_ID_CMD_OPCODE,
    HCI_DBG_FLASH_ER_CMD_OPCODE,
    HCI_DBG_FLASH_WR_CMD_OPCODE,
    HCI_DBG_FLASH_RD_CMD_OPCODE,
    HCI_DBG_RD_PAR_CMD_OPCODE,
    HCI_DBG_WR_PAR_CMD_OPCODE,
    HCI_DBG_PLF_RESET_CMD_OPCODE,
};



/*
 * LOCAL FUNCTIONS DEFINTIONS
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @brief Function called in basic kernel message sending for Controller Baseband commands
 *        with no parameters.
 *
 * @param ocf  OCF of command for identification.
 * Uses the hci_env command header OGF and OCF components.
 *****************************************************************************************
 */
static void hci_cmd_dispatch_basic_cntlr_bb(uint8_t ocf)
{
    switch(ocf)
    {
        case OCF(RESET):
            // Send command complete event
            hci_ccevt_pk(HCI_RESET_CMD_OPCODE, CO_ERROR_NO_ERROR, HCI_CCEVT_RESET_RETPAR_LEN-1);
            break;

        // commands with params should not end up here
        default:
            ASSERT_ERR(0);
            break;
    }
}

/**
 ****************************************************************************************
 * @brief Function called in basic kernel message sending for Information Parameters
 *        commands with no parameters.
 *
 * @param ocf  OCF of command for identification.
 * Uses the hci_env command header OGF and OCF components.
 *****************************************************************************************
 */
static void hci_cmd_dispatch_basic_info_par(uint8_t ocf)
{
    switch(ocf)
    {
        case OCF(RD_LOCAL_VER_INFO):
            hci_rd_local_ver_info_ccevt_pk();
            break;

        //cmds with no params end up here
        default:
            ASSERT_ERR(0);
            break;
    }
}

/**
 ****************************************************************************************
 * @brief Function called in kernel message dispatch for Debug commands with parameters.
 *
 * @param[in]  ocf  COmmand OCF field for identification.
 * @param[in]  payl Pointer to receiver buffer payload
 *****************************************************************************************
 */
static void hci_cmd_dispatch_dbg(uint8_t ocf, uint8_t * payl)
{
    switch(ocf)
    {
        case OCF(DBG_RD_MEM)        :
            hci_dbg_rd_mem_cmd_unpk(payl);
            break;
        case OCF(DBG_WR_MEM)        :
            hci_dbg_wr_mem_cmd_unpk(payl);
            break;
        case OCF(DBG_DEL_PAR)       :
            hci_dbg_wr_param_cmd_unpk(payl);
            break;
        case OCF(DBG_FLASH_ID)      :
            hci_dbg_flash_identify_cmd_unpk(payl);
            break;
        case OCF(DBG_FLASH_ER)      :
            hci_dbg_flash_erase_cmd_unpk(payl);
            break;
        case OCF(DBG_FLASH_WR)      :
            hci_dbg_flash_write_cmd_unpk(payl);
            break;
        case OCF(DBG_FLASH_RD)      :
            hci_dbg_flash_read_cmd_unpk(payl);
            break;
        case OCF(DBG_RD_PAR)        :
            hci_dbg_rd_param_cmd_unpk(payl);
            break;
        case OCF(DBG_WR_PAR)        :
            hci_dbg_wr_param_cmd_unpk(payl);
            break;
        case OCF(DBG_PLF_RESET)     :
            hci_dbg_plf_reset_cmd_unpk(payl);
            break;

        //cmds with no params end up here
        default:
            ASSERT_ERR(0);
            break;
    }
}

/*
 * EXPORTED FUNCTIONS DEFINTIONS
 ****************************************************************************************
 */

void hci_init()
{
    //init uart hci
    hci_uart_init();
}

void hci_cmd_dispatch(uint8_t * payl )
{
    if (hci_env.chdr.known_opcode)
    {
        switch(hci_env.chdr.ogf)
        {
            case CNTLR_BB_OGF:
                hci_cmd_dispatch_basic_cntlr_bb(hci_env.chdr.ocf);
                break;

            case INFO_PAR_OGF:
                hci_cmd_dispatch_basic_info_par(hci_env.chdr.ocf);
                break;

            case DBG_OGF:
                hci_cmd_dispatch_dbg(hci_env.chdr.ocf, payl);
                break;
        }
    }
    //unknown opcode
    else
    {
        // Send command complete event
        hci_ccevt_pk(co_htobs((((uint16_t)(hci_env.chdr.ogf) )<<10) | ((uint16_t)(hci_env.chdr.ocf))),
                     CO_ERROR_UNKNOWN_HCI_COMMAND,
                     HCI_CCEVT_UNNKNOWN_RETPAR_LEN-1);
    }
}

void hci_push(uint8_t length)
{
    // Forward the message to the HCIH EIF for immediate transmission
    hci_uart_write(&hci_env.evt_buf[HCI_EVT_HDR_OFFSET], length);
}

/// @} HCI
