/**
 ****************************************************************************************
 *
 * @file hci_uart.c
 *
 * @brief HCIH EIF transport module functions.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup HCI_UART
 * @{
 ****************************************************************************************
 */


/*
 * INCLUDE FILES
 ****************************************************************************************
 */
#include "co_endian.h"
#include "co_utils.h"

#include "hci.h"
#include "hci_msg.h"
#include "hci_uart.h"

#include "uart.h"


/*
 * LOCAL FUNCTION DECLARATIONS
 ****************************************************************************************
 */

/**
 ******************************************************************************************
 * @brief Local function : places HCIH EIF in RX_START state and sets the UART environment.
 ******************************************************************************************
 */
static void hci_uart_read_start(void);

/**
 ****************************************************************************************
 * @brief Local function : places HCIH EIF in RX header state and sets the UART env.
 * @param[in] len Length of header to be received in the currently set buffer.
 *****************************************************************************************
 */
static void hci_uart_read_hdr(uint8_t len);

/**
 ******************************************************************************************
 * @brief Local function : places HCIH EIF in RX payload state and sets the UART env.
 * @param[in] len Length of payload to be received in the currently set buffer.
 ******************************************************************************************
 */
static void hci_uart_read_payl(uint8_t len);

/**
 ****************************************************************************************
 * @brief Local function : extracts command header components and places them in the
 * HCI environment command header structure.
 *****************************************************************************************
 */
static void hci_uart_rx_cmd_hdr_extract(void);

/*
 * LOCAL FUNCTION DEFINITIONS
 ****************************************************************************************
 */

static void hci_uart_read_start(void)
{
    //Initialize UART in reception mode state
    hci_env.rx_state = HCI_STATE_RX_START;

    //Set the UART environment to message type 1 byte reception
    uart_read(&hci_env.curr_msg_type, HCI_TRANSPORT_HDR_LEN);
}

static void hci_uart_read_hdr(uint8_t len)
{
    //change Rx state - wait for header next
    hci_env.rx_state = HCI_STATE_RX_HDR;

    //set UART environment to header reception of len bytes
    uart_read(hci_env.curr_hdr_buff, len);
}

static void hci_uart_read_payl(uint8_t len)
{
    //change rx state to payload reception
    hci_env.rx_state = HCI_STATE_RX_PAYL;

    //set UART environment to payload reception of len bytes
    uart_read(hci_env.cmd_buf, len);
}

static void hci_uart_rx_cmd_hdr_extract(void)
{
    //check opcode existence
    hci_env.chdr.known_opcode = 0;

    //check if opcode exists
    for(int i=0; i<HCI_CMD_OPCODE_NB_MAX; i++)
    {
        if (hci_cmd_opcodes[i] == co_btohs(co_read16p(hci_env.curr_hdr_buff)))
        {
            hci_env.chdr.known_opcode = 1;
            break;
        }
    }

    //extract command header:ocf, ogf, parameter length
    hci_env.chdr.ocf    = hci_env.curr_hdr_buff[0];
    hci_env.chdr.ogf    = hci_env.curr_hdr_buff[1]>>2;
    hci_env.chdr.parlen = hci_env.curr_hdr_buff[2];
}


/*
 * EXPORTED FUNCTION DEFINITIONS
 ****************************************************************************************
 */

void hci_uart_init(void)
{
    //start uart reception
    hci_uart_read_start();
}

void hci_uart_write(uint8_t *buf, uint16_t len)
{
    //pack event type message (UART header)
    buf -= HCI_TRANSPORT_HDR_LEN;
    *buf = HCI_EVT_MSG_TYPE;

    uart_write(buf, len + HCI_TRANSPORT_HDR_LEN);
}

void hci_uart_tx_done(int status)
{
    // Sanity check: Transmission should always work
    ASSERT_ERR(status == RWIP_EIF_STATUS_OK);
}


void hci_uart_rx_done(int status)
{
    //detect UART RX error and handle accordingly
    if (status == RWIP_EIF_STATUS_ERROR)
    {
        hci_env.rx_state = HCI_STATE_RX_ERR;
    }

    //check HCI state to see what was received
    switch(hci_env.rx_state)
    {
        /* RECEIVE MESSAGE TYPE STATE*/
        case HCI_STATE_RX_START:

            //Check message type correct
            ASSERT_ERR(hci_env.curr_msg_type == HCI_CMD_MSG_TYPE);

            //change state to header reception
            hci_uart_read_hdr(HCI_CMD_HDR_LEN);

            break;
        /* RECEIVE MESSAGE TYPE STATE END*/


        /* RECEIVE HEADER STATE*/
        case HCI_STATE_RX_HDR:

            // Extract the command header components
            hci_uart_rx_cmd_hdr_extract();

            // Check if parameters have to be received
            if (hci_env.chdr.parlen == 0)
            {
                // Send basic kernel message
                hci_cmd_dispatch(hci_env.cmd_buf);

                //change hci rx state to message type reception
                hci_uart_read_start();
            }
            //Command has parameters so go to payload reception
            else
            {
                hci_uart_read_payl(hci_env.chdr.parlen);
            }

            break;
        /* RECEIVE HEADER STATE END*/

        /* RECEIVE PAYLOAD STATE */
        case HCI_STATE_RX_PAYL:

            //call the right unpack handler
            hci_cmd_dispatch(hci_env.cmd_buf);

            //change hci rx state to message type reception - common to all types
            hci_uart_read_start();

            break;
        /* RECEIVE PAYLOAD STATE END*/


        /* ERROR STATE */
        case HCI_STATE_RX_ERR:
            //start rx again
            hci_uart_init();

            break;
            /* ERROR STATE END*/

    }
    /* STATE SWITCH END */
}

/// @} HCI_UART
