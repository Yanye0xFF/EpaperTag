#ifndef _FR_BLE_CONFIG_H
#define _FR_BLE_CONFIG_H

#define STACK_TMP_TOP_ADDR          0x40003000
#define BOOT_RECV_BUFFER            0x40002000
#define BOOT_SEND_BUFFER            0x40002400
#define APP_LOAD_BASE_ADDR          0x20000000  //vectors and jump_table
#define APP_STORAGE_BASE_ADDR_0     0x00000000
#define APP_STORAGE_BASE_ADDR_1     0x00014000  //80x1024
#define VECTOR_HANDLER_COUNT        52

#define CFG_CPU_CORTEX_M3
#define CFG_EMB
#define CFG_HOST
#define CFG_HCITL
//#define CFG_AHITL
#define CFG_BLE
#define CFG_RF_FREQ
#define CFG_ALLROLES
#define CFG_CON             6
#define CFG_SEC_CON
#define CFG_SLEEP
#define CFG_WLAN_COEX
#define CFG_CHNL_ASSESS
#define CFG_APP
#define CFG_ATTC
#define CFG_ATTS
#define RP_HWSIM_BYPASS
#define CFG_PRF
#define CFG_NB_PRF          10
#define CFG_DBG_PRINTF
#define CFG_BUTTON
#define CFG_DBG_STACK_PROF

#define CFG_PRF_HOGPD
#define CFG_PRF_DISS
#define CFG_PRF_BASS
//#define CFG_PRF_SPSS
//#define CFG_PRF_SPSC
//#define CFG_PRF_FMPT
//#define CFG_PRF_OTAS
//#define CFG_PRF_PXPR

#if 0
#define CFG_PRF_DISC
#define CFG_PRF_DISS
#define CFG_PRF_HOGPD
#define CFG_PRF_BASS
#define CFG_PRF_PXPM
#define CFG_PRF_PXPR
#define CFG_PRF_FMPL
#define CFG_PRF_FMPT
#define CFG_PRF_HTPC
#define CFG_PRF_HTPT
#define CFG_PRF_DISC
#define CFG_PRF_DISS
#define CFG_PRF_BLPC
#define CFG_PRF_BLPS
#define CFG_PRF_TIPC
#define CFG_PRF_TIPS
#define CFG_PRF_HRPC
#define CFG_PRF_HRPS
#define CFG_PRF_SCPPC
#define CFG_PRF_SCPPS
#define CFG_PRF_BASC
#define CFG_PRF_BASS
#define CFG_PRF_HOGPBH
#define CFG_PRF_HOGPRH
#define CFG_PRF_GLPC
#define CFG_PRF_GLPS
#define CFG_PRF_RSCPC
#define CFG_PRF_RSCPS
#define CFG_PRF_CSCPC
#define CFG_PRF_CSCPS
#define CFG_PRF_CPPC
#define CFG_PRF_CPPS
#define CFG_PRF_LANC
#define CFG_PRF_LANS
#define CFG_PRF_ANPC
#define CFG_PRF_ANPS
#define CFG_PRF_PASPC
#define CFG_PRF_PASPS
#endif
#endif  //_FR_BLE_CONFIG_H

