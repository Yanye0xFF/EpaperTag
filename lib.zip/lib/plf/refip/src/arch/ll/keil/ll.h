/**
 ****************************************************************************************
 *
 * @file ll.h
 *
 * @brief Declaration of low level functions.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */

#ifndef LL_H_
#define LL_H_

#ifndef __arm__
#error "File only included with keil!"
#endif // __arm__

#include <stdint.h>
#include "arch.h"
#include "system.h"

#ifdef CFG_CPU_CORTEX_M3
typedef unsigned int CPU_SR;
#endif

/** @brief Enable interrupts globally in the system.
 * This macro must be used when the initialization phase is over and the interrupts
 * can start being handled by the system.
 */
#ifndef CFG_CPU_CORTEX_M3
#define GLOBAL_INT_START()                                                  \
do {                                                                        \
    uint32_t __l_cpsr_tmp;                                                  \
    __asm("                                                                 \
        MRS     __l_cpsr_tmp, CPSR;                                         \
        BIC     __l_cpsr_tmp, __l_cpsr_tmp, #0x80;                          \
        MSR     CPSR_cxsf, __l_cpsr_tmp;                                    \
    ");                                                                     \
} while(0)
#else
void GLOBAL_INT_START(void);
#endif

/** @brief Disable interrupts globally in the system.
 * This macro must be used when the system wants to disable all the interrupt
 * it could handle.
 */
#ifndef CFG_CPU_CORTEX_M3
#define GLOBAL_INT_STOP()                                                   \
do {                                                                        \
    uint32_t __l_cpsr_tmp;                                                  \
    __asm("                                                                 \
        MRS     __l_cpsr_tmp, CPSR;                                         \
        ORR     __l_cpsr_tmp, __l_cpsr_tmp, #0x80;                          \
        MSR     CPSR_cxsf, __l_cpsr_tmp;                                    \
    ");                                                                     \
} while(0)
#else
void GLOBAL_INT_STOP(void);
#endif


/** @brief Disable interrupts globally in the system.
 * This macro must be used in conjunction with the @ref GLOBAL_INT_RESTORE macro since this
 * last one will close the brace that the current macro opens.  This means that both
 * macros must be located at the same scope level.
 */

#ifndef CFG_CPU_CORTEX_M3
#define GLOBAL_INT_DISABLE()                                                \
do {                                                                        \
    uint32_t __l_cpsr_tmp;                                                  \
    uint32_t __l_irq_rest;                                                  \
    __asm("                                                                 \
        MRS     __l_cpsr_tmp, CPSR;                                         \
        AND     __l_irq_rest, __l_cpsr_tmp, #0x80;                          \
        ORR     __l_cpsr_tmp, __l_cpsr_tmp, #0x80;                          \
        MSR     CPSR_cxsf, __l_cpsr_tmp;                                    \
    ")
#else
uint32_t CPU_SR_Save(uint8_t);
#define GLOBAL_INT_DISABLE()    CPU_SR cpu_sr;  {cpu_sr = CPU_SR_Save(0x20);}
#endif



/** @brief Restore interrupts from the previous global disable.
 * @sa GLOBAL_INT_DISABLE
 */

#ifndef CFG_CPU_CORTEX_M3
#define GLOBAL_INT_RESTORE()                                                \
    __asm("                                                                 \
        MRS     __l_cpsr_tmp, CPSR;                                         \
        BIC     __l_cpsr_tmp, __l_cpsr_tmp, #0x80;                          \
        ORR     __l_cpsr_tmp, __l_cpsr_tmp, __l_irq_rest;                   \
        MSR     CPSR_cxsf, __l_cpsr_tmp;                                    \
    ");                                                                     \
} while(0)
#else
void CPU_SR_Restore(CPU_SR reg);
#define GLOBAL_INT_RESTORE()    CPU_SR_Restore(cpu_sr)
#endif

/** @brief Invoke the wait for interrupt procedure of the processor.
 *
 * @warning It is suggested that this macro is called while the interrupts are disabled
 * to have performed the checks necessary to decide to move to sleep mode.
 *
 */

#ifndef CFG_CPU_CORTEX_M3
#define WFI()                                                                            \
do {                                                                                     \
    GLOBAL_INT_DISABLE();                                                                \
    while(intc_irqstatus_get() == 0);                                                    \
    GLOBAL_INT_RESTORE();                                                                \
} while (0)
#else
#define WFI()
#endif

#endif // LL_H_
