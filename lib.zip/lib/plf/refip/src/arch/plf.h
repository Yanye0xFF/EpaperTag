/**
 ****************************************************************************************
 *
 * @file plf.h
 *
 * @brief This file contains the definitions of the macros and functions that are
 * platform dependent.  The implementation of those is implemented in the
 * appropriate platform directory.
 *
 * Copyright (C) RivieraWaves 2009-2015
 *
 *
 ****************************************************************************************
 */
#ifndef _PLF_H_
#define _PLF_H_

/**
 ****************************************************************************************
 * @defgroup PLF
 * @ingroup DRIVERS
 *
 * @brief Platform register driver
 *
 * @{
 *
 ****************************************************************************************
 */

/*
 * FUNCTION DECLARATIONS
 ****************************************************************************************
 */

#define plf_read_rf_board_id()      0
#define plf_rf_switch()             1

/*
 * HARDWARE BASE ADDRESS DECLARATIONS
 ****************************************************************************************
 */

#define SYSTEM_REG_BASE     0x50000000
#define WATCHDOG_BASE       0x50010000
#define TIMER_BASE          0x50020000
#define I2C0_BASE           0x50030000
#define I2C1_BASE           0x50038000
#define SSP0_BASE           0x50040000
#define SSP1_BASE           0x50048000
#define UART0_BASE          0x50050000
#define UART1_BASE          0x50058000
#define UART2_BASE          0x50058000
#define GPIOAB_BASE         0x50060000
#define GPIOCD_BASE         0x50064000
#define EXTI_BASE           0x50068000
#define I2S_BASE            0x50070000
#define EFUSE_BASE          0x50080000
#define TUBE_BASE           0x500D0000
#define PWM_BASE            0x500E0000
#define APB2SPI_BASE        0x500F0000

/// @} PLF

#endif // _PLF_H_
