#ifndef _JUMP_TABLE_H
#define _JUMP_TABLE_H

#include <stdint.h>
#include "rwip_config.h"
#include "co_bt.h"  //struct bd_addr

#define SYSTEM_OPTION_SLEEP_ENABLE          CO_BIT(0)
#define SYSTEM_OPTION_EXT_WAKEUP_ENABLE     CO_BIT(1)
#define SYSTEM_OPTION_PRINT_SEL_MSK         0x0C
#define SYSTEM_OPTION_PRINT_SWO             0x00
#define SYSTEM_OPTION_PRINT_UART1           0x04
#define SYSTEM_OPTION_PRINT_UART2           0x08
#define SYSTEM_OPTION_DEEP_SLEEP_ENABLE     CO_BIT(4)
#define SYSTEM_OPTION_LP_CLK_SEL_MSK        0x60
#define SYSTEM_OPTION_LP_CLK_RC             0x00
#define SYSTEM_OPTION_LP_CLK_32K            0x20
#define SYSTEM_OPTION_LP_CLK_32768          0x40
#define SYSTEM_OPTION_FIX_BAD_CHANNEL       CO_BIT(7)
#define SYSTEM_OPTION_TL_SEL                CO_BIT(8)   //0:uart0, 1:uart1
#define SYSTEM_OPTION_VECTOR_REMAP          CO_BIT(9)
#define SYSTEM_OPTION_WAIT_SLEEP_FLAG       CO_BIT(10)

#define JUMP_TABLE_CP_CONFIG_CNT        3
struct cp_config_t
{
    uint16_t cp_dest;
    uint16_t cp_src;
    uint16_t cp_size;
};

struct jump_table_t
{
    uint32_t reserved_data;
    void *entry;
    uint8_t *rwip_heap_env_start;
    uint32_t rwip_heap_env_size;
    uint8_t *rwip_heap_db_start;
    uint32_t rwip_heap_db_size;
    uint8_t *rwip_heap_msg_start;
    uint32_t rwip_heap_msg_size;
    uint8_t *rwip_heap_no_ret_start;
    uint32_t rwip_heap_no_ret_size;
    uint32_t *rwip_prf_env_start;
    uint32_t *rwip_ke_env_start;

    uint32_t *stack_top_address;
#if RW_DEBUG_STACK_PROF
    uint32_t stack_size;
#endif
    uint32_t firmware_version;

    struct cp_config_t cp_config[JUMP_TABLE_CP_CONFIG_CNT];

    //the following configuration may be put into another structure
    //GAP configuration
    uint16_t GAP_TMR_LIM_ADV_TIMEOUT_VAL;
    uint16_t GAP_TMR_GEN_DISC_SCAN_VAL;
    uint16_t GAP_TMR_LIM_DISC_SCAN_VAL;
    uint16_t GAP_TMR_PRIV_ADDR_INT_VAL;
    uint16_t GAP_TMR_CONN_PARAM_TIMEOUT_VAL;
    uint16_t GAP_TMR_LECB_CONN_TIMEOUT_VAL;
    uint16_t GAP_TMR_LECB_DISCONN_TIMEOUT_VAL;
    uint16_t GAP_MAX_LE_MTU_VAL;
    uint8_t GAP_MAX_NAME_SIZE_VAL;
    uint8_t GAP_LE_EVT_MASK_VAL;
#if (BLE_CHNL_ASSESS)
    uint8_t LLM_UTIL_CH_ASSES_DFLT_TIMER_DUR_VAL;
    uint8_t LLM_CHNL_REASSESS_DFLT_TIMER_DUR_VAL;
    int8_t LLM_UTIL_CH_ASSES_DFLT_MIN_THR_VAL;
    int8_t LLM_UTIL_CH_ASSES_DFLT_MAX_THR_VAL;
    int8_t LLM_UTIL_CH_ASSES_DFLT_NOISE_THR_VAL;
#endif
    //the following configuration may be put into another structure
    uint32_t gpio_button_sel;
    uint32_t button_disable_multi_click;
    uint32_t radio_power_down_up;
    uint32_t diag_port;
    uint32_t system_option;
    uint16_t twext;
    uint16_t twrm;
    uint16_t twosc;
    uint16_t wakeup_to_poweron_offset;  //*us
    uint16_t lp_clk_calib_cnt;
    uint16_t onkey_map;
    uint8_t wakeup_to_poweron_rc_cnt;
    uint8_t wakeup_to_proget;  //*slot
    uint8_t system_work_type;
    uint8_t system_clk;
    uint8_t bandrate;   //bit7:4 is for uart1, bit3:0 is for uart0
    uint8_t le_features;
    uint8_t lowpower_sca;
    uint8_t conn_max;
    uint8_t prf_max;
    struct bd_addr addr;
    uint8_t checkword[4];
};

extern struct jump_table_t __jump_table;
extern uint32_t stack_space[STACK_SIZE];      //STACK_SIZE

#endif //_JUMP_TABLE_H

