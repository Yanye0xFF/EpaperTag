#include <stdio.h>
#include <stdio.h>
#include "system.h"
#include "user_mem.h"
#include "apb2spi.h"
#include "uart.h"

void HardFault_Handler_C(unsigned int* hardfault_args)
{
    printf("Crash, dump regs\r\n");
    printf("PC    = 0x%.8X\r\n",hardfault_args[6]);
    printf("LR    = 0x%.8X\r\n",hardfault_args[5]);
	    
    printf("R0    = 0x%.8X\r\n",hardfault_args[0]);
    printf("R1    = 0x%.8X\r\n",hardfault_args[1]);
    printf("R2    = 0x%.8X\r\n",hardfault_args[2]);
    printf("R3    = 0x%.8X\r\n",hardfault_args[3]);
    printf("R12   = 0x%.8X\r\n",hardfault_args[4]);
       /* printf("PSR   = 0x%.8X\r\n",hardfault_args[7]);
        printf("BFAR  = 0x%.8X\r\n",*(unsigned int*)0xE000ED38);
        printf("CFSR  = 0x%.8X\r\n",*(unsigned int*)0xE000ED28);
        printf("HFSR  = 0x%.8X\r\n",*(unsigned int*)0xE000ED2C);
        printf("DFSR  = 0x%.8X\r\n",*(unsigned int*)0xE000ED30);
        printf("AFSR  = 0x%.8X\r\n",*(unsigned int*)0xE000ED3C);
        printf("SHCSR = 0x%.8X\r\n",SCB->SHCSR);*/
    
#if USER_MEM_API_ENABLE
    show_ke_malloc();
#endif
    //while (1);
    uart_finish_transfers();
    apb2spi_write(0x4F,0xC7,APB2SPI_TYPE_OOL);
    __set_FAULTMASK(1);
    NVIC_SystemReset();
}


